package com.cozy.house.game

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.abs
import kotlin.math.sin

private fun DrawScope.tri(c: Color, ax: Float, ay: Float, bx: Float, by: Float, cx: Float, cy: Float, stroke: Float = 2.5f) {
    val p = Path().apply { moveTo(ax, ay); lineTo(bx, by); lineTo(cx, cy); close() }
    drawPath(p, c); drawPath(p, OUT, style = Stroke(stroke))
}

// ------------------------------------------------------------------ shoes

/** One foot. look.shoes: 0 starter white shoes, 1 sneakers, 2 boots, 3 sandals, 4 slippers, 5 barefoot. */
internal fun DrawScope.drawFoot(look: Look, cx: Float, cy: Float, r: Float, skin: Color) {
    when (look.shoes) {
        1 -> {
            roundRectOutlined(Offset(cx - r - 1f, cy - r * 0.6f), Size(2 * r + 2f, r * 1.5f), 6f, Color.White, 3f)
            drawLine(Color(0xFFFF6B9A), Offset(cx - r + 1f, cy + 1f), Offset(cx + r - 1f, cy + 1f), 2.5f, StrokeCap.Round)
        }
        2 -> roundRectOutlined(Offset(cx - r, cy - r * 1.4f), Size(2 * r, r * 2.2f), 5f, Color(0xFF9C6B3E), 3f)
        3 -> {
            circleOutlined(Offset(cx, cy), r, skin, 3f)
            drawLine(OUT, Offset(cx - r, cy - 1f), Offset(cx + r, cy - 1f), 2.5f, StrokeCap.Round)
            drawLine(Color(0xFFFF9EC4), Offset(cx - r + 1f, cy + 2f), Offset(cx + r - 1f, cy + 2f), 2f, StrokeCap.Round)
        }
        4 -> {
            circleOutlined(Offset(cx, cy), r + 1f, Color(0xFFFFC8DD), 3f)
            for (d in listOf(-4f to -2f, 3f to -3f, 0f to 2f)) drawCircle(Color.White.copy(alpha = 0.8f), 1.8f, Offset(cx + d.first, cy + d.second))
        }
        5 -> circleOutlined(Offset(cx, cy), r, skin, 3f)
        else -> circleOutlined(Offset(cx, cy), r, Color.White, 3f)
    }
}

// ------------------------------------------------------------------ hats (15)

/** Draws hat [id] sitting on a head whose top is at [topY] and half-width [hw]. Also used (scaled) for a pet's matching hat. */
internal fun DrawScope.drawHatShape(id: Int, x: Float, topY: Float, hw: Float) {
    when (id) {
        1 -> {   // cap
            val c = Color(0xFF4D79FF)
            drawArc(c, 180f, 180f, true, Offset(x - hw - 1f, topY - 14f), Size(2 * hw + 2f, 30f))
            drawArc(OUT, 180f, 180f, false, Offset(x - hw - 1f, topY - 14f), Size(2 * hw + 2f, 30f), style = Stroke(3f))
            roundRectOutlined(Offset(x - 2f, topY + 1f), Size(hw + 8f, 6f), 3f, c, 2.5f)
        }
        2 -> {   // beanie
            val c = Color(0xFFFF8FB1)
            drawArc(c, 180f, 180f, true, Offset(x - hw - 1f, topY - 16f), Size(2 * hw + 2f, 34f))
            drawArc(OUT, 180f, 180f, false, Offset(x - hw - 1f, topY - 16f), Size(2 * hw + 2f, 34f), style = Stroke(3f))
            roundRectOutlined(Offset(x - hw - 1f, topY + 1f), Size(2 * hw + 2f, 8f), 4f, Color(0xFFFFB3D1), 2.5f)
            circleOutlined(Offset(x, topY - 17f), 5f, Color.White, 2.5f)
        }
        3 -> {   // cowboy
            val c = Color(0xFFB07A4F)
            drawOval(OUT, Offset(x - hw - 12f, topY - 2f), Size(2 * hw + 24f, 14f))
            drawOval(c, Offset(x - hw - 10f, topY), Size(2 * hw + 20f, 10f))
            roundRectOutlined(Offset(x - 14f, topY - 16f), Size(28f, 20f), 8f, c, 3f)
            drawRect(Color(0xFF7B4B3A), Offset(x - 13f, topY - 3f), Size(26f, 4f))
        }
        4 -> {   // flower crown
            val cols = listOf(Color(0xFFFF9EC4), Color(0xFFFFE066), Color(0xFFD9B3FF), Color(0xFFFFFFFF), Color(0xFFFF9EC4))
            for (k in -2..2) {
                val fx = x + k * 9f
                val fy = topY + 3f + abs(k) * 2f
                circleOutlined(Offset(fx, fy), 5.5f, cols[k + 2], 2f)
                drawCircle(Color(0xFFFFB400), 1.8f, Offset(fx, fy))
            }
        }
        5 -> {   // headphones
            drawArc(OUT, 180f, 180f, false, Offset(x - hw - 2f, topY - 8f), Size(2 * hw + 4f, 30f), style = Stroke(7f))
            drawArc(Color(0xFF8E7CC3), 180f, 180f, false, Offset(x - hw - 2f, topY - 8f), Size(2 * hw + 4f, 30f), style = Stroke(4f))
            for (sg in listOf(-1f, 1f)) roundRectOutlined(Offset(x + sg * (hw + 2f) - 5f, topY + 8f), Size(10f, 16f), 5f, Color(0xFF8E7CC3), 3f)
        }
        6 -> {   // santa hat
            tri(Color(0xFFE63946), x - hw, topY + 4f, x + hw, topY + 4f, x + hw * 0.7f, topY - 28f, 3f)
            roundRectOutlined(Offset(x - hw - 2f, topY - 2f), Size(2 * hw + 4f, 9f), 4f, Color.White, 2.5f)
            circleOutlined(Offset(x + hw * 0.7f, topY - 28f), 5f, Color.White, 2.5f)
        }
        7 -> {   // pumpkin hat
            circleOutlined(Offset(x, topY - 5f), hw * 0.85f, Color(0xFFFF9A3C), 3f)
            drawLine(OUT.copy(alpha = 0.5f), Offset(x - 6f, topY - 14f), Offset(x - 6f, topY + 3f), 2f)
            drawLine(OUT.copy(alpha = 0.5f), Offset(x + 6f, topY - 14f), Offset(x + 6f, topY + 3f), 2f)
            roundRectOutlined(Offset(x - 3f, topY - 24f), Size(6f, 9f), 2f, Color(0xFF4CAF50), 2f)
        }
        8 -> {   // birthday cake hat
            roundRectOutlined(Offset(x - 16f, topY - 10f), Size(32f, 12f), 4f, Color(0xFFFFC8DD), 2.5f)
            roundRectOutlined(Offset(x - 11f, topY - 20f), Size(22f, 10f), 4f, Color(0xFFFFE9A8), 2.5f)
            drawRect(Color.White, Offset(x - 16f, topY - 11f), Size(32f, 3f))
            drawLine(OUT, Offset(x, topY - 20f), Offset(x, topY - 28f), 3f, StrokeCap.Round)
            drawCircle(Color(0xFFFFB400), 3f, Offset(x, topY - 31f))
        }
        9 -> {   // fox ears
            for (sg in listOf(-1f, 1f)) {
                tri(Color(0xFFFF9A3C), x + sg * 7f, topY + 2f, x + sg * 22f, topY + 3f, x + sg * 16f, topY - 22f)
                tri(Color.White, x + sg * 12f, topY + 1f, x + sg * 19f, topY + 2f, x + sg * 16f, topY - 12f, 1.5f)
            }
        }
        10 -> {  // cat ears
            for (sg in listOf(-1f, 1f)) {
                tri(Color(0xFFB0B7C3), x + sg * 6f, topY + 2f, x + sg * 22f, topY + 3f, x + sg * 17f, topY - 20f)
                tri(Color(0xFFFFB3D1), x + sg * 11f, topY + 1f, x + sg * 19f, topY + 2f, x + sg * 16f, topY - 11f, 1.5f)
            }
        }
        11 -> {  // angel halo
            drawOval(Color(0xFFFFE066), Offset(x - 15f, topY - 16f), Size(30f, 9f), style = Stroke(5f))
            drawOval(OUT, Offset(x - 17f, topY - 18f), Size(34f, 13f), style = Stroke(1.5f))
        }
        12 -> {  // devil horns
            for (sg in listOf(-1f, 1f)) tri(Color(0xFFD62839), x + sg * 6f, topY + 3f, x + sg * 16f, topY + 3f, x + sg * 17f, topY - 17f)
        }
        13 -> {  // crown
            val gold = Color(0xFFFFC93C)
            val p = Path().apply {
                moveTo(x - 17f, topY + 3f); lineTo(x - 19f, topY - 18f); lineTo(x - 8f, topY - 8f); lineTo(x, topY - 22f)
                lineTo(x + 8f, topY - 8f); lineTo(x + 19f, topY - 18f); lineTo(x + 17f, topY + 3f); close()
            }
            drawPath(p, gold); drawPath(p, OUT, style = Stroke(3f))
            for (gx in listOf(-9f, 0f, 9f)) drawCircle(Color(0xFFFF4D6D), 2.5f, Offset(x + gx, topY - 2f))
        }
        14 -> {  // golden crown (2 stars)
            val gold = Color(0xFFFFD700)
            val p = Path().apply {
                moveTo(x - 20f, topY + 4f); lineTo(x - 23f, topY - 24f); lineTo(x - 10f, topY - 11f); lineTo(x, topY - 29f)
                lineTo(x + 10f, topY - 11f); lineTo(x + 23f, topY - 24f); lineTo(x + 20f, topY + 4f); close()
            }
            drawPath(p, gold); drawPath(p, OUT, style = Stroke(3f))
            drawCircle(Color(0xFFFF3D6B), 4f, Offset(x, topY - 4f))
            for (gx in listOf(-12f, 12f)) drawCircle(Color(0xFF4DA3FF), 2.8f, Offset(x + gx, topY - 3f))
            sparkle(Offset(x + 18f, topY - 30f), 4f, Color.White)
        }
        15 -> {  // party hat
            tri(Color(0xFFB57BDB), x - 14f, topY + 4f, x + 14f, topY + 4f, x, topY - 30f, 3f)
            drawLine(Color(0xFFFFE066), Offset(x - 9f, topY - 6f), Offset(x + 9f, topY - 6f), 3f)
            drawLine(Color(0xFFFF9EC4), Offset(x - 5f, topY - 16f), Offset(x + 5f, topY - 16f), 3f)
            circleOutlined(Offset(x, topY - 31f), 4f, Color(0xFFFF6B9A), 2f)
        }
    }
}

// ------------------------------------------------------------------ glasses (8) + earrings (4)

internal fun DrawScope.drawGlasses(look: Look, paints: Paints, x: Float, ey: Float) {
    val nc = drawContext.canvas.nativeCanvas
    when (look.glasses) {
        1 -> { for (sg in listOf(-9f, 9f)) drawCircle(OUT, 7f, Offset(x + sg, ey), style = Stroke(2.5f)); drawLine(OUT, Offset(x - 2f, ey), Offset(x + 2f, ey), 2f) }
        2 -> {
            for (sg in listOf(-9f, 9f)) drawRoundRect(OUT, Offset(x + sg - 7f, ey - 6f), Size(14f, 12f), CornerRadius(3f), style = Stroke(2.5f))
            drawLine(OUT, Offset(x - 2f, ey - 1f), Offset(x + 2f, ey - 1f), 2f)
        }
        3 -> {
            for (sg in listOf(-9f, 9f)) drawRoundRect(Color(0xFF2F2A41), Offset(x + sg - 8f, ey - 6f), Size(16f, 12f), CornerRadius(5f))
            drawLine(OUT, Offset(x - 2f, ey - 2f), Offset(x + 2f, ey - 2f), 3f)
            drawLine(Color.White.copy(alpha = 0.6f), Offset(x - 14f, ey - 3f), Offset(x - 10f, ey - 5f), 2f, StrokeCap.Round)
        }
        4 -> { paints.glyph.textSize = 20f; paints.glyph.color = 0xFFFF4D8D.toInt(); nc.drawText("♥", x - 9f, ey + 7f, paints.glyph); nc.drawText("♥", x + 9f, ey + 7f, paints.glyph) }
        5 -> { paints.glyph.textSize = 20f; paints.glyph.color = 0xFFFFB400.toInt(); nc.drawText("★", x - 9f, ey + 7f, paints.glyph); nc.drawText("★", x + 9f, ey + 7f, paints.glyph) }
        6 -> {
            roundRectOutlined(Offset(x - 19f, ey - 7f), Size(38f, 14f), 7f, Color(0xFFBDE0FE), 2.5f)
            for (sg in listOf(-9f, 9f)) drawArc(OUT, 20f, 140f, false, Offset(x + sg - 4f, ey - 4f), Size(8f, 7f), style = Stroke(2f, cap = StrokeCap.Round))
            sparkle(Offset(x + 14f, ey - 12f), 3f, Color(0xFFFFE066))
        }
        7 -> {
            for (sg in listOf(-1f, 1f)) {
                drawRoundRect(OUT, Offset(x + sg * 9f - 7f, ey - 5f), Size(14f, 11f), CornerRadius(5f), style = Stroke(2.5f))
                tri(OUT, x + sg * 15f, ey - 4f, x + sg * 19f, ey - 10f, x + sg * 11f, ey - 5f, 1.5f)
            }
            drawLine(OUT, Offset(x - 2f, ey), Offset(x + 2f, ey), 2f)
        }
        8 -> {
            drawLine(OUT, Offset(x - 24f, ey), Offset(x + 24f, ey), 5f, StrokeCap.Round)
            for (sg in listOf(-9f, 9f)) { circleOutlined(Offset(x + sg, ey), 8f, Color(0xFFBDE9FF), 3f); drawCircle(Color.White, 2f, Offset(x + sg - 2f, ey - 2f)) }
        }
    }
}

internal fun DrawScope.drawEarrings(look: Look, paints: Paints, x: Float, hy: Float, hw: Float) {
    if (look.earrings == 0) return
    val nc = drawContext.canvas.nativeCanvas
    for (sg in listOf(-1f, 1f)) {
        val ex = x + sg * (hw + 1f)
        val ey = hy + 9f
        when (look.earrings) {
            1 -> circleOutlined(Offset(ex, ey), 2.8f, Color(0xFFFFE066), 1.5f)
            2 -> drawCircle(Color(0xFFFFC93C), 5f, Offset(ex, ey + 4f), style = Stroke(2.2f))
            3 -> { paints.glyph.textSize = 12f; paints.glyph.color = 0xFFFFB400.toInt(); nc.drawText("★", ex, ey + 5f, paints.glyph) }
            else -> { paints.glyph.textSize = 12f; paints.glyph.color = 0xFFFF4D8D.toInt(); nc.drawText("♥", ex, ey + 5f, paints.glyph) }
        }
    }
}

// ------------------------------------------------------------------ backpacks (5)

/** The part of the backpack you can see behind the body. */
internal fun DrawScope.drawBackpackBack(look: Look, x: Float, top: Float) {
    when (look.backpack) {
        1 -> {
            for (sg in listOf(-1f, 1f)) tri(Color(0xFFFFA97A), x + sg * 7f, top + 4f, x + sg * 17f, top + 3f, x + sg * 15f, top - 8f)
            roundRectOutlined(Offset(x - 17f, top + 3f), Size(34f, 22f), 9f, Color(0xFFFFA97A), 3f)
        }
        2 -> {
            roundRectOutlined(Offset(x - 17f, top + 3f), Size(34f, 22f), 9f, Color(0xFFD9A066), 3f)
            for (sg in listOf(-1f, 1f)) roundRectOutlined(Offset(x + sg * 16f - 4f, top - 2f), Size(8f, 14f), 4f, Color(0xFF9C6B3E), 2.5f)
        }
        3 -> {
            roundRectOutlined(Offset(x - 17f, top + 3f), Size(34f, 22f), 9f, Color.White, 3f)
            for (sg in listOf(-1f, 1f)) roundRectOutlined(Offset(x + sg * 8f - 3.5f, top - 14f), Size(7f, 20f), 4f, Color.White, 2.5f)
        }
        4 -> roundRectOutlined(Offset(x - 17f, top + 3f), Size(34f, 22f), 9f, Color(0xFFFFD86B), 3f)
        5 -> {
            roundRectOutlined(Offset(x - 17f, top + 2f), Size(34f, 24f), 7f, Color(0xFF3B5BA9), 3f)
            roundRectOutlined(Offset(x - 8f, top + 15f), Size(16f, 8f), 3f, Color(0xFF2F4B8C), 2f)
        }
    }
}

/** Shoulder straps drawn on top of the outfit. */
internal fun DrawScope.drawBackpackStraps(look: Look, x: Float, top: Float) {
    if (look.backpack == 0) return
    drawLine(OUT, Offset(x - 8f, top + 1f), Offset(x - 10f, top + 18f), 3f, StrokeCap.Round)
    drawLine(OUT, Offset(x + 8f, top + 1f), Offset(x + 10f, top + 18f), 3f, StrokeCap.Round)
}

// ------------------------------------------------------------------ things held in the hand (7)

internal fun DrawScope.drawHandheld(look: Look, paints: Paints, x: Float, y: Float, bob: Float, t: Float) {
    if (look.handheld == 0) return
    val nc = drawContext.canvas.nativeCanvas
    val hx = x + 20f
    val hy = y - 22f - bob
    circleOutlined(Offset(hx, hy), 4.5f, Color(0xFFFFE0C7), 2f)           // the hand
    paints.emoji.alpha = 255
    when (look.handheld) {
        1 -> {   // bubble wand with floating bubbles
            drawLine(OUT, Offset(hx, hy), Offset(hx + 6f, hy - 20f), 2.5f, StrokeCap.Round)
            drawCircle(OUT, 6f, Offset(hx + 7f, hy - 25f), style = Stroke(2.5f))
            for (i in 0..2) {
                val a = (t * 0.8f + i * 0.33f) % 1f
                drawCircle(Color(0xFF8EC9FF).copy(alpha = 0.8f * (1f - a)), 3f + a * 4f, Offset(hx + 12f + sin(t * 2f + i) * 6f, hy - 30f - a * 28f), style = Stroke(1.8f))
            }
        }
        2 -> {   // balloon
            drawLine(OUT.copy(alpha = 0.6f), Offset(hx, hy), Offset(hx + 4f + sin(t * 2f) * 3f, hy - 40f), 1.8f)
            balloonArt(hx + 4f + sin(t * 2f) * 3f, hy - 52f)
        }
        3 -> lollipopArt(hx + 3f, hy - 12f)
        4 -> bookArt(hx + 2f, hy - 8f)
        5 -> ballArt(hx + 3f, hy - 8f + abs(sin(t * 3f)) * -3f)
        6 -> {   // kite on a string
            val kx = hx + 10f + sin(t * 1.6f) * 6f
            val ky = hy - 44f
            drawLine(OUT.copy(alpha = 0.6f), Offset(hx, hy), Offset(kx, ky + 8f), 1.5f)
            kiteArt(kx, ky + 8f, t)
        }
        else -> waterGunArt(hx + 4f, hy - 6f)
    }
}
