package com.cozy.house.game

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// ============================================================================
// More hand-drawn art: crops, garden critters, pets, food, tools, icons. No emoji.
// ============================================================================

private fun DrawScope.ov(x: Float, y: Float, w: Float, h: Float, c: Color, st: Float = 2.5f) {
    drawOval(c, Offset(x, y), Size(w, h)); if (st > 0f) drawOval(OUT, Offset(x, y), Size(w, h), style = Stroke(st))
}
private fun DrawScope.ci(x: Float, y: Float, r: Float, c: Color, st: Float = 2.5f) {
    drawCircle(c, r, Offset(x, y)); if (st > 0f) drawCircle(OUT, r, Offset(x, y), style = Stroke(st))
}
private fun DrawScope.rr(x: Float, y: Float, w: Float, h: Float, rad: Float, c: Color, st: Float = 2.5f) =
    roundRectOutlined(Offset(x, y), Size(w, h), rad, c, st)
private fun DrawScope.ln(x1: Float, y1: Float, x2: Float, y2: Float, w: Float = 2.5f, c: Color = OUT) =
    drawLine(c, Offset(x1, y1), Offset(x2, y2), w, StrokeCap.Round)
private fun DrawScope.poly(c: Color, st: Float, vararg p: Float) {
    val path = Path().apply { moveTo(p[0], p[1]); var i = 2; while (i < p.size) { lineTo(p[i], p[i + 1]); i += 2 }; close() }
    drawPath(path, c); if (st > 0f) drawPath(path, OUT, style = Stroke(st))
}

private val GREEN = Color(0xFF5FBF6A)
private val DGREEN = Color(0xFF3E9E52)
private val CREAM = Color(0xFFFFF4DD)

// ------------------------------------------------------------------ small icons

internal fun DrawScope.heartIcon(cx: Float, cy: Float, s: Float, c: Color) {
    drawCircle(c, s * 0.3f, Offset(cx - s * 0.25f, cy - s * 0.12f)); drawCircle(c, s * 0.3f, Offset(cx + s * 0.25f, cy - s * 0.12f))
    drawPath(Path().apply { moveTo(cx - s * 0.52f, cy - s * 0.02f); lineTo(cx + s * 0.52f, cy - s * 0.02f); lineTo(cx, cy + s * 0.5f); close() }, c)
}
internal fun DrawScope.coinIcon(cx: Float, cy: Float, r: Float) {
    ci(cx, cy, r, Color(0xFFFFD34D), 2.5f); ci(cx, cy, r * 0.62f, Color(0xFFFFE98A), 1.5f); ln(cx, cy - r * 0.35f, cx, cy + r * 0.35f, 2f, Color(0xFFD99A1A))
}
internal fun DrawScope.starIcon(cx: Float, cy: Float, ro: Float, c: Color) {
    val p = Path()
    for (i in 0 until 10) { val a = -PI / 2 + i * PI / 5; val r = if (i % 2 == 0) ro else ro * 0.45f; val px = cx + (cos(a) * r).toFloat(); val py = cy + (sin(a) * r).toFloat(); if (i == 0) p.moveTo(px, py) else p.lineTo(px, py) }
    p.close(); drawPath(p, c); drawPath(p, OUT, style = Stroke(2f))
}
internal fun DrawScope.dropIcon(cx: Float, cy: Float, s: Float) {
    val p = Path().apply { moveTo(cx, cy - s); quadraticBezierTo(cx + s * 0.9f, cy + s * 0.1f, cx, cy + s * 0.8f); quadraticBezierTo(cx - s * 0.9f, cy + s * 0.1f, cx, cy - s) }
    drawPath(p, Color(0xFF6CC4FF)); drawPath(p, OUT, style = Stroke(2f))
}
internal fun DrawScope.ghostIcon(cx: Float, cy: Float, s: Float) {
    val p = Path().apply {
        moveTo(cx - 10f * s, cy + 12f * s); lineTo(cx - 10f * s, cy - 2f * s)
        quadraticBezierTo(cx - 10f * s, cy - 16f * s, cx, cy - 16f * s); quadraticBezierTo(cx + 10f * s, cy - 16f * s, cx + 10f * s, cy - 2f * s)
        lineTo(cx + 10f * s, cy + 12f * s); lineTo(cx + 5f * s, cy + 8f * s); lineTo(cx, cy + 12f * s); lineTo(cx - 5f * s, cy + 8f * s); close()
    }
    drawPath(p, Color(0xFFF4F4FF)); drawPath(p, OUT, style = Stroke(2.2f))
    drawCircle(OUT, 1.8f * s, Offset(cx - 3.5f * s, cy - 5f * s)); drawCircle(OUT, 1.8f * s, Offset(cx + 3.5f * s, cy - 5f * s))
    drawOval(OUT, Offset(cx - 2f * s, cy - 1f * s), Size(4f * s, 5f * s))
}
internal fun DrawScope.speakerIcon(cx: Float, cy: Float) {
    poly(Color(0xFF5B3A4A), 0f, cx - 6f, cy - 2f, cx - 2f, cy - 2f, cx + 2f, cy - 6f, cx + 2f, cy + 6f, cx - 2f, cy + 2f, cx - 6f, cy + 2f)
    drawArc(OUT, -50f, 100f, false, Offset(cx - 2f, cy - 5f), Size(10f, 10f), style = Stroke(1.8f, cap = StrokeCap.Round))
    drawArc(OUT, -50f, 100f, false, Offset(cx - 2f, cy - 8f), Size(16f, 16f), style = Stroke(1.8f, cap = StrokeCap.Round))
}
internal fun DrawScope.speechIcon(cx: Float, cy: Float) {
    rr(cx - 12f, cy - 9f, 24f, 16f, 8f, Color.White, 2.5f)
    poly(Color.White, 0f, cx - 5f, cy + 6f, cx - 9f, cy + 13f, cx + 1f, cy + 6f)
    for (i in -1..1) drawCircle(OUT, 1.8f, Offset(cx + i * 6f, cy - 1f))
}
internal fun DrawScope.mailIcon(cx: Float, cy: Float) {
    rr(cx - 10f, cy - 7f, 20f, 14f, 3f, Color.White, 2.5f)
    drawPath(Path().apply { moveTo(cx - 10f, cy - 6f); lineTo(cx, cy + 2f); lineTo(cx + 10f, cy - 6f) }, OUT, style = Stroke(2f))
    heartIcon(cx + 9f, cy - 9f, 8f, Color(0xFFFF4D6D))
}
internal fun DrawScope.pumpkinIcon(cx: Float, cy: Float, s: Float) {
    ov(cx - 16f * s, cy - 11f * s, 32f * s, 24f * s, Color(0xFFFF9A3C), 3f)
    ov(cx - 8f * s, cy - 11f * s, 16f * s, 24f * s, Color(0xFFFFAE55), 2f)
    rr(cx - 2.5f * s, cy - 17f * s, 5f * s, 8f * s, 2f, Color(0xFF4CAF50), 2f)
}
internal fun DrawScope.xmasTree(cx: Float, base: Float) {
    rr(cx - 6f, base - 12f, 12f, 14f, 2f, Color(0xFF8B5A3C), 2.5f)
    poly(Color(0xFF2E9E57), 3f, cx - 34f, base - 8f, cx + 34f, base - 8f, cx, base - 46f)
    poly(Color(0xFF39B56A), 3f, cx - 28f, base - 36f, cx + 28f, base - 36f, cx, base - 74f)
    poly(Color(0xFF4CC97C), 3f, cx - 20f, base - 62f, cx + 20f, base - 62f, cx, base - 96f)
    starIcon(cx, base - 100f, 9f, Color(0xFFFFD34D))
    for ((dx, dy, c) in listOf(Triple(-14f, -22f, 0xFFFF6B6B), Triple(12f, -30f, 0xFF8EC9FF), Triple(-6f, -52f, 0xFFFFD34D), Triple(10f, -70f, 0xFFFF9EC4))) ci(cx + dx, base + dy, 4f, Color(c), 1.5f)
}
internal fun DrawScope.checkeredFlag(cx: Float, cy: Float) {
    ln(cx - 8f, cy + 10f, cx - 8f, cy - 12f, 3f)
    for (i in 0 until 4) for (j in 0 until 3) drawRect(if ((i + j) % 2 == 0) OUT else Color.White, Offset(cx - 6f + i * 5f, cy - 12f + j * 5f), Size(5f, 5f))
}
internal fun DrawScope.pigeon(cx: Float, cy: Float, t: Float) {
    ov(cx - 9f, cy - 6f, 18f, 12f, Color(0xFFB0B7C3), 2f)
    ci(cx + 9f, cy - 8f, 5f, Color(0xFF8E98A8), 2f)
    poly(Color(0xFFFFA94D), 1.2f, cx + 13f, cy - 9f, cx + 18f, cy - 7f, cx + 13f, cy - 6f)
    ln(cx - 9f, cy - 2f, cx - 15f, cy - 5f + sin(t * 3f) * 1.5f, 3f, Color(0xFF8E98A8))
    ln(cx - 2f, cy + 6f, cx - 2f, cy + 11f, 1.5f); ln(cx + 3f, cy + 6f, cx + 3f, cy + 11f, 1.5f)
}
internal fun DrawScope.duckIcon(cx: Float, cy: Float, s: Float) {
    ov(cx - s * 0.4f, cy - s * 0.05f, s * 0.8f, s * 0.5f, Color(0xFFFFE066), 2.5f)
    ci(cx + s * 0.18f, cy - s * 0.18f, s * 0.22f, Color(0xFFFFE066), 2.5f)
    poly(Color(0xFFFF9A3C), 1.5f, cx + s * 0.36f, cy - s * 0.2f, cx + s * 0.55f, cy - s * 0.15f, cx + s * 0.36f, cy - s * 0.08f)
    drawCircle(OUT, 1.6f, Offset(cx + s * 0.22f, cy - s * 0.24f))
}
internal fun DrawScope.shopIcon(id: String, cx: Float, cy: Float) {
    when (id) {
        "pet" -> { ov(cx - 6f, cy - 1f, 12f, 10f, Color(0xFFFF8FB1), 2f); for (d in listOf(-8f to -4f, -3f to -9f, 3f to -9f, 8f to -4f)) ci(cx + d.first, cy + d.second, 2.8f, Color(0xFFFF8FB1), 1.5f) }
        "home" -> { rr(cx - 11f, cy - 4f, 22f, 12f, 4f, Color(0xFFFF9EC4), 2f); rr(cx - 13f, cy - 2f, 5f, 10f, 2f, Color(0xFFFF8FB1), 1.5f); rr(cx + 8f, cy - 2f, 5f, 10f, 2f, Color(0xFFFF8FB1), 1.5f); rr(cx - 9f, cy - 9f, 18f, 7f, 3f, Color(0xFFFFB3D1), 1.5f) }
        "mart" -> { rr(cx - 9f, cy - 6f, 18f, 11f, 3f, Color(0xFF8EE6A0), 2f); ln(cx - 12f, cy - 9f, cx - 9f, cy - 6f, 2f); ci(cx - 5f, cy + 8f, 2.4f, OUT, 0f); ci(cx + 5f, cy + 8f, 2.4f, OUT, 0f) }
        "style" -> { poly(Color(0xFFD9B3FF), 2f, cx - 4f, cy - 9f, cx + 4f, cy - 9f, cx + 11f, cy + 10f, cx - 11f, cy + 10f); rr(cx - 4f, cy - 10f, 8f, 8f, 2f, Color(0xFFB57BDB), 1.5f) }
        "cafe" -> { rr(cx - 8f, cy - 3f, 14f, 12f, 4f, Color.White, 2f); drawArc(OUT, -80f, 160f, false, Offset(cx + 2f, cy - 1f), Size(10f, 8f), style = Stroke(2f)); for (i in 0..1) ln(cx - 3f + i * 5f, cy - 5f, cx - 4f + i * 5f, cy - 10f, 1.6f, Color(0xFFB0B7C3)) }
        else -> { rr(cx - 12f, cy - 6f, 24f, 14f, 6f, Color(0xFF8EC9FF), 2f); ln(cx - 7f, cy + 1f, cx - 3f, cy + 1f, 2f); ln(cx - 5f, cy - 1f, cx - 5f, cy + 3f, 2f); ci(cx + 5f, cy - 1f, 1.6f, OUT, 0f); ci(cx + 9f, cy + 2f, 1.6f, OUT, 0f) }
    }
}
internal fun DrawScope.dreamIcon(i: Int, cx: Float, cy: Float) {
    when (i % 6) {
        0 -> for ((k, c) in listOf(0xFFFF8A8A, 0xFFFFD86B, 0xFF8EE6A0, 0xFF8EC9FF).withIndex()) drawArc(Color(c), 180f, 180f, false, Offset(cx - 12f + k * 2.5f, cy - 8f + k * 2.5f), Size(24f - k * 5f, 24f - k * 5f), style = Stroke(2.8f))
        1 -> foodArt(5, cx, cy, 11f)
        2 -> starIcon(cx, cy, 11f, Color(0xFFFFD34D))
        3 -> heartIcon(cx, cy, 24f, Color(0xFFFF6B9A))
        4 -> { for (p in listOf(-6f to 2f, 0f to -3f, 6f to 2f)) ci(cx + p.first, cy + p.second, 6f, Color(0xFFF1F8FF), 2f) }
        else -> { ci(cx, cy, 10f, Color(0xFFFFF4C2), 2f); ci(cx + 5f, cy - 3f, 8f, Color.White, 0f) }
    }
}

// ------------------------------------------------------------------ crops (3 growth stages)

/** crop 0 carrot, 1 tomato, 2 corn, 3 strawberry, 4 pumpkin, 5 sunflower. stage 0 sprout, 1 small, 2 full. */
internal fun DrawScope.cropArt(crop: Int, stage: Int, cx: Float, cy: Float) {
    val b = cy + 14f
    ov(cx - 11f, b - 3f, 22f, 8f, Color(0xFF6A4630), 0f)               // little soil mound
    if (stage == 0) {
        ln(cx, b, cx, b - 10f, 3f, DGREEN)
        ov(cx - 11f, b - 14f, 11f, 7f, GREEN, 2f); ov(cx, b - 16f, 11f, 7f, GREEN, 2f)
        return
    }
    if (stage == 1) {
        ln(cx, b, cx, b - 16f, 3f, DGREEN)
        for (i in 0..2) { val a = -PI / 2 + (i - 1) * 0.7; ov(cx + (cos(a) * 11f).toFloat() - 7f, b - 16f + (sin(a) * 9f).toFloat() - 4f, 14f, 8f, if (i == 1) DGREEN else GREEN, 2f) }
        if (crop == 5) ci(cx, b - 22f, 4f, Color(0xFF8B5A3C), 1.5f)
        return
    }
    when (crop) {
        0 -> { poly(Color(0xFFFF9A3C), 2.5f, cx - 8f, b - 18f, cx + 8f, b - 18f, cx, b + 1f); ln(cx - 4f, b - 13f, cx + 2f, b - 12f, 1.5f); ln(cx - 3f, b - 7f, cx + 3f, b - 6f, 1.5f)
            for (i in -1..1) ov(cx + i * 6f - 3f, b - 34f + abs(i) * 4f, 6f, 17f, GREEN, 2f) }
        1 -> { for (i in -1..1) ov(cx + i * 9f - 6f, b - 20f - abs(i) * 3f, 12f, 8f, GREEN, 2f); for (p in listOf(-8f to -10f, 8f to -12f, 0f to -20f)) { ci(cx + p.first, b + p.second, 7f, Color(0xFFE63946), 2f); star5(cx + p.first, b + p.second - 5f, 4f) } }
        2 -> { ln(cx, b, cx, b - 36f, 4f, DGREEN); poly(GREEN, 2f, cx, b - 14f, cx - 15f, b - 30f, cx - 3f, b - 20f); poly(GREEN, 2f, cx, b - 18f, cx + 15f, b - 34f, cx + 3f, b - 24f)
            ov(cx - 6f, b - 34f, 12f, 22f, Color(0xFFFFD34D), 2.5f); for (i in 0..2) ln(cx - 4f, b - 28f + i * 6f, cx + 4f, b - 28f + i * 6f, 1.3f, Color(0xFFD99A1A)); poly(GREEN, 2f, cx - 6f, b - 12f, cx + 6f, b - 12f, cx, b - 22f) }
        3 -> { for (i in -1..1) ov(cx + i * 9f - 6f, b - 14f - abs(i) * 2f, 12f, 8f, GREEN, 2f)
            for (p in listOf(-8f to -4f, 8f to -6f, 0f to -12f)) { poly(Color(0xFFE63946), 2f, cx + p.first - 6f, b + p.second - 7f, cx + p.first + 6f, b + p.second - 7f, cx + p.first, b + p.second + 6f); for (d in listOf(-2f to -2f, 2f to 0f, 0f to 3f)) drawCircle(Color(0xFFFFE9A0), 0.9f, Offset(cx + p.first + d.first, b + p.second + d.second)) } }
        4 -> { ov(cx - 17f, b - 22f, 34f, 26f, Color(0xFFFF9A3C), 3f); ov(cx - 9f, b - 22f, 18f, 26f, Color(0xFFFFAE55), 2f); rr(cx - 2.5f, b - 29f, 5f, 8f, 2f, Color(0xFF4CAF50), 2f); ov(cx + 3f, b - 30f, 11f, 6f, GREEN, 2f) }
        else -> { ln(cx, b, cx, b - 30f, 4f, DGREEN); ov(cx - 14f, b - 14f, 12f, 7f, GREEN, 2f); ov(cx + 2f, b - 18f, 12f, 7f, GREEN, 2f)
            for (i in 0 until 10) { val a = i * PI / 5; ov(cx + (cos(a) * 10f).toFloat() - 4f, b - 38f + (sin(a) * 10f).toFloat() - 4f, 8f, 8f, Color(0xFFFFD34D), 1.8f) }; ci(cx, b - 38f, 7f, Color(0xFF8B5A3C), 2f) }
    }
}
private fun DrawScope.star5(cx: Float, cy: Float, r: Float) {
    for (i in 0 until 5) { val a = -PI / 2 + i * 2 * PI / 5; ln(cx, cy, cx + (cos(a) * r).toFloat(), cy + (sin(a) * r).toFloat(), 2f, DGREEN) }
}

// ------------------------------------------------------------------ garden critters

internal fun DrawScope.critterArt(kind: Int, x: Float, y: Float, t: Float, pecking: Boolean) {
    when (kind) {
        0 -> {   // butterfly
            val f = 0.45f + 0.55f * abs(sin(t * 14f))
            val yy = y + sin(t * 3f) * 4f
            ov(x - 11f * f - 1f, yy - 9f, 11f * f, 11f, Color(0xFFFF9EC4), 1.8f); ov(x + 1f, yy - 9f, 11f * f, 11f, Color(0xFFFF9EC4), 1.8f)
            ov(x - 8f * f - 1f, yy, 8f * f, 8f, Color(0xFFFFD1E8), 1.8f); ov(x + 1f, yy, 8f * f, 8f, Color(0xFFFFD1E8), 1.8f)
            rr(x - 1.4f, yy - 7f, 2.8f, 15f, 1.4f, OUT, 0f)
            ln(x, yy - 7f, x - 3f, yy - 12f, 1.3f); ln(x, yy - 7f, x + 3f, yy - 12f, 1.3f)
        }
        1 -> {   // bee
            val bx = x + sin(t * 30f) * 1.5f
            val by = y + cos(t * 22f) * 2f
            ov(bx - 6f, by - 10f, 7f, 6f, Color(0xFFEAF6FF), 1.2f); ov(bx - 0f, by - 10f, 7f, 6f, Color(0xFFEAF6FF), 1.2f)
            ov(bx - 7f, by - 4f, 14f, 9f, Color(0xFFFFD34D), 2f)
            for (i in 0..1) rr(bx - 2f + i * 5f - 4f, by - 3f, 2.6f, 7f, 1f, OUT, 0f)
            ci(bx + 7f, by, 3f, Color(0xFFFFD34D), 1.6f)
        }
        else -> {   // bird
            val by = y - (if (pecking) abs(sin(t * 8f)) * 3f else 0f)
            drawOval(Color.Black.copy(alpha = 0.12f), Offset(x - 8f, y + 2f), Size(16f, 6f))
            ln(x - 2f, by + 4f, x - 2f, by + 9f, 1.5f); ln(x + 2f, by + 4f, x + 2f, by + 9f, 1.5f)
            ov(x - 8f, by - 8f, 16f, 13f, Color(0xFF8EC9FF), 2f)
            ci(x + 7f, by - 7f, 5f, Color(0xFF8EC9FF), 2f)
            poly(Color(0xFFFFA94D), 1.2f, x + 11f, by - 8f, x + 16f, by - 6f, x + 11f, by - 5f)
            drawCircle(OUT, 1.2f, Offset(x + 8f, by - 8f))
            ov(x - 6f, by - 5f, 9f, 6f, Color(0xFF6BB3FF), 1.5f)
            poly(Color(0xFF6BB3FF), 1.5f, x - 8f, by - 2f, x - 15f, by - 6f, x - 13f, by + 1f)
        }
    }
}

// ------------------------------------------------------------------ pets (0 cat 1 dog 2 bunny 3 hamster 4 turtle 5 fox 6 panda)

internal fun DrawScope.petArt(type: Int, x: Float, y: Float, sleeping: Boolean, moving: Boolean, t: Float) {
    val by = y - 12f                                   // body centre
    val wag = if (sleeping) 0f else sin(t * (if (moving) 14f else 4f)) * 4f
    fun eyes(cy: Float, spread: Float = 4.2f) {
        if (sleeping) { ln(x + 4f - spread, cy, x + 4f - spread + 4f, cy, 1.8f); ln(x + 4f + spread - 4f, cy, x + 4f + spread, cy, 1.8f) }
        else { drawCircle(OUT, 1.9f, Offset(x + 4f - spread, cy)); drawCircle(OUT, 1.9f, Offset(x + 4f + spread, cy)) }
    }
    when (type) {
        0 -> {   // cat
            drawPath(Path().apply { moveTo(x - 10f, by + 4f); quadraticBezierTo(x - 20f, by - 6f + wag, x - 14f, by - 16f + wag) }, OUT, style = Stroke(6f, cap = StrokeCap.Round))
            drawPath(Path().apply { moveTo(x - 10f, by + 4f); quadraticBezierTo(x - 20f, by - 6f + wag, x - 14f, by - 16f + wag) }, Color(0xFFFFA45C), style = Stroke(3.5f, cap = StrokeCap.Round))
            ov(x - 11f, by - 4f, 22f, 16f, Color(0xFFFFA45C), 2.5f)
            poly(Color(0xFFFFA45C), 2.2f, x - 1f, by - 8f, x + 1f, by - 20f, x + 7f, by - 11f); poly(Color(0xFFFFA45C), 2.2f, x + 9f, by - 11f, x + 15f, by - 20f, x + 17f, by - 8f)
            ci(x + 8f, by - 5f, 9f, Color(0xFFFFA45C), 2.5f)
            eyes(by - 6f); drawCircle(Color(0xFFFF7FA0), 1.6f, Offset(x + 8f, by - 2f))
            ln(x + 11f, by - 2f, x + 18f, by - 4f, 1.2f); ln(x + 11f, by - 1f, x + 18f, by, 1.2f)
            for (i in 0..1) ln(x - 4f + i * 5f, by - 3f, x - 4f + i * 5f, by + 2f, 1.8f, Color(0xFFD9803A))
        }
        1 -> {   // dog
            ov(x - 12f, by - 3f, 24f, 16f, Color(0xFFC98D58), 2.5f)
            ln(x - 11f, by + 1f, x - 16f, by - 8f + wag, 4f, Color(0xFFC98D58))
            ci(x + 8f, by - 5f, 9.5f, Color(0xFFC98D58), 2.5f)
            ov(x + 10f, by - 5f, 11f, 8f, Color(0xFFF0D0A8), 2f)
            ov(x - 1f, by - 12f, 6f, 11f, Color(0xFF8B5A3C), 2f); ov(x + 12f, by - 12f, 6f, 11f, Color(0xFF8B5A3C), 2f)
            eyes(by - 7f); ci(x + 19f, by - 3f, 2.2f, OUT, 0f)
            if (!sleeping) drawOval(Color(0xFFFF8FA3), Offset(x + 13f, by + 2f), Size(4f, 5f))
        }
        2 -> {   // bunny
            ov(x - 10f, by - 3f, 22f, 15f, Color.White, 2.5f); ci(x - 11f, by + 6f, 4.5f, Color(0xFFFFEAF3), 1.8f)
            ov(x + 1f, by - 26f, 6f, 18f, Color.White, 2f); ov(x + 2.2f, by - 23f, 3.4f, 13f, Color(0xFFFFB3D1), 0f)
            ov(x + 9f, by - 26f, 6f, 18f, Color.White, 2f); ov(x + 10.2f, by - 23f, 3.4f, 13f, Color(0xFFFFB3D1), 0f)
            ci(x + 8f, by - 5f, 9f, Color.White, 2.5f)
            eyes(by - 6f); drawCircle(Color(0xFFFF7FA0), 1.6f, Offset(x + 8f, by - 2f))
            drawCircle(Color(0xFFFFB3D1).copy(alpha = 0.7f), 2.5f, Offset(x + 1f, by - 2f)); drawCircle(Color(0xFFFFB3D1).copy(alpha = 0.7f), 2.5f, Offset(x + 15f, by - 2f))
        }
        3 -> {   // hamster
            ov(x - 11f, by - 5f, 22f, 18f, Color(0xFFE9C79B), 2.5f); ov(x - 6f, by + 1f, 12f, 11f, Color(0xFFFFF4E3), 0f)
            ci(x - 2f, by - 7f, 3.5f, Color(0xFFE9C79B), 2f); ci(x + 10f, by - 7f, 3.5f, Color(0xFFE9C79B), 2f)
            ci(x + 4f, by - 3f, 10f, Color(0xFFE9C79B), 2.5f)
            eyes(by - 5f); drawCircle(Color(0xFFFF7FA0), 1.6f, Offset(x + 4f, by - 1f))
            drawCircle(Color(0xFFFFB3D1).copy(alpha = 0.7f), 3f, Offset(x - 3f, by)); drawCircle(Color(0xFFFFB3D1).copy(alpha = 0.7f), 3f, Offset(x + 11f, by))
        }
        4 -> {   // turtle
            for (fx in listOf(-8f, 8f)) ov(x + fx - 3f, by + 6f, 6f, 5f, Color(0xFF9ADFA0), 1.8f)
            ci(x + 12f, by - 1f, 5f, Color(0xFF9ADFA0), 2f); drawCircle(OUT, 1.3f, Offset(x + 14f, by - 2f))
            drawArc(Color(0xFF4FAE6A), 180f, 180f, true, Offset(x - 13f, by - 12f), Size(26f, 24f)); drawArc(OUT, 180f, 180f, false, Offset(x - 13f, by - 12f), Size(26f, 24f), style = Stroke(2.5f))
            ln(x - 7f, by - 2f, x - 4f, by - 8f, 1.5f); ln(x + 7f, by - 2f, x + 4f, by - 8f, 1.5f); ln(x, by - 11f, x, by, 1.5f)
        }
        5 -> {   // fox
            drawPath(Path().apply { moveTo(x - 10f, by + 4f); quadraticBezierTo(x - 22f, by - 4f + wag, x - 15f, by - 14f + wag) }, OUT, style = Stroke(9f, cap = StrokeCap.Round))
            drawPath(Path().apply { moveTo(x - 10f, by + 4f); quadraticBezierTo(x - 22f, by - 4f + wag, x - 15f, by - 14f + wag) }, Color(0xFFFF8A3D), style = Stroke(6f, cap = StrokeCap.Round))
            ov(x - 11f, by - 3f, 22f, 15f, Color(0xFFFF8A3D), 2.5f)
            poly(Color(0xFFFF8A3D), 2.2f, x - 1f, by - 8f, x + 1f, by - 21f, x + 7f, by - 11f); poly(Color(0xFFFF8A3D), 2.2f, x + 9f, by - 11f, x + 15f, by - 21f, x + 17f, by - 8f)
            ci(x + 8f, by - 5f, 9f, Color(0xFFFF8A3D), 2.5f)
            poly(Color.White, 0f, x + 8f, by + 4f, x - 1f, by - 2f, x + 17f, by - 2f)
            eyes(by - 6f); ci(x + 8f, by + 1f, 1.8f, OUT, 0f)
        }
        else -> {   // panda
            ov(x - 11f, by - 3f, 22f, 16f, Color.White, 2.5f); ov(x - 10f, by + 1f, 6f, 7f, OUT, 0f); ov(x + 4f, by + 1f, 6f, 7f, OUT, 0f)
            ci(x - 2f, by - 12f, 4.5f, OUT, 0f); ci(x + 18f, by - 12f, 4.5f, OUT, 0f)
            ci(x + 8f, by - 5f, 10f, Color.White, 2.5f)
            ov(x + 0f, by - 9f, 6f, 8f, OUT, 0f); ov(x + 10f, by - 9f, 6f, 8f, OUT, 0f)
            if (!sleeping) { drawCircle(Color.White, 1.4f, Offset(x + 3f, by - 6f)); drawCircle(Color.White, 1.4f, Offset(x + 13f, by - 6f)) } else { ln(x + 1f, by - 6f, x + 5f, by - 6f, 1.6f, Color.White); ln(x + 11f, by - 6f, x + 15f, by - 6f, 1.6f, Color.White) }
            ci(x + 8f, by - 1f, 2f, OUT, 0f)
        }
    }
}

// ------------------------------------------------------------------ food (the 12 recipes)

internal fun DrawScope.foodArt(idx: Int, cx: Float, cy: Float, s: Float) {
    val k = s / 16f
    fun bowl(soup: Color) {
        drawArc(Color(0xFFFFFFFF), 0f, 180f, true, Offset(cx - 15f * k, cy - 8f * k), Size(30f * k, 24f * k)); drawArc(OUT, 0f, 180f, false, Offset(cx - 15f * k, cy - 8f * k), Size(30f * k, 24f * k), style = Stroke(2.5f))
        ov(cx - 14f * k, cy - 8f * k, 28f * k, 8f * k, soup, 2f)
    }
    when (idx) {
        0 -> { bowl(Color(0xFFE63946)); for (i in -1..1) ln(cx + i * 6f * k, cy - 11f * k, cx + i * 6f * k + 2f, cy - 18f * k, 1.6f, Color(0xFFB0B7C3)) }
        1 -> { bowl(Color(0xFF6BCB77)); ci(cx - 5f * k, cy - 8f * k, 3.5f * k, Color(0xFFE63946), 1.5f); ci(cx + 5f * k, cy - 9f * k, 3f * k, Color(0xFFFF9A3C), 1.5f); ci(cx, cy - 11f * k, 3f * k, Color(0xFF9ADF6A), 1.5f) }
        2 -> { for (i in 0..2) ov(cx - 14f * k, cy + (4f - i * 6f) * k, 28f * k, 9f * k, Color(0xFFE9B96E), 2.2f); rr(cx - 4f * k, cy - 14f * k, 8f * k, 5f * k, 1.5f, Color(0xFFFFE98A), 1.5f); drawArc(Color(0xFF8B4A2A), 20f, 140f, false, Offset(cx - 10f * k, cy - 14f * k), Size(20f * k, 10f * k), style = Stroke(3f * k, cap = StrokeCap.Round)) }
        3 -> { poly(Color(0xFFFFB3D1), 2.5f, cx - 9f * k, cy - 12f * k, cx + 9f * k, cy - 12f * k, cx + 7f * k, cy + 13f * k, cx - 7f * k, cy + 13f * k); ln(cx + 3f * k, cy - 11f * k, cx + 8f * k, cy - 20f * k, 2.5f, Color(0xFFE63946)); ci(cx - 9f * k, cy - 12f * k, 4f * k, Color(0xFFE63946), 1.5f) }
        4 -> { poly(Color(0xFFFFD86B), 2.5f, cx - 14f * k, cy - 10f * k, cx + 14f * k, cy - 10f * k, cx, cy + 14f * k); drawArc(Color(0xFFE9B96E), 200f, 140f, false, Offset(cx - 16f * k, cy - 18f * k), Size(32f * k, 16f * k), style = Stroke(4f * k, cap = StrokeCap.Round)); for (p in listOf(-5f to -4f, 5f to -4f, 0f to 4f)) ci(cx + p.first * k, cy + p.second * k, 3f * k, Color(0xFFD64545), 1.5f) }
        5 -> { rr(cx - 14f * k, cy - 1f * k, 28f * k, 14f * k, 4f, Color(0xFFFFC8DD), 2.5f); rr(cx - 10f * k, cy - 10f * k, 20f * k, 11f * k, 4f, Color(0xFFFFE9F2), 2.5f); ci(cx, cy - 13f * k, 3.2f * k, Color(0xFFE63946), 1.5f); ln(cx, cy - 16f * k, cx, cy - 21f * k, 2f, Color(0xFF8EC9FF)) }
        6 -> { drawArc(Color(0xFFE9B96E), 180f, 180f, true, Offset(cx - 14f * k, cy - 14f * k), Size(28f * k, 22f * k)); drawArc(OUT, 180f, 180f, false, Offset(cx - 14f * k, cy - 14f * k), Size(28f * k, 22f * k), style = Stroke(2.5f)); rr(cx - 14f * k, cy - 4f * k, 28f * k, 4f * k, 2f, Color(0xFF6BCB77), 1.5f); rr(cx - 13f * k, cy, 26f * k, 6f * k, 3f, Color(0xFF8B4A2A), 2f); rr(cx - 14f * k, cy + 6f * k, 28f * k, 6f * k, 4f, Color(0xFFE9B96E), 2.5f) }
        7 -> { poly(Color(0xFFFF9A3C), 2.5f, cx - 13f * k, cy - 8f * k, cx + 13f * k, cy - 8f * k, cx, cy + 14f * k); drawArc(Color(0xFFE9B96E), 200f, 140f, false, Offset(cx - 15f * k, cy - 16f * k), Size(30f * k, 16f * k), style = Stroke(4f * k, cap = StrokeCap.Round)); ci(cx, cy - 4f * k, 3.5f * k, Color.White, 1.5f) }
        8 -> { poly(Color(0xFFFFB3D1), 2.2f, cx - 9f * k, cy, cx + 9f * k, cy, cx + 6f * k, cy + 14f * k, cx - 6f * k, cy + 14f * k); ci(cx, cy - 3f * k, 9f * k, Color(0xFFFFE9F2), 2.5f); ci(cx, cy - 12f * k, 4f * k, Color(0xFFFFE9F2), 2f); ci(cx, cy - 17f * k, 2.5f * k, Color(0xFFE63946), 1.5f) }
        9 -> { bowl(Color(0xFFFFE9A0)); for (p in listOf(-6f to -7f, 0f to -10f, 6f to -7f)) ci(cx + p.first * k, cy + p.second * k, 2.6f * k, Color(0xFFFFC93C), 1.2f) }
        10 -> { bowl(Color(0xFFFFA94D)); for (p in listOf(-6f to -8f, 0f to -10f, 6f to -8f)) ov(cx + p.first * k - 3f, cy + p.second * k - 2f, 6f * k, 4f * k, Color(0xFFFFC27A), 1.2f) }
        else -> { poly(Color(0xFFE9B96E), 2.5f, cx - 8f * k, cy, cx + 8f * k, cy, cx, cy + 16f * k); ci(cx - 4f * k, cy - 3f * k, 6.5f * k, Color(0xFFFFB3D1), 2.5f); ci(cx + 4f * k, cy - 5f * k, 6.5f * k, Color(0xFFFFF1A8), 2.5f) }
    }
}
internal fun DrawScope.dirtyPlate(cx: Float, cy: Float) {
    ov(cx - 11f, cy - 3f, 22f, 8f, Color.White, 2.5f); ov(cx - 6f, cy - 2f, 12f, 5f, Color(0xFFEAF0F6), 0f)
    drawCircle(Color(0xFFC98D58), 2.2f, Offset(cx + 2f, cy)); drawCircle(Color(0xFFE63946), 1.6f, Offset(cx - 3f, cy + 1f))
}
internal fun DrawScope.fridgeItem(i: Int, cx: Float, cy: Float) {
    when (i % 3) {
        0 -> { rr(cx - 5f, cy - 10f, 10f, 14f, 2f, Color.White, 2f); poly(Color(0xFF8EC9FF), 1.5f, cx - 5f, cy - 10f, cx + 5f, cy - 10f, cx + 2f, cy - 15f, cx - 2f, cy - 15f) }
        1 -> { ov(cx - 5f, cy - 8f, 10f, 13f, Color(0xFFFFF4DD), 2f) }
        else -> poly(Color(0xFFFFD34D), 2f, cx - 9f, cy + 3f, cx + 9f, cy + 3f, cx + 9f, cy - 6f, cx - 9f, cy - 2f)
    }
}
internal fun DrawScope.crazyFace(cx: Float, cy: Float) {
    ci(cx, cy, 13f, Color(0xFFFFD34D), 2.5f)
    ci(cx - 5f, cy - 3f, 3.5f, Color.White, 1.8f); ci(cx + 5f, cy - 4f, 2.6f, Color.White, 1.8f)
    drawCircle(OUT, 1.4f, Offset(cx - 4f, cy - 2f)); drawCircle(OUT, 1.2f, Offset(cx + 5f, cy - 3f))
    drawPath(Path().apply { moveTo(cx - 6f, cy + 5f); quadraticBezierTo(cx, cy + 10f, cx + 6f, cy + 4f) }, OUT, style = Stroke(2f, cap = StrokeCap.Round))
    drawOval(Color(0xFFFF8FA3), Offset(cx + 1f, cy + 6f), Size(5f, 6f))
}

// ------------------------------------------------------------------ tools in the hand

internal fun DrawScope.toolIcon(tool: String, cx: Float, cy: Float) {
    when (tool) {
        "🚿" -> { rr(cx - 9f, cy - 6f, 14f, 12f, 4f, Color(0xFF6BB3FF), 2f); drawPath(Path().apply { moveTo(cx + 5f, cy - 2f); lineTo(cx + 13f, cy - 9f) }, OUT, style = Stroke(3f, cap = StrokeCap.Round)); drawArc(OUT, 180f, 180f, false, Offset(cx - 7f, cy - 12f), Size(10f, 10f), style = Stroke(2f)); dropIcon(cx + 15f, cy - 3f, 3.5f) }
        "🌱" -> { ln(cx, cy + 6f, cx, cy - 3f, 2.5f, DGREEN); ov(cx - 9f, cy - 8f, 9f, 6f, GREEN, 1.8f); ov(cx, cy - 10f, 9f, 6f, GREEN, 1.8f); ov(cx - 6f, cy + 5f, 12f, 4f, Color(0xFF6A4630), 0f) }
        "🧺" -> { poly(Color(0xFFD9A066), 2.2f, cx - 10f, cy - 2f, cx + 10f, cy - 2f, cx + 7f, cy + 9f, cx - 7f, cy + 9f); drawArc(OUT, 180f, 180f, false, Offset(cx - 9f, cy - 12f), Size(18f, 20f), style = Stroke(2.2f)) }
        "🍳" -> { ci(cx - 3f, cy, 8f, Color(0xFF7B7F92), 2.2f); ci(cx - 3f, cy, 5f, Color(0xFF5B5F72), 0f); ln(cx + 5f, cy, cx + 15f, cy - 3f, 3.2f, Color(0xFF5B3A4A)) }
        "🍽️" -> { ov(cx - 11f, cy - 2f, 22f, 9f, Color.White, 2.2f); ov(cx - 6f, cy - 1f, 12f, 5f, Color(0xFFEAF0F6), 0f) }
        "🗑️" -> { poly(Color(0xFFB0B7C3), 2.2f, cx - 7f, cy - 4f, cx + 7f, cy - 4f, cx + 5f, cy + 9f, cx - 5f, cy + 9f); rr(cx - 9f, cy - 8f, 18f, 4f, 2f, Color(0xFF8E98A8), 2f); for (i in -1..1) ln(cx + i * 3f, cy - 1f, cx + i * 2.4f, cy + 6f, 1.3f) }
        "🧽" -> { rr(cx - 9f, cy - 5f, 18f, 11f, 3f, Color(0xFFFFE066), 2.2f); for (p in listOf(-5f to -1f, 1f to 2f, 5f to -2f)) drawCircle(Color(0xFFD99A1A), 1.4f, Offset(cx + p.first, cy + p.second)) }
        "🍴" -> { ln(cx - 4f, cy + 8f, cx - 4f, cy - 8f, 2.5f, Color(0xFFB0B7C3)); for (i in -1..1) ln(cx - 4f + i * 2.4f, cy - 8f, cx - 4f + i * 2.4f, cy - 2f, 1.6f, Color(0xFFB0B7C3)); ln(cx + 5f, cy + 8f, cx + 5f, cy - 8f, 2.5f, Color(0xFFB0B7C3)); ov(cx + 3f, cy - 9f, 4f, 7f, Color(0xFFB0B7C3), 1.5f) }
        "⛏️" -> { ln(cx, cy + 9f, cx, cy - 6f, 3f, Color(0xFFB07A4F)); drawArc(OUT, 190f, 160f, false, Offset(cx - 11f, cy - 14f), Size(22f, 16f), style = Stroke(4f, cap = StrokeCap.Round)); drawArc(Color(0xFFB0B7C3), 190f, 160f, false, Offset(cx - 11f, cy - 14f), Size(22f, 16f), style = Stroke(2f, cap = StrokeCap.Round)) }
        "🍰" -> foodArt(5, cx, cy, 11f)
        "🍕" -> foodArt(4, cx, cy, 11f)
        "🧋" -> foodArt(3, cx, cy, 11f)
        "🍨" -> foodArt(11, cx, cy, 11f)
        else -> ci(cx, cy, 5f, Color(0xFFFFD34D), 2f)
    }
}

// ------------------------------------------------------------------ things held in the hand (look.handheld)

internal fun DrawScope.balloonArt(cx: Float, cy: Float) {
    ov(cx - 9f, cy - 12f, 18f, 24f, Color(0xFFFF6B8A), 2.5f); ov(cx - 5f, cy - 8f, 4f, 7f, Color.White.copy(alpha = 0.6f), 0f)
    poly(Color(0xFFFF6B8A), 1.5f, cx - 2.5f, cy + 12f, cx + 2.5f, cy + 12f, cx, cy + 16f)
}
internal fun DrawScope.lollipopArt(cx: Float, cy: Float) {
    ln(cx, cy + 14f, cx, cy + 2f, 2.5f, Color.White); ci(cx, cy - 4f, 8f, Color(0xFFFF8FB1), 2.5f)
    drawArc(Color.White, 0f, 270f, false, Offset(cx - 4f, cy - 8f), Size(8f, 8f), style = Stroke(1.8f))
}
internal fun DrawScope.bookArt(cx: Float, cy: Float) {
    rr(cx - 8f, cy - 7f, 16f, 14f, 2f, Color(0xFF8EC9FF), 2.2f); ln(cx - 5f, cy - 7f, cx - 5f, cy + 7f, 2f); ln(cx - 2f, cy - 3f, cx + 5f, cy - 3f, 1.4f, Color.White); ln(cx - 2f, cy + 1f, cx + 5f, cy + 1f, 1.4f, Color.White)
}
internal fun DrawScope.ballArt(cx: Float, cy: Float) {
    ci(cx, cy, 8f, Color.White, 2.5f); poly(OUT, 0f, cx, cy - 3f, cx + 3f, cy - 1f, cx + 2f, cy + 3f, cx - 2f, cy + 3f, cx - 3f, cy - 1f)
    for (a in 0 until 5) { val r = -PI / 2 + a * 2 * PI / 5; ln(cx + (cos(r) * 3f).toFloat(), cy + (sin(r) * 3f).toFloat(), cx + (cos(r) * 8f).toFloat(), cy + (sin(r) * 8f).toFloat(), 1.4f) }
}
internal fun DrawScope.kiteArt(cx: Float, cy: Float, t: Float) {
    poly(Color(0xFFFF9EC4), 2.2f, cx, cy - 12f, cx + 10f, cy, cx, cy + 12f, cx - 10f, cy)
    ln(cx, cy - 12f, cx, cy + 12f, 1.4f); ln(cx - 10f, cy, cx + 10f, cy, 1.4f)
    for (i in 1..3) { ci(cx + sin(t * 4f + i) * 4f, cy + 12f + i * 7f, 2.4f, listOf(Color(0xFFFFD34D), Color(0xFF8EC9FF), Color(0xFFFF9EC4))[i - 1], 1.2f) }
}
internal fun DrawScope.waterGunArt(cx: Float, cy: Float) {
    rr(cx - 9f, cy - 6f, 18f, 8f, 3f, Color(0xFF6BB3FF), 2.2f); rr(cx - 4f, cy + 1f, 6f, 9f, 2f, Color(0xFFFF6B8A), 2f); rr(cx - 3f, cy - 10f, 9f, 5f, 2f, Color(0xFFBDE9FF), 1.8f); ln(cx + 9f, cy - 3f, cx + 14f, cy - 3f, 3f)
}

// ------------------------------------------------------------------ emote faces (the bubble above the head)

internal fun DrawScope.emoteFace(e: Emote, cx: Float, cy: Float, r: Float, t: Float) {
    val face = when (e) { Emote.ANGRY -> Color(0xFFFF8A7A); Emote.SICK -> Color(0xFFB7E4A0); else -> Color(0xFFFFD86B) }
    if (e == Emote.WAVE) {   // a waving hand
        ci(cx, cy + 3f, r * 0.55f, Color(0xFFFFE0C7), 2.2f)
        for (i in -2..2) { rr(cx + i * r * 0.22f - 2f, cy - r * 0.8f + abs(i) * 2f, 4f, r * 0.8f, 2f, Color(0xFFFFE0C7), 1.6f) }
        return
    }
    if (e == Emote.DANCE) {  // music notes
        ci(cx - 4f, cy + 6f, 3.5f, OUT, 0f); ln(cx - 1f, cy + 5f, cx - 1f, cy - 7f, 2f); ci(cx + 6f, cy + 3f, 3.5f, OUT, 0f); ln(cx + 9f, cy + 2f, cx + 9f, cy - 9f, 2f); ln(cx - 1f, cy - 7f, cx + 9f, cy - 9f, 3f)
        return
    }
    ci(cx, cy, r, face, 2.2f)
    val ey = cy - r * 0.15f
    val dx = r * 0.36f
    when (e) {
        Emote.LOVE -> { heartIcon(cx - dx, ey, 8f, Color(0xFFFF4D6D)); heartIcon(cx + dx, ey, 8f, Color(0xFFFF4D6D)) }
        Emote.LAUGH -> { drawArc(OUT, 200f, 140f, false, Offset(cx - dx - 3f, ey - 2f), Size(6f, 5f), style = Stroke(1.8f)); drawArc(OUT, 200f, 140f, false, Offset(cx + dx - 3f, ey - 2f), Size(6f, 5f), style = Stroke(1.8f)) }
        Emote.SLEEPY -> { ln(cx - dx - 2f, ey, cx - dx + 2f, ey, 1.8f); ln(cx + dx - 2f, ey, cx + dx + 2f, ey, 1.8f) }
        Emote.COOL -> rr(cx - r * 0.8f, ey - 3f, r * 1.6f, 6f, 3f, Color(0xFF2F2A41), 1.5f)
        Emote.SURPRISE -> { ci(cx - dx, ey, 3f, Color.White, 1.5f); ci(cx + dx, ey, 3f, Color.White, 1.5f); drawCircle(OUT, 1.2f, Offset(cx - dx, ey)); drawCircle(OUT, 1.2f, Offset(cx + dx, ey)) }
        Emote.SICK -> { ln(cx - dx - 2f, ey - 2f, cx - dx + 2f, ey + 2f, 1.6f); ln(cx - dx - 2f, ey + 2f, cx - dx + 2f, ey - 2f, 1.6f); ln(cx + dx - 2f, ey - 2f, cx + dx + 2f, ey + 2f, 1.6f); ln(cx + dx - 2f, ey + 2f, cx + dx + 2f, ey - 2f, 1.6f) }
        Emote.ANGRY -> { drawCircle(OUT, 1.8f, Offset(cx - dx, ey + 1f)); drawCircle(OUT, 1.8f, Offset(cx + dx, ey + 1f)); ln(cx - dx - 3f, ey - 4f, cx - dx + 3f, ey - 2f, 1.8f); ln(cx + dx + 3f, ey - 4f, cx + dx - 3f, ey - 2f, 1.8f) }
        else -> { drawCircle(OUT, 1.8f, Offset(cx - dx, ey)); drawCircle(OUT, 1.8f, Offset(cx + dx, ey)) }
    }
    val my = cy + r * 0.42f
    when (e) {
        Emote.CRY -> { drawArc(OUT, 200f, 140f, false, Offset(cx - 4f, my - 2f), Size(8f, 5f), style = Stroke(1.8f)); dropIcon(cx - dx, cy + r * 0.45f, 3f) }
        Emote.ANGRY, Emote.SICK -> drawArc(OUT, 200f, 140f, false, Offset(cx - 4f, my - 1f), Size(8f, 5f), style = Stroke(1.8f))
        Emote.SURPRISE -> ci(cx, my + 1f, 2.4f, OUT, 0f)
        Emote.LAUGH -> drawArc(OUT, 0f, 180f, true, Offset(cx - 5f, my - 3f), Size(10f, 8f))
        Emote.HUNGRY -> { drawOval(OUT, Offset(cx - 3f, my - 2f), Size(6f, 6f)); dropIcon(cx + 5f, my + 5f, 3f) }
        Emote.SLEEPY -> ln(cx - 3f, my, cx + 3f, my, 1.8f)
        else -> drawArc(OUT, 20f, 140f, false, Offset(cx - 5f, my - 4f), Size(10f, 8f), style = Stroke(1.8f, cap = StrokeCap.Round))
    }
}
