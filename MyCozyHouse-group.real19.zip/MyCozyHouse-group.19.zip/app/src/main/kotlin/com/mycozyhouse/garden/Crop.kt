package com.mycozyhouse.garden

enum class CropType(
    val seedName: String,
    val growTimeMs: Long = 60_000,
    val stages: Int = 3,
    val coinYield: Int = 5,
    val starOnFirstHarvest: Boolean = false
) {
    CARROT("Carrot"),
    TOMATO("Tomato"),
    CORN("Corn"),
    STRAWBERRY("Strawberry"),
    PUMPKIN("Pumpkin"),
    SUNFLOWER("Sunflower", starOnFirstHarvest = true);

    val stageDurationMs: Long get() = growTimeMs / stages
}

enum class CropStage { EMPTY, SEEDED, SPROUT, SMALL, FULLY_GROWN }

data class CropState(
    val cropType: CropType? = null,
    val stage: CropStage = CropStage.EMPTY,
    val plantedAt: Long = 0L,
    val lastWateredAt: Long = 0L,
    val isWatered: Boolean = false,
    val harvested: Boolean = false
) {
    fun updateCurrentTime(nowMs: Long): CropState {
        if (cropType == null || stage == CropStage.EMPTY || harvested) return this
        if (!isWatered) return this
        val elapsedMs = nowMs - plantedAt
        val newStage = when {
            elapsedMs < cropType.stageDurationMs -> CropStage.SPROUT
            elapsedMs < cropType.stageDurationMs * 2 -> CropStage.SMALL
            else -> CropStage.FULLY_GROWN
        }
        return copy(stage = newStage)
    }

    fun water(nowMs: Long): CropState =
        copy(isWatered = true, lastWateredAt = nowMs)

    fun plant(type: CropType, nowMs: Long): CropState =
        copy(
            cropType = type,
            stage = CropStage.SPROUT,
            plantedAt = nowMs,
            isWatered = true,
            harvested = false
        )

    fun harvest(): Pair<Int, Boolean?> {
        val coins = if (stage == CropStage.FULLY_GROWN && !harvested) cropType!!.coinYield else 0
        val star = if (stage == CropStage.FULLY_GROWN && !harvested
            && cropType!!.starOnFirstHarvest) true else null
        return Pair(coins, star)
    }

    fun isReady(): Boolean = stage == CropStage.FULLY_GROWN && !harvested
}
