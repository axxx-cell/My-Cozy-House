package com.mycozyhouse.garden

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.mycozyhouse.util.GameTime

@Composable
fun GardenPlot(
    index: Int,
    manager: GardenManager,
    onHarvest: (Int, Int, Boolean?) -> Unit,
    onWater: (Int) -> Unit,
    onPlant: (Int, CropType) -> Unit,
    selectedSeed: CropType?
) {
    val state by manager.plotStates[index].collectAsState()
    val nowMs = GameTime.nowMs()
    val liveState = state.updateCurrentTime(nowMs)

    Box(
        modifier = Modifier
            .size(64.dp)
            .clickable {
                when {
                    liveState.isReady() -> {
                        val (coins, star) = liveState.harvest()
                        manager.harvestPlot(index)
                        onHarvest(index, coins, star)
                    }
                    liveState.stage != CropStage.EMPTY && !liveState.isWatered -> {
                        manager.waterPlot(index)
                        onWater(index)
                    }
                    liveState.stage == CropStage.EMPTY && selectedSeed != null -> {
                        manager.plantPlot(index, selectedSeed)
                        onPlant(index, selectedSeed)
                    }
                }
            },
        contentAlignment = Alignment.Center
    ) {
        Text(text = "🌱", modifier = Modifier.size(32.dp))
        if (!liveState.isWatered && liveState.stage != CropStage.EMPTY) {
            Text(text = "💧", modifier = Modifier.align(Alignment.TopEnd))
        }
        if (liveState.isReady()) {
            Text(text = "✨", modifier = Modifier.align(Alignment.BottomCenter))
        }
    }
}
