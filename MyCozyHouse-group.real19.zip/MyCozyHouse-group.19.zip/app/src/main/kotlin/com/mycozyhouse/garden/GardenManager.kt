package com.mycozyhouse.garden

import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import com.mycozyhouse.util.GameTime

class GardenManager {
    private val scope = CoroutineScope(Dispatchers.Default + SupervisorJob())
    val plotStates = List(8) { MutableStateFlow(CropState()) }

    init {
        scope.launch {
            while (isActive) {
                val now = GameTime.nowMs()
                plotStates.forEachIndexed { index, flow ->
                    flow.value = flow.value.updateCurrentTime(now)
                }
                delay(1000)
            }
        }
    }

    fun plantPlot(index: Int, cropType: CropType) {
        val now = GameTime.nowMs()
        plotStates[index].value = plotStates[index].value.plant(cropType, now)
    }

    fun waterPlot(index: Int) {
        val now = GameTime.nowMs()
        plotStates[index].value = plotStates[index].value.water(now)
    }

    fun harvestPlot(index: Int) {
        if (plotStates[index].value.isReady()) {
            plotStates[index].value = plotStates[index].value.copy(harvested = true)
        }
    }

    fun restoreFromSave(savedStates: List<CropState>) {
        val now = GameTime.nowMs()
        savedStates.forEachIndexed { index, saved ->
            plotStates[index].value = saved.updateCurrentTime(now)
        }
    }

    fun destroy() {
        scope.cancel()
    }
}
