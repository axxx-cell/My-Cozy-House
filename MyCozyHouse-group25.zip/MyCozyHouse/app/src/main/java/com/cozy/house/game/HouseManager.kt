package com.cozy.house.game

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Rect
import org.json.JSONArray
import org.json.JSONObject

class PlacedItem(val uid: Int, val item: Int, var x: Int, var y: Int, var rot: Int)

/**
 * The shared house: furniture in storage + furniture placed in the world.
 * Same pattern as the farm: every phone keeps a copy, the HOST is the boss and syncs it.
 * Bought furniture is shared by everybody; coins stay personal.
 */
class HouseManager {
    val inventory = mutableStateListOf<Int>()        // item ids in storage (the same id can appear many times)
    val placed = mutableStateListOf<PlacedItem>()

    fun rectOf(pi: PlacedItem, f: Furn): Rect {
        val w = (if (pi.rot % 2 == 0) f.w else f.h) / 2f
        val h = (if (pi.rot % 2 == 0) f.h else f.w) / 2f
        return Rect(pi.x - w, pi.y - h, pi.x + w, pi.y + h)
    }

    /** Solid furniture blocks the player. */
    fun rebuild() {
        World.dynamic = placed.mapNotNull { pi ->
            FurnitureCatalog.byId(pi.item)?.takeIf { it.solid }?.let { f ->
                val r = rectOf(pi, f)
                Rect(r.left + 3f, r.top + 3f, r.right - 3f, r.bottom - 3f)
            }
        }
    }

    /** Same rules on host and clients. Returns true if something changed. */
    fun apply(op: String, item: Int, x: Int, y: Int, rot: Int, uid: Int): Boolean {
        when (op) {
            "ADD" -> {
                if (FurnitureCatalog.byId(item) == null) return false
                inventory.add(item)
                return true
            }
            "PLACE" -> {
                val i = inventory.indexOf(item)
                if (i < 0) return false
                inventory.removeAt(i)
                placed.add(PlacedItem(uid, item, x, y, rot and 3))
                rebuild()
                return true
            }
            "STORE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                inventory.add(p.item)
                rebuild()
                return true
            }
            "DELETE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                rebuild()
                return true
            }
            "MOVE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                p.x = x; p.y = y; p.rot = rot and 3
                rebuild()
                return true
            }
        }
        return false
    }

    fun toJson(): JSONObject {
        val pl = JSONArray()
        placed.forEach { pl.put(JSONArray().put(it.uid).put(it.item).put(it.x).put(it.y).put(it.rot)) }
        return JSONObject().put("inv", JSONArray(inventory.toList())).put("pl", pl)
    }

    fun load(o: JSONObject) {
        inventory.clear()
        o.optJSONArray("inv")?.let { a -> for (i in 0 until a.length()) inventory.add(a.optInt(i)) }
        placed.clear()
        o.optJSONArray("pl")?.let { a ->
            for (i in 0 until a.length()) {
                val r = a.optJSONArray(i) ?: continue
                placed.add(PlacedItem(r.optInt(0), r.optInt(1), r.optInt(2), r.optInt(3), r.optInt(4)))
            }
        }
        rebuild()
    }
}
