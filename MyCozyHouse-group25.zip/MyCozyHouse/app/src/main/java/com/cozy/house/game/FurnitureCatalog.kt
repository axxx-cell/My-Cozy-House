package com.cozy.house.game

/**
 * Everything you can buy at Cozy Home. size w x h is in world units (1 tile = 20).
 * kind: decor, sofa (sit), bed (sleep), lamp (glows at night), wardrobe, mirror, fridge, bookshelf.
 * IMPORTANT: ids come from the order below. Only ever ADD new items at the END of a list or the file, never reorder.
 */
class Furn(
    val id: Int, val room: String, val cat: String, val name: String, val emoji: String, val color: Int,
    val w: Int, val h: Int, val price: Int, val stars: Int, val kind: String, val solid: Boolean,
)

object FurnitureCatalog {
    val ROOMS = listOf("living", "bedroom", "kitchen", "garden", "playground", "bathroom", "rare")
    val ROOM_LABEL = mapOf(
        "living" to "🛋️ Living", "bedroom" to "🛏️ Bedroom", "kitchen" to "🍳 Kitchen", "garden" to "🌷 Garden",
        "playground" to "🎠 Playground", "bathroom" to "🛁 Bathroom", "rare" to "⭐ Rare"
    )

    val ALL: List<Furn> = build()
    private val byIdMap = ALL.associateBy { it.id }
    fun byId(id: Int): Furn? = byIdMap[id]

    private fun build(): List<Furn> {
        val out = ArrayList<Furn>()
        fun add(room: String, cat: String, name: String, emoji: String, color: Long, w: Int, h: Int, price: Int,
                kind: String = "decor", solid: Boolean = true, stars: Int = 0) {
            out.add(Furn(out.size + 1, room, cat, name, emoji, color.toInt(), w, h, price, stars, kind, solid))
        }

        // ---------------- LIVING ROOM
        val sofas = listOf("Pink" to 0xFFFFB3D1, "Blue" to 0xFFBDE0FE, "Mint" to 0xFFB9FBC0, "Yellow" to 0xFFFFF1A8,
            "Cat" to 0xFFFFA97A, "Cloud" to 0xFFE6F4FF, "Rainbow" to 0xFFFFD9E8, "Heart" to 0xFFFF9EC4)
        val sofaEmoji = listOf("🛋️", "🛋️", "🛋️", "🛋️", "🐱", "☁️", "🌈", "💗")
        sofas.forEachIndexed { i, (n, c) -> add("living", "Sofa", "$n Sofa", sofaEmoji[i], c, 160, 80, 60 + (i % 4) * 5, "sofa") }
        add("living", "Table", "Coffee Table", "☕", 0xFFF3D9B1, 100, 60, 25)
        add("living", "Table", "Side Table", "🕯️", 0xFFF3D9B1, 40, 40, 20)
        add("living", "Table", "TV Stand", "📦", 0xFFD9C2F0, 140, 40, 25)
        add("living", "TV", "Old TV", "📺", 0xFFB0A090, 80, 60, 50)
        add("living", "TV", "Flat TV", "📺", 0xFF2F2A41, 120, 40, 70)
        add("living", "TV", "Cat TV", "😺", 0xFFFFB3D1, 100, 60, 65)
        add("living", "Lamp", "Floor Lamp", "💡", 0xFFFFF1A8, 40, 40, 20, "lamp")
        add("living", "Lamp", "Table Lamp", "💡", 0xFFFFE9A8, 30, 30, 15, "lamp")
        add("living", "Lamp", "Star Lamp", "⭐", 0xFFFFE066, 40, 40, 25, "lamp")
        add("living", "Lamp", "Heart Lamp", "💖", 0xFFFFC8DD, 40, 40, 25, "lamp")
        add("living", "Lamp", "Mushroom Lamp", "🍄", 0xFFFF9EC4, 40, 40, 30, "lamp")
        add("living", "Lamp", "Fairy Lights", "✨", 0xFFFFF8D6, 120, 20, 30, "lamp", solid = false)
        listOf("Round" to "⭕", "Heart" to "💗", "Star" to "⭐", "Cat Face" to "🐱", "Rainbow" to "🌈", "Cloud" to "☁️", "Flower" to "🌸", "Checker" to "🏁")
            .forEachIndexed { i, (n, e) -> add("living", "Rug", "$n Rug", e, listOf(0xFFFFD9E8, 0xFFFFC8DD, 0xFFFFF1A8, 0xFFFFE0C7, 0xFFE8F4FF, 0xFFE6F4FF, 0xFFFFD1E8, 0xFFEFEFEF)[i], 160, 120, 20 + (i % 3) * 10, solid = false) }
        listOf("Fern" to "🌿", "Cactus" to "🌵", "Monstera" to "🪴", "Bonsai" to "🌳", "Tulips" to "🌷", "Sunflower" to "🌻", "Rose" to "🌹", "Bamboo" to "🎋", "Palm" to "🌴", "Mini Tree" to "🎄")
            .forEachIndexed { i, (n, e) -> add("living", "Plant", n, e, 0xFFC9F0B8, 40, 40, 12 + (i % 4) * 3) }
        add("living", "Decor", "Photo Wall", "🖼️", 0xFFFFF0F5, 160, 20, 30, solid = false)
        add("living", "Decor", "Bookshelf", "📚", 0xFFD9A066, 100, 40, 45, "bookshelf")
        add("living", "Decor", "Fireplace", "🔥", 0xFFFFB38A, 110, 60, 60)
        listOf("Pink", "Blue", "Mint", "Yellow", "Lavender", "Peach", "White", "Red", "Green", "Purple").forEachIndexed { i, n ->
            add("living", "Curtains", "$n Curtains", "🪟", listOf(0xFFFFB3D1, 0xFFBDE0FE, 0xFFB9FBC0, 0xFFFFF1A8, 0xFFD9C2F0, 0xFFFFCCBC, 0xFFFFFFFF, 0xFFFF8A8A, 0xFF8EE6A0, 0xFFB57BDB)[i], 80, 20, 15, solid = false)
        }
        listOf("Sunset", "Mountain", "Flowers", "Kitty", "Puppy", "Ocean", "Stars", "Rainbow", "Hearts", "Forest", "Moon", "Abstract").forEachIndexed { i, n ->
            add("living", "Wall Art", "$n Art", "🖼️", listOf(0xFFFFD1A9, 0xFFBDE0FE, 0xFFFFC8DD, 0xFFFFE0C7, 0xFFE0C9A6, 0xFF8EC9FF, 0xFF3A2D6B, 0xFFFFE9F5, 0xFFFF9EC4, 0xFF9ADFA0, 0xFFE6E6FA, 0xFFD9B3FF)[i], 60, 16, 15, solid = false)
        }

        // ---------------- BEDROOM
        listOf(Triple("Single Bed", "🛏️", 0xFFFFB3D1), Triple("Double Bed", "🛏️", 0xFFBDE0FE), Triple("Bunk Bed", "🛏️", 0xFFD9A066),
            Triple("Cat Bed", "🐱", 0xFFFFA97A), Triple("Cloud Bed", "☁️", 0xFFE6F4FF), Triple("Princess Bed", "👑", 0xFFFFC8DD),
            Triple("Car Bed", "🚗", 0xFFFF8A8A), Triple("Hammock", "🌴", 0xFFB9FBC0)).forEachIndexed { i, (n, e, c) ->
            add("bedroom", "Bed", n, e, c, if (i == 1) 160 else 110, 170, 40 + i * 5, "bed")
        }
        listOf("Pink", "White", "Wood", "Lavender").forEachIndexed { i, n ->
            add("bedroom", "Wardrobe", "$n Wardrobe", "🧥", listOf(0xFFFFB3D1, 0xFFFFFFFF, 0xFFD9A066, 0xFFD9C2F0)[i], 90, 50, 40, "wardrobe")
        }
        listOf("Round" to "🪞", "Heart" to "💗", "Star" to "⭐").forEachIndexed { i, (n, e) -> add("bedroom", "Mirror", "$n Mirror", e, 0xFFE6F4FF, 60, 20, 25, "mirror", solid = false) }
        add("bedroom", "Furniture", "Desk", "🗂️", 0xFFD9A066, 110, 60, 30)
        add("bedroom", "Furniture", "Chair", "🪑", 0xFFD9A066, 40, 40, 12)
        add("bedroom", "Furniture", "Toy Box", "🧸", 0xFFFFE08A, 70, 50, 25)
        add("bedroom", "Lamp", "Night Lamp", "💡", 0xFFFFF1A8, 30, 30, 15, "lamp")
        listOf("Space", "Cats", "Music").forEachIndexed { i, n -> add("bedroom", "Poster", "$n Poster", "🖼️", listOf(0xFF3A2D6B, 0xFFFFD1A9, 0xFFD9B3FF)[i], 50, 16, 10, solid = false) }

        // ---------------- KITCHEN
        listOf("White", "Mint", "Pink").forEachIndexed { i, n -> add("kitchen", "Fridge", "$n Fridge", "🧊", listOf(0xFFFFFFFF, 0xFFB9FBC0, 0xFFFFC8DD)[i], 80, 70, 50, "fridge") }
        listOf("Classic", "Pastel").forEachIndexed { i, n -> add("kitchen", "Stove", "$n Stove", "🍳", listOf(0xFFE8E8F0, 0xFFFFD9E8)[i], 80, 70, 45) }
        add("kitchen", "Furniture", "Kitchen Sink", "🚰", 0xFFD6EEFF, 100, 60, 35)
        add("kitchen", "Furniture", "Counter", "🍞", 0xFFFFE9C7, 160, 50, 25)
        add("kitchen", "Furniture", "Table + 4 Chairs", "🍽️", 0xFFF3D9B1, 160, 120, 55)
        add("kitchen", "Decor", "Hanging Pans", "🍳", 0xFFB0B7C3, 80, 20, 15, solid = false)
        add("kitchen", "Decor", "Recipe Board", "📋", 0xFFFFF1A8, 60, 16, 12, solid = false)

        // ---------------- GARDEN
        listOf("White", "Pink", "Blue", "Wood", "Mint").forEachIndexed { i, n -> add("garden", "Fence", "$n Fence", "🚧", listOf(0xFFFFFFFF, 0xFFFFC8DD, 0xFFBDE0FE, 0xFFD9A066, 0xFFB9FBC0)[i], 120, 20, 10) }
        listOf("Stone" to "🪨", "Wood" to "🪵", "Flower" to "🌸", "Rainbow" to "🌈").forEachIndexed { i, (n, e) ->
            add("garden", "Path", "$n Path", e, listOf(0xFFD9D9D9, 0xFFD9A066, 0xFFFFD9E8, 0xFFFFF1F8)[i], 120, 60, 10, solid = false)
        }
        add("garden", "Decor", "Pond", "💧", 0xFF8EC9FF, 160, 110, 40)
        add("garden", "Decor", "Fountain", "⛲", 0xFFBDE0FE, 90, 90, 55)
        add("garden", "Decor", "Flower Bed", "🌷", 0xFFFFD1E8, 140, 50, 20, solid = false)
        listOf("Farmer", "Witch", "Pirate").forEachIndexed { i, n -> add("garden", "Scarecrow", "$n Scarecrow", "🧑‍🌾", 0xFFE9C46A, 50, 60, 25) }
        add("garden", "Lamp", "String Lights", "✨", 0xFFFFF8D6, 160, 16, 20, "lamp", solid = false)
        add("garden", "Lamp", "Fireflies Jar", "🫙", 0xFFFFF59D, 30, 30, 15, "lamp")
        add("garden", "Decor", "Big Tree", "🌳", 0xFF9ADFA0, 110, 110, 60)

        // ---------------- PLAYGROUND
        listOf("Red", "Blue", "Yellow").forEachIndexed { i, n -> add("playground", "Slide", "$n Slide", "🎢", listOf(0xFFFF8A8A, 0xFF8EC9FF, 0xFFFFE066)[i], 100, 140, 50) }
        listOf("Red", "Blue", "Yellow").forEachIndexed { i, n -> add("playground", "Swing", "$n Swing", "🎠", listOf(0xFFFF8A8A, 0xFF8EC9FF, 0xFFFFE066)[i], 200, 60, 45) }
        listOf("Pink", "Blue", "Green").forEachIndexed { i, n -> add("playground", "Trampoline", "$n Trampoline", "🤸", listOf(0xFFFFC8DD, 0xFFBDE0FE, 0xFFB9FBC0)[i], 140, 120, 40, solid = false) }
        add("playground", "Decor", "House Flag", "🚩", 0xFFFF9EC4, 40, 60, 15)

        // ---------------- BATHROOM
        listOf("White", "Pink", "Blue").forEachIndexed { i, n -> add("bathroom", "Bathtub", "$n Bathtub", "🛁", listOf(0xFFFFFFFF, 0xFFFFC8DD, 0xFFBDE0FE)[i], 200, 110, 55) }
        add("bathroom", "Furniture", "Shower", "🚿", 0xFFD6EEFF, 100, 140, 45)
        add("bathroom", "Mirror", "Bathroom Mirror", "🪞", 0xFFE6F4FF, 80, 16, 20, "mirror", solid = false)
        listOf("Pink", "Blue", "Yellow").forEachIndexed { i, n -> add("bathroom", "Towel", "$n Towel", "🧺", listOf(0xFFFFC8DD, 0xFFBDE0FE, 0xFFFFF1A8)[i], 40, 40, 8, solid = false) }
        listOf("Yellow", "Pink", "Blue").forEachIndexed { i, n -> add("bathroom", "Decor", "$n Rubber Duck", "🦆", listOf(0xFFFFF1A8, 0xFFFFC8DD, 0xFFBDE0FE)[i], 30, 30, 8) }

        // ---------------- RARE (Stars only)
        add("rare", "Rare", "Rainbow Wallpaper", "🌈", 0xFFFFF1F8, 200, 20, 0, solid = false, stars = 2)
        add("rare", "Rare", "Golden Bed", "🛏️", 0xFFFFD700, 130, 170, 0, "bed", stars = 3)
        add("rare", "Rare", "Secret Room Key", "🗝️", 0xFFFFE066, 30, 30, 0, solid = false, stars = 3)
        add("rare", "Rare", "Galaxy Ceiling", "🌌", 0xFF3A2D6B, 200, 20, 0, solid = false, stars = 2)
        add("rare", "Rare", "Floating Shelf", "📚", 0xFFFFE9C7, 100, 20, 0, solid = false, stars = 2)
        return out
    }
}

/** Wall (15) and floor (10) styles for each room; applying them comes with Decorate Mode. */
object WallFloor {
    val WALLS = listOf("Pastel Pink", "Baby Blue", "Mint", "Cream", "Lavender", "Peach", "White", "Wood", "Brick", "Starry Night", "Rainbow", "Strawberry", "Ocean", "Forest", "Polka Dot")
    val FLOORS = listOf("Wood", "Tile White", "Tile Pink", "Carpet Pink", "Carpet Blue", "Grass", "Marble", "Checker", "Rainbow Rug", "Cloud")
}
