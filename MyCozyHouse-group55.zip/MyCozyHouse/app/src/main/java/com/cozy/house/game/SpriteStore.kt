package com.cozy.house.game

import android.content.Context
import android.content.res.Resources
import android.graphics.BitmapFactory
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asImageBitmap
import com.cozy.house.R

/**
 * Characters that come as pictures instead of being drawn by code. Each one has 5 poses:
 * front (also used while walking toward you), back (walking away), side (left/right), sit and sleep.
 * Look.sprite tells which set to use (0 = the normal drawn avatar).
 */
object SpriteStore {
    class SpriteSet(val front: ImageBitmap, val back: ImageBitmap, val side: ImageBitmap, val sit: ImageBitmap, val sleep: ImageBitmap)

    private var res: Resources? = null
    private val cache = HashMap<Int, SpriteSet>()

    private val IDS = mapOf(
        1 to intArrayOf(R.drawable.spr_mochi_front, R.drawable.spr_mochi_back, R.drawable.spr_mochi_side, R.drawable.spr_mochi_sit, R.drawable.spr_mochi_sleep),
    )

    fun init(ctx: Context) { res = ctx.applicationContext.resources }

    fun get(id: Int): SpriteSet? {
        if (id == 0) return null
        cache[id]?.let { return it }
        val r = res ?: return null
        val ids = IDS[id] ?: return null
        return try {
            val b = ids.map { BitmapFactory.decodeResource(r, it).asImageBitmap() }
            SpriteSet(b[0], b[1], b[2], b[3], b[4]).also { cache[id] = it }
        } catch (e: Exception) { null }
    }
}
