package com.cozy.house

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.Characters
import com.cozy.house.game.CreatorEditor
import com.cozy.house.game.LocalSave
import com.cozy.house.game.Look
import com.cozy.house.game.Paints
import com.cozy.house.game.PlayerState
import com.cozy.house.game.drawPlayer

/**
 * Settings: pick your character, or customize every detail. This is the ONLY place the avatar changes,
 * so nobody's look changes while a game is running.
 */
@Composable
fun CharacterScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val paints = remember { Paints() }
    var look by remember {
        mutableStateOf(LocalSave.load(ctx).optString("look").takeIf { it.isNotEmpty() }?.let { Look.decode(it) } ?: Characters.DEFAULT.look)
    }
    var picked by remember { mutableStateOf(LocalSave.load(ctx).optString("char", "rosie")) }
    var editing by remember { mutableStateOf(false) }
    val pv = remember { PlayerState("preview", "", 0) }
    pv.updateLook(look)

    fun save(l: Look, id: String) {
        look = l; picked = id
        LocalSave.save(ctx, LocalSave.load(ctx).put("look", l.encode()).put("char", id))
    }

    BackHandler { if (editing) editing = false else onBack() }

    if (editing) {
        Box(Modifier.fillMaxSize().padding(8.dp), contentAlignment = Alignment.Center) {
            CreatorEditor(look, "", paints, { save(it.copy(sprite = 0), "custom") }) { editing = false }
        }
        return
    }

    Column(Modifier.fillMaxSize().padding(14.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("⚙️ Settings · Your character", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Cozy.Outline, modifier = Modifier.weight(1f))
            SmallButton("✕ Back", Cozy.Pink, onBack)
        }
        Row(Modifier.weight(1f), horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Box(
                Modifier.width(130.dp).fillMaxHeight().background(Color.White, RoundedCornerShape(18.dp))
                    .border(3.dp, Cozy.Outline, RoundedCornerShape(18.dp))
            ) {
                Canvas(Modifier.fillMaxSize()) {
                    val sc = size.height / 150f
                    withTransform({ translate(size.width / 2f, size.height * 0.9f); scale(sc, sc, Offset.Zero) }) {
                        drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
                    }
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Pick a character. This is how you look in every game.", fontSize = 13.sp, color = Cozy.Outline)
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Characters.ALL.forEach { c ->
                        val on = picked == c.id
                        Column(
                            Modifier.width(96.dp).clickable { save(c.look, c.id) },
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Image(
                                painterResource(c.pic), c.name,
                                Modifier.size(96.dp, 132.dp).clip(RoundedCornerShape(14.dp))
                                    .border(if (on) 4.dp else 2.dp, if (on) Color(0xFFF2587A) else Cozy.Outline, RoundedCornerShape(14.dp)),
                                contentScale = ContentScale.Crop
                            )
                            Text(if (on) "✔ ${c.name}" else c.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
                        }
                    }
                }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    SmallButton("🎨 Customize", Cozy.Yellow) { editing = true }
                    SmallButton("✔ Done", Cozy.Mint, onBack)
                }
                Text(
                    "Your look is locked while you play, so friends never see you change in the middle of a game. Clothes you buy in the Style Star shop are still yours.",
                    fontSize = 11.sp, color = Cozy.Outline
                )
            }
        }
    }
}

@Composable
private fun SmallButton(label: String, color: Color, onClick: () -> Unit) {
    Box(
        Modifier.background(color, RoundedCornerShape(20.dp)).border(3.dp, Cozy.Outline, RoundedCornerShape(20.dp))
            .clickable { onClick() }.padding(horizontal = 16.dp, vertical = 8.dp)
    ) { Text(label, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = Cozy.Outline) }
}
