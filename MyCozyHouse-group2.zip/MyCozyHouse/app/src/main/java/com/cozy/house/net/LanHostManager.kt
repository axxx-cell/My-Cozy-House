package com.cozy.house.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.net.*
import java.util.concurrent.ConcurrentHashMap

/** Small helpers shared by host + client. */
object NetUtils {
    /** Phone's LAN / hotspot IPv4. Prefers wlan/ap interfaces so mobile data is skipped. */
    fun localIp(): String {
        try {
            val nis = NetworkInterface.getNetworkInterfaces().toList()
                .filter { it.isUp && !it.isLoopback }
                .sortedBy { n -> if (n.name.startsWith("wlan") || n.name.startsWith("ap") || n.name.startsWith("swlan")) 0 else 1 }
            for (ni in nis) for (a in ni.inetAddresses.toList()) {
                if (a is Inet4Address && a.isSiteLocalAddress) return a.hostAddress ?: ""
            }
        } catch (_: Exception) {}
        return ""
    }

    /** Every broadcast address we can find (works on WiFi AND phone hotspot) + 255.255.255.255. */
    fun broadcastAddresses(): List<InetAddress> {
        val out = mutableListOf<InetAddress>()
        try {
            for (ni in NetworkInterface.getNetworkInterfaces().toList()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { out.add(it) }
            }
        } catch (_: Exception) {}
        try { out.add(InetAddress.getByName("255.255.255.255")) } catch (_: Exception) {}
        return out.distinct()
    }
}

/**
 * Hosts a house: TCP server (port 8080), NSD + UDP discovery, roster, relay, kick,
 * 5-second snapshots and host hand-over.
 *
 * hostId = "p1" normally. A MIGRATED host passes the id it already had as a client.
 */
class LanHostManager(
    context: Context,
    val houseName: String,
    val hostName: String,
    private val hostId: String = "p1",
    private val hostAvatar: JSONObject = JSONObject(),
    private val gameTimeProvider: () -> Long = { 0L },
    private val snapshotProvider: () -> JSONObject = { JSONObject() },
) {
    private class Conn(val id: String, val socket: Socket, val out: Channel<String>)

    private val appContext = context.applicationContext
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val lock = Any()
    private val conns = ConcurrentHashMap<String, Conn>()
    private var idCounter = 1
    private var server: ServerSocket? = null
    private var multicast: WifiManager.MulticastLock? = null
    private var nsdListener: NsdManager.RegistrationListener? = null

    var started = false
        private set

    private val _players = MutableStateFlow<List<PlayerInfo>>(emptyList())
    /** Roster, host first, then in join order. */
    val players: StateFlow<List<PlayerInfo>> = _players

    private val _events = MutableSharedFlow<GameMessage>(extraBufferCapacity = 256)
    /** Every game message (JOIN, LEAVE, MOVE, CHAT, BUY, CUSTOM, SYNC) so the game can react. */
    val events: SharedFlow<GameMessage> = _events

    // ---------------------------------------------------------------- start / stop

    fun start(): Boolean {
        if (started) return true
        return try {
            scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
            val ip = NetUtils.localIp()
            server = ServerSocket().apply {
                reuseAddress = true
                bind(InetSocketAddress(Net.TCP_PORT))
            }
            _players.value = listOf(PlayerInfo(hostId, hostName, true, ip, hostAvatar))
            started = true

            try {
                val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
                multicast = wifi.createMulticastLock("cozy-house").apply {
                    setReferenceCounted(false); acquire()
                }
            } catch (_: Exception) {}

            scope.launch { acceptLoop() }
            scope.launch { udpBroadcastLoop() }
            scope.launch { snapshotLoop() }
            registerNsd()
            true
        } catch (e: Exception) {
            stop()
            false
        }
    }

    fun stop() {
        val wasStarted = started
        started = false
        scope.cancel()
        runCatching { server?.close() }
        conns.values.forEach { c ->
            runCatching { c.out.close() }
            runCatching { c.socket.close() }
        }
        conns.clear()
        nsdListener?.let { l ->
            runCatching {
                (appContext.getSystemService(Context.NSD_SERVICE) as NsdManager).unregisterService(l)
            }
        }
        nsdListener = null
        runCatching { multicast?.release() }
        multicast = null
        if (wasStarted) _players.value = emptyList()
    }

    /**
     * Host leaves but the house lives on: earliest-joined player becomes host.
     * Clients get HOST_CHANGE with the new host's IP + the latest snapshot, then reconnect.
     */
    suspend fun handOverAndStop() {
        val next = _players.value.firstOrNull { !it.isHost }
        if (next != null) {
            broadcast(GameMessage(MsgType.HOST_CHANGE, hostId, JSONObject()
                .put("newHostId", next.id)
                .put("newHostName", next.name)
                .put("newHostIp", next.ip)
                .put("gameTimeMs", gameTimeProvider())
                .put("state", snapshotProvider())))
            delay(500)
        }
        stop()
    }

    // ---------------------------------------------------------------- public API

    /** Send to everyone (host's own MOVE / CHAT / START / SYNC...). */
    fun broadcast(msg: GameMessage, exceptId: String? = null) {
        val line = msg.encode()
        conns.values.forEach { if (it.id != exceptId) it.out.trySend(line) }
    }

    fun sendTo(id: String, msg: GameMessage) {
        conns[id]?.out?.trySend(msg.encode())
    }

    fun startGame() = broadcast(GameMessage(MsgType.START, hostId))

    /** Host only. Cannot kick yourself. */
    fun kick(id: String) {
        if (id == hostId) return
        val c = conns[id] ?: return
        c.out.trySend(GameMessage.kick(id).encode())
        scope.launch { delay(250); removeClient(id) }
    }

    // ---------------------------------------------------------------- discovery

    private fun registerNsd() {
        try {
            val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
            val info = NsdServiceInfo().apply {
                serviceName = houseName
                serviceType = Net.NSD_SERVICE_TYPE
                port = Net.TCP_PORT
                setAttribute("host", hostName)
            }
            val l = object : NsdManager.RegistrationListener {
                override fun onRegistrationFailed(s: NsdServiceInfo, e: Int) {}
                override fun onUnregistrationFailed(s: NsdServiceInfo, e: Int) {}
                override fun onServiceRegistered(s: NsdServiceInfo) {}
                override fun onServiceUnregistered(s: NsdServiceInfo) {}
            }
            nsdListener = l
            nsd.registerService(info, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (_: Exception) {
            // NSD is a bonus; UDP broadcast + manual IP still work.
        }
    }

    private suspend fun udpBroadcastLoop() {
        try {
            DatagramSocket().use { s ->
                s.broadcast = true
                while (currentCoroutineContext().isActive) {
                    val json = JSONObject()
                        .put("app", "myhouse")
                        .put("name", houseName)
                        .put("host", hostName)
                        .put("players", _players.value.size)
                        .put("max", Net.MAX_PLAYERS)
                        .put("ip", NetUtils.localIp())
                        .put("port", Net.TCP_PORT)
                    val bytes = json.toString().toByteArray()
                    for (addr in NetUtils.broadcastAddresses()) {
                        try { s.send(DatagramPacket(bytes, bytes.size, addr, Net.UDP_PORT)) } catch (_: Exception) {}
                    }
                    delay(1000)
                }
            }
        } catch (_: Exception) {}
    }

    // ---------------------------------------------------------------- server

    private suspend fun acceptLoop() {
        val srv = server ?: return
        while (currentCoroutineContext().isActive) {
            val s = try { srv.accept() } catch (e: Exception) { break }
            scope.launch { handleClient(s) }
        }
    }

    private suspend fun snapshotLoop() {
        while (currentCoroutineContext().isActive) {
            delay(Net.SNAPSHOT_EVERY_MS)
            broadcast(GameMessage(MsgType.SYNC, hostId, JSONObject()
                .put("kind", "SNAPSHOT")
                .put("gameTimeMs", gameTimeProvider())
                .put("state", snapshotProvider())))
        }
    }

    private fun freshId(): String {
        do { idCounter++ } while (_players.value.any { it.id == "p$idCounter" })
        return "p$idCounter"
    }

    /** Returns the new player's id, or null if the house is full. */
    private fun admit(join: GameMessage, socket: Socket, out: Channel<String>): String? =
        synchronized(lock) {
            if (_players.value.size >= Net.MAX_PLAYERS) return@synchronized null
            val wanted = join.playerId // set when reconnecting after a host change
            val id = if (wanted.isNotBlank() && _players.value.none { it.id == wanted }) wanted else freshId()
            val info = PlayerInfo(
                id = id,
                name = join.data.optString("name", "Player").take(12),
                isHost = false,
                ip = socket.inetAddress?.hostAddress ?: "",
                avatar = join.data.optJSONObject("avatar") ?: JSONObject(),
            )
            conns[id] = Conn(id, socket, out)
            _players.value = _players.value + info
            id
        }

    private suspend fun handleClient(socket: Socket) {
        var id: String? = null
        val out = Channel<String>(Channel.UNLIMITED)
        scope.launch {
            try {
                val w = socket.getOutputStream()
                for (line in out) { w.write(line.toByteArray()); w.flush() }
            } catch (_: Exception) {}
        }
        try {
            socket.tcpNoDelay = true
            socket.soTimeout = 5000 // must send JOIN within 5 s
            val reader = socket.getInputStream().bufferedReader()
            val join = GameMessage.decode(reader.readLine() ?: return) ?: return
            if (join.type != MsgType.JOIN) return

            val newId = admit(join, socket, out)
            if (newId == null) {
                out.trySend(GameMessage(MsgType.KICK, "", JSONObject().put("reason", "FULL")).encode())
                delay(300)
                return
            }
            id = newId
            socket.soTimeout = 0

            sendTo(newId, GameMessage(MsgType.WELCOME, newId, JSONObject()
                .put("houseName", houseName)
                .put("hostName", hostName)
                .put("players", PlayerInfo.listToJson(_players.value))
                .put("gameTimeMs", gameTimeProvider())
                .put("state", snapshotProvider())))
            broadcast(GameMessage.lobby(_players.value))
            _events.tryEmit(GameMessage(MsgType.JOIN, newId, JSONObject().put("name", join.data.optString("name", "Player"))))

            while (true) {
                val line = reader.readLine() ?: break
                val m = GameMessage.decode(line) ?: continue
                when (m.type) {
                    MsgType.PING -> out.trySend(GameMessage.pong(m.data.optLong("t")).encode())
                    MsgType.LEAVE -> break
                    MsgType.MOVE, MsgType.CHAT, MsgType.BUY, MsgType.CUSTOM, MsgType.SYNC -> {
                        val safe = m.copy(playerId = newId) // players cannot pretend to be others
                        broadcast(safe, exceptId = newId)
                        _events.tryEmit(safe)
                    }
                    else -> {} // players cannot send START / KICK / LOBBY / WELCOME
                }
            }
        } catch (_: Exception) {
        } finally {
            val done = id
            if (done != null) removeClient(done) else {
                runCatching { out.close() }
                runCatching { socket.close() }
            }
        }
    }

    private fun removeClient(id: String) {
        val c = conns.remove(id) ?: return
        runCatching { c.out.close() }
        runCatching { c.socket.close() }
        synchronized(lock) { _players.value = _players.value.filter { it.id != id } }
        broadcast(GameMessage.leave(id))
        broadcast(GameMessage.lobby(_players.value))
        _events.tryEmit(GameMessage.leave(id))
    }
}
