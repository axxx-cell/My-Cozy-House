package com.cozy.house.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.Cozy
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin

/** How each recipe is made by hand: what you do after adding the ingredients. */
private class Plan(val chop: Boolean, val heat: String?, val heatButton: String, val tool: String)

private val PLANS = listOf(
    Plan(false, "Simmer the soup", "🥄 Ladle it!", "🍲"),       // Tomato Soup
    Plan(true, null, "", "🥗"),                                 // Salad
    Plan(false, "Cook the pancake", "🥞 Flip it!", "🍳"),       // Pancake
    Plan(false, null, "", "🥤"),                                // Strawberry Milk
    Plan(false, "Bake the pizza", "🔥 Take it out!", "🍕"),     // Pizza
    Plan(false, "Bake the cake", "🔥 Take it out!", "🎂"),      // Cake
    Plan(false, "Grill the patty", "🍔 Flip it!", "🍔"),        // Burger
    Plan(false, "Bake the pie", "🔥 Take it out!", "🥧"),       // Pumpkin Pie
    Plan(false, "Bake the cupcakes", "🔥 Take it out!", "🧁"),  // Cupcake
    Plan(false, "Simmer the chowder", "🥄 Ladle it!", "🍜"),    // Corn Chowder
    Plan(false, "Cook the pasta", "🧀 Serve it!", "🍝"),        // Mac & Cheese
    Plan(false, null, "", "🍨"),                                // Ice Cream
)

private fun ingColor(i: Ing) = when (i) {
    Ing.CARROT -> Color(0xFFFFA24D); Ing.TOMATO -> Color(0xFFFF6B6B); Ing.CORN -> Color(0xFFFFE066)
    Ing.STRAWBERRY -> Color(0xFFFF8FB5); Ing.PUMPKIN -> Color(0xFFFFA94D); Ing.MILK -> Color(0xFFFFFFFF)
    Ing.EGGS -> Color(0xFFFFF1B8); Ing.CHEESE -> Color(0xFFFFD25A); Ing.FLOUR -> Color(0xFFFFF8EC); Ing.SUGAR -> Color(0xFFFFFFFF)
}

private fun mixColor(list: List<Ing>): Color {
    if (list.isEmpty()) return Color(0xFFFFF4E0)
    var r = 0f; var g = 0f; var b = 0f
    for (i in list) { val c = ingColor(i); r += c.red; g += c.green; b += c.blue }
    val n = list.size
    return Color(r / n, g / n, b / n)
}

@Composable
internal fun CookingScreen(pm: PlayerManager) {
    val idx = pm.cookIndex
    val recipe = KitchenManager.RECIPES.getOrNull(idx) ?: run { pm.panel = null; return }
    val plan = PLANS.getOrElse(idx) { PLANS[0] }
    val time by produceState(0f) { while (true) { withFrameNanos { value = it / 1e9f } } }

    // 0 add ingredients, 1 stir/chop, 2 cook (if the recipe has it), 3 done, 4 burnt
    var step by remember { mutableStateOf(0) }
    val added = remember { mutableStateListOf<Ing>() }
    var mixTotal by remember { mutableStateOf(0f) }      // radians stirred, or chops
    var stars by remember { mutableStateOf(3) }
    var bowlRect by remember { mutableStateOf(Rect.Zero) }
    var burst by remember { mutableStateOf(0f) }         // little bounce after each ingredient

    fun addIng(i: Ing) {
        if (i in added) return
        added.add(i)
        SoundFx.pop()
        burst = time
        if (added.size == recipe.needs.size) step = 1
    }

    val need = if (plan.chop) 12f else 6f * PI.toFloat()   // 12 chops or 3 full stirs
    LaunchedEffect(mixTotal) {
        if (step == 1 && mixTotal >= need) {
            SoundFx.splash()
            if (plan.heat != null) step = 2 else { stars = 3; step = 3 }
        }
    }

    Column(
        Modifier.fillMaxSize().background(Color(0xFFFFF1DC)).padding(10.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        // title + steps
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(10.dp)) {
            Box(
                Modifier.background(Color.White, RoundedCornerShape(20.dp)).border(3.dp, OUT, RoundedCornerShape(20.dp))
                    .clickable { pm.panel = null }.padding(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("✕", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = OUT) }
            Text("${recipe.emoji} ${recipe.name}", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            val labels = buildList { add("Add"); add(if (plan.chop) "Chop" else "Stir"); if (plan.heat != null) add("Cook"); add("Serve") }
            val cur = when (step) { 0 -> 0; 1 -> 1; 2, 4 -> 2; else -> labels.size - 1 }
            labels.forEachIndexed { n, l ->
                Text(
                    (if (n < cur || step == 3) "✅ " else "${n + 1}. ") + l, fontSize = 12.sp,
                    fontWeight = if (n == cur && step != 3) FontWeight.ExtraBold else FontWeight.Normal, color = OUT
                )
            }
        }

        // the stage
        Box(
            Modifier.fillMaxWidth().weight(1f)
                .background(Color(0xFFFFE3C2), RoundedCornerShape(22.dp)).border(3.dp, OUT, RoundedCornerShape(22.dp)).padding(8.dp)
        ) {
            when (step) {
                0 -> Row(Modifier.fillMaxSize(), horizontalArrangement = Arrangement.spacedBy(10.dp), verticalAlignment = Alignment.CenterVertically) {
                    // shelf with the ingredients
                    Column(Modifier.width(150.dp), verticalArrangement = Arrangement.spacedBy(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        Text("Drag into the bowl 👉", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            recipe.needs.forEach { ing ->
                                DragIngredient(ing, ing in added, bowlRect) { addIng(ing) }
                            }
                        }
                        Text("or tap them", fontSize = 10.sp, color = OUT)
                    }
                    Box(Modifier.weight(1f).fillMaxHeight().onGloballyPositioned { bowlRect = it.boundsInRoot() }, contentAlignment = Alignment.Center) {
                        Bowl(added, 0f, time, burst)
                    }
                    Column(Modifier.width(120.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                        recipe.needs.forEach { ing ->
                            Text((if (ing in added) "✅ " else "⬜ ") + ing.emoji + " " + ing.label, fontSize = 12.sp, color = OUT)
                        }
                    }
                }
                1 -> if (plan.chop) ChopStep(recipe.needs, mixTotal) { mixTotal += 1f; SoundFx.pop() }
                     else StirStep(added, mixTotal, need, time) { mixTotal += it }
                2 -> HeatStep(plan, time) { s ->
                    if (s == 0) { step = 4; SoundFx.pop() } else { stars = s; step = 3; SoundFx.harvest() }
                }
                3 -> Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    val bounce = 1f + 0.08f * sin(time * 6f)
                    Text(recipe.emoji, fontSize = 72.sp, modifier = Modifier.graphicsLayer { scaleX = bounce; scaleY = bounce })
                    Text(when (stars) { 3 -> "Perfect! ✨"; 2 -> "Yummy! 😋"; else -> "Good job! 🙂" }, fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                    Text("⭐".repeat(stars), fontSize = 28.sp)
                    Spacer(Modifier.height(6.dp))
                    Box(
                        Modifier.background(Cozy.Mint, RoundedCornerShape(26.dp)).border(3.dp, OUT, RoundedCornerShape(26.dp))
                            .clickable { pm.finishCooking(idx, stars) }.padding(horizontal = 30.dp, vertical = 10.dp)
                    ) { Text("🍽️ Serve it!", fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = OUT) }
                }
                else -> Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
                    Text("💨😵", fontSize = 64.sp)
                    Text("Oops! It burnt!", fontSize = 22.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                    Text("Nothing is lost. Try again!", fontSize = 13.sp, color = OUT)
                    Spacer(Modifier.height(8.dp))
                    Box(
                        Modifier.background(Cozy.Yellow, RoundedCornerShape(26.dp)).border(3.dp, OUT, RoundedCornerShape(26.dp))
                            .clickable { step = 2 }.padding(horizontal = 28.dp, vertical = 10.dp)
                    ) { Text("🔁 Try again", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT) }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ step pieces

@Composable
private fun DragIngredient(ing: Ing, used: Boolean, bowl: Rect, onDrop: () -> Unit) {
    var ox by remember { mutableStateOf(0f) }
    var oy by remember { mutableStateOf(0f) }
    var spot by remember { mutableStateOf(Rect.Zero) }
    var drag by remember { mutableStateOf(false) }
    val bowlNow by rememberUpdatedState(bowl)
    val dropNow by rememberUpdatedState(onDrop)
    Box(
        Modifier.size(58.dp)
            .onGloballyPositioned { spot = it.boundsInRoot() }
            .graphicsLayer { translationX = ox; translationY = oy; alpha = if (used) 0.25f else 1f; scaleX = if (drag) 1.25f else 1f; scaleY = if (drag) 1.25f else 1f }
            .background(Color.White, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
            .clickable(enabled = !used) { dropNow() }
            .pointerInput(used) {
                if (!used) detectDragGestures(
                    onDragStart = { drag = true },
                    onDrag = { change, d -> change.consume(); ox += d.x; oy += d.y },
                    onDragEnd = {
                        drag = false
                        val c = spot.center + Offset(ox, oy)
                        if (bowlNow.inflate(80f).contains(c)) dropNow()
                        ox = 0f; oy = 0f
                    },
                    onDragCancel = { drag = false; ox = 0f; oy = 0f }
                )
            },
        contentAlignment = Alignment.Center
    ) { Text(ing.emoji, fontSize = 30.sp) }
}

private fun DrawScope.drawBowl(content: List<Ing>, swirl: Float, t: Float, burst: Float) {
    val w = size.width; val h = size.height
    val cx = w / 2f; val cy = h * 0.55f
    val rw = minOf(w * 0.42f, h * 0.75f); val rh = rw * 0.42f
    // shadow + back rim
    drawOval(Color.Black.copy(alpha = 0.10f), Offset(cx - rw, cy + rh * 0.9f), Size(rw * 2f, rh * 0.5f))
    drawOval(Color(0xFFB8C4E8), Offset(cx - rw, cy - rh), Size(rw * 2f, rh * 2f))
    drawOval(OUT, Offset(cx - rw, cy - rh), Size(rw * 2f, rh * 2f), style = Stroke(5f))
    // food inside
    val col = mixColor(content)
    val fw = rw * 0.86f; val fh = rh * 0.78f
    drawOval(col, Offset(cx - fw, cy - fh), Size(fw * 2f, fh * 2f))
    // chunks
    content.forEachIndexed { n, ing ->
        val a = n * 2.1f + swirl * 0.5f
        drawCircle(ingColor(ing).copy(alpha = 0.9f), 9f, Offset(cx + cos(a) * fw * 0.5f, cy + sin(a) * fh * 0.5f))
        drawCircle(OUT.copy(alpha = 0.35f), 9f, Offset(cx + cos(a) * fw * 0.5f, cy + sin(a) * fh * 0.5f), style = Stroke(2f))
    }
    // swirl lines (they turn while you stir)
    rotate(swirl * 57.29578f, Offset(cx, cy)) {
        for (k in 0..2) {
            val rr = 0.3f + k * 0.22f
            drawArc(Color.White.copy(alpha = 0.55f), k * 60f, 140f, false, Offset(cx - fw * rr, cy - fh * rr), Size(fw * rr * 2f, fh * rr * 2f), style = Stroke(4f))
        }
    }
    drawOval(OUT, Offset(cx - fw, cy - fh), Size(fw * 2f, fh * 2f), style = Stroke(3f))
    // front rim
    val bounce = (1f - (t - burst).coerceIn(0f, 0.4f) / 0.4f) * 8f
    drawArc(OUT, 0f, 180f, false, Offset(cx - rw, cy - rh + bounce * 0f), Size(rw * 2f, rh * 2f), style = Stroke(5f))
}

@Composable
private fun Bowl(content: List<Ing>, swirl: Float, t: Float, burst: Float) {
    val bounce = 1f + 0.06f * (1f - (t - burst).coerceIn(0f, 0.35f) / 0.35f)
    Canvas(Modifier.fillMaxSize().graphicsLayer { scaleX = bounce; scaleY = bounce }) { drawBowl(content, swirl, t, burst) }
}

@Composable
private fun StirStep(added: List<Ing>, total: Float, need: Float, t: Float, onTurn: (Float) -> Unit) {
    var finger by remember { mutableStateOf<Offset?>(null) }
    var last by remember { mutableStateOf<Float?>(null) }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally) {
        Text("Stir in circles with your finger! 🥄", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
        Box(Modifier.weight(1f).fillMaxWidth()) {
            Bowl(added, total, t, 0f)
            Box(
                Modifier.fillMaxSize().pointerInput(Unit) {
                    detectDragGestures(
                        onDragStart = { last = null },
                        onDragEnd = { finger = null; last = null },
                        onDragCancel = { finger = null; last = null },
                        onDrag = { change, _ ->
                            change.consume()
                            val c = Offset(size.width / 2f, size.height * 0.55f)
                            val p = change.position
                            finger = p
                            if ((p - c).getDistance() > 12f) {
                                val a = atan2(p.y - c.y, p.x - c.x)
                                val l = last
                                if (l != null) {
                                    var d = a - l
                                    while (d > PI) d -= (2 * PI).toFloat()
                                    while (d < -PI) d += (2 * PI).toFloat()
                                    onTurn(abs(d))
                                }
                                last = a
                            }
                        }
                    )
                }
            ) {
                finger?.let { f -> Text("🥄", fontSize = 44.sp, modifier = Modifier.graphicsLayer { translationX = f.x - 30f; translationY = f.y - 60f }) }
            }
        }
        ProgressBar((total / need).coerceIn(0f, 1f))
    }
}

@Composable
private fun ChopStep(needs: List<Ing>, total: Float, onChop: () -> Unit) {
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text("Tap the board to chop! 🔪", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
        Box(
            Modifier.weight(1f).fillMaxWidth(0.7f)
                .background(Color(0xFFE8C48A), RoundedCornerShape(18.dp)).border(4.dp, OUT, RoundedCornerShape(18.dp))
                .clickable { onChop() },
            contentAlignment = Alignment.Center
        ) {
            val n = total.toInt()
            Row(horizontalArrangement = Arrangement.spacedBy((6 - minOf(n, 10) / 2).dp)) {
                needs.forEach { ing ->
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        val pieces = 1 + n / 3
                        Text(ing.emoji.repeat(minOf(pieces, 5)), fontSize = (34 - minOf(n, 12)).sp, textAlign = TextAlign.Center)
                    }
                }
            }
            Text(if (n % 2 == 0) "🔪" else "🔪", fontSize = 40.sp,
                modifier = Modifier.align(Alignment.TopEnd).padding(14.dp).graphicsLayer { rotationZ = if (n % 2 == 0) -20f else 20f })
        }
        ProgressBar((total / 12f).coerceIn(0f, 1f))
    }
}

@Composable
private fun ProgressBar(f: Float) {
    Box(Modifier.fillMaxWidth(0.6f).height(14.dp).background(Color.White, RoundedCornerShape(8.dp)).border(2.dp, OUT, RoundedCornerShape(8.dp))) {
        Box(Modifier.fillMaxHeight().fillMaxWidth(f).background(Cozy.Pink, RoundedCornerShape(8.dp)))
    }
}

/** Real cooking takes time: the pot heats up, steams and bubbles. Tap the pot to stir. Take it out when the marker is in the green. */
@Composable
private fun HeatStep(plan: Plan, t: Float, onResult: (Int) -> Unit) {
    var startT by remember { mutableStateOf(-1f) }
    if (startT < 0f) startT = t
    var stirs by remember { mutableStateOf(0) }
    var stirT by remember { mutableStateOf(-10f) }
    var msg by remember { mutableStateOf("") }
    val prog = (t - startT) / 9f                    // 1.0 = perfectly done (after 9 seconds)
    LaunchedEffect(prog >= 1.45f) { if (prog >= 1.45f) onResult(0) }
    val label = when {
        prog < 0.7f -> "Cooking… ⏱ ${((0.88f - prog) * 9f).toInt() + 1}s  ·  tap the pot to stir 🥄"
        prog < 0.88f -> "Almost ready… ⏱ ${((0.88f - prog) * 9f).toInt() + 1}s"
        prog < 1.12f -> "NOW! Take it out! 🔥"
        else -> "Hurry!! It's getting too hot! 😰"
    }
    Column(Modifier.fillMaxSize(), horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
        Text(plan.heat + "!  " + label, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT, textAlign = TextAlign.Center)
        Box(Modifier.weight(1f).fillMaxWidth().clickable { stirs++; stirT = t; SoundFx.pop(); msg = "" }) {
            Canvas(Modifier.fillMaxSize()) {
                val shake = if (t - stirT < 0.4f) sin((t - stirT) * 40f) * 5f else 0f
                val cx = size.width / 2f + shake; val cy = size.height * 0.62f
                val heat = prog.coerceIn(0f, 1.3f)
                drawOval(Color.Black.copy(alpha = 0.10f), Offset(cx - 110f, cy + 30f), Size(220f, 26f))
                // flames under the pot
                for (i in 0..6) {
                    val fh = 10f + 8f * sin(t * 9f + i) + heat * 8f
                    drawOval(Color(0xFFFF8A3D), Offset(cx - 80f + i * 26f, cy + 38f - fh / 2f), Size(14f, fh))
                    drawOval(Color(0xFFFFD86B), Offset(cx - 77f + i * 26f, cy + 40f - fh / 3f), Size(8f, fh * 0.6f))
                }
                drawRoundRect(Color(0xFF6B6785), Offset(cx - 100f, cy - 20f), Size(200f, 60f), CornerRadius(24f))
                drawRoundRect(OUT, Offset(cx - 100f, cy - 20f), Size(200f, 60f), CornerRadius(24f), style = Stroke(4f))
                drawRoundRect(Color(0xFF6B6785), Offset(cx + 98f, cy - 4f), Size(66f, 14f), CornerRadius(7f))
                val food = if (prog < 1.12f) Color(0xFFFFD58A) else Color(0xFF8A5A30)
                drawOval(food, Offset(cx - 88f, cy - 34f), Size(176f, 38f))
                drawOval(OUT, Offset(cx - 88f, cy - 34f), Size(176f, 38f), style = Stroke(3f))
                // bubbles in the pot
                for (i in 0..4) {
                    val a = (t * 1.3f + i * 0.21f) % 1f
                    drawCircle(Color.White.copy(alpha = 0.8f), 3f + 4f * a, Offset(cx - 50f + i * 25f, cy - 20f - a * 8f))
                }
                // steam rises more and more
                val n = 3 + (heat * 5f).toInt()
                for (i in 0 until n) {
                    val a = (t * (0.7f + heat * 0.5f) + i * 0.17f) % 1f
                    drawCircle(Color.White.copy(alpha = 0.75f * (1f - a)), 8f + 10f * a, Offset(cx - 70f + i * (140f / n) + sin(t * 2f + i) * 8f, cy - 44f - a * 90f))
                }
                if (prog >= 1.12f) for (i in 0..2) {
                    val a = (t * 0.9f + i * 0.33f) % 1f
                    drawCircle(Color(0xFF3B3355).copy(alpha = 0.6f * (1f - a)), 10f + 12f * a, Offset(cx - 30f + i * 30f, cy - 50f - a * 80f))
                }
            }
            if (stirs > 0 && t - stirT < 0.6f) Text("🥄", fontSize = 40.sp, modifier = Modifier.align(Alignment.Center).graphicsLayer { translationY = -50f; rotationZ = sin((t - stirT) * 25f) * 25f })
        }
        // progress bar: raw | ok | PERFECT | too hot
        Box(Modifier.fillMaxWidth(0.8f).height(24.dp).border(3.dp, OUT, RoundedCornerShape(12.dp)).background(Color(0xFFD8DDF0), RoundedCornerShape(12.dp))) {
            Row(Modifier.fillMaxSize()) {
                Box(Modifier.weight(0.7f).fillMaxHeight().background(Color(0xFFD8DDF0)))                  // raw
                Box(Modifier.weight(0.18f).fillMaxHeight().background(Color(0xFFFFE066)))                  // ok
                Box(Modifier.weight(0.24f).fillMaxHeight().background(Color(0xFF7BDC8C)))                  // perfect
                Box(Modifier.weight(0.33f).fillMaxHeight().background(Color(0xFFFF8A8A)))                  // too hot
            }
            BoxWithConstraints(Modifier.fillMaxSize()) {
                Text("🔻", fontSize = 22.sp, modifier = Modifier.graphicsLayer { translationX = (prog / 1.45f).coerceIn(0f, 1f) * constraints.maxWidth - 24f; translationY = -8f })
            }
        }
        if (msg.isNotEmpty()) Text(msg, fontSize = 12.sp, color = Color(0xFFB3261E), fontWeight = FontWeight.Bold)
        Box(
            Modifier.background(Color(0xFFFF8A3D), RoundedCornerShape(26.dp)).border(3.dp, OUT, RoundedCornerShape(26.dp))
                .clickable {
                    when {
                        prog < 0.7f -> { msg = "Still raw! Wait a little more 🥶"; SoundFx.pop() }
                        else -> {
                            var s = if (prog < 0.88f) 2 else if (prog < 1.12f) 3 else 1
                            if (stirs >= 4 && s < 3) s += 1      // a well-stirred pot is a better dish
                            onResult(s)
                        }
                    }
                }.padding(horizontal = 30.dp, vertical = 8.dp)
        ) { Text(plan.heatButton, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = Color.White) }
    }
}
