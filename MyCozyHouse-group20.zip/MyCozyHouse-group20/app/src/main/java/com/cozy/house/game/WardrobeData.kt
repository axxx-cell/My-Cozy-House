package com.cozy.house.game

enum class ClothingSlot { TOP, BOTTOM, DRESS, ONESIE, FULL }

data class WardrobeItem(
    val id: String,
    val name: String,
    val slot: ClothingSlot,
    val priceCoins: Int,
    val priceStars: Int = 0,
    val available: Boolean = true
) {
    companion object {
        val ALL = listOf(
            WardrobeItem("pajama", "Pajama Set", ClothingSlot.FULL, 20),
            WardrobeItem("hoodie", "Hoodie + Pants", ClothingSlot.FULL, 30),
            WardrobeItem("dress_casual", "Casual Dress", ClothingSlot.DRESS, 30),
            WardrobeItem("overalls", "Denim Overalls", ClothingSlot.FULL, 35),
            WardrobeItem("sporty", "Sporty Tee + Shorts", ClothingSlot.FULL, 25),
            WardrobeItem("cute_dress", "Cute Dress", ClothingSlot.DRESS, 40),
            WardrobeItem("school_uniform", "School Uniform", ClothingSlot.DRESS, 45),
            WardrobeItem("party_dress", "Party Dress", ClothingSlot.DRESS, 50),
            WardrobeItem("farmer_overalls", "Farmer Overalls", ClothingSlot.FULL, 35),
            WardrobeItem("raincoat", "Raincoat", ClothingSlot.TOP, 30),
            WardrobeItem("winter_coat", "Winter Coat", ClothingSlot.TOP, 45),
            WardrobeItem("tee_white", "Plain White Tee", ClothingSlot.TOP, 15),
            WardrobeItem("tee_pink", "Pink Tee", ClothingSlot.TOP, 15),
            WardrobeItem("tee_blue", "Blue Tee", ClothingSlot.TOP, 15),
            WardrobeItem("jeans", "Blue Jeans", ClothingSlot.BOTTOM, 25),
            WardrobeItem("skirt_denim", "Denim Skirt", ClothingSlot.BOTTOM, 25),
            WardrobeItem("skirt_flowy", "Flowy Skirt", ClothingSlot.BOTTOM, 30),
            WardrobeItem("shorts_denim", "Denim Shorts", ClothingSlot.BOTTOM, 20),
            WardrobeItem("onesie_cat", "Cat Onesie", ClothingSlot.ONESIE, 40),
            WardrobeItem("onesie_bear", "Bear Onesie", ClothingSlot.ONESIE, 40),
            WardrobeItem("onesie_rabbit", "Bunny Onesie", ClothingSlot.ONESIE, 40),
            WardrobeItem("cardigan", "Cozy Cardigan", ClothingSlot.TOP, 30),
            WardrobeItem("sweater", "Knitted Sweater", ClothingSlot.TOP, 35),
            WardrobeItem("flannel", "Plaid Flannel", ClothingSlot.TOP, 30),
            WardrobeItem("leggings", "Cute Leggings", ClothingSlot.BOTTOM, 18),
            WardrobeItem("jumpsuit", "Cotton Jumpsuit", ClothingSlot.FULL, 45),
            WardrobeItem("apron", "Cute Apron", ClothingSlot.TOP, 15),
            WardrobeItem("sun_dress", "Sun Dress", ClothingSlot.DRESS, 35),
            WardrobeItem("nightgown", "Soft Nightgown", ClothingSlot.DRESS, 25),
            WardrobeItem("tracksuit", "Tracksuit", ClothingSlot.FULL, 40)
        )

        val COLORS = listOf(
            0xFFFF9EC4, 0xFFFF6B9A, 0xFFFF8E8E, 0xFFFFA97A, 0xFFFFD86B,
            0xFFF8E880, 0xFFC8E6C9, 0xFF8EE6A0, 0xFF60D090, 0xFF8EC9FF,
            0xFF6BB3FF, 0xFF7060E0, 0xFFB57BDB, 0xFFD9B3FF, 0xFFFFFFFF,
            0xFFE0E0E0, 0xFF909090, 0xFF5B3A4A, 0xFF2F2A41, 0xFF905030
        ).map { it.toInt() }

        fun getById(id: String): WardrobeItem? = ALL.find { it.id == id }
    }
}
