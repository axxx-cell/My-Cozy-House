package com.cozy.house

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cozy.house.game.LocalSave
import com.cozy.house.game.PlayerManager
import com.cozy.house.game.WardrobePanel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val save = LocalSave(this)
        val pm = PlayerManager(save)
        setContent {
            AppScreen(pm)
        }
    }
}

@Composable
fun AppScreen(pm: PlayerManager) {
    var currentScreen by remember { mutableStateOf(Screen.LOBBY) }

    MaterialTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFFDF6F0))
            ) {
                when (currentScreen) {
                    Screen.LOBBY -> LobbyScreen(pm = pm, onNavigate = { currentScreen = it })
                    Screen.WARDROBE -> WardrobePanel(pm = pm, onClose = { currentScreen = Screen.LOBBY })
                    else -> Text("Coming Soon! ✨", modifier = Modifier.align(Alignment.Center))
                }
            }
        }
    }
}
