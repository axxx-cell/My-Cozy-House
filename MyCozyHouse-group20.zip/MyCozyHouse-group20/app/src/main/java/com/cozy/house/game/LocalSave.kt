package com.cozy.house.game

import android.content.Context
import android.content.SharedPreferences

class LocalSave(context: Context) {
    private val prefs: SharedPreferences = context.getSharedPreferences("game_save", Context.MODE_PRIVATE)

    var coins: Int
        get() = prefs.getInt("coins", 100)
        set(value) = prefs.edit().putInt("coins", value).apply()

    var stars: Int
        get() = prefs.getInt("stars", 0)
        set(value) = prefs.edit().putInt("stars", value).apply()

    var ownedOutfits: Set<String>
        get() = prefs.getString("ownedOutfits", "")?.split(",")?.filter { it.isNotEmpty() }?.toSet() ?: setOf("pajama", "hoodie")
        set(value) = prefs.edit().putString("ownedOutfits", value.joinToString(",")).apply()

    var equippedOutfit: String
        get() = prefs.getString("equippedOutfit", "hoodie") ?: "hoodie"
        set(value) = prefs.edit().putString("equippedOutfit", value).apply()

    var outfitColorIndex: Int
        get() = prefs.getInt("outfitColorIndex", 0)
        set(value) = prefs.edit().putInt("outfitColorIndex", value).apply()

    var lookEncoded: String?
        get() = prefs.getString("look", null)
        set(value) = prefs.edit().putString("look", value).apply()

    fun clearAll() = prefs.edit().clear().apply()
}
