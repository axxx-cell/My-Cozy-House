package com.cozy.house

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.AvatarPreview
import com.cozy.house.game.PlayerManager

@Composable
fun LobbyScreen(pm: PlayerManager, onNavigate: (Screen) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFDF6F0))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(20.dp)
    ) {
        Spacer(modifier = Modifier.height(30.dp))
        
        Text(
            text = "🏠 My Cozy House",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold
        )
        
        Spacer(modifier = Modifier.height(20.dp))
        
        AvatarPreview(look = pm.myLook, size = 120f)
        
        Spacer(modifier = Modifier.height(10.dp))
        
        Text(
            text = "💰 Coins: ${pm.coins}",
            fontSize = 20.sp
        )
        
        Spacer(modifier = Modifier.height(30.dp))
        
        CozyButton(
            text = "👗 Open Wardrobe",
            onClick = { onNavigate(Screen.WARDROBE) }
        )
        
        CozyButton(
            text = "🎮 Play Game",
            onClick = { }
        )
        
        CozyButton(
            text = "👥 Visit Friends",
            onClick = { }
        )
        
        CozyButton(
            text = "🛒 Shop",
            onClick = { }
        )
        
        Spacer(modifier = Modifier.weight(1f))
    }
}
