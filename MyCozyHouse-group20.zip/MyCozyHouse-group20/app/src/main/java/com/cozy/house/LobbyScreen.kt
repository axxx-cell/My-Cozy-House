package com.cozy.house

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.AvatarPreview
import com.cozy.house.game.PlayerManager

@Composable
fun LobbyScreen(pm: PlayerManager, onNavigate: (Screen) -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFFDF6F0))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(24.dp)
    ) {
        Spacer(Modifier.height(20.dp))
        
        Text("🏠 My Cozy House", fontSize = 28.sp, fontWeight = FontWeight.Bold)
        
        AvatarPreview(look = pm.myLook, size = 120f)
        
        Text("💰 Coins: ${pm.coins}", fontSize = 20.sp)
        
        Spacer(Modifier.height(10.dp))
        
        CozyButton(text = "Open Wardrobe 👗", onClick = { onNavigate(Screen.WARDROBE) })
        CozyButton(text = "Play Game 🎮", onClick = { onNavigate(Screen.GAME) })
        CozyButton(text = "Visit Friends 👥", onClick = { onNavigate(Screen.FRIENDS) })
        CozyButton(text = "Shop 🛒", onClick = { onNavigate(Screen.SHOP) })
        
        Spacer(Modifier.weight(1f))
    }
}
