package com.cozy.house.game

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun GameScreen(pm: PlayerManager) {
    // Main game content goes here
    Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
        Button(onClick = { pm.openWardrobe() }) {
            Text("👗 Open Wardrobe")
        }
    }

    // Panels overlay
    pm.panel?.let { panelName ->
        Box(
            Modifier
                .fillMaxSize()
                .clickable { pm.panel = null },
            contentAlignment = Alignment.Center
        ) {
            Box(
                Modifier
                    .fillMaxWidth(0.9f)
                    .padding(16.dp)
                    .clickable(enabled = false) {}
            ) {
                when (panelName) {
                    "WARDROBE" -> WardrobePanel(pm)
                }
            }
        }
    }
}

@Composable
fun WardrobePanel(pm: PlayerManager) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
    ) {
        Text("👗 My Wardrobe", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        Divider(Modifier.padding(vertical = 8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            modifier = Modifier.weight(1f)
        ) {
            items(WardrobeItem.ALL.filter { it.available }) { item ->
                val owned = item.id in pm.ownedOutfits
                val equipped = pm.equippedOutfit == item.id

                Card(modifier = Modifier.padding(4.dp).fillMaxWidth()) {
                    Column(Modifier.padding(8.dp)) {
                        Text(
                            item.name,
                            fontWeight = if (equipped) FontWeight.Bold else FontWeight.Normal
                        )
                        Text("${item.priceCoins} 🪙", fontSize = 13.sp)

                        when {
                            equipped -> Text("✓ Wearing", fontSize = 12.sp, color = Color(0xFF4CAF50))
                            owned -> Button(
                                onClick = { pm.equipOutfit(item.id) },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Wear")
                            }
                            else -> Button(
                                onClick = { pm.buyOutfit(item.id) },
                                enabled = pm.coins >= item.priceCoins,
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Buy")
                            }
                        }
                    }
                }
            }
        }

        Text("🎨 Colors:", Modifier.padding(top = 8.dp))
        LazyRow(Modifier.padding(vertical = 4.dp)) {
            itemsIndexed(WardrobeItem.COLORS) { i, color ->
                val isSelected = pm.outfitColorIndex == i
                Box(
                    Modifier
                        .size(40.dp)
                        .padding(2.dp)
                        .border(
                            BorderStroke(if (isSelected) 3.dp else 1.dp, Color(0xFF5B3A4A))
                        )
                        .background(Color(color))
                        .clickable { pm.setOutfitColor(i) }
                )
            }
        }

        Button(
            onClick = { pm.panel = null },
            modifier = Modifier
                .align(Alignment.End)
                .padding(top = 8.dp)
        ) {
            Text("Close")
        }
    }
}
