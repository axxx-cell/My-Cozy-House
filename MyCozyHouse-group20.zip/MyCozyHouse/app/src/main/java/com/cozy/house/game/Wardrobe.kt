package com.cozy.house.game

enum class GCat(val label: String) { TOP("Tops"), BOTTOM("Bottoms"), DRESS("Dresses"), ONESIE("Onesies"), SET("Sets") }

/** One piece you can buy at Style Star. id 0 is reserved for "the starter outfit from the creator". */
class Garment(val id: Int, val name: String, val cat: GCat, val style: String, val price: Int, val color: Int)

object Wardrobe {
    val ALL: List<Garment> = listOf(
        Garment(1, "Pajama Set", GCat.SET, "pajama", 20, 0xFF8EC9FF.toInt()),
        Garment(2, "Hoodie + Pants", GCat.SET, "hoodie", 30, 0xFFFF9EC4.toInt()),
        Garment(3, "Casual Dress", GCat.DRESS, "casualdress", 30, 0xFFFFD86B.toInt()),
        Garment(4, "Denim Overalls", GCat.SET, "denim", 35, 0xFF6BB3FF.toInt()),
        Garment(5, "Sporty Tee + Shorts", GCat.SET, "sporty", 25, 0xFF8EE6A0.toInt()),
        Garment(6, "Cute Dress", GCat.DRESS, "cutedress", 40, 0xFFFF9EC4.toInt()),
        Garment(7, "School Uniform", GCat.SET, "school", 45, 0xFF3B5BA9.toInt()),
        Garment(8, "Party Dress", GCat.DRESS, "party", 50, 0xFFB57BDB.toInt()),
        Garment(9, "Farmer Overalls", GCat.SET, "farmer", 35, 0xFF6BB3FF.toInt()),
        Garment(10, "Raincoat", GCat.TOP, "raincoat", 30, 0xFFFFD86B.toInt()),
        Garment(11, "Winter Coat", GCat.TOP, "coat", 45, 0xFFE07A7A.toInt()),
        Garment(12, "White Tee", GCat.TOP, "tee", 15, 0xFFFFFFFF.toInt()),
        Garment(13, "Pink Tee", GCat.TOP, "tee", 15, 0xFFFF9EC4.toInt()),
        Garment(14, "Blue Tee", GCat.TOP, "tee", 15, 0xFF8EC9FF.toInt()),
        Garment(15, "Blue Jeans", GCat.BOTTOM, "jeans", 25, 0xFFFFFFFF.toInt()),
        Garment(16, "Denim Skirt", GCat.BOTTOM, "skirtdenim", 25, 0xFFFF9EC4.toInt()),
        Garment(17, "Flowy Skirt", GCat.BOTTOM, "skirtflowy", 30, 0xFFFFFFFF.toInt()),
        Garment(18, "Denim Shorts", GCat.BOTTOM, "shorts", 20, 0xFFFFFFFF.toInt()),
        Garment(19, "Cute Leggings", GCat.BOTTOM, "leggings", 18, 0xFFFF9EC4.toInt()),
        Garment(20, "Cat Onesie", GCat.ONESIE, "onesie_cat", 40, 0xFFFFA97A.toInt()),
        Garment(21, "Bear Onesie", GCat.ONESIE, "onesie_bear", 40, 0xFFB07A4F.toInt()),
        Garment(22, "Bunny Onesie", GCat.ONESIE, "onesie_bunny", 40, 0xFFFFFFFF.toInt()),
        Garment(23, "Cozy Cardigan", GCat.TOP, "cardigan", 30, 0xFFFFB3D1.toInt()),
        Garment(24, "Knitted Sweater", GCat.TOP, "sweater", 35, 0xFFD9B3FF.toInt()),
        Garment(25, "Plaid Flannel", GCat.TOP, "flannel", 30, 0xFFFF6B6B.toInt()),
        Garment(26, "Cotton Jumpsuit", GCat.SET, "jumpsuit", 45, 0xFF8EE6A0.toInt()),
        Garment(27, "Cute Apron", GCat.TOP, "apron", 15, 0xFFFF9EC4.toInt()),
        Garment(28, "Sun Dress", GCat.DRESS, "sundress", 35, 0xFFFFE066.toInt()),
        Garment(29, "Soft Nightgown", GCat.DRESS, "nightgown", 25, 0xFFD9B3FF.toInt()),
        Garment(30, "Tracksuit", GCat.SET, "tracksuit", 40, 0xFF6BB3FF.toInt()),
        Garment(31, "Sailor Outfit", GCat.SET, "sailor", 40, 0xFF3B5BA9.toInt()),
        Garment(32, "Princess Gown", GCat.DRESS, "princess", 50, 0xFFFFC8DD.toInt()),
        Garment(33, "Kimono Robe", GCat.DRESS, "kimono", 45, 0xFFFF6B9A.toInt()),
    )

    fun byId(id: Int): Garment? = if (id <= 0) null else ALL.firstOrNull { it.id == id }
}
