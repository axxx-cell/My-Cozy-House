package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue

class PlayerManager(private val save: LocalSave) {
    var coins by mutableStateOf(save.coins)
        private set
    var stars by mutableStateOf(save.stars)
        private set

    var ownedOutfits by mutableStateOf(save.ownedOutfits)
        private set
    var equippedOutfit by mutableStateOf(save.equippedOutfit)
        private set
    var outfitColorIndex by mutableStateOf(save.outfitColorIndex)
        private set

    var myLook: Look
        get() = Look.decode(save.lookEncoded ?: "") ?: Look.default(0)
        set(value) {
            save.lookEncoded = value.encode()
            field = value
        }

    var panel by mutableStateOf<String?>(null)

    init {
        myLook = Look.default(0)
    }

    fun addCoins(amount: Int) {
        save.coins = coins + amount
        coins = save.coins
    }

    fun spendCoins(amount: Int): Boolean {
        if (coins < amount) return false
        save.coins = coins - amount
        coins = save.coins
        return true
    }

    fun buyOutfit(itemId: String): Boolean {
        val item = WardrobeItem.getById(itemId) ?: return false
        if (item.id in ownedOutfits || item.priceCoins > coins) return false
        spendCoins(item.priceCoins)
        ownedOutfits = ownedOutfits + itemId
        save.ownedOutfits = ownedOutfits
        showToast("Got: ${item.name}! ✨")
        saveNow()
        return true
    }

    fun equipOutfit(itemId: String) {
        if (itemId !in ownedOutfits) return
        equippedOutfit = itemId
        save.equippedOutfit = itemId
        myLook = myLook.copy(fullOutfit = itemId)
        saveNow()
    }

    fun setOutfitColor(index: Int) {
        outfitColorIndex = index.coerceIn(0, WardrobeItem.COLORS.size - 1)
        save.outfitColorIndex = outfitColorIndex
        myLook = myLook.copy(outfitColor = WardrobeItem.COLORS[outfitColorIndex])
        saveNow()
    }

    fun openWardrobe() {
        panel = "WARDROBE"
    }

    private fun saveNow() {
        save.lookEncoded = myLook.encode()
    }

    private fun showToast(text: String) {
        // Replace with actual Toast in GameScreen
        println(text)
    }
}
