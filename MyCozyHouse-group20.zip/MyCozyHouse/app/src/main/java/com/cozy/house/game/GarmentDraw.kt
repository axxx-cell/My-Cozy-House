package com.cozy.house.game

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke

internal fun shade(c: Color, k: Float) = Color((c.red * k).coerceIn(0f, 1f), (c.green * k).coerceIn(0f, 1f), (c.blue * k).coerceIn(0f, 1f))

private val DENIM = Color(0xFF5B8FD9)

private fun DrawScope.torso(col: Color, x: Float, top: Float, h: Float = 26f) =
    roundRectOutlined(Offset(x - 14f, top), Size(28f, h), 10f, col, 3f)

private fun DrawScope.band(col: Color, x: Float, top: Float, h: Float) =
    roundRectOutlined(Offset(x - 14f, top), Size(28f, h), 6f, col, 3f)

private fun DrawScope.skirt(col: Color, x: Float, top: Float, bottom: Float, half: Float) {
    val p = Path().apply { moveTo(x - 11f, top); lineTo(x + 11f, top); lineTo(x + half, bottom); lineTo(x - half, bottom); close() }
    drawPath(p, col); drawPath(p, OUT, style = Stroke(3f))
}

private fun DrawScope.dots(c: Color, pts: List<Pair<Float, Float>>, x: Float, top: Float, r: Float = 2f) {
    for ((dx, dy) in pts) drawCircle(c, r, Offset(x + dx, top + dy))
}

private fun DrawScope.onesie(kind: String, col: Color, x: Float, top: Float, hy: Float) {
    circleOutlined(Offset(x, hy), 25f, col, 3f)                     // hood behind the head
    for (sg in listOf(-1f, 1f)) {
        when (kind) {
            "onesie_cat" -> {
                val ear = Path().apply { moveTo(x + sg * 6f, hy - 20f); lineTo(x + sg * 16f, hy - 38f); lineTo(x + sg * 23f, hy - 14f); close() }
                drawPath(ear, col); drawPath(ear, OUT, style = Stroke(3f))
            }
            "onesie_bear" -> circleOutlined(Offset(x + sg * 19f, hy - 18f), 7f, col, 3f)
            else -> roundRectOutlined(Offset(x + sg * 11f - 5f, hy - 50f), Size(10f, 28f), 5f, col, 3f)
        }
    }
    torso(col, x, top, 28f)
    drawOval(shade(col, 1.12f), Offset(x - 8f, top + 8f), Size(16f, 14f))
}

/** All 33 shop clothes. The main colour is the player's outfit colour (recolourable). */
internal fun DrawScope.drawGarment(g: Garment, look: Look, x: Float, y: Float, bob: Float) {
    val col = Color(look.outfitColor)
    val top = y - 32f - bob
    val hy = y - 52f - bob
    val dark = shade(col, 0.8f)
    val light = shade(col, 1.15f)
    val white = Color.White
    when (g.style) {
        "tee" -> torso(col, x, top)
        "pajama" -> {
            torso(col, x, top); band(dark, x, top + 16f, 10f)
            dots(white.copy(alpha = 0.85f), listOf(-6f to 6f, 5f to 4f, 0f to 11f), x, top, 2.2f)
        }
        "hoodie" -> {
            circleOutlined(Offset(x, top + 2f), 11f, col, 3f)
            torso(col, x, top)
            roundRectOutlined(Offset(x - 8f, top + 14f), Size(16f, 8f), 4f, dark, 2f)
            drawLine(OUT, Offset(x - 3f, top + 3f), Offset(x - 3f, top + 9f), 2f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 3f, top + 3f), Offset(x + 3f, top + 9f), 2f, StrokeCap.Round)
        }
        "casualdress" -> { skirt(col, x, top + 14f, y - 4f, 19f); torso(col, x, top, 20f) }
        "denim" -> {
            torso(white, x, top); band(col, x, top + 12f, 14f)
            drawLine(OUT, Offset(x - 7f, top + 12f), Offset(x - 7f, top + 3f), 3f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 7f, top + 12f), Offset(x + 7f, top + 3f), 3f, StrokeCap.Round)
            dots(Color(0xFFFFD86B), listOf(-7f to 14f, 7f to 14f), x, top, 2f)
        }
        "sporty" -> {
            torso(col, x, top)
            drawRect(white, Offset(x - 13f, top + 8f), Size(26f, 4f)); drawRect(white, Offset(x - 13f, top + 14f), Size(26f, 2.5f))
            band(white, x, top + 19f, 7f)
        }
        "cutedress" -> {
            skirt(col, x, top + 14f, y - 4f, 20f); torso(col, x, top, 20f)
            circleOutlined(Offset(x - 14f, top + 5f), 5f, col, 2.5f); circleOutlined(Offset(x + 14f, top + 5f), 5f, col, 2.5f)
            circleOutlined(Offset(x, top + 3f), 3.5f, Color(0xFFFF6B9A), 2f)
        }
        "school" -> {
            skirt(col, x, top + 16f, y - 6f, 16f); torso(white, x, top, 22f)
            roundRectOutlined(Offset(x - 14f, top), Size(10f, 22f), 6f, col, 2.5f); roundRectOutlined(Offset(x + 4f, top), Size(10f, 22f), 6f, col, 2.5f)
            val tie = Path().apply { moveTo(x - 3f, top + 2f); lineTo(x + 3f, top + 2f); lineTo(x, top + 14f); close() }
            drawPath(tie, Color(0xFFD64545)); drawPath(tie, OUT, style = Stroke(2f))
        }
        "sailor" -> {
            skirt(col, x, top + 16f, y - 6f, 16f); torso(white, x, top, 22f)
            val collar = Path().apply { moveTo(x - 12f, top + 1f); lineTo(x + 12f, top + 1f); lineTo(x, top + 14f); close() }
            drawPath(collar, col); drawPath(collar, OUT, style = Stroke(2.5f))
            circleOutlined(Offset(x, top + 12f), 3f, Color(0xFFD64545), 2f)
        }
        "party" -> {
            skirt(col, x, top + 13f, y - 2f, 25f); torso(col, x, top, 18f)
            band(Color(0xFFFFD86B), x, top + 13f, 5f)
            dots(white.copy(alpha = 0.9f), listOf(-14f to 24f, 0f to 28f, 13f to 25f, -6f to 18f, 8f to 20f), x, top, 2f)
        }
        "princess" -> {
            skirt(light, x, top + 13f, y - 2f, 27f); skirt(col, x, top + 13f, y - 8f, 21f); torso(col, x, top, 18f)
            circleOutlined(Offset(x, top + 8f), 3.5f, Color(0xFFFF6B9A), 2f)
        }
        "farmer" -> {
            torso(Color(0xFFFFE0E0), x, top)
            for (i in 1..3) drawLine(Color(0xFFD64545).copy(alpha = 0.6f), Offset(x - 13f, top + i * 6f), Offset(x + 13f, top + i * 6f), 2f)
            band(col, x, top + 12f, 14f)
            drawLine(OUT, Offset(x - 7f, top + 12f), Offset(x - 7f, top + 3f), 3f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 7f, top + 12f), Offset(x + 7f, top + 3f), 3f, StrokeCap.Round)
            roundRectOutlined(Offset(x - 5f, top + 15f), Size(10f, 7f), 2f, dark, 2f)
        }
        "raincoat" -> {
            circleOutlined(Offset(x, top + 2f), 12f, col, 3f); torso(col, x, top)
            dots(OUT.copy(alpha = 0.8f), listOf(0f to 6f, 0f to 13f, 0f to 20f), x, top, 2f)
        }
        "coat" -> {
            torso(col, x, top); band(dark, x, top + 15f, 5f)
            for (i in -2..2) circleOutlined(Offset(x + i * 5.5f, top + 1f), 4f, white, 2f)
            dots(OUT.copy(alpha = 0.8f), listOf(0f to 9f, 0f to 22f), x, top, 2f)
        }
        "cardigan" -> {
            torso(white, x, top)
            roundRectOutlined(Offset(x - 14f, top), Size(11f, 26f), 6f, col, 2.5f); roundRectOutlined(Offset(x + 3f, top), Size(11f, 26f), 6f, col, 2.5f)
            dots(OUT.copy(alpha = 0.8f), listOf(-2f to 8f, -2f to 15f, -2f to 22f), x, top, 1.6f)
        }
        "sweater" -> {
            torso(col, x, top)
            for (i in 1..3) drawLine(light, Offset(x - 13f, top + 4f + i * 5f), Offset(x + 13f, top + 4f + i * 5f), 2.5f, StrokeCap.Round)
        }
        "flannel" -> {
            torso(col, x, top)
            for (i in 1..3) drawLine(dark.copy(alpha = 0.7f), Offset(x - 13f, top + i * 6f), Offset(x + 13f, top + i * 6f), 2f)
            for (i in -1..1) drawLine(dark.copy(alpha = 0.7f), Offset(x + i * 8f, top + 2f), Offset(x + i * 8f, top + 24f), 2f)
        }
        "jeans" -> { torso(col, x, top, 20f); band(DENIM, x, top + 14f, 12f); dots(OUT.copy(alpha = 0.6f), listOf(-8f to 19f, 8f to 19f), x, top, 1.8f) }
        "skirtdenim" -> { skirt(DENIM, x, top + 15f, y - 5f, 17f); torso(col, x, top, 20f) }
        "skirtflowy" -> { skirt(Color(0xFFFFE3F0), x, top + 15f, y - 3f, 23f); torso(col, x, top, 20f) }
        "shorts" -> { torso(col, x, top, 20f); band(DENIM, x, top + 16f, 10f) }
        "leggings" -> { torso(col, x, top, 20f); band(Color(0xFF3B3355), x, top + 16f, 10f) }
        "onesie_cat", "onesie_bear", "onesie_bunny" -> onesie(g.style, col, x, top, hy)
        "jumpsuit" -> { torso(col, x, top); band(dark, x, top + 14f, 5f); dots(white.copy(alpha = 0.8f), listOf(0f to 6f, 0f to 10f), x, top, 1.8f) }
        "apron" -> {
            torso(white, x, top)
            val ap = Path().apply { moveTo(x - 9f, top + 6f); lineTo(x + 9f, top + 6f); lineTo(x + 12f, top + 26f); lineTo(x - 12f, top + 26f); close() }
            drawPath(ap, col); drawPath(ap, OUT, style = Stroke(2.5f))
            roundRectOutlined(Offset(x - 5f, top + 15f), Size(10f, 7f), 2f, dark, 2f)
        }
        "sundress" -> {
            skirt(col, x, top + 12f, y - 5f, 17f); torso(col, x, top, 18f)
            drawLine(OUT, Offset(x - 8f, top), Offset(x - 8f, top - 3f), 2f); drawLine(OUT, Offset(x + 8f, top), Offset(x + 8f, top - 3f), 2f)
            circleOutlined(Offset(x + 8f, top + 15f), 3f, white, 1.5f)
        }
        "nightgown" -> {
            skirt(col, x, top + 10f, y - 2f, 20f); torso(col, x, top, 16f)
            dots(Color(0xFFFFE066), listOf(-8f to 20f, 6f to 24f, 0f to 15f), x, top, 2.2f)
        }
        "tracksuit" -> {
            torso(col, x, top); band(dark, x, top + 17f, 9f)
            drawLine(white, Offset(x - 12f, top + 2f), Offset(x - 12f, top + 24f), 2.5f); drawLine(white, Offset(x + 12f, top + 2f), Offset(x + 12f, top + 24f), 2.5f)
            drawLine(OUT, Offset(x, top + 2f), Offset(x, top + 16f), 2f)
        }
        "kimono" -> {
            skirt(col, x, top + 14f, y - 3f, 18f); torso(col, x, top, 22f)
            drawLine(white, Offset(x - 9f, top + 1f), Offset(x + 2f, top + 14f), 3f, StrokeCap.Round)
            drawLine(white, Offset(x + 9f, top + 1f), Offset(x - 2f, top + 14f), 3f, StrokeCap.Round)
            band(Color(0xFFFFD86B), x, top + 14f, 6f)
        }
        else -> torso(col, x, top)
    }
}
