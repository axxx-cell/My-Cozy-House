package com.cozy.house.game

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.Cozy
import org.json.JSONArray
import org.json.JSONObject

/** One "Move the sofa here?" vote. Immutable: every change makes a new copy so Compose redraws. */
data class VoteState(
    val id: Int, val uid: Int, val item: Int, val x: Int, val y: Int, val rot: Int,
    val proposer: String, val proposerName: String,
    val yes: Set<String>, val no: Set<String>, val left: Float,
) {
    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("uid", uid).put("item", item).put("x", x).put("y", y).put("rot", rot)
        .put("pr", proposer).put("pn", proposerName)
        .put("yes", JSONArray(yes.toList())).put("no", JSONArray(no.toList())).put("left", left.toDouble())

    companion object {
        private fun set(a: JSONArray?): Set<String> {
            val s = HashSet<String>()
            if (a != null) for (i in 0 until a.length()) s.add(a.optString(i))
            return s
        }
        fun fromJson(o: JSONObject) = VoteState(
            o.optInt("id"), o.optInt("uid"), o.optInt("item"), o.optInt("x"), o.optInt("y"), o.optInt("rot"),
            o.optString("pr"), o.optString("pn"), set(o.optJSONArray("yes")), set(o.optJSONArray("no")),
            o.optDouble("left", 15.0).toFloat()
        )
    }
}

/**
 * Shared house voting. The HOST is the boss (same pattern as farm and house):
 * it starts the vote, counts it, moves the furniture, and tells everybody.
 * Rules: only one vote at a time, 15 seconds, majority YES moves it. A tie or NO means it stays.
 * Only one player in the house = the move just happens.
 */
class HouseVoteManager {
    var current by mutableStateOf<VoteState?>(null)
    private var nextId = 1

    /** Host: open a vote. Returns an error text, or null if it started. */
    fun start(house: HouseManager, uid: Int, x: Int, y: Int, rot: Int, proposer: String, name: String): String? {
        if (current != null) return "Another vote is running. Wait a moment! 🗳️"
        val p = house.placed.firstOrNull { it.uid == uid } ?: return "That furniture is gone."
        current = VoteState(nextId++, uid, p.item, x, y, rot and 3, proposer, name, setOf(proposer), emptySet(), 15f)
        return null
    }

    /** Host: someone answered. Returns the result (true/false) if the vote is decided, else null. */
    fun cast(id: Int, voter: String, yes: Boolean, voters: Set<String>): Boolean? {
        val c = current ?: return null
        if (c.id != id || voter in c.yes || voter in c.no) return null
        current = if (yes) c.copy(yes = c.yes + voter) else c.copy(no = c.no + voter)
        return decide(voters, timeUp = false)
    }

    /** Count only the players who are still in the house (someone may have left). */
    fun decide(voters: Set<String>, timeUp: Boolean): Boolean? {
        val c = current ?: return null
        val n = maxOf(1, voters.size)
        val y = c.yes.count { it in voters }
        val no = c.no.count { it in voters }
        if (y * 2 > n) return true            // majority
        if (no * 2 >= n) return false         // majority can't be reached any more
        if (timeUp) return false
        return null
    }

    /** Everybody counts the timer down on screen. Only the host ends the vote. */
    fun tick(dt: Float) { current = current?.let { it.copy(left = maxOf(0f, it.left - dt)) } }
}

internal fun ghostRect(item: Int, x: Int, y: Int, rot: Int): Rect? {
    val f = FurnitureCatalog.byId(item) ?: return null
    val w = (if (rot % 2 == 0) f.w else f.h) / 2f
    val h = (if (rot % 2 == 0) f.h else f.w) / 2f
    return Rect(x - w, y - h, x + w, y + h)
}

/** Yellow outline = piece you are moving, pink outline = where it wants to go (or the vote is about). */
internal fun DrawScope.drawDecorateGhosts(pm: PlayerManager) {
    fun box(r: Rect, c: Color) =
        drawRoundRect(c, r.topLeft, Size(r.width, r.height), CornerRadius(12f), style = Stroke(5f))
    val sel = pm.house.placed.firstOrNull { it.uid == pm.decoSel }
    if (pm.panel == "DECORATE" && sel != null) {
        ghostRect(sel.item, sel.x, sel.y, sel.rot)?.let { box(it, Color(0xFFFFD84D)) }
        ghostRect(sel.item, pm.decoX, pm.decoY, pm.decoRot)?.let { box(it, Color(0xFFFF7FAE)) }
    }
    pm.votes.current?.let { v -> ghostRect(v.item, v.x, v.y, v.rot)?.let { box(it, Color(0xFFFF7FAE)) } }
}

@Composable
private fun DPill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
            .border(BorderStroke(3.dp, OUT), RoundedCornerShape(20.dp)).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
}

@Composable
internal fun DecoratePanel(pm: PlayerManager) {
    Column(
        Modifier.width(430.dp).heightIn(max = 310.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🎨 Decorate Mode", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            DPill("🏠") { pm.panel = "INVENTORY" }
            Spacer(Modifier.width(6.dp))
            DPill("✕") { pm.panel = null; pm.decoSel = 0 }
        }
        val sel = pm.house.placed.firstOrNull { it.uid == pm.decoSel }
        val f = sel?.let { FurnitureCatalog.byId(it.item) }
        if (sel != null && f != null) {
            Text("${f.emoji} ${f.name}: yellow = now, pink = new spot (grid 20)", fontSize = 11.sp, color = OUT)
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                DPill("⬅️") { pm.decoNudge(-1, 0) }
                DPill("⬆️") { pm.decoNudge(0, -1) }
                DPill("⬇️") { pm.decoNudge(0, 1) }
                DPill("➡️") { pm.decoNudge(1, 0) }
                DPill("↻") { pm.decoTurn() }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                DPill("✔ Move here") { pm.proposeMove() }
                DPill("Store") { pm.storeFurniture(sel.uid); pm.decoSel = 0 }
                if (pm.isHostNow()) DPill("🗑️") { pm.deleteFurniture(sel.uid); pm.decoSel = 0 }
            }
            Text("With friends in the house, a move needs a vote 🗳️ (15 sec).", fontSize = 10.sp, color = OUT)
        } else {
            Text("Tap a piece to move it:", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
        }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(4.dp)) {
            pm.house.placed.reversed().forEach { pi ->
                val g = FurnitureCatalog.byId(pi.item) ?: return@forEach
                val on = pi.uid == pm.decoSel
                Row(
                    Modifier.fillMaxWidth()
                        .background(if (on) Cozy.Yellow else Cozy.Cream, RoundedCornerShape(12.dp))
                        .clickable { pm.decoSelect(pi.uid) }.padding(8.dp)
                ) { Text("${g.emoji} ${g.name}", fontSize = 12.sp, color = OUT) }
            }
        }
    }
}

/** The "Move the sofa here? YES / NO" popup + a small banner for the proposer. */
@Composable
internal fun BoxScope.VoteOverlay(pm: PlayerManager) {
    val v = pm.votes.current ?: return
    val f = FurnitureCatalog.byId(v.item)
    val label = "${f?.emoji ?: ""} ${f?.name ?: "furniture"}"
    val secs = v.left.toInt() + 1
    if (pm.myId !in v.yes && pm.myId !in v.no) {
        Column(
            Modifier.align(Alignment.Center).width(300.dp)
                .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
                .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Text("🗳️ Move $label to the pink spot?", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            Text("${v.proposerName} wants to move it · ${secs}s", fontSize = 12.sp, color = OUT)
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                DPill("YES 👍") { pm.castVote(true) }
                DPill("NO 👎") { pm.castVote(false) }
            }
        }
    } else {
        Box(
            Modifier.align(Alignment.TopCenter).padding(top = 52.dp)
                .background(Cozy.Yellow, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 5.dp)
        ) { Text("🗳️ $label · 👍${v.yes.size} 👎${v.no.size} · ${secs}s", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT) }
    }
}
