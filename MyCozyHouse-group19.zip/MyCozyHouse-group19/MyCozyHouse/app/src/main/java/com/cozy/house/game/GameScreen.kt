package com.cozy.house.game

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.Divider
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.RectangleShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun WardrobePanel(pm: PlayerManager, onClose: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Wardrobe", fontSize = 22.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(16.dp))
        Divider()
        Spacer(Modifier.height(16.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            items(WardrobeItem.all) { item ->
                WardrobeItemCard(item, pm)
            }
        }

        Spacer(Modifier.height(16.dp))
        Divider()
        Spacer(Modifier.height(16.dp))

        Text("Colors", fontSize = 18.sp, fontWeight = FontWeight.Medium)
        Spacer(Modifier.height(8.dp))

        LazyVerticalGrid(
            columns = GridCells.Fixed(5),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(WardrobeItem.COLORS) { color ->
                val i = WardrobeItem.COLORS.indexOf(color)
                val isSelected = pm.outfitColorIndex == i
                Box(
                    Modifier
                        .size(44.dp)
                        .padding(2.dp)
                        .then(
                            if (isSelected) Modifier.border(
                                BorderStroke(3.dp, Color(0xFF5B3A4A)),
                                RectangleShape
                            ) else Modifier
                        )
                        .clip(RectangleShape)
                        .background(Color(color))
                        .clickable { pm.setOutfitColor(i) }
                )
            }
        }

        Spacer(Modifier.weight(1f))
        Button(onClick = onClose) {
            Text("Close")
        }
    }
}

@Composable
fun WardrobeItemCard(item: WardrobeItem, pm: PlayerManager) {
    val owned = item.id in pm.ownedOutfits
    val equipped = pm.equippedOutfit == item.id

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable {
                when {
                    equipped -> {}
                    owned -> pm.equipOutfit(item.id)
                    else -> pm.buyOutfit(item.id)
                }
            },
        border = if (equipped) BorderStroke(3.dp, Color(0xFFFFB347)) else null
    ) {
        Column(
            Modifier.padding(12.dp)
        ) {
            Text(item.emoji, fontSize = 28.sp)
            Text(item.name, fontWeight = FontWeight.Bold)
            when {
                equipped -> Text("Equipped ✅", color = Color(0xFF2E7D32))
                owned -> Text("Owned — Tap to wear")
                else -> Text("${item.priceCoins} 💰", color = Color(0xFFB8860B))
            }
        }
    }
}
