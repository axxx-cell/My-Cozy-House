package com.cozy.house

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import com.cozy.house.game.AvatarPreview
import com.cozy.house.game.Look
import com.cozy.house.game.LocalSave
import com.cozy.house.game.PlayerManager
import com.cozy.house.game.WardrobePanel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val save = LocalSave(this)
        val pm = PlayerManager(save)

        setContent {
            AppScreen(pm = pm)
        }
    }
}

@Composable
fun AppScreen(pm: PlayerManager) {
    var showWardrobe by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(modifier = Modifier.fillMaxSize()) { padding ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(padding)
                    .background(Color(0xFFFDF6F0)),
                contentAlignment = Alignment.Center
            ) {
                if (showWardrobe) {
                    WardrobePanel(pm = pm, onClose = { showWardrobe = false })
                } else {
                    MainGameUI(
                        pm = pm,
                        onOpenWardrobe = { showWardrobe = true }
                    )
                }
            }
        }
    }
}

@Composable
fun MainGameUI(pm: PlayerManager, onOpenWardrobe: () -> Unit) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text("🏠 My Cozy House", style = MaterialTheme.typography.headlineMedium)

        AvatarPreview(look = pm.myLook, size = 120f)

        Text("💰 Coins: ${pm.coins}", style = MaterialTheme.typography.bodyLarge)

        Button(onClick = onOpenWardrobe) {
            Text("Open Wardrobe 🧥")
        }
    }
}
