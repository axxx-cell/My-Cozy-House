package com.cozy.house.game

class HairDef(val name: String, val back: Int, val top: Int, val fringe: Int, val extra: Int)

/** Everything that makes an avatar look like *you*. Sent to friends as a short text, so everybody sees you exactly. */
data class Look(
    val skin: Int = 0, val face: Int = 0, val eyes: Int = 0, val brows: Int = 0, val nose: Int = 0, val mouth: Int = 0,
    val blush: Int = 1, val hair: Int = 0, val hairColor: Int = 0xFF7B4B3A.toInt(),
    val highlight: Boolean = false, val highlightColor: Int = 0xFFFFD86B.toInt(),
    val outfit: Int = 1, val outfitColor: Int = 0xFFFF9EC4.toInt(), val personality: Int = 0, val voice: Int = 0,
) {
    fun encode(): String =
        "$skin,$face,$eyes,$brows,$nose,$mouth,$blush,$hair,$hairColor,${if (highlight) 1 else 0},$highlightColor,$outfit,$outfitColor,$personality,$voice"

    companion object {
        val SKINS = listOf(0xFFFFE0C7, 0xFFF9D2B0, 0xFFF1C27D, 0xFFE0AC69, 0xFFC68642, 0xFF9C6B3E, 0xFF7A4B2A, 0xFF4E2E1B).map { it.toInt() }
        val HAIR_COLORS = listOf(0xFF2F2A41, 0xFF4A2C1D, 0xFF7B4B3A, 0xFFB07A4F, 0xFFE9C46A, 0xFFE07A3F,
            0xFFC0392B, 0xFFFF9EC4, 0xFF6BB3FF, 0xFF7EDDB5, 0xFFB57BDB, 0xFFEDEDED).map { it.toInt() }
        val HIGHLIGHT_COLORS = listOf(0xFFFFD86B, 0xFFFF9EC4, 0xFF6BB3FF, 0xFF7EDDB5, 0xFFFFFFFF, 0xFFB57BDB, 0xFFFF6B6B, 0xFFFFA94D).map { it.toInt() }
        val OUTFIT_COLORS = listOf(0xFFFF9EC4, 0xFF8EC9FF, 0xFF8EE6A0, 0xFFFFD86B, 0xFFD9B3FF, 0xFFFFA97A, 0xFFFF6B6B, 0xFF6BB3FF, 0xFF7EDDB5, 0xFFFFE066,
            0xFFF8BBD0, 0xFFB3E5FC, 0xFFC8E6C9, 0xFFFFF9C4, 0xFFE1BEE7, 0xFFFFCCBC, 0xFFFFFFFF, 0xFF90A4AE, 0xFF5B3A4A, 0xFF2F2A41).map { it.toInt() }

        val FACES = listOf("Round", "Oval", "Square", "Chubby")
        val EYES = listOf("Happy", "Sleepy", "Sparkle", "Big", "Small", "Wink", "Heart Eyes", "Star Eyes", "Sleepy Half", "Cute Dot", "Angry", "Surprised")
        val BROWS = listOf("Thin", "Thick", "Curved", "Straight", "Angry", "Cute")
        val NOSES = listOf("Small", "Round", "Pointy", "Button")
        val MOUTHS = listOf("Smile", "Grin", "Open", "Cat Mouth", "Small O", "Pout", "Tongue Out", "Teeth Smile", "Sleepy", "Laugh")
        val BLUSHES = listOf("None", "Pink", "Red", "Hearts", "Freckles")
        val OUTFITS = listOf("Pajama", "Hoodie", "Dress", "Overalls", "Sporty", "Cute")
        val PERSONALITIES = listOf("Shy", "Energetic", "Chill", "Funny")
        val VOICES = listOf("Cute", "Cool", "Funny", "Soft")

        val HAIRS = listOf(
            HairDef("Long Straight", 1, 1, 0, 0), HairDef("Long Wavy", 2, 1, 0, 0), HairDef("Short Bob", 3, 1, 1, 0),
            HairDef("Ponytail", 4, 1, 0, 1), HairDef("Twin Pigtails", 4, 1, 0, 2), HairDef("Curly", 6, 5, 0, 0),
            HairDef("Afro", 5, 5, 0, 0), HairDef("Spiky", 0, 3, 0, 0), HairDef("Bald", 0, 0, 0, 0),
            HairDef("Buzz", 0, 2, 0, 0), HairDef("Side Part", 4, 1, 2, 0), HairDef("Bangs", 4, 1, 1, 0),
            HairDef("Braid", 4, 1, 0, 5), HairDef("Bun", 0, 1, 0, 3), HairDef("Twin Buns", 0, 1, 0, 4),
            HairDef("Messy", 4, 4, 0, 0), HairDef("Wolf Cut", 3, 4, 3, 0),
            HairDef("Pixie", 0, 6, 4, 0), HairDef("Mushroom", 7, 1, 1, 0), HairDef("Curtain Bangs", 1, 1, 3, 0),
            HairDef("Half-up", 1, 1, 0, 9), HairDef("Side Ponytail", 4, 1, 2, 6), HairDef("Low Pigtails", 4, 1, 1, 7),
            HairDef("Fluffy Bob", 3, 5, 1, 0), HairDef("Long with Bangs", 1, 1, 1, 0), HairDef("Anime Spiky", 0, 3, 4, 11),
            HairDef("Bangs & Buns", 0, 1, 1, 4), HairDef("Cat Ear Buns", 0, 1, 0, 8), HairDef("Fauxhawk", 0, 2, 0, 10),
            HairDef("Long Curly", 6, 5, 1, 0),
        )

        private val SHIRTS = listOf(0xFFFF9EC4, 0xFF8EC9FF, 0xFF8EE6A0, 0xFFFFD86B).map { it.toInt() }
        private val HAIR_DEFAULT = listOf(0xFF7B4B3A, 0xFF2F2A41, 0xFFE9A15B, 0xFFB57BDB).map { it.toInt() }

        fun default(i: Int) = Look(
            skin = i % 3, hair = listOf(0, 4, 2, 14)[i % 4], hairColor = HAIR_DEFAULT[i % 4],
            outfit = 1, outfitColor = SHIRTS[i % 4],
        )

        fun random(): Look {
            val r = java.util.Random()
            return Look(
                skin = r.nextInt(8), face = r.nextInt(4), eyes = r.nextInt(12), brows = r.nextInt(6), nose = r.nextInt(4),
                mouth = r.nextInt(10), blush = r.nextInt(5), hair = r.nextInt(30), hairColor = HAIR_COLORS[r.nextInt(12)],
                highlight = r.nextInt(3) == 0, highlightColor = HIGHLIGHT_COLORS[r.nextInt(8)],
                outfit = r.nextInt(6), outfitColor = OUTFIT_COLORS[r.nextInt(20)], personality = r.nextInt(4), voice = r.nextInt(4),
            )
        }

        fun decode(s: String): Look? = try {
            val p = s.split(",").map { it.toInt() }
            Look(p[0].coerceIn(0, 7), p[1].coerceIn(0, 3), p[2].coerceIn(0, 11), p[3].coerceIn(0, 5), p[4].coerceIn(0, 3),
                p[5].coerceIn(0, 9), p[6].coerceIn(0, 4), p[7].coerceIn(0, 29), p[8], p[9] == 1, p[10],
                p[11].coerceIn(0, 5), p[12], p[13].coerceIn(0, 3), p[14].coerceIn(0, 3))
        } catch (e: Exception) { null }
    }
}
