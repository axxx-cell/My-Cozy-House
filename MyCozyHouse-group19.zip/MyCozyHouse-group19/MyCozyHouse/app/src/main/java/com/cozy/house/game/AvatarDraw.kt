package com.cozy.house.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

val OUT = Color(0xFF5B3A4A)

// Helper drawing functions
fun DrawScope.circleOutlined(center: Offset, radius: Float, fill: Color, strokeWidth: Float = 3f) {
    drawCircle(fill, center = center, radius = radius)
    drawCircle(OUT, center = center, radius = radius, style = Stroke(strokeWidth))
}

fun DrawScope.roundRectOutlined(topLeft: Offset, size: Size, radius: Float, fill: Color, strokeWidth: Float = 3f) {
    drawRoundRect(fill, topLeft, size, CornerRadius(radius))
    drawRoundRect(OUT, topLeft, size, CornerRadius(radius), style = Stroke(strokeWidth))
}

// Chibi parts, drawn from a Look
internal fun faceHW(face: Int) = when (face) { 1 -> 20f; 3 -> 25f; else -> 22f }
internal fun faceHT(face: Int) = when (face) { 1 -> 25f; 2 -> 21f; 3 -> 21f; else -> 22f }

internal fun DrawScope.drawHead(look: Look, x: Float, hy: Float, skin: Color) {
    when (look.face) {
        1 -> {
            drawOval(skin, Offset(x - 20f, hy - 25f), Size(40f, 49f))
            drawOval(OUT, Offset(x - 20f, hy - 25f), Size(40f, 49f), style = Stroke(3f))
        }
        2 -> roundRectOutlined(Offset(x - 22f, hy - 21f), Size(44f, 42f), 14f, skin, 3f)
        3 -> {
            drawOval(skin, Offset(x - 25f, hy - 21f), Size(50f, 43f))
            drawOval(OUT, Offset(x - 25f, hy - 21f), Size(50f, 43f), style = Stroke(3f))
        }
        else -> circleOutlined(Offset(x, hy), 22f, skin)
    }
}

internal fun DrawScope.drawHairBack(look: Look, x: Float, hy: Float, run: Float = 0f, moving: Boolean = false) {
    val hd = Look.HAIRS[look.hair.coerceIn(0, 29)]
    val c = Color(look.hairColor)
    val hw = faceHW(look.face)
    val sway = if (moving) sin(run) * 3f else 0f
    when (hd.back) {
        1 -> roundRectOutlined(Offset(x - hw - 3f + sway / 2f, hy - 8f), Size(2 * hw + 6f, 58f), 14f, c, 3f)
        2 -> {
            roundRectOutlined(Offset(x - hw - 3f + sway / 2f, hy - 8f), Size(2 * hw + 6f, 50f), 14f, c, 3f)
            for (i in -1..1) circleOutlined(Offset(x + i * (hw * 0.75f) + sway, hy + 44f), 9f, c, 3f)
        }
        3 -> roundRectOutlined(Offset(x - hw - 4f, hy - 8f), Size(2 * hw + 8f, 36f), 16f, c, 3f)
        4 -> roundRectOutlined(Offset(x - hw - 1f, hy - 10f), Size(2 * hw + 2f, 24f), 12f, c, 3f)
        5 -> circleOutlined(Offset(x, hy - 8f), hw + 14f, c, 3f)
        6 -> {
            roundRectOutlined(Offset(x - hw - 2f, hy - 8f), Size(2 * hw + 4f, 30f), 12f, c, 3f)
            for (i in -2..2) circleOutlined(Offset(x + i * (hw / 1.8f), hy + 20f + (abs(i) % 2) * 6f), 11f, c, 3f)
        }
        7 -> roundRectOutlined(Offset(x - hw - 6f, hy - 16f), Size(2 * hw + 12f, 42f), 20f, c, 3f)
    }
}

internal fun DrawScope.drawHairFront(look: Look, x: Float, hy: Float) {
    val hd = Look.HAIRS[look.hair.coerceIn(0, 29)]
    val c = Color(look.hairColor)
    val hw = faceHW(look.face)
    val ht = faceHT(look.face)
    val tl = Offset(x - hw - 1f, hy - ht - 1f)
    val sz = Size(2 * hw + 2f, 2 * ht + 2f)
    fun cap() {
        drawArc(c, 180f, 180f, true, tl, sz)
        drawArc(OUT, 180f, 180f, false, tl, sz, style = Stroke(3f))
    }

    when (hd.top) {
        1 -> cap()
        2 -> {
            drawArc(c, 200f, 140f, true, tl, sz)
            drawArc(OUT, 200f, 140f, false, tl, sz, style = Stroke(3f))
        }
        3 -> {
            cap()
            for (i in -2..2) {
                val bx = x + i * 9f
                val apex = hy - ht - 12f - (3 - abs(i)) * 3f
                val p = Path().apply {
                    moveTo(bx - 6f, hy - ht + 5f)
                    lineTo(bx, apex)
                    lineTo(bx + 6f, hy - ht + 5f)
                    close()
                }
                drawPath(p, c)
                drawPath(p, OUT, style = Stroke(2.5f))
            }
        }
        4 -> cap()
        5 -> cap()
        6 -> cap()
    }
    if (look.highlight && hd.top != 0) {
        drawArc(
            Color(look.highlightColor).copy(alpha = 0.9f),
            235f, 50f, false,
            Offset(x - hw + 5f, hy - ht + 5f),
            Size(2 * hw - 10f, 2 * ht - 10f),
            style = Stroke(5f, cap = StrokeCap.Round)
        )
    }
}

internal fun DrawScope.drawOutfit(look: Look, x: Float, y: Float, bob: Float) {
    val col = Color(look.outfitColor)
    val top = y - 32f - bob
    val dark = Color(col.red * 0.85f, col.green * 0.85f, col.blue * 0.85f)

    when (look.fullOutfit) {
        "pajama" -> {
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            for ((dx, dy) in listOf(-6f to 7f, 5f to 5f, 0f to 15f)) {
                drawCircle(Color.White.copy(alpha = 0.85f), 2.2f, Offset(x + dx, top + dy))
            }
        }
        "hoodie" -> {
            circleOutlined(Offset(x, top + 2f), 11f, col, 3f)
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            roundRectOutlined(Offset(x - 8f, top + 14f), Size(16f, 8f), 4f, dark, 2f)
            drawLine(OUT, Offset(x - 3f, top + 3f), Offset(x - 3f, top + 9f), 2f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 3f, top + 3f), Offset(x + 3f, top + 9f), 2f, StrokeCap.Round)
        }
        "dress_casual", "cute_dress", "party_dress", "sun_dress" -> {
            val skirt = Path().apply {
                moveTo(x - 11f, top + 16f)
                lineTo(x + 11f, top + 16f)
                lineTo(x + 20f, y - 4f)
                lineTo(x - 20f, y - 4f)
                close()
            }
            drawPath(skirt, col)
            drawPath(skirt, OUT, style = Stroke(3f))
            roundRectOutlined(Offset(x - 12f, top), Size(24f, 20f), 9f, col, 3f)
        }
        "overalls", "farmer_overalls" -> {
            roundRectOutlined(Offset(x - 12f, top), Size(24f, 28f), 8f, col, 3f)
            roundRectOutlined(Offset(x - 10f, top - 4f), Size(8f, 14f), 3f, col, 2f)
            roundRectOutlined(Offset(x + 2f, top - 4f), Size(8f, 14f), 3f, col, 2f)
            drawLine(dark, Offset(x - 12f, top + 6f), Offset(x + 12f, top + 6f), 2f)
        }
        "sporty", "tracksuit" -> {
            roundRectOutlined(Offset(x - 13f, top), Size(26f, 14f), 8f, col, 3f)
            roundRectOutlined(Offset(x - 12f, top + 12f), Size(10f, 14f), 4f, col, 2f)
            roundRectOutlined(Offset(x + 2f, top + 12f), Size(10f, 14f), 4f, col, 2f)
        }
        else -> {
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            drawCircle(Color.White.copy(alpha = 0.7f), 3.5f, Offset(x, top + 12f))
        }
    }
}

@Composable
fun AvatarPreview(look: Look, size: Float = 100f) {
    Canvas(modifier = Modifier.size(size.dp)) {
        val cx = size / 2f
        val cy = size / 2f
        val skinColor = Color(Look.SKINS[look.skin.coerceIn(0, 7)])
        drawHairBack(look, cx, cy)
        drawHead(look, cx, cy, skinColor)
        drawHairFront(look, cx, cy)
        drawOutfit(look, cx, cy + 22f, 0f)
    }
}
