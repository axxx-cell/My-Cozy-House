package com.cozy.house.game

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.AudioTrack
import android.media.MediaRecorder
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.cozy.house.net.Net
import kotlinx.coroutines.*
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.InetSocketAddress
import java.net.SocketAddress
import java.util.concurrent.ConcurrentHashMap
import kotlin.math.max

/**
 * Push-to-talk voice over UDP (port 8889), straight between phones.
 * 16 kHz, mono, 16-bit, squeezed to 8 bits with A-law. One packet = 20 ms = 324 bytes.
 * Packet: [sender number][1][seq hi][seq lo][320 bytes of A-law].
 */
class VoiceManager {
    var muted by mutableStateOf(false)
    var talking by mutableStateOf(false)

    private var scope: CoroutineScope? = null
    private var socket: DatagramSocket? = null
    private var myNumber: () -> Int = { 0 }
    private var peers: () -> List<String> = { emptyList() }
    private val lastHeard = ConcurrentHashMap<Int, Long>()
    private val tracks = ConcurrentHashMap<Int, AudioTrack>()
    private val addrCache = ConcurrentHashMap<String, InetAddress>()
    private var seq = 0

    companion object {
        private const val RATE = 16000
        private const val FRAME = 320   // 20 ms
    }

    fun start(myNumber: () -> Int, peers: () -> List<String>) {
        stop()
        this.myNumber = myNumber
        this.peers = peers
        try {
            socket = DatagramSocket(null as SocketAddress?).apply {
                reuseAddress = true
                bind(InetSocketAddress(Net.VOICE_PORT))
            }
        } catch (e: Exception) {
            socket = null   // voice just stays off, the game still works
            return
        }
        val s = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        scope = s
        s.launch { receiveLoop() }
    }

    fun stop() {
        talking = false
        scope?.cancel(); scope = null
        runCatching { socket?.close() }
        socket = null
        tracks.values.forEach { runCatching { it.stop(); it.release() } }
        tracks.clear()
    }

    fun toggleMute() {
        muted = !muted
        if (muted) talking = false
    }

    fun isSpeaking(id: String): Boolean {
        val n = id.filter { it.isDigit() }.toIntOrNull() ?: return false
        val t = lastHeard[n] ?: return false
        return System.currentTimeMillis() - t < 400
    }

    // ------------------------------------------------------------ talk

    fun startTalking() {
        val s = scope ?: return
        if (muted || talking || socket == null) return
        talking = true
        s.launch { capture() }
    }

    fun stopTalking() { talking = false }

    private suspend fun capture() {
        val sock = socket ?: run { talking = false; return }
        var rec: AudioRecord? = null
        try {
            val minBuf = AudioRecord.getMinBufferSize(RATE, AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT)
            rec = AudioRecord(
                MediaRecorder.AudioSource.MIC, RATE, AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT, max(minBuf, FRAME * 2 * 10)
            )
            if (rec.state != AudioRecord.STATE_INITIALIZED) return
            rec.startRecording()
            val pcm = ShortArray(FRAME)
            val pkt = ByteArray(4 + FRAME)
            while (talking && currentCoroutineContext().isActive) {
                var got = 0
                while (got < FRAME && talking) {
                    val n = rec.read(pcm, got, FRAME - got)
                    if (n <= 0) break
                    got += n
                }
                if (got < FRAME) break
                seq = (seq + 1) and 0xFFFF
                pkt[0] = myNumber().toByte()
                pkt[1] = 1
                pkt[2] = (seq shr 8).toByte()
                pkt[3] = seq.toByte()
                for (i in 0 until FRAME) pkt[4 + i] = linearToALaw(pcm[i])
                for (ip in peers()) {
                    try {
                        val addr = addrCache.getOrPut(ip) { InetAddress.getByName(ip) }
                        sock.send(DatagramPacket(pkt, pkt.size, addr, Net.VOICE_PORT))
                    } catch (_: Exception) {}
                }
            }
        } catch (_: Exception) {
        } finally {
            runCatching { rec?.stop() }
            runCatching { rec?.release() }
            talking = false
        }
    }

    // ------------------------------------------------------------ listen

    private suspend fun receiveLoop() {
        val s = socket ?: return
        val buf = ByteArray(1024)
        while (currentCoroutineContext().isActive && !s.isClosed) {
            val p = DatagramPacket(buf, buf.size)
            try { s.receive(p) } catch (e: Exception) { if (s.isClosed) break else continue }
            if (p.length <= 4) continue
            val num = buf[0].toInt() and 0xFF
            if (num == myNumber() || buf[1].toInt() != 1) continue
            lastHeard[num] = System.currentTimeMillis()
            if (muted) continue
            val n = p.length - 4
            val pcm = ShortArray(n)
            for (i in 0 until n) pcm[i] = alawToLinear(buf[4 + i])
            trackFor(num)?.write(pcm, 0, n)
        }
    }

    private fun trackFor(num: Int): AudioTrack? {
        tracks[num]?.let { return it }
        return try {
            val min = AudioTrack.getMinBufferSize(RATE, AudioFormat.CHANNEL_OUT_MONO, AudioFormat.ENCODING_PCM_16BIT)
            val t = AudioTrack.Builder()
                .setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_MEDIA)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH).build()
                )
                .setAudioFormat(
                    AudioFormat.Builder()
                        .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                        .setSampleRate(RATE)
                        .setChannelMask(AudioFormat.CHANNEL_OUT_MONO).build()
                )
                .setBufferSizeInBytes(max(min, FRAME * 2 * 8))
                .setTransferMode(AudioTrack.MODE_STREAM)
                .build()
            t.play()
            tracks[num] = t
            t
        } catch (e: Exception) { null }
    }

    // ------------------------------------------------------------ G.711 A-law

    private val segEnd = intArrayOf(0x1F, 0x3F, 0x7F, 0xFF, 0x1FF, 0x3FF, 0x7FF, 0xFFF)

    private fun linearToALaw(sample: Short): Byte {
        var v = sample.toInt() shr 3
        val mask: Int
        if (v >= 0) mask = 0xD5 else { mask = 0x55; v = -v - 1 }
        var seg = 8
        for (i in 0 until 8) if (v <= segEnd[i]) { seg = i; break }
        if (seg >= 8) return (0x7F xor mask).toByte()
        var a = seg shl 4
        a = a or (if (seg < 2) (v shr 1) and 0xF else (v shr seg) and 0xF)
        return (a xor mask).toByte()
    }

    private fun alawToLinear(b: Byte): Short {
        val a = (b.toInt() and 0xFF) xor 0x55
        var t = (a and 0xF) shl 4
        val seg = (a and 0x70) shr 4
        when (seg) {
            0 -> t += 8
            1 -> t += 0x108
            else -> { t += 0x108; t = t shl (seg - 1) }
        }
        return (if (a and 0x80 != 0) t else -t).toShort()
    }
}
