package com.cozy.house.game

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.cozy.house.Cozy
import com.cozy.house.Session
import com.cozy.house.net.Area
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private val OUT = Color(0xFF5B3A4A)
private val SHIRTS = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B))
private val HAIRS = listOf(Color(0xFF7B4B3A), Color(0xFF2F2A41), Color(0xFFE9A15B), Color(0xFFB57BDB))
private val SKIN = Color(0xFFFFE0C7)

private class Paints {
    val room = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 46f; color = 0x2E5B3A4A }
    val chat = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 14f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val emoji = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER }
    val nameFill = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val nameStroke = Paint().apply {
        isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
}

@Composable
fun GameScreen(onExit: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    val pm = remember { PlayerManager() }
    val paints = remember { Paints() }
    var tick by remember { mutableStateOf(0L) }
    var leaving by remember { mutableStateOf(false) }
    var showEmotes by remember { mutableStateOf(false) }
    var chatOpen by remember { mutableStateOf(false) }
    var chatText by remember { mutableStateOf("") }
    val ctx = LocalContext.current
    val voice = remember { VoiceManager() }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pm.toast = if (granted) "Mic ready! Hold 🎤 to talk" else "Mic is off. You can still chat with text!"
    }
    DisposableEffect(Unit) {
        voice.start(myNumber = { pm.myNumber() }, peers = { pm.peerIps() })
        onDispose { voice.stop() }
    }

    LaunchedEffect(Session.host, Session.client) {
        GameNet.current()?.let { pm.runNetwork(it) }
    }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) pm.update(((now - last) / 1_000_000_000f).coerceAtMost(0.05f))
                last = now
                tick = now
            }
        }
    }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { if (chatOpen) chatOpen = false else if (showEmotes) showEmotes = false else leave() }

    Box(Modifier.fillMaxSize().background(Cozy.Cream)) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val frame = tick
            val s = size.height / 520f
            val viewW = size.width / s
            val viewH = 520f
            val me = pm.me
            val camX = ((me?.x ?: World.W / 2f) - viewW / 2f).coerceIn(0f, max(0f, World.W - viewW))
            val camY = ((me?.y ?: World.H / 2f) - viewH / 2f).coerceIn(0f, max(0f, World.H - viewH))

            withTransform({
                scale(s, s, Offset.Zero)
                translate(-camX, -camY)
            }) {
                drawWorld(paints)
                for (d in pm.dust) {
                    val life = 1f - d.age / 0.5f
                    drawCircle(Color(0xFFF2E3D0).copy(alpha = 0.6f * life), 3f + d.age * 14f, Offset(d.x, d.y))
                }

                // carried players are drawn right after (on top of) their carrier
                val all = pm.players.values.sortedBy { p ->
                    val c = p.carriedBy?.let { pm.players[it] }
                    if (c != null) c.y + 0.5f else p.y
                }
                for (p in all) {
                    val c = p.carriedBy?.let { pm.players[it] }
                    val near = pm.players.values.any { o -> o !== p && hyp(o.x - p.x, o.y - p.y) < 90f }
                    val talk = if (p.id == pm.myId) voice.talking else voice.isSpeaking(p.id)
                    if (c != null) drawPlayer(p, p.id == pm.myId, near, paints, c.x + 8f, c.y - 36f, carried = true, speaking = talk)
                    else drawPlayer(p, p.id == pm.myId, near, paints, p.x, p.y, carried = false, speaking = talk)
                }
                for (q in pm.particles) drawParticle(q, paints)
            }
        }

        // ---- top-left: leave
        Box(
            Modifier.align(Alignment.TopStart).padding(12.dp)
                .background(Cozy.Pink, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                .clickable { leave() }.padding(horizontal = 14.dp, vertical = 6.dp)
        ) { Text("✕ Leave", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }

        // ---- top-center: where am I
        if (pm.areaName.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(12.dp)
                    .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("📍 ${pm.areaName}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- top-right: stats
        Row(
            Modifier.align(Alignment.TopEnd).padding(12.dp)
                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatBar("⚡", pm.energy, Color(0xFFFFD86B))
            StatBar("🍙", pm.hunger, Color(0xFFFFA97A))
            StatBar("😊", pm.happiness, Color(0xFFFF9EC4))
            Text("🪙 ${pm.coins}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
        }

        // ---- left side: chat, push-to-talk, mute
        Column(
            Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 58.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Box(
                    Modifier.size(44.dp).background(Cozy.Blue, CircleShape).border(3.dp, OUT, CircleShape)
                        .clickable { chatOpen = !chatOpen; if (chatOpen) pm.unread = 0 },
                    contentAlignment = Alignment.Center
                ) { Text("💬", fontSize = 20.sp) }
                if (pm.unread > 0 && !chatOpen) {
                    Box(Modifier.size(14.dp).background(Color(0xFFFF4D6D), CircleShape).border(2.dp, OUT, CircleShape))
                }
            }
            Box(
                Modifier.size(44.dp)
                    .background(if (voice.talking) Cozy.Pink else Cozy.Mint, CircleShape)
                    .border(3.dp, OUT, CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                voice.startTalking()
                                tryAwaitRelease()
                                voice.stopTalking()
                            } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Text("🎤", fontSize = 20.sp) }
            Box(
                Modifier.size(44.dp).background(if (voice.muted) Cozy.Pink else Cozy.Yellow, CircleShape)
                    .border(3.dp, OUT, CircleShape).clickable { voice.toggleMute() },
                contentAlignment = Alignment.Center
            ) { Text(if (voice.muted) "🔇" else "🔊", fontSize = 20.sp) }
        }

        // ---- chat panel
        if (chatOpen) {
            Column(
                Modifier.align(Alignment.TopCenter).padding(top = 56.dp).width(340.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(18.dp))
                    .border(3.dp, OUT, RoundedCornerShape(18.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (pm.chatLog.isEmpty()) Text("Say hi to your friends! 👋", fontSize = 13.sp, color = OUT)
                pm.chatLog.takeLast(4).forEach { Text(it, fontSize = 13.sp, color = OUT) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = chatText,
                        onValueChange = { if (it.length <= 60) chatText = it },
                        singleLine = true,
                        placeholder = { Text("Say something…", fontSize = 13.sp) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Pill("Send") { pm.sendChat(chatText); chatText = ""; chatOpen = false }
                }
            }
        }

        // ---- toast
        pm.toast?.let {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)
                    .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(it, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- friend actions (only when a friend is close, or while carrying / carried)
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                pm.carriedById != null -> Pill("⬇️ Get down") { pm.getDown() }
                pm.carryingId != null -> Pill("⬇️ Put down") { pm.toggleCarry() }
                pm.nearbyFriend != null -> {
                    Pill("🤗 Hug") { pm.hug() }
                    Pill("🙌 High five") { pm.highFive() }
                    Pill("🎒 Carry") { pm.toggleCarry() }
                }
            }
        }

        // ---- emotes
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 52.dp, bottom = 140.dp).size(64.dp)
                .background(Cozy.Yellow, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { showEmotes = !showEmotes },
            contentAlignment = Alignment.Center
        ) { Text("😊", fontSize = 28.sp) }

        if (showEmotes) {
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 124.dp, bottom = 120.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Emote.values().toList().chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { e ->
                            Box(
                                Modifier.size(44.dp).background(Cozy.Cream, CircleShape).border(2.dp, OUT, CircleShape)
                                    .clickable { pm.emote(e); showEmotes = false },
                                contentAlignment = Alignment.Center
                            ) { Text(e.emoji, fontSize = 22.sp) }
                        }
                    }
                }
            }
        }

        // ---- joystick left, interact right
        Joystick(
            Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 24.dp),
            onMove = { x, y -> pm.joyX = x; pm.joyY = y }
        )
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 36.dp, bottom = 36.dp).size(92.dp)
                .background(Cozy.Mint, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { pm.interact() },
            contentAlignment = Alignment.Center
        ) { Text("✋", fontSize = 36.sp) }
    }
}

private fun hyp(a: Float, b: Float) = sqrt(a * a + b * b)

@Composable
private fun StatBar(icon: String, value: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 16.sp)
        Box(
            Modifier.width(52.dp).height(12.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(6.dp))
                .border(2.dp, OUT, RoundedCornerShape(6.dp))
        ) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0, 100) / 100f).background(color, RoundedCornerShape(6.dp)))
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
}

// ------------------------------------------------------------------ joystick

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier.size(150.dp).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f * 0.6f
                fun update(p: Offset) {
                    var d = p - center
                    val len = d.getDistance()
                    if (len > radius) d = d * (radius / len)
                    knob = d
                    onMove(d.x / radius, d.y / radius)
                }
                update(down.position)
                var pressed = true
                while (pressed) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id }
                    if (change != null && change.pressed) {
                        update(change.position)
                        change.consume()
                    } else pressed = false
                }
                knob = Offset.Zero
                onMove(0f, 0f)
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.White.copy(alpha = 0.55f), size.width / 2f - 4f, c)
            drawCircle(OUT, size.width / 2f - 4f, c, style = Stroke(5f))
            drawCircle(Cozy.Pink, 30.dp.toPx(), c + knob)
            drawCircle(OUT, 30.dp.toPx(), c + knob, style = Stroke(5f))
        }
    }
}

// ------------------------------------------------------------------ drawing (world units)

private fun DrawScope.roundRectOutlined(tl: Offset, sz: Size, radius: Float, fill: Color, stroke: Float = 4f) {
    drawRoundRect(fill, tl, sz, CornerRadius(radius))
    drawRoundRect(OUT, tl, sz, CornerRadius(radius), style = Stroke(stroke))
}

private fun DrawScope.circleOutlined(c: Offset, r: Float, fill: Color, stroke: Float = 3f) {
    drawCircle(fill, r, c)
    drawCircle(OUT, r, c, style = Stroke(stroke))
}

private fun floorColor(a: Area) = when (a) {
    Area.BEDROOM -> Color(0xFFFFE3F0)
    Area.LIVING_ROOM -> Color(0xFFFFF3D6)
    Area.KITCHEN -> Color(0xFFE0F7EA)
    Area.BATHROOM -> Color(0xFFE0F0FF)
    Area.GARDEN -> Color(0xFFC9F0B8)
    Area.PLAYGROUND -> Color(0xFFFBE9B7)
    Area.TOWN -> Color(0xFFE8E8E8)
}

private fun DrawScope.drawWorld(paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas

    for ((area, r) in World.rooms) {
        drawRect(floorColor(area), r.topLeft, r.size)
        if (area == Area.KITCHEN || area == Area.BATHROOM) {
            val alt = if (area == Area.KITCHEN) Color(0xFFCFF0DD) else Color(0xFFCDE6FA)
            var iy = 0
            var y = r.top
            while (y < r.bottom) {
                var ix = 0
                var x = r.left
                while (x < r.right) {
                    if ((ix + iy) % 2 == 0) drawRect(alt, Offset(x, y), Size(80f, 80f))
                    x += 80f; ix++
                }
                y += 80f; iy++
            }
        }
        nc.drawText(World.areaLabel(area), r.center.x, r.top + 80f, paints.room)
    }

    for (f in World.furniture.sortedBy { if (it.solid) 1 else 0 }) {
        roundRectOutlined(f.rect.topLeft, f.rect.size, 14f, f.color)
        if (f.emoji.isNotEmpty()) {
            paints.emoji.alpha = 255
            paints.emoji.textSize = min(f.rect.width, f.rect.height) * 0.6f
            nc.drawText(f.emoji, f.rect.center.x, f.rect.center.y + paints.emoji.textSize * 0.35f, paints.emoji)
        }
    }

    for (w in World.walls) roundRectOutlined(w.topLeft, w.size, 8f, Color(0xFFE9B8CB), 4f)
}

private fun DrawScope.drawParticle(q: Particle, paints: Paints) {
    val life = (1f - q.age / q.life).coerceIn(0f, 1f)
    if (q.kind == 0) {
        val nc = drawContext.canvas.nativeCanvas
        paints.emoji.textSize = 20f
        paints.emoji.alpha = (255 * life).toInt()
        nc.drawText("💗", q.x, q.y, paints.emoji)
        paints.emoji.alpha = 255
    } else {
        val c = q.color.copy(alpha = life)
        withTransform({ rotate(q.spin * q.age, Offset(q.x, q.y)) }) {
            drawRect(c, Offset(q.x - 4f, q.y - 2.5f), Size(8f, 5f))
        }
    }
}

private fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    drawLine(color, Offset(c.x - r, c.y), Offset(c.x + r, c.y), 2.5f, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y - r), Offset(c.x, c.y + r), 2.5f, StrokeCap.Round)
}

private fun wrapChat(text: String, paint: Paint, maxW: Float): List<String> {
    val lines = ArrayList<String>()
    var cur = ""
    for (w in text.split(" ").flatMap { it.chunked(18) }) {
        val trial = if (cur.isEmpty()) w else "$cur $w"
        if (cur.isEmpty() || paint.measureText(trial) <= maxW) cur = trial else { lines.add(cur); cur = w }
        if (lines.size >= 3) break
    }
    if (cur.isNotEmpty() && lines.size < 3) lines.add(cur)
    return lines
}

private fun DrawScope.drawPlayer(
    p: PlayerState, isMe: Boolean, near: Boolean, paints: Paints,
    px: Float, py: Float, carried: Boolean, speaking: Boolean
) {
    val nc = drawContext.canvas.nativeCanvas
    val t = p.animT
    val emote = p.emote
    val et = p.emoteT
    val happy = p.happiness
    val sad = happy < 30
    val joy = happy > 80

    val run = t * (if (joy) 17f else 14f)
    var bob = if (p.moving && !carried) abs(sin(run)) * 5f else sin(t * 2.5f) * 1.5f
    val step = if (p.moving && !carried) sin(run) * 5f else 0f

    // emote body animations
    var dx = 0f
    if (emote != null) {
        if (et < 0.4f) bob += abs(sin(et / 0.4f * PI.toFloat())) * 10f      // little hop for every emote
        when (emote) {
            Emote.DANCE -> { dx = sin(et * 10f) * 6f; bob += abs(sin(et * 10f)) * 6f }
            Emote.LAUGH, Emote.ANGRY -> dx = sin(et * 40f) * 1.5f
            else -> {}
        }
    }
    val x = px + dx
    val y = py

    val shirt = SHIRTS[p.colorIndex % 4]
    val hair = HAIRS[p.colorIndex % 4]
    val headY = y - 52f - bob

    // shadow + feet (not for carried: they sit on a back)
    if (!carried) {
        drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 17f, y - 6f), Size(34f, 12f))
        circleOutlined(Offset(x - 8f, y - 4f - max(0f, step)), 7f, Color.White)
        circleOutlined(Offset(x + 8f, y - 4f - max(0f, -step)), 7f, Color.White)
    } else {
        circleOutlined(Offset(x - 8f, y - 4f), 6f, Color.White)
        circleOutlined(Offset(x + 8f, y - 4f), 6f, Color.White)
    }

    // body + head
    roundRectOutlined(Offset(x - 14f, y - 32f - bob), Size(28f, 26f), 10f, shirt, 3f)
    circleOutlined(Offset(x, headY), 22f, SKIN)
    drawArc(hair, 180f, 180f, true, Offset(x - 23f, headY - 23f), Size(46f, 46f))
    drawArc(OUT, 180f, 180f, false, Offset(x - 23f, headY - 23f), Size(46f, 46f), style = Stroke(3f))

    // eyes
    val eyeY = headY + 4f
    if (emote == Emote.COOL) {
        roundRectOutlined(Offset(x - 17f, eyeY - 7f), Size(34f, 13f), 6f, Color(0xFF2F2A41), 2.5f)
    } else {
        for (sx in listOf(-9f, 9f)) {
            val cx = x + sx + 2f * p.facing
            val closed = p.blinkLeft > 0f || emote == Emote.LAUGH || emote == Emote.SLEEPY
            if (closed) {
                drawLine(OUT, Offset(cx - 5f, eyeY), Offset(cx + 5f, eyeY), 3f, StrokeCap.Round)
            } else {
                val big = if (emote == Emote.SURPRISE) 3f else 0f
                drawOval(OUT, Offset(cx - 5f - big / 2f, eyeY - 7f - big), Size(10f + big, 14f + big))
                drawCircle(Color.White, 2.2f, Offset(cx - 1f, eyeY - 3f))
            }
            if (emote == Emote.ANGRY) {
                val s = if (sx < 0) 1f else -1f
                drawLine(OUT, Offset(cx - 6f * s, eyeY - 13f), Offset(cx + 5f * s, eyeY - 8f), 3f, StrokeCap.Round)
            }
            if (emote == Emote.CRY) {
                val ty = eyeY + 6f + (et * 40f) % 22f
                drawCircle(Color(0xFF7CC4FF), 3f, Offset(cx, ty))
            }
        }
    }

    // cheeks: blush near friends, red when angry, green when sick
    val cheek = when {
        emote == Emote.ANGRY -> Color(0xFFFF4D4D).copy(alpha = 0.6f)
        emote == Emote.SICK -> Color(0xFF8FD18F).copy(alpha = 0.8f)
        near -> Color(0xFFFF7FA5).copy(alpha = 0.65f)
        else -> null
    }
    if (cheek != null) {
        drawCircle(cheek, 6f, Offset(x - 15f, eyeY + 9f))
        drawCircle(cheek, 6f, Offset(x + 15f, eyeY + 9f))
    }

    // mouth: sad frown, surprised O, happy smile
    when {
        emote == Emote.SURPRISE -> circleOutlined(Offset(x, eyeY + 10f), 3.5f, Color.White, 2f)
        sad || emote == Emote.CRY || emote == Emote.SICK ->
            drawArc(OUT, 200f, 140f, false, Offset(x - 5f, eyeY + 8f), Size(10f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))
        else ->
            drawArc(OUT, 20f, 140f, false, Offset(x - 5f, eyeY + 4f), Size(10f, 8f), style = Stroke(if (joy) 3.5f else 2.5f, cap = StrokeCap.Round))
    }

    // wave hand
    if (emote == Emote.WAVE) {
        val hx = x + 24f
        val hy = headY + 6f + sin(et * 14f) * 7f
        drawLine(OUT, Offset(x + 14f, y - 26f - bob), Offset(hx, hy), 5f, StrokeCap.Round)
        circleOutlined(Offset(hx, hy), 6f, SKIN, 2.5f)
    }
    // sleepy Zz
    if (emote == Emote.SLEEPY) {
        nc.drawText("Z", x + 24f, headY - 8f - (et * 14f) % 18f, paints.nameFill)
        nc.drawText("z", x + 34f, headY - 18f - (et * 14f) % 18f, paints.nameFill)
    }

    // name
    val nameY = headY - 30f
    nc.drawText(p.name, x, nameY, paints.nameStroke)
    nc.drawText(p.name, x, nameY, paints.nameFill)
    if (isMe) drawCircle(Cozy.Pink, 4f, Offset(x, nameY - 20f))
    if (speaking) {
        paints.emoji.textSize = 15f
        paints.emoji.alpha = 255
        nc.drawText("🔊", x + paints.nameFill.measureText(p.name) / 2f + 14f, nameY, paints.emoji)
    }

    // happy sparkles
    if (joy) {
        for (i in 0..2) {
            val a = t * 2f + i * 2.1f
            val tw = 0.5f + 0.5f * sin(t * 6f + i)
            sparkle(Offset(x + cos(a) * 32f, headY + sin(a) * 20f), 3f + 3f * tw, Color(0xFFFFC93C).copy(alpha = 0.6f + 0.4f * tw))
        }
    }
    // sad rain cloud + rain
    if (sad) {
        val cy = headY - 58f
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(OUT, r + 2.5f, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(Color(0xFFC5CFE0), r, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for (i in 0..2) {
            val ry = (t * 60f + i * 13f) % 24f
            drawLine(Color(0xFF7CC4FF), Offset(x - 10f + i * 10f, cy + 12f + ry), Offset(x - 10f + i * 10f, cy + 17f + ry), 2f, StrokeCap.Round)
        }
    }

    // chat bubble (5 seconds, fades out)
    val chat = p.chat
    if (chat != null) {
        val lines = wrapChat(chat, paints.chat, 150f)
        val w = (lines.maxOfOrNull { paints.chat.measureText(it) } ?: 0f) + 18f
        val h = lines.size * 17f + 10f
        val a = if (p.chatT > 4.5f) ((5f - p.chatT) / 0.5f).coerceIn(0f, 1f) else 1f
        val bottom = headY - 100f
        val top = bottom - h
        roundRectOutlined(Offset(x - w / 2f, top), Size(w, h), 12f, Color.White.copy(alpha = a), 3f)
        val tail = Path().apply { moveTo(x - 6f, bottom - 1f); lineTo(x + 6f, bottom - 1f); lineTo(x, bottom + 8f); close() }
        drawPath(tail, Color.White.copy(alpha = a))
        drawLine(OUT.copy(alpha = a), Offset(x - 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        drawLine(OUT.copy(alpha = a), Offset(x + 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        paints.chat.alpha = (255 * a).toInt()
        lines.forEachIndexed { i, l -> nc.drawText(l, x, top + 18f + i * 17f, paints.chat) }
        paints.chat.alpha = 255
    }

    // emote bubble (pops in, floats, fades out)
    if (emote != null) {
        val pop = if (et < 0.2f) 0.4f + (et / 0.2f) * 0.8f else if (et < 0.3f) 1.2f - (et - 0.2f) * 2f else 1f
        val alpha = if (et > 2.1f) ((2.5f - et) / 0.4f).coerceIn(0f, 1f) else 1f
        val bx = x
        val by = headY - 78f - min(et, 1f) * 6f
        withTransform({ scale(pop, pop, Offset(bx, by)) }) {
            roundRectOutlined(Offset(bx - 20f, by - 18f), Size(40f, 34f), 14f, Color.White.copy(alpha = alpha), 3f)
            paints.emoji.textSize = 24f
            paints.emoji.alpha = (255 * alpha).toInt()
            nc.drawText(emote.emoji, bx, by + 8f, paints.emoji)
            paints.emoji.alpha = 255
        }
    }
}
