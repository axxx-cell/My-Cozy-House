package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

enum class Crop(val emoji: String, val label: String) {
    CARROT("🥕", "Carrot"), TOMATO("🍅", "Tomato"), CORN("🌽", "Corn"),
    STRAWBERRY("🍓", "Strawberry"), PUMPKIN("🎃", "Pumpkin"), SUNFLOWER("🌻", "Sunflower (rare)"),
}

enum class Weather(val emoji: String) { SUNNY("☀️"), CLOUDY("☁️"), RAINY("🌧️") }

class Plot {
    var crop = -1          // -1 = empty, else index into Crop
    var growMs = 0f
    var wetMs = 0f         // soil stays wet for 90 s after watering
    fun ready() = crop >= 0 && growMs >= FarmManager.GROW_MS
}

/**
 * The shared farm. Every phone simulates the same simple rules; the HOST is the authority:
 * it applies everybody's actions, rolls the weather, and sends the full state every 2 s.
 *
 * Rules: a planted crop grows only while the soil is wet. One watering (or rain) is enough
 * for the whole 60 s growth. Nothing ever dies. Stages: Sprout (0-30 s), Small (30-60 s), Full = ready.
 */
/** One thing you can buy for the greenhouse. */
class GreenhouseUp(val key: String, val label: String, val price: Int)

class FarmManager {
    companion object {
        const val GROW_MS = 60_000f
        const val WET_MS = 90_000f
        const val MAX_PLOTS = 12

        val UPGRADES = listOf(
            GreenhouseUp("P1", "More plots (4 in total)", 50),
            GreenhouseUp("CARROT", "Carrot seeds 🥕", 100),
            GreenhouseUp("CAN", "Watering can: soil stays wet 2x longer 💧", 150),
            GreenhouseUp("P2", "More plots (6 in total)", 250),
            GreenhouseUp("PUMPKIN", "Pumpkin seeds 🎃", 400),
            GreenhouseUp("P3", "More plots (8 in total)", 600),
            GreenhouseUp("BIG", "Big greenhouse: 12 plots", 600),
            GreenhouseUp("BERRY", "Strawberry + Sunflower seeds 🍓🌻", 800),
        )
    }

    val plots = Array(MAX_PLOTS) { Plot() }

    /** What you bought for the greenhouse (shared by the whole house). Houses saved before this update have everything. */
    val unlocked = mutableStateListOf<String>()
    private var legacy = false

    fun has(key: String) = legacy || key in unlocked
    fun plotCount(): Int = when {
        legacy || "BIG" in unlocked -> MAX_PLOTS
        else -> min(8, 2 + 2 * listOf("P1", "P2", "P3").count { it in unlocked })
    }
    /** Tomato and Corn from the start; the rest is bought. */
    fun cropOk(c: Int): Boolean = when (c) {
        Crop.CARROT.ordinal -> has("CARROT")
        Crop.PUMPKIN.ordinal -> has("PUMPKIN")
        Crop.STRAWBERRY.ordinal, Crop.SUNFLOWER.ordinal -> has("BERRY")
        else -> true
    }
    val seeds = mutableStateListOf(3, 3, 3, 3, 3, 1)           // shared seed inventory (per Crop)
    val harvested = mutableStateListOf(1, 1, 0, 0, 0, 0)       // shared harvested crops
    var weather by mutableStateOf(Weather.SUNNY)
    var selectedSeed by mutableStateOf(0)                       // local choice, not synced
    private var weatherLeft = 45f

    fun nearestPlot(x: Float, y: Float): Int? =
        World.plots.withIndex()
            .minByOrNull { World.distanceTo(it.value, x, y) }
            ?.takeIf { World.distanceTo(it.value, x, y) < 70f }
            ?.index

    fun tick(dt: Float, isHost: Boolean) {
        val ms = dt * 1000f
        for (p in plots) {
            if (p.crop < 0) continue
            if (weather == Weather.RAINY) p.wetMs = WET_MS      // rain auto-waters
            if (p.wetMs > 0f) {
                p.growMs = min(GROW_MS, p.growMs + ms)
                p.wetMs = max(0f, p.wetMs - ms)
            }
        }
        if (isHost) {
            weatherLeft -= dt
            if (weatherLeft <= 0f) {
                val r = Math.random()
                weather = if (r < 0.5) Weather.SUNNY else if (r < 0.75) Weather.CLOUDY else Weather.RAINY
                weatherLeft = 40f + Math.random().toFloat() * 40f
            }
        }
    }

    /** Same rules on host and clients. Returns true if it changed anything. */
    fun apply(op: String, idx: Int, crop: Int): Boolean {
        if (op == "UNLOCK") {
            val u = UPGRADES.getOrNull(idx) ?: return false
            if (legacy || u.key in unlocked) return false
            unlocked.add(u.key); return true
        }
        if (idx !in plots.indices) return false
        val p = plots[idx]
        return when (op) {
            "PLANT" -> if (idx < plotCount() && cropOk(crop) && p.crop < 0 && crop in 0..5 && seeds[crop] > 0) {
                p.crop = crop; p.growMs = 0f; p.wetMs = 0f
                seeds[crop] = seeds[crop] - 1
                true
            } else false
            "WATER" -> if (p.crop >= 0) { p.wetMs = if (has("CAN")) WET_MS * 2f else WET_MS; true } else false
            "GIVE" -> if (crop in 0..5) { seeds[crop] = seeds[crop] + 1; true } else false   // free seeds from Grandma / mailman
            "HARVEST" -> if (p.ready()) {
                harvested[p.crop] = harvested[p.crop] + 1
                p.crop = -1; p.growMs = 0f; p.wetMs = 0f
                true
            } else false
            else -> false
        }
    }

    fun toJson(): JSONObject {
        val pa = JSONArray()
        plots.forEach { pa.put(JSONArray().put(it.crop).put(it.growMs.toInt()).put(it.wetMs.toInt())) }
        return JSONObject()
            .put("w", weather.ordinal)
            .put("p", pa)
            .put("s", JSONArray(seeds.toList()))
            .put("h", JSONArray(harvested.toList()))
            .put("u", JSONArray(unlocked.toList()))
    }

    fun load(o: JSONObject) {
        weather = Weather.values().getOrElse(o.optInt("w")) { Weather.SUNNY }
        legacy = !o.has("u")
        unlocked.clear()
        o.optJSONArray("u")?.let { a -> for (i in 0 until a.length()) unlocked.add(a.optString(i)) }
        o.optJSONArray("p")?.let { pa ->
            for (i in 0 until min(pa.length(), plots.size)) {
                val a = pa.getJSONArray(i)
                plots[i].crop = a.optInt(0, -1)
                plots[i].growMs = a.optInt(1).toFloat()
                plots[i].wetMs = a.optInt(2).toFloat()
            }
        }
        o.optJSONArray("s")?.let { a -> for (i in 0 until min(a.length(), seeds.size)) seeds[i] = a.optInt(i) }
        o.optJSONArray("h")?.let { a -> for (i in 0 until min(a.length(), harvested.size)) harvested[i] = a.optInt(i) }
    }
}
