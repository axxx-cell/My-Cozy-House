package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/** Crops come from the shared garden harvest, the rest from the fridge (restocked at Fresh Mart later). */
enum class Ing(val emoji: String, val label: String, val farmIdx: Int, val pantryIdx: Int) {
    CARROT("🥕", "Carrot", 0, -1), TOMATO("🍅", "Tomato", 1, -1), CORN("🌽", "Corn", 2, -1),
    STRAWBERRY("🍓", "Strawberry", 3, -1), PUMPKIN("🎃", "Pumpkin", 4, -1),
    MILK("🥛", "Milk", -1, 0), EGGS("🥚", "Eggs", -1, 1), CHEESE("🧀", "Cheese", -1, 2),
    FLOUR("🌾", "Flour", -1, 3), SUGAR("🍬", "Sugar", -1, 4),
}

class Recipe(val emoji: String, val name: String, val needs: List<Ing>, val energy: Int, val happy: Int)

/**
 * Shared kitchen: one stove, a table with up to 4 plates, a sink with dirty dishes.
 * Same idea as the farm: every phone runs the same simple rules, the HOST is the authority and syncs every 2 s.
 *
 * Stove phases: 0 idle, 1 cooking (10 s), 2 ready (burns after 30 s), 3 burnt (throw it away).
 * Unlocks: 3 recipes at the start, +1 for every 3 dishes cooked.
 */
class KitchenManager(private val farm: FarmManager) {
    companion object {
        const val COOK_S = 10f
        const val BURN_S = 30f
        const val MAX_PLATES = 4

        val RECIPES = listOf(
            Recipe("🍲", "Tomato Soup", listOf(Ing.TOMATO, Ing.CORN), 20, 10),
            Recipe("🥗", "Salad", listOf(Ing.CARROT, Ing.TOMATO), 15, 8),
            Recipe("🥞", "Pancake", listOf(Ing.FLOUR, Ing.EGGS), 20, 10),
            Recipe("🥤", "Strawberry Milk", listOf(Ing.STRAWBERRY, Ing.MILK), 15, 12),
            Recipe("🍕", "Pizza", listOf(Ing.FLOUR, Ing.TOMATO, Ing.CHEESE), 30, 15),
            Recipe("🍰", "Cake", listOf(Ing.FLOUR, Ing.EGGS, Ing.SUGAR), 25, 18),
            Recipe("🍔", "Burger", listOf(Ing.FLOUR, Ing.CHEESE, Ing.EGGS), 30, 14),
            Recipe("🥧", "Pumpkin Pie", listOf(Ing.PUMPKIN, Ing.FLOUR, Ing.SUGAR), 28, 16),
            Recipe("🧁", "Strawberry Cupcake", listOf(Ing.STRAWBERRY, Ing.FLOUR, Ing.SUGAR), 22, 18),
            Recipe("🍜", "Corn Chowder", listOf(Ing.CORN, Ing.MILK, Ing.CHEESE), 26, 12),
            Recipe("🧀", "Mac & Cheese", listOf(Ing.FLOUR, Ing.CHEESE, Ing.MILK), 30, 15),
            Recipe("🍨", "Ice Cream", listOf(Ing.MILK, Ing.SUGAR, Ing.STRAWBERRY), 18, 20),
        )

        val STOVE: Rect by lazy { World.furniture.first { it.name == "Stove" }.rect }
        val FRIDGE: Rect by lazy { World.furniture.first { it.name == "Fridge" }.rect }
        val TABLE: Rect by lazy { World.furniture.first { it.name == "Table" }.rect }
        val SINK: Rect by lazy { World.furniture.first { it.name == "Kitchen Sink" }.rect }
    }

    val pantry = mutableStateListOf(5, 5, 5, 5, 5)     // milk, eggs, cheese, flour, sugar
    val plates = mutableStateListOf<Int>()              // recipe index per plate on the table
    var cooks by mutableStateOf(0)
    var dirty by mutableStateOf(0)
    var phase by mutableStateOf(0)
    var t = 0f
    var recipe = 0
    var lastServed = 0

    fun isUnlocked(i: Int) = i < min(RECIPES.size, 3 + cooks / 3)
    fun cooksToUnlock(i: Int) = max(0, (i - 2) * 3 - cooks)

    fun have(ing: Ing): Int = if (ing.farmIdx >= 0) farm.harvested[ing.farmIdx] else pantry[ing.pantryIdx]

    private fun take(ing: Ing) {
        if (ing.farmIdx >= 0) farm.harvested[ing.farmIdx] = farm.harvested[ing.farmIdx] - 1
        else pantry[ing.pantryIdx] = pantry[ing.pantryIdx] - 1
    }

    fun canCook(i: Int) = i in RECIPES.indices && isUnlocked(i) && phase == 0 && RECIPES[i].needs.all { have(it) > 0 }

    fun tick(dt: Float) {
        when (phase) {
            1 -> { t += dt; if (t >= COOK_S) { phase = 2; t = 0f } }
            2 -> { t += dt; if (t >= BURN_S) { phase = 3; t = 0f } }
        }
    }

    /** Same rules on host and clients. Returns true if something changed. */
    fun apply(op: String, arg: Int): Boolean = when (op) {
        "COOK" -> if (canCook(arg)) {
            RECIPES[arg].needs.forEach { take(it) }
            recipe = arg; phase = 1; t = 0f
            true
        } else false
        "FINISH" -> if (phase == 1) { phase = 2; t = 0f; true } else false   // cooked by hand in the cooking game
        "SERVE" -> if (phase == 2 && plates.size < MAX_PLATES) {
            plates.add(recipe); lastServed = recipe
            cooks += 1; phase = 0; t = 0f
            true
        } else false
        "TRASH" -> if (phase == 3) { phase = 0; t = 0f; dirty += 1; true } else false
        "EAT" -> if (plates.isNotEmpty()) { plates.removeAt(0); dirty += 1; true } else false
        "WASH" -> if (dirty > 0) { dirty -= 1; true } else false
        "STOCK" -> if (arg in 0..4) { pantry[arg] = pantry[arg] + 1; true } else false   // bought at Fresh Mart
        "TAKE" -> if (arg in Ing.values().indices && have(Ing.values()[arg]) > 0) { take(Ing.values()[arg]); true } else false   // pet food
        else -> false
    }

    fun toJson(): JSONObject = JSONObject()
        .put("pan", JSONArray(pantry.toList()))
        .put("cooks", cooks).put("dirty", dirty)
        .put("ph", phase).put("t", t.toDouble()).put("r", recipe)
        .put("pl", JSONArray(plates.toList()))

    fun load(o: JSONObject) {
        o.optJSONArray("pan")?.let { a -> for (i in 0 until min(a.length(), pantry.size)) pantry[i] = a.optInt(i) }
        cooks = o.optInt("cooks"); dirty = o.optInt("dirty")
        phase = o.optInt("ph"); t = o.optDouble("t", 0.0).toFloat(); recipe = o.optInt("r").coerceIn(0, RECIPES.size - 1)
        plates.clear()
        o.optJSONArray("pl")?.let { a -> for (i in 0 until a.length()) plates.add(a.optInt(i)) }
    }
}
