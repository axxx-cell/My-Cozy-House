package com.cozy.house

import android.content.Context
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.HouseSaves
import com.cozy.house.net.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch

// ------------------------------------------------------------------ shared look

object Cozy {
    val Cream = Color(0xFFFFF6E9)
    val Outline = Color(0xFF5B3A4A)
    val Pink = Color(0xFFFFC8DD)
    val Blue = Color(0xFFBDE0FE)
    val Mint = Color(0xFFB9FBC0)
    val Yellow = Color(0xFFFFF1A8)
    val Error = Color(0xFFB3261E)
    val avatarColors = listOf(Pink, Blue, Mint, Yellow)
}

/** Holds the running host or client so screens can come and go. */
object Session {
    var host: LanHostManager? by mutableStateOf(null)
    var client: LanClientManager? by mutableStateOf(null)
    var myName: String = "Player"
    var houseId: String = ""          // which saved house the host is playing (empty = not saving)
    val active: Boolean get() = host != null || client != null

    suspend fun leaveAll() {
        host?.handOverAndStop()
        client?.leave()
        client?.release()
        host = null
        client = null
        houseId = ""
    }

    fun dropClient() {
        client?.release()
        client = null
    }
}

/** Opens (hosts) a saved house. Returns an error text, or null if it worked. */
fun startHost(ctx: Context, houseId: String, houseName: String, playerName: String): String? {
    val host = LanHostManager(ctx, houseName, playerName)
    if (!host.start()) return "Couldn't open the house. Is WiFi or hotspot on?"
    Session.host = host
    Session.myName = playerName
    Session.houseId = houseId
    HouseSaves.touch(ctx, houseId)
    return null
}

fun savedPlayerName(ctx: Context): String = loadName(ctx).ifBlank { "Player" }

private fun loadName(ctx: Context) =
    ctx.getSharedPreferences("cozy", Context.MODE_PRIVATE).getString("name", "") ?: ""

private fun saveName(ctx: Context, name: String) =
    ctx.getSharedPreferences("cozy", Context.MODE_PRIVATE).edit().putString("name", name).apply()

private fun firstChar(name: String): String =
    if (name.isBlank()) "?" else String(Character.toChars(name.codePointAt(0))).uppercase()

private fun limit(s: String, max: Int) = s.codePointCount(0, s.length) <= max

@Composable
private fun CozyCard(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    val shape = RoundedCornerShape(20.dp)
    Column(
        modifier.background(Color.White.copy(alpha = 0.7f), shape).border(3.dp, Cozy.Outline, shape).padding(12.dp),
        content = content
    )
}

@Composable
private fun CozyField(value: String, onChange: (String) -> Unit, label: String) {
    OutlinedTextField(
        value = value, onValueChange = onChange, label = { Text(label) },
        singleLine = true, shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun Title(text: String) =
    Text(text, fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Cozy.Outline)

@Composable
private fun PlayerRow(index: Int, p: PlayerInfo, isMe: Boolean, onKick: (() -> Unit)?) {
    Row(
        Modifier.fillMaxWidth().padding(vertical = 4.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(
            Modifier.size(44.dp).background(Cozy.avatarColors[index % 4], CircleShape).border(3.dp, Cozy.Outline, CircleShape),
            contentAlignment = Alignment.Center
        ) { Text(firstChar(p.name), fontSize = 20.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline) }
        Column(Modifier.weight(1f)) {
            Text(p.name + if (isMe) " (you)" else "", fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
            if (p.isHost) Text("👑 HOST", fontSize = 12.sp, color = Cozy.Outline)
        }
        if (onKick != null) {
            Button(
                onClick = onKick,
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(2.dp, Cozy.Outline),
                colors = ButtonDefaults.buttonColors(containerColor = Cozy.Pink, contentColor = Cozy.Outline),
                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp)
            ) { Text("KICK", fontSize = 12.sp, fontWeight = FontWeight.Bold) }
        }
    }
}

// ------------------------------------------------------------------ create house

@Composable
fun CreateHouseScreen(onCreated: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    var name by remember { mutableStateOf(loadName(ctx)) }
    var house by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }
    var houses by remember { mutableStateOf(HouseSaves.list(ctx)) }
    var askDelete by remember { mutableStateOf<String?>(null) }

    fun go(id: String, houseName: String) {
        val n = name.trim().ifBlank { "Player" }
        saveName(ctx, n)
        val err = startHost(ctx, id, houseName, n)
        if (err == null) onCreated() else error = err
    }

    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Title("Create House")
        CozyField(name, { if (limit(it, 12)) name = it }, "Your name (12 max, emoji ok)")
        error?.let { Text(it, color = Cozy.Error, fontSize = 14.sp) }
        if (houses.isNotEmpty()) {
            Text("🏠 Your houses · tap PLAY to continue", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
            houses.forEach { h ->
                Row(
                    Modifier.fillMaxWidth().background(Color.White, RoundedCornerShape(20.dp))
                        .border(3.dp, Cozy.Outline, RoundedCornerShape(20.dp)).padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(h.name, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = Cozy.Outline)
                        Text("Day ${h.day} · ${h.furniture} furniture placed", fontSize = 12.sp, color = Cozy.Outline)
                    }
                    if (askDelete == h.id) {
                        Button(
                            onClick = { HouseSaves.delete(ctx, h.id); houses = HouseSaves.list(ctx); askDelete = null },
                            colors = ButtonDefaults.buttonColors(containerColor = Cozy.Pink, contentColor = Cozy.Outline)
                        ) { Text("Delete?", fontWeight = FontWeight.Bold) }
                        Button(
                            onClick = { askDelete = null },
                            colors = ButtonDefaults.buttonColors(containerColor = Cozy.Blue, contentColor = Cozy.Outline)
                        ) { Text("No", fontWeight = FontWeight.Bold) }
                    } else {
                        Button(
                            onClick = { go(h.id, h.name) },
                            colors = ButtonDefaults.buttonColors(containerColor = Cozy.Mint, contentColor = Cozy.Outline)
                        ) { Text("PLAY", fontWeight = FontWeight.ExtraBold) }
                        Button(
                            onClick = { askDelete = h.id },
                            colors = ButtonDefaults.buttonColors(containerColor = Cozy.Pink, contentColor = Cozy.Outline)
                        ) { Text("🗑️") }
                    }
                }
            }
        }
        Text("✨ New house", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
        CozyField(house, { if (limit(it, 20)) house = it }, "House name")
        CozyButton("NEW HOUSE", Cozy.Pink) {
            val n = name.trim().ifBlank { "Player" }
            val h = house.trim().ifBlank { "$n's House" }
            go(HouseSaves.create(ctx, h), h)
        }
        CozyButton("BACK", Cozy.Blue, onBack)
    }
}

// ------------------------------------------------------------------ join house

@Composable
fun JoinHouseScreen(onJoined: () -> Unit, onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var name by remember { mutableStateOf(loadName(ctx)) }
    var ip by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    val scanner = remember { HouseScanner(ctx) }
    DisposableEffect(Unit) {
        scanner.start()
        onDispose { scanner.stop() }
    }
    val houses by scanner.houses.collectAsState()

    fun join(targetIp: String, port: Int) {
        if (busy || targetIp.isBlank()) return
        busy = true
        error = null
        val n = name.trim().ifBlank { "Player" }
        saveName(ctx, n)
        scope.launch {
            val c = LanClientManager(ctx)
            val ok = c.connect(targetIp.trim(), n, port = port)
            busy = false
            if (ok) {
                Session.client = c
                Session.myName = n
                onJoined()
            } else {
                error = if (c.state.value == ConnState.FULL) "This house is full!" else "Couldn't join. Try again!"
                c.release()
            }
        }
    }

    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Title("Houses nearby")
            CozyCard(Modifier.weight(1f).fillMaxWidth()) {
                LazyColumn(Modifier.fillMaxSize()) {
                    if (houses.isEmpty()) item {
                        Text("Looking for houses… ask a friend to tap CREATE HOUSE on the same WiFi or hotspot.",
                            color = Cozy.Outline, fontSize = 14.sp)
                    }
                    items(houses, key = { it.ip }) { h ->
                        Row(
                            Modifier.fillMaxWidth().clickable(enabled = !busy) { join(h.ip, h.port) }.padding(vertical = 8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(h.name, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
                                Text("Host: ${h.host}", fontSize = 12.sp, color = Cozy.Outline)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text("Players ${if (h.players < 0) "?" else h.players.toString()}/${h.max}", fontSize = 13.sp, color = Cozy.Outline)
                                Text(if (h.pingMs < 0) "ping …" else "${h.pingMs} ms", fontSize = 12.sp, color = Cozy.Outline)
                            }
                        }
                        Divider(color = Cozy.Outline.copy(alpha = 0.2f))
                    }
                }
            }
            CozyButton("REFRESH", Cozy.Mint) { scanner.refresh() }
        }

        Column(
            Modifier.weight(1f).fillMaxHeight().verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            Title("Join")
            CozyField(name, { if (limit(it, 12)) name = it }, "Your name (12 max, emoji ok)")
            CozyField(ip, { ip = it }, "Or type host IP (hotspot)")
            CozyButton(if (busy) "JOINING…" else "JOIN BY IP", Cozy.Yellow) { join(ip, Net.TCP_PORT) }
            error?.let { Text(it, color = Cozy.Error, fontSize = 14.sp) }
            CozyButton("BACK", Cozy.Blue, onBack)
        }
    }
}

// ------------------------------------------------------------------ host lobby

@Composable
fun HostLobbyScreen(onStart: () -> Unit, onExit: (String?) -> Unit) {
    val host = Session.host ?: return
    val scope = rememberCoroutineScope()
    val players by host.players.collectAsState()
    val ip = remember { NetUtils.localIp() }
    var leaving by remember { mutableStateOf(false) }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { leave() }

    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        CozyCard(Modifier.weight(1.3f).fillMaxHeight()) {
            Title(host.houseName)
            Text("Friends can join with IP: ${ip.ifBlank { "?" }}", fontSize = 12.sp, color = Cozy.Outline)
            Spacer(Modifier.height(8.dp))
            Text("Players ${players.size}/${Net.MAX_PLAYERS}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
            LazyColumn {
                items(players.size, key = { players[it].id }) { i ->
                    val p = players[i]
                    PlayerRow(i, p, isMe = p.isHost, onKick = if (p.isHost) null else ({ host.kick(p.id) }))
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            CozyButton("START", Cozy.Mint) { host.startGame(); onStart() }
            Spacer(Modifier.height(12.dp))
            CozyButton("CLOSE HOUSE", Cozy.Pink) { leave() }
        }
    }
}

// ------------------------------------------------------------------ client lobby

@Composable
fun ClientLobbyScreen(onExit: (String?) -> Unit) {
    val client = Session.client ?: return
    val scope = rememberCoroutineScope()
    val players by client.players.collectAsState()
    val state by client.state.collectAsState()
    val ping by client.pingMs.collectAsState()
    var leaving by remember { mutableStateOf(false) }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { leave() }

    Row(Modifier.fillMaxSize().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(16.dp)) {
        CozyCard(Modifier.weight(1.3f).fillMaxHeight()) {
            Title(client.houseName)
            Text("Players ${players.size}/${Net.MAX_PLAYERS}", fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline)
            LazyColumn {
                items(players.size, key = { players[it].id }) { i ->
                    val p = players[i]
                    PlayerRow(i, p, isMe = p.id == client.myId, onKick = null)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.Center) {
            Text(
                if (state == ConnState.RECONNECTING) "Host left! Finding the new host…" else "WAITING for host to start…",
                fontSize = 18.sp, fontWeight = FontWeight.Bold, color = Cozy.Outline
            )
            if (ping >= 0) Text("Ping: $ping ms", fontSize = 13.sp, color = Cozy.Outline)
            Spacer(Modifier.height(16.dp))
            CozyButton("LEAVE", Cozy.Pink) { leave() }
        }
    }
}

/** Runs while a client is in the lobby or game: START, kicked, lost host, and becoming the new host. */
@Composable
fun ClientEffects(client: LanClientManager, screen: Screen, setScreen: (Screen) -> Unit, onExit: (String?) -> Unit) {
    val ctx = LocalContext.current
    val currentScreen by rememberUpdatedState(screen)

    LaunchedEffect(client) {
        client.events.collect {
            if (it.type == MsgType.START && currentScreen == Screen.CLIENT_LOBBY) setScreen(Screen.GAME)
        }
    }
    LaunchedEffect(client) {
        client.state.collect { st ->
            when (st) {
                ConnState.KICKED -> { Session.dropClient(); onExit("The host removed you from the house.") }
                ConnState.LOST -> { Session.dropClient(); onExit("Lost connection to the house.") }
                else -> {}
            }
        }
    }
    LaunchedEffect(client) {
        client.becomeHost.collect { h ->
            val host = LanHostManager(
                ctx, client.houseName, h.myName, hostId = h.myId, hostAvatar = h.avatar,
                gameTimeProvider = { h.gameTimeMs }, snapshotProvider = { h.state }
            )
            if (host.start()) {
                Session.dropClient()
                Session.host = host
                Session.houseId = HouseSaves.create(ctx, client.houseName)   // keep a copy of this house on the new host's phone
                setScreen(if (currentScreen == Screen.GAME) Screen.GAME else Screen.HOST_LOBBY)
            } else {
                Session.dropClient()
                onExit("Couldn't take over hosting.")
            }
        }
    }
}

// ------------------------------------------------------------------ placeholder until Part 2

@Composable
fun GamePlaceholder(onExit: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    val flow: StateFlow<List<PlayerInfo>> = remember(Session.host, Session.client) {
        Session.host?.players ?: Session.client?.players ?: MutableStateFlow(emptyList())
    }
    val players by flow.collectAsState()
    var leaving by remember { mutableStateOf(false) }
    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { leave() }

    Column(Modifier.fillMaxSize().padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Title("🏡 The house is open!")
        Text("Everyone is connected: ${players.joinToString { it.name }}", color = Cozy.Outline, fontSize = 16.sp)
        Text("The map and movement come in Part 2.", color = Cozy.Outline, fontSize = 14.sp)
        CozyButton("LEAVE HOUSE", Cozy.Pink) { leave() }
    }
}
