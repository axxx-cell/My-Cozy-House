package com.cozy.house.game

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/**
 * Every house you create is saved by itself (furniture, farm, kitchen, day, pet stock).
 * Coins, level, outfits and pets stay personal on your phone (LocalSave).
 */
object HouseSaves {
    class Info(val id: String, val name: String, val last: Long, val day: Int, val furniture: Int)

    private const val FILE = "cozy_houses"

    private fun prefs(ctx: Context) = ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE)

    private fun readIndex(ctx: Context): JSONArray = try {
        JSONArray(prefs(ctx).getString("index", "[]") ?: "[]")
    } catch (e: Exception) { JSONArray() }

    private fun writeIndex(ctx: Context, a: JSONArray) { prefs(ctx).edit().putString("index", a.toString()).apply() }

    /** Newest played first. The house from the old single save becomes "My Cozy House". */
    fun list(ctx: Context): List<Info> {
        migrate(ctx)
        val a = readIndex(ctx)
        val out = ArrayList<Info>()
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            out.add(Info(o.optString("id"), o.optString("name"), o.optLong("last"), o.optInt("day", 1), o.optInt("furn")))
        }
        return out.sortedByDescending { it.last }
    }

    fun lastPlayed(ctx: Context): Info? = list(ctx).firstOrNull()

    private fun migrate(ctx: Context) {
        val p = prefs(ctx)
        if (p.getBoolean("migrated", false)) return
        p.edit().putBoolean("migrated", true).apply()
        if (readIndex(ctx).length() > 0) return
        val old = LocalSave.load(ctx).optJSONObject("house") ?: return
        if ((old.optJSONArray("pl")?.length() ?: 0) == 0 && (old.optJSONArray("inv")?.length() ?: 0) == 0) return
        val id = create(ctx, "My Cozy House")
        save(ctx, id, JSONObject().put("house", old))
    }

    fun create(ctx: Context, name: String): String {
        val id = System.currentTimeMillis().toString()
        val a = readIndex(ctx)
        a.put(JSONObject().put("id", id).put("name", name).put("last", System.currentTimeMillis()).put("day", 1).put("furn", 0))
        writeIndex(ctx, a)
        return id
    }

    fun load(ctx: Context, id: String): JSONObject? = try {
        prefs(ctx).getString("d_$id", null)?.let { JSONObject(it) }
    } catch (e: Exception) { null }

    fun save(ctx: Context, id: String, data: JSONObject) {
        prefs(ctx).edit().putString("d_$id", data.toString()).apply()
        val a = readIndex(ctx)
        for (i in 0 until a.length()) {
            val o = a.optJSONObject(i) ?: continue
            if (o.optString("id") == id) {
                o.put("last", System.currentTimeMillis())
                o.put("day", data.optJSONObject("clock")?.optInt("day", 1) ?: o.optInt("day", 1))
                o.put("furn", data.optJSONObject("house")?.optJSONArray("pl")?.length() ?: o.optInt("furn"))
            }
        }
        writeIndex(ctx, a)
    }

    /** Opening a house moves it to the top of the list. */
    fun touch(ctx: Context, id: String) {
        val a = readIndex(ctx)
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { if (it.optString("id") == id) it.put("last", System.currentTimeMillis()) }
        writeIndex(ctx, a)
    }

    fun delete(ctx: Context, id: String) {
        val a = readIndex(ctx)
        val b = JSONArray()
        for (i in 0 until a.length()) a.optJSONObject(i)?.let { if (it.optString("id") != id) b.put(it) }
        writeIndex(ctx, b)
        prefs(ctx).edit().remove("d_$id").apply()
    }
}
