package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import java.util.TimeZone

class Quest(val emoji: String, val text: String, val key: String, val goal: Int) {
    var progress by mutableStateOf(0)
    var claimed by mutableStateOf(false)
}

/**
 * 3 daily quests, the same for everybody on the same real day. Each pays 50 coins + 1 Star + 20 XP.
 * Progress is personal (counted on this phone).
 */
class QuestManager {
    val today: List<Quest>

    init {
        val day = (System.currentTimeMillis() + TimeZone.getDefault().rawOffset) / 86_400_000L
        val all = listOf(
            Quest("🥕", "Harvest 5 crops", "HARVEST", 5),
            Quest("🚿", "Water 6 plants", "WATER", 6),
            Quest("🍲", "Cook 2 dishes for friends", "COOK", 2),
            Quest("😋", "Eat 2 dishes", "EAT", 2),
            Quest("🏃", "Play 2 mini-games", "GAME", 2),
            Quest("🤗", "Hug your friends 3 times", "HUG", 3),
            Quest("🐱", "Pet the cat 3 times", "CAT", 3),
        )
        today = all.shuffled(java.util.Random(day)).take(3)
    }

    fun bump(key: String, n: Int = 1) {
        today.forEach { if (it.key == key && !it.claimed) it.progress += n }
    }
}
