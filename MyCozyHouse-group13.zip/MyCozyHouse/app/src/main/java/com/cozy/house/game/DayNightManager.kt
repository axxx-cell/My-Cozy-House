package com.cozy.house.game

import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.max

/**
 * 1 game day = 30 real minutes. Morning / Noon / Sunset / Night = 7.5 minutes each (shown as 6:00 to 6:00).
 * The host owns the clock and syncs it every 2 s, so everybody sees the same time (also late joiners).
 */
class DayClock {
    companion object {
        const val DAY_MS = 1_800_000f
        val NAMES = listOf("Morning", "Noon", "Sunset", "Night")
        val EMOJI = listOf("🌅", "☀️", "🌇", "🌙")

        private val KEYS = listOf(
            0.00f to Color(0x29FFC857), 0.125f to Color(0x0FFFC857),
            0.25f to Color(0x00FFFFFF), 0.45f to Color(0x00FFFFFF),
            0.50f to Color(0x1AFF9A3C), 0.625f to Color(0x38FF7A2E),
            0.75f to Color(0x4D0B1B4D), 0.875f to Color(0x660B1B4D), 0.95f to Color(0x550B1B4D),
            1.00f to Color(0x29FFC857),
        )
    }

    var ms = 0f
    var day = 1

    fun tick(dt: Float) {
        ms += dt * 1000f
        if (ms >= DAY_MS) { ms -= DAY_MS; day += 1 }
    }

    fun frac() = (ms / DAY_MS).coerceIn(0f, 0.9999f)
    fun phase() = (frac() * 4f).toInt().coerceIn(0, 3)

    fun hourText(): String {
        val h = (6f + frac() * 24f) % 24f
        val hh = h.toInt()
        val mm = ((h - hh) * 60f).toInt() / 10 * 10
        return "%d:%02d".format(hh, mm)
    }

    fun minsToNext(): Int = max(1, ceil(((phase() + 1) / 4f - frac()) * 30f).toInt())

    /** 0 = bright day, 1 = deep night (stars, lamps on). */
    fun nightFactor(): Float {
        val f = frac()
        return when {
            f >= 0.70f && f < 0.78f -> (f - 0.70f) / 0.08f
            f >= 0.78f -> 1f - max(0f, (f - 0.95f) / 0.05f)
            else -> 0f
        }
    }

    /** Fireflies come out at sunset and stay all night. */
    fun fireflyFactor(): Float {
        val f = frac()
        return when {
            f >= 0.58f && f < 0.75f -> (f - 0.58f) / 0.17f
            f >= 0.75f -> 1f - max(0f, (f - 0.95f) / 0.05f)
            else -> 0f
        }
    }

    fun tint(): Color {
        val f = frac()
        for (i in 0 until KEYS.size - 1) {
            if (f <= KEYS[i + 1].first) {
                val (f0, c0) = KEYS[i]
                val (f1, c1) = KEYS[i + 1]
                return lerp(c0, c1, ((f - f0) / (f1 - f0)).coerceIn(0f, 1f))
            }
        }
        return KEYS.last().second
    }

    fun toJson(): JSONObject = JSONObject().put("ms", ms.toDouble()).put("day", day)
    fun load(o: JSONObject) { ms = o.optDouble("ms").toFloat(); day = o.optInt("day", 1) }
}
