package com.cozy.house.game

import com.cozy.house.R

/** A ready-made character: a picture for the picker + the matching in-game look. */
class CozyCharacter(val id: String, val name: String, val pic: Int, val look: Look)

object Characters {
    private fun c(v: Long) = v.toInt()

    val ALL: List<CozyCharacter> = listOf(
        CozyCharacter("rosie", "Rosie", R.drawable.char_rosie, Look(
            skin = 0, eyes = 2, brows = 5, blush = 1, hair = 0, hairColor = c(0xFF1E1B26), outfit = 1, outfitColor = c(0xFFFF9EC4),
            hat = 2, eyeColor = c(0xFF4A3428))),
        CozyCharacter("mochi", "Mochi", R.drawable.char_mochi, Look(
            skin = 1, eyes = 0, brows = 1, mouth = 0, blush = 1, hair = 10, hairColor = c(0xFF1E1B26), outfit = 1,
            outfitColor = c(0xFF7EDDB5), glasses = 1, eyeColor = c(0xFF1F1B3A))),
        CozyCharacter("sunny", "Sunny", R.drawable.char_sunny, Look(
            skin = 4, eyes = 0, brows = 2, mouth = 0, blush = 2, hair = 5, hairColor = c(0xFF2F2A41), outfit = 2,
            outfitColor = c(0xFFFFD86B), eyeColor = c(0xFF6B4226))),
        CozyCharacter("star", "Star", R.drawable.char_star, Look(
            skin = 0, eyes = 2, brows = 2, mouth = 2, blush = 1, hair = 15, hairColor = c(0xFF7B4B3A), outfit = 1,
            outfitColor = c(0xFF6BB3FF), eyeColor = c(0xFF3FA66B))),
        CozyCharacter("cherry", "Cherry", R.drawable.char_cherry, Look(
            skin = 0, eyes = 2, brows = 2, mouth = 2, blush = 1, hair = 1, hairColor = c(0xFFE9C46A), outfit = 2,
            outfitColor = c(0xFFE1BEE7), eyeColor = c(0xFF2F6FDB))),
        CozyCharacter("vee", "Vee", R.drawable.char_vee, Look(
            skin = 1, eyes = 4, brows = 3, mouth = 0, blush = 1, hair = 3, hairColor = c(0xFF1E1B26), outfit = 4,
            outfitColor = c(0xFFFF6B6B), eyeColor = c(0xFF1F1B3A))),
        CozyCharacter("berry", "Berry", R.drawable.char_berry, Look(
            skin = 0, eyes = 9, brows = 5, mouth = 5, blush = 1, hair = 2, hairColor = c(0xFFFF9EC4), outfit = 1,
            outfitColor = c(0xFFFFF9C4), hat = 10, eyeColor = c(0xFF4A3428))),
    )

    val DEFAULT get() = ALL[0]
}
