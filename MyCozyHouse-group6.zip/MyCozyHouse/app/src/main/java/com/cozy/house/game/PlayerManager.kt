package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.cozy.house.Session
import com.cozy.house.net.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.*

/** One adapter so the game does not care if this phone is the host or a client. */
class GameNet(private val host: LanHostManager?, private val client: LanClientManager?) {
    val myId: String
        get() = host?.players?.value?.firstOrNull { it.isHost }?.id ?: client?.myId ?: "p1"
    val players: StateFlow<List<PlayerInfo>> = host?.players ?: client!!.players
    val events: SharedFlow<GameMessage> = host?.events ?: client!!.events

    fun send(m: GameMessage) {
        if (host != null) host.broadcast(m.copy(playerId = myId)) else client?.send(m)
    }

    companion object {
        fun current(): GameNet? =
            if (Session.host != null || Session.client != null) GameNet(Session.host, Session.client) else null
    }
}

class Dust(var x: Float, var y: Float, var age: Float = 0f)

/** kind 0 = heart, 1 = confetti */
class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    val life: Float, val kind: Int, val color: Color, var age: Float = 0f, val spin: Float = 0f,
)

class PlayerManager {
    val players = LinkedHashMap<String, PlayerState>()
    val dust = ArrayList<Dust>()
    val particles = ArrayList<Particle>()

    var myId = ""
    var joyX = 0f
    var joyY = 0f

    // ---- stats (floats inside, ints for the UI so it only redraws when a number changes)
    private var energyF = 100f
    private var hungerF = 100f
    private var happyF = 100f
    var energy by mutableStateOf(100)
    var hunger by mutableStateOf(100)
    var happiness by mutableStateOf(100)
    var coins by mutableStateOf(0)

    // ---- UI state
    var areaName by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    var nearbyFriend by mutableStateOf<String?>(null)
    var carryingId by mutableStateOf<String?>(null)
    var carriedById by mutableStateOf<String?>(null)
    private var toastLeft = 0f

    private var net: GameNet? = null
    private var sendAcc = 0f
    private var keepAliveAcc = 0f
    private var wasMoving = false
    private var actionCd = 0f
    private var hungryNag = 0f

    val me: PlayerState? get() = players[myId]

    companion object {
        const val SPEED = 190f
        private val CONFETTI = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFFD9B3FF))
    }

    /** Mood decides speed: sad = slow, happy = fast, no energy = 20% slower (never blocked). */
    private fun mySpeed(): Float {
        var s = SPEED
        if (happyF > 80f) s *= 1.2f else if (happyF < 30f) s *= 0.7f
        if (energyF <= 0f) s *= 0.8f
        if (me?.carrying != null) s *= 0.85f
        return s
    }

    private fun addHappy(n: Float) { happyF = min(100f, happyF + n) }

    // ------------------------------------------------------------ network

    suspend fun runNetwork(n: GameNet) = coroutineScope {
        net = n
        myId = n.myId
        launch { n.players.collect { syncRoster(it) } }
        launch { n.events.collect { onMessage(it) } }
    }

    private fun syncRoster(list: List<PlayerInfo>) {
        list.forEachIndexed { i, info ->
            val existing = players[info.id]
            if (existing == null) {
                val num = info.id.filter { it.isDigit() }.toIntOrNull() ?: i
                val p = PlayerState(info.id, info.name, num % 4)
                val s = World.spawn(i)
                p.x = s.x; p.y = s.y; p.tx = s.x; p.ty = s.y
                p.area = World.areaAt(p.x, p.y)
                players[info.id] = p
            } else existing.name = info.name
        }
        players.keys.retainAll(list.map { it.id }.toSet())
        myId = net?.myId ?: myId
        for (p in players.values) {          // someone left while carrying / being carried
            if (p.carriedBy != null && players[p.carriedBy!!] == null) p.carriedBy = null
            if (p.carrying != null && players[p.carrying!!] == null) p.carrying = null
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun onMessage(m: GameMessage) {
        when (m.type) {
            MsgType.MOVE -> onMove(m)
            MsgType.CUSTOM -> onCustom(m)
            else -> {}
        }
    }

    private fun onMove(m: GameMessage) {
        if (m.playerId == myId) return
        val p = players[m.playerId] ?: return
        val nx = m.data.optInt("x").toFloat()
        val ny = m.data.optInt("y").toFloat()
        val now = System.currentTimeMillis()

        if (!p.seenMove) {
            p.x = nx; p.y = ny; p.tx = nx; p.ty = ny
            p.seenMove = true
        } else {
            val dtMs = now - p.lastMoveMs
            if (dtMs in 20..500) {
                p.vx = (nx - p.rx) / dtMs * 1000f
                p.vy = (ny - p.ry) / dtMs * 1000f
            }
            val speed = hypot(p.vx, p.vy)
            val cap = if (speed > SPEED * 1.5f) SPEED * 1.5f / speed else 1f
            p.tx = nx + p.vx * cap * 0.07f
            p.ty = ny + p.vy * cap * 0.07f
        }
        p.rx = nx; p.ry = ny
        p.lastMoveMs = now
        p.facing = if (m.data.optInt("f", 1) >= 0) 1 else -1
        p.moving = m.data.optInt("m", 0) == 1
        p.happiness = m.data.optInt("hp", 100)
        runCatching { p.area = Area.valueOf(m.data.optString("area")) }
        if (!p.moving) { p.vx = 0f; p.vy = 0f }
    }

    private fun onCustom(m: GameMessage) {
        val sender = players[m.playerId]
        when (m.data.optString("kind")) {
            "EMOTE" -> {
                val e = Emote.values().firstOrNull { it.name == m.data.optString("emote") } ?: return
                sender?.emote = e; sender?.emoteT = 0f
                SoundFx.emote(e.ordinal)
            }
            "HUG", "HIGHFIVE" -> {
                val hug = m.data.optString("kind") == "HUG"
                val target = players[m.data.optString("target")]
                if (sender == null || target == null) return
                if (hug) { hearts(sender.x, sender.y - 60f); hearts(target.x, target.y - 60f); SoundFx.hug() }
                else { confetti((sender.x + target.x) / 2f, min(sender.y, target.y) - 50f); SoundFx.highFive() }
                if (target.id == myId) {
                    addHappy(if (hug) 10f else 5f)
                    if (hug) { target.emote = Emote.LOVE; target.emoteT = 0f }
                }
            }
            "CARRY" -> applyCarry(m.data.optString("carrier"), m.data.optString("carried"), m.data.optInt("on") == 1)
        }
    }

    private fun applyCarry(carrierId: String, carriedId: String, on: Boolean) {
        val carrier = players[carrierId] ?: return
        val carried = players[carriedId] ?: return
        if (on) {
            carrier.carrying = carriedId; carried.carriedBy = carrierId
        } else {
            carrier.carrying = null; carried.carriedBy = null
            // put down next to the carrier
            carried.x = carrier.x + 34f * carrier.facing; carried.y = carrier.y
            if (World.blocked(carried.x, carried.y)) { carried.x = carrier.x; carried.y = carrier.y }
            carried.tx = carried.x; carried.ty = carried.y; carried.rx = carried.x; carried.ry = carried.y
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun sendCustom(o: JSONObject) {
        net?.send(GameMessage(MsgType.CUSTOM, myId, o))
    }

    private fun sendMove(p: PlayerState) {
        net?.send(
            GameMessage(
                MsgType.MOVE, myId,
                JSONObject()
                    .put("x", p.x.roundToInt())
                    .put("y", p.y.roundToInt())
                    .put("area", p.area.name)
                    .put("f", p.facing)
                    .put("m", if (p.moving) 1 else 0)
                    .put("hp", happyF.roundToInt())
            )
        )
    }

    // ------------------------------------------------------------ per frame

    fun update(dt: Float) {
        val m = me
        if (m != null) {
            updateStats(m, dt)
            moveLocal(m, dt)
            updateNearby(m)
        }

        for (p in players.values) {
            if (p.id != myId) {
                val k = 1f - exp(-12f * dt)
                p.x += (p.tx - p.x) * k
                p.y += (p.ty - p.y) * k
                if (p.moving && p.carriedBy == null) spawnDust(p, dt, 0f, 0f)
            }
            p.animT += dt
            p.blinkTimer -= dt
            if (p.blinkTimer <= 0f) { p.blinkLeft = 0.12f; p.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
            if (p.blinkLeft > 0f) p.blinkLeft -= dt
            if (p.emote != null) { p.emoteT += dt; if (p.emoteT > 2.5f) p.emote = null }
        }

        val di = dust.iterator()
        while (di.hasNext()) { val d = di.next(); d.age += dt; if (d.age > 0.5f) di.remove() }

        val pi = particles.iterator()
        while (pi.hasNext()) {
            val q = pi.next()
            q.age += dt
            q.x += q.vx * dt; q.y += q.vy * dt
            if (q.kind == 1) q.vy += 260f * dt
            if (q.age > q.life) pi.remove()
        }

        if (actionCd > 0f) actionCd -= dt
        if (toastLeft > 0f) { toastLeft -= dt; if (toastLeft <= 0f) toast = null }
    }

    private fun updateStats(m: PlayerState, dt: Float) {
        // slow and gentle: nothing ever blocks you
        happyF = max(0f, happyF - dt / 5f)
        hungerF = max(0f, hungerF - dt / 12f)
        energyF = max(0f, energyF - dt / (if (m.moving) 12f else 40f))
        m.happiness = happyF.roundToInt()

        val e = energyF.roundToInt(); if (e != energy) energy = e
        val h = hungerF.roundToInt(); if (h != hunger) hunger = h
        val hp = happyF.roundToInt(); if (hp != happiness) happiness = hp

        // hunger 0: "I'm hungry" + sad face, but you can still play
        if (hungerF <= 0f) {
            hungryNag -= dt
            if (hungryNag <= 0f) { hungryNag = 30f; emote(Emote.HUNGRY) }
        }
    }

    private fun moveLocal(m: PlayerState, dt: Float) {
        var moving = false
        var jx = 0f
        var jy = 0f

        val carrier = m.carriedBy?.let { players[it] }
        if (m.carriedBy != null && carrier == null) { m.carriedBy = null; carriedById = null }

        if (carrier != null) {
            m.x = carrier.x; m.y = carrier.y          // riding on their back
        } else {
            jx = joyX; jy = joyY
            val len = hypot(jx, jy)
            if (len < 0.12f) { jx = 0f; jy = 0f } else if (len > 1f) { jx /= len; jy /= len }
            moving = jx != 0f || jy != 0f
            if (moving) {
                val sp = mySpeed()
                val nx = m.x + jx * sp * dt
                if (!World.blocked(nx, m.y)) m.x = nx
                val ny = m.y + jy * sp * dt
                if (!World.blocked(m.x, ny)) m.y = ny
                if (abs(jx) > 0.15f) m.facing = if (jx > 0f) 1 else -1
                spawnDust(m, dt, jx, jy)
            }
        }
        m.moving = moving
        m.tx = m.x; m.ty = m.y

        val a = World.areaAt(m.x, m.y)
        if (a != m.area || areaName.isEmpty()) { m.area = a; areaName = World.areaLabel(a) }

        // sync 15x per second while moving (+ last packet when stopping, + 1/sec keep-alive)
        sendAcc += dt
        keepAliveAcc += dt
        if (sendAcc >= 1f / Net.MOVE_HZ) {
            sendAcc = 0f
            if (moving || wasMoving || keepAliveAcc >= 1f) { sendMove(m); keepAliveAcc = 0f }
            wasMoving = moving
        }
    }

    private fun updateNearby(m: PlayerState) {
        val id = if (m.carriedBy != null) null else
            players.values
                .filter { it.id != myId && it.carriedBy == null }
                .minByOrNull { hypot(it.x - m.x, it.y - m.y) }
                ?.takeIf { hypot(it.x - m.x, it.y - m.y) < 75f }?.id
        if (id != nearbyFriend) nearbyFriend = id
    }

    private fun spawnDust(p: PlayerState, dt: Float, jx: Float, jy: Float) {
        p.dustTimer -= dt
        if (p.dustTimer <= 0f) {
            p.dustTimer = 0.12f
            dust.add(Dust(p.x - jx * 8f - p.facing * 4f, p.y - 2f))
        }
    }

    // ------------------------------------------------------------ particles

    private fun hearts(x: Float, y: Float) {
        repeat(6) {
            particles.add(Particle(
                x + (Math.random().toFloat() - 0.5f) * 40f, y,
                (Math.random().toFloat() - 0.5f) * 30f, -40f - Math.random().toFloat() * 30f,
                1.5f, 0, Color.White
            ))
        }
    }

    private fun confetti(x: Float, y: Float) {
        repeat(26) {
            val a = Math.random().toFloat() * 6.283f
            val sp = 60f + Math.random().toFloat() * 120f
            particles.add(Particle(
                x, y, cos(a) * sp, sin(a) * sp - 120f, 1.4f, 1,
                CONFETTI[(Math.random() * CONFETTI.size).toInt()], spin = Math.random().toFloat() * 720f
            ))
        }
    }

    // ------------------------------------------------------------ buttons

    fun interact() {
        val m = me ?: return
        val near = World.furniture
            .filter { it.interactive }
            .minByOrNull { World.distanceTo(it.rect, m.x, m.y) }
        showToast(
            if (near != null && World.distanceTo(near.rect, m.x, m.y) < 80f) "${near.name}: coming soon!"
            else "Nothing to do here"
        )
    }

    private fun showToast(t: String) { toast = t; toastLeft = 2f }

    fun emote(e: Emote) {
        val m = me ?: return
        m.emote = e; m.emoteT = 0f
        SoundFx.emote(e.ordinal)
        sendCustom(JSONObject().put("kind", "EMOTE").put("emote", e.name))
    }

    fun hug() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(10f)
        m.emote = Emote.LOVE; m.emoteT = 0f
        hearts(m.x, m.y - 60f); hearts(t.x, t.y - 60f)
        SoundFx.hug()
        sendCustom(JSONObject().put("kind", "HUG").put("target", t.id))
    }

    fun highFive() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(5f)
        confetti((m.x + t.x) / 2f, min(m.y, t.y) - 50f)
        SoundFx.highFive()
        sendCustom(JSONObject().put("kind", "HIGHFIVE").put("target", t.id))
    }

    /** Pick up the nearby friend, or put down whoever I carry. */
    fun toggleCarry() {
        val m = me ?: return
        val carrying = m.carrying
        if (carrying != null) {
            applyCarry(myId, carrying, false)
            sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", carrying).put("on", 0))
            return
        }
        val t = players[nearbyFriend ?: return] ?: return
        if (t.carrying != null) return
        applyCarry(myId, t.id, true)
        SoundFx.pop()
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", t.id).put("on", 1))
    }

    /** I am being carried and want to get down. */
    fun getDown() {
        val carrier = me?.carriedBy ?: return
        applyCarry(carrier, myId, false)
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", carrier).put("carried", myId).put("on", 0))
    }
}
