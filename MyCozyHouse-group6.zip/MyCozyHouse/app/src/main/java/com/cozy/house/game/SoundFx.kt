package com.cozy.house.game

import android.media.AudioManager
import android.media.ToneGenerator

/** Tiny beeps for now (no sound files needed). Part 6's SoundManager replaces this with real sounds. */
object SoundFx {
    private var tg: ToneGenerator? = null

    private val emoteTones = intArrayOf(
        ToneGenerator.TONE_DTMF_1, ToneGenerator.TONE_DTMF_2, ToneGenerator.TONE_DTMF_3, ToneGenerator.TONE_DTMF_4,
        ToneGenerator.TONE_DTMF_5, ToneGenerator.TONE_DTMF_6, ToneGenerator.TONE_DTMF_7, ToneGenerator.TONE_DTMF_8,
        ToneGenerator.TONE_DTMF_9, ToneGenerator.TONE_DTMF_0, ToneGenerator.TONE_DTMF_S, ToneGenerator.TONE_DTMF_P,
    )

    private fun gen(): ToneGenerator? {
        if (tg == null) tg = try { ToneGenerator(AudioManager.STREAM_MUSIC, 45) } catch (e: Exception) { null }
        return tg
    }

    private fun beep(tone: Int, ms: Int) {
        try { gen()?.startTone(tone, ms) } catch (_: Exception) {}
    }

    fun emote(index: Int) = beep(emoteTones[index % emoteTones.size], 90)
    fun hug() = beep(ToneGenerator.TONE_PROP_ACK, 160)
    fun highFive() = beep(ToneGenerator.TONE_PROP_BEEP2, 220)
    fun pop() = beep(ToneGenerator.TONE_PROP_BEEP, 70)
}
