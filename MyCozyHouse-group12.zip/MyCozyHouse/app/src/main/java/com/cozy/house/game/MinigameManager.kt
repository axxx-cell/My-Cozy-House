package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.ceil
import kotlin.math.hypot
import kotlin.math.max
import kotlin.math.sin

/**
 * Tag, Hide & Seek, Race, Balloon Pop. The HOST runs the game and sends the state 4x per second.
 * phase: 0 none, 1 countdown (Hide & Seek: the 15 s hiding time), 2 playing, 3 result.
 */
class MinigameManager {
    companion object {
        const val TAG = 1
        const val HIDE = 2
        const val RACE = 3
        const val BALLOON = 4
        const val LAPS = 3
        val NAMES = listOf("", "Tag", "Hide & Seek", "Race", "Balloon Pop")
        val EMOJI = listOf("", "🏃", "🙈", "🏁", "🎈")
        val MIN_PLAYERS = intArrayOf(0, 2, 2, 1, 1)
        // garden race track, clockwise. Checkpoint 0 is the start / finish line.
        val CPX = floatArrayOf(900f, 1520f, 1520f, 900f)
        val CPY = floatArrayOf(1000f, 960f, 690f, 690f)

        fun playTime(g: Int) = when (g) { TAG -> 60f; HIDE -> 60f; RACE -> 90f; else -> 30f }
        fun countTime(g: Int) = if (g == HIDE) 15f else 3f
    }

    var game by mutableStateOf(0)
    var phase by mutableStateOf(0)
    var itId by mutableStateOf("")      // Tag: who is IT. Hide & Seek: the seeker.
    var sec by mutableStateOf(0)
    var ver by mutableStateOf(0)        // bumps whenever the lists below change (HUD refresh)

    var timeLeft = 0f
    var round = 0
    var seed = 0
    var ids: List<String> = emptyList()
    val itTime = HashMap<String, Float>()
    val ghosts = HashSet<String>()
    val lap = HashMap<String, Int>()
    val cp = HashMap<String, Int>()
    val finish = ArrayList<String>()
    val popped = HashSet<Int>()
    val scores = HashMap<String, Int>()
    var winners: List<String> = emptyList()
    var changed = false
    private var tagCd = 0f

    private fun touchSec() {
        val s = ceil(timeLeft).toInt()
        if (s != sec) sec = s
    }

    fun elapsed() = playTime(game) - timeLeft

    /** Nobody moves during the countdown, except hiders while the seeker counts. */
    fun lockedFor(id: String) = phase == 1 && (game != HIDE || id == itId)

    // ------------------------------------------------------------ host

    fun start(g: Int, participants: List<String>): Boolean {
        if (phase != 0 || g !in 1..4 || participants.size < MIN_PLAYERS[g]) return false
        round += 1
        game = g; phase = 1; ids = participants
        timeLeft = countTime(g)
        seed = (Math.random() * 100000).toInt()
        itTime.clear(); ghosts.clear(); lap.clear(); cp.clear(); finish.clear(); popped.clear(); scores.clear()
        winners = emptyList()
        participants.forEach { itTime[it] = 0f; lap[it] = 0; cp[it] = 1; scores[it] = 0 }
        itId = if (g == TAG || g == HIDE) participants[(Math.random() * participants.size).toInt()] else ""
        tagCd = 2f
        changed = true
        ver++
        touchSec()
        return true
    }

    fun popRequest(i: Int, by: String): Boolean {
        if (game != BALLOON || phase != 2 || i in popped) return false
        popped.add(i)
        scores[by] = (scores[by] ?: 0) + 1
        changed = true
        ver++
        return true
    }

    fun tickHost(dt: Float, pos: Map<String, PlayerState>) {
        if (phase == 0) return
        timeLeft -= dt
        touchSec()
        when (phase) {
            1 -> if (timeLeft <= 0f) { phase = 2; timeLeft = playTime(game); changed = true; ver++; touchSec() }
            2 -> {
                var over = false
                when (game) {
                    TAG -> {
                        itTime[itId] = (itTime[itId] ?: 0f) + dt
                        tagCd -= dt
                        val it0 = pos[itId]
                        if (it0 != null && tagCd <= 0f) {
                            for (q in ids) {
                                if (q == itId) continue
                                val p = pos[q] ?: continue
                                if (hypot(p.x - it0.x, p.y - it0.y) < 42f) { itId = q; tagCd = 2f; changed = true; ver++; break }
                            }
                        }
                    }
                    HIDE -> {
                        val s = pos[itId]
                        if (s != null) {
                            for (q in ids) {
                                if (q == itId || q in ghosts) continue
                                val p = pos[q] ?: continue
                                if (hypot(p.x - s.x, p.y - s.y) < 48f) { ghosts.add(q); changed = true; ver++ }
                            }
                        }
                        if (ids.filter { it != itId }.all { it in ghosts }) over = true
                    }
                    RACE -> {
                        for (id in ids) {
                            if (id in finish) continue
                            val p = pos[id] ?: continue
                            val t = cp[id] ?: 1
                            if (hypot(p.x - CPX[t], p.y - CPY[t]) < 70f) {
                                if (t == 0) {
                                    lap[id] = (lap[id] ?: 0) + 1
                                    if ((lap[id] ?: 0) >= LAPS) finish.add(id)
                                }
                                cp[id] = (t + 1) % 4
                                changed = true; ver++
                            }
                        }
                        if (ids.all { it in finish }) over = true
                    }
                }
                if (timeLeft <= 0f || over) end()
            }
            3 -> if (timeLeft <= 0f) { phase = 0; game = 0; changed = true; ver++ }
        }
    }

    private fun end() {
        winners = when (game) {
            TAG -> ids.minByOrNull { itTime[it] ?: 0f }?.let { listOf(it) } ?: emptyList()
            HIDE -> {
                val hiders = ids.filter { it != itId }
                if (hiders.all { it in ghosts }) listOf(itId) else hiders.filter { it !in ghosts }
            }
            RACE -> finish.take(1)
            else -> {
                val best = scores.values.maxOrNull() ?: 0
                if (best > 0) ids.filter { (scores[it] ?: 0) == best } else emptyList()
            }
        }
        phase = 3
        timeLeft = 5f
        changed = true
        ver++
        touchSec()
    }

    // ------------------------------------------------------------ everybody

    fun clientTick(dt: Float) {
        if (phase == 0) return
        timeLeft = max(0f, timeLeft - dt)
        touchSec()
    }

    /** Same balloons on every phone: positions come from the shared seed. */
    fun balloonAt(i: Int, el: Float): Offset? {
        if (i >= 32) return null
        val age = el - i * 0.95f
        if (age < 0f) return null
        val rnd = java.util.Random(seed * 31L + i)
        val bx = 1660f + rnd.nextFloat() * 680f
        val sp = 70f + rnd.nextFloat() * 40f
        val y = 1270f - age * sp
        if (y < 640f) return null
        return Offset(bx + sin(age * 2f + i) * 18f, y)
    }

    private fun mapJson(m: Map<String, Number>): JSONObject {
        val o = JSONObject()
        m.forEach { (k, v) -> o.put(k, v.toDouble()) }
        return o
    }

    fun toJson(): JSONObject = JSONObject()
        .put("g", game).put("ph", phase).put("t", timeLeft.toDouble()).put("r", round).put("s", seed).put("it", itId)
        .put("ids", JSONArray(ids)).put("gh", JSONArray(ghosts.toList())).put("fin", JSONArray(finish.toList()))
        .put("win", JSONArray(winners)).put("pop", JSONArray(popped.toList()))
        .put("itt", mapJson(itTime)).put("lap", mapJson(lap)).put("cp", mapJson(cp)).put("sc", mapJson(scores))

    private fun strs(a: JSONArray?): List<String> = if (a == null) emptyList() else (0 until a.length()).map { a.optString(it) }

    private fun <T> readMap(o: JSONObject?, into: MutableMap<String, T>, conv: (Double) -> T) {
        into.clear()
        o?.keys()?.forEach { k -> into[k] = conv(o.optDouble(k)) }
    }

    fun load(o: JSONObject) {
        game = o.optInt("g"); phase = o.optInt("ph"); timeLeft = o.optDouble("t").toFloat()
        round = o.optInt("r"); seed = o.optInt("s"); itId = o.optString("it")
        ids = strs(o.optJSONArray("ids"))
        ghosts.clear(); ghosts.addAll(strs(o.optJSONArray("gh")))
        finish.clear(); finish.addAll(strs(o.optJSONArray("fin")))
        winners = strs(o.optJSONArray("win"))
        popped.clear()
        o.optJSONArray("pop")?.let { a -> for (i in 0 until a.length()) popped.add(a.optInt(i)) }
        readMap(o.optJSONObject("itt"), itTime) { it.toFloat() }
        readMap(o.optJSONObject("lap"), lap) { it.toInt() }
        readMap(o.optJSONObject("cp"), cp) { it.toInt() }
        readMap(o.optJSONObject("sc"), scores) { it.toInt() }
        touchSec()
        ver++
    }
}
