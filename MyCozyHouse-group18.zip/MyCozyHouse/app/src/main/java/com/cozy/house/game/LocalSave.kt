package com.cozy.house.game

import android.content.Context
import org.json.JSONObject

/** Local save on this phone (works offline). The cloud save in Part 11 will merge with this. */
object LocalSave {
    private const val FILE = "cozy_save"

    fun load(ctx: Context): JSONObject = try {
        JSONObject(ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).getString("data", "{}") ?: "{}")
    } catch (e: Exception) { JSONObject() }

    fun save(ctx: Context, o: JSONObject) {
        ctx.getSharedPreferences(FILE, Context.MODE_PRIVATE).edit().putString("data", o.toString()).apply()
    }
}
