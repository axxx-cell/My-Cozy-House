package com.cozy.house.game

import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// Chibi parts, drawn from a Look. Face shapes: 0 round, 1 oval, 2 square, 3 chubby.
internal fun faceHW(face: Int) = when (face) { 1 -> 20f; 3 -> 25f; else -> 22f }
internal fun faceHT(face: Int) = when (face) { 1 -> 25f; 2 -> 21f; 3 -> 21f; else -> 22f }

internal fun DrawScope.drawHead(look: Look, x: Float, hy: Float, skin: Color) {
    when (look.face) {
        1 -> { drawOval(skin, Offset(x - 20f, hy - 25f), Size(40f, 49f)); drawOval(OUT, Offset(x - 20f, hy - 25f), Size(40f, 49f), style = Stroke(3f)) }
        2 -> roundRectOutlined(Offset(x - 22f, hy - 21f), Size(44f, 42f), 14f, skin, 3f)
        3 -> { drawOval(skin, Offset(x - 25f, hy - 21f), Size(50f, 43f)); drawOval(OUT, Offset(x - 25f, hy - 21f), Size(50f, 43f), style = Stroke(3f)) }
        else -> circleOutlined(Offset(x, hy), 22f, skin)
    }
    // soft shading: lighter forehead, a little shadow along the chin
    val hw = faceHW(look.face)
    val ht = faceHT(look.face)
    drawOval(Color.White.copy(alpha = 0.22f), Offset(x - hw * 0.62f, hy - ht * 0.72f), Size(hw * 0.55f, ht * 0.28f))
    drawArc(shade(skin, 0.78f).copy(alpha = 0.45f), 30f, 120f, false, Offset(x - hw + 4f, hy - ht + 5f), Size(2 * hw - 8f, 2 * ht - 8f), style = Stroke(3f, cap = StrokeCap.Round))
}

/** Hair that sits behind the head and body (long hair, pigtails, buns...). */
internal fun DrawScope.drawHairBack(look: Look, x: Float, hy: Float, run: Float, moving: Boolean) {
    val hd = Look.HAIRS[look.hair.coerceIn(0, 29)]
    val c = Color(look.hairColor)
    val hw = faceHW(look.face)
    val ht = faceHT(look.face)
    val sway = if (moving) sin(run) * 3f else 0f          // hair bounces when running
    when (hd.back) {
        1 -> roundRectOutlined(Offset(x - hw - 3f + sway / 2f, hy - 8f), Size(2 * hw + 6f, 58f), 14f, c, 3f)
        2 -> {
            roundRectOutlined(Offset(x - hw - 3f + sway / 2f, hy - 8f), Size(2 * hw + 6f, 50f), 14f, c, 3f)
            for (i in -1..1) circleOutlined(Offset(x + i * (hw * 0.75f) + sway, hy + 44f), 9f, c, 3f)
        }
        3 -> roundRectOutlined(Offset(x - hw - 4f, hy - 8f), Size(2 * hw + 8f, 36f), 16f, c, 3f)
        4 -> roundRectOutlined(Offset(x - hw - 1f, hy - 10f), Size(2 * hw + 2f, 24f), 12f, c, 3f)
        5 -> circleOutlined(Offset(x, hy - 8f), hw + 14f, c, 3f)
        6 -> {
            roundRectOutlined(Offset(x - hw - 2f, hy - 8f), Size(2 * hw + 4f, 30f), 12f, c, 3f)
            for (i in -2..2) circleOutlined(Offset(x + i * (hw / 1.8f), hy + 20f + (abs(i) % 2) * 6f), 11f, c, 3f)
        }
        7 -> roundRectOutlined(Offset(x - hw - 6f, hy - 16f), Size(2 * hw + 12f, 42f), 20f, c, 3f)
    }
    when (hd.extra) {
        1 -> roundRectOutlined(Offset(x + hw - 4f + sway, hy - 16f), Size(14f, 42f), 7f, c, 3f)
        2 -> for (sg in listOf(-1f, 1f)) roundRectOutlined(Offset(x + sg * (hw + 2f) - 7f + sway * sg, hy - 2f), Size(14f, 36f), 7f, c, 3f)
        3 -> circleOutlined(Offset(x, hy - ht - 6f), 11f, c, 3f)
        4 -> for (sg in listOf(-1f, 1f)) circleOutlined(Offset(x + sg * (hw - 3f), hy - ht - 4f), 10f, c, 3f)
        5 -> for (i in 0..2) circleOutlined(Offset(x + hw - 2f + sway * (i / 2f), hy + 14f + i * 12f), 7f, c, 3f)
        6 -> roundRectOutlined(Offset(x - hw - 12f - sway, hy - 4f), Size(14f, 38f), 7f, c, 3f)
        7 -> for (sg in listOf(-1f, 1f)) roundRectOutlined(Offset(x + sg * (hw - 3f) - 6f + sway * sg, hy + 12f), Size(12f, 34f), 6f, c, 3f)
        8 -> for (sg in listOf(-1f, 1f)) {
            val bx = x + sg * (hw - 3f)
            val by = hy - ht - 4f
            val tri = Path().apply { moveTo(bx - 9f, by + 8f); lineTo(bx - 5f * sg, by - 16f); lineTo(bx + 9f, by + 8f); close() }
            drawPath(tri, c); drawPath(tri, OUT, style = Stroke(3f))
            circleOutlined(Offset(bx, by + 6f), 8f, c, 3f)
        }
        9 -> circleOutlined(Offset(x, hy - ht - 3f), 8f, c, 3f)
    }
}

/** Hair on top of the head: cap, spikes, bangs, fringe, highlight. */
internal fun DrawScope.drawHairFront(look: Look, x: Float, hy: Float) {
    val hd = Look.HAIRS[look.hair.coerceIn(0, 29)]
    val c = Color(look.hairColor)
    val hw = faceHW(look.face)
    val ht = faceHT(look.face)
    val tl = Offset(x - hw - 1f, hy - ht - 1f)
    val sz = Size(2 * hw + 2f, 2 * ht + 2f)
    fun cap() { drawArc(c, 180f, 180f, true, tl, sz); drawArc(OUT, 180f, 180f, false, tl, sz, style = Stroke(3f)) }
    fun poly(p: Path) { drawPath(p, c); drawPath(p, OUT, style = Stroke(2.5f)) }

    when (hd.top) {
        1 -> cap()
        2 -> { drawArc(c, 200f, 140f, true, tl, sz); drawArc(OUT, 200f, 140f, false, tl, sz, style = Stroke(3f)) }
        3 -> {
            cap()
            for (i in -2..2) {
                val bx = x + i * 9f
                val apex = hy - ht - 12f - (3 - abs(i)) * 3f
                poly(Path().apply { moveTo(bx - 6f, hy - ht + 5f); lineTo(bx, apex); lineTo(bx + 6f, hy - ht + 5f); close() })
            }
        }
        4 -> {
            cap()
            for (i in -2..1) circleOutlined(Offset(x + i * 10f + 5f, hy - ht + 2f + (if (abs(i) % 2 == 0) -3f else 1f)), 6f, c, 2.5f)
        }
        5 -> {
            cap()
            for (k in 0..4) {
                val a = (200f + k * 35f) * 3.14159f / 180f
                circleOutlined(Offset(x + cos(a) * (hw + 1f), hy + sin(a) * (ht + 1f)), 8f, c, 2.5f)
            }
        }
        6 -> {
            cap()
            poly(Path().apply { moveTo(x - hw + 1f, hy - 4f); lineTo(x - hw + 1f, hy - ht + 6f); lineTo(x - 4f, hy - ht + 2f); close() })
        }
    }
    when (hd.fringe) {
        1 -> roundRectOutlined(Offset(x - hw + 2f, hy - ht + 3f), Size(2 * hw - 4f, 12f), 5f, c, 2.5f)
        2 -> poly(Path().apply { moveTo(x - hw + 1f, hy - 2f); lineTo(x - hw + 1f, hy - ht + 2f); lineTo(x + hw * 0.4f, hy - ht + 2f); close() })
        3 -> for (sg in listOf(-1f, 1f)) {
            poly(Path().apply { moveTo(x + sg * hw, hy - 2f); lineTo(x + sg * hw, hy - ht + 2f); lineTo(x + sg * 3f, hy - ht + 2f); close() })
        }
        4 -> for (i in -1..1) drawCircle(c, 4f, Offset(x + i * 8f, hy - ht + 11f))
    }
    when (hd.extra) {
        10 -> poly(Path().apply { moveTo(x - 8f, hy - ht + 4f); lineTo(x, hy - ht - 18f); lineTo(x + 8f, hy - ht + 4f); close() })
        11 -> {
            val curl = Path().apply { moveTo(x, hy - ht + 1f); quadraticBezierTo(x + 9f, hy - ht - 12f, x + 2f, hy - ht - 16f) }
            drawPath(curl, OUT, style = Stroke(7f, cap = StrokeCap.Round))
            drawPath(curl, c, style = Stroke(4f, cap = StrokeCap.Round))
        }
    }
    if (hd.top != 0) {   // hair shine + a few strands
        drawArc(Color.White.copy(alpha = 0.38f), 212f, 42f, false, Offset(x - hw + 6f, hy - ht + 6f), Size(2 * hw - 12f, 2 * ht - 12f), style = Stroke(4.5f, cap = StrokeCap.Round))
        val dk = shade(c, 0.78f)
        drawLine(dk, Offset(x + 2f, hy - ht + 3f), Offset(x + 9f, hy - ht + 12f), 1.6f, StrokeCap.Round)
        drawLine(dk, Offset(x - 8f, hy - ht + 4f), Offset(x - 12f, hy - ht + 12f), 1.6f, StrokeCap.Round)
    }
    if (look.highlight && hd.top != 0) {
        drawArc(Color(look.highlightColor).copy(alpha = 0.9f), 235f, 50f, false,
            Offset(x - hw + 5f, hy - ht + 5f), Size(2 * hw - 10f, 2 * ht - 10f), style = Stroke(5f, cap = StrokeCap.Round))
    }
}

/** The 6 starter outfits. */
internal fun DrawScope.drawOutfit(look: Look, x: Float, y: Float, bob: Float) {
    val shopGarment = Wardrobe.byId(look.garment)
    if (shopGarment != null) { drawGarment(shopGarment, look, x, y, bob); return }
    val col = Color(look.outfitColor)
    val top = y - 32f - bob
    val dark = Color(col.red * 0.85f, col.green * 0.85f, col.blue * 0.85f)
    when (look.outfit) {
        0 -> {   // pajama with little dots
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            for ((dx, dy) in listOf(-6f to 7f, 5f to 5f, 0f to 15f)) drawCircle(Color.White.copy(alpha = 0.85f), 2.2f, Offset(x + dx, top + dy))
        }
        1 -> {   // hoodie: hood, pocket, strings
            circleOutlined(Offset(x, top + 2f), 11f, col, 3f)
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            roundRectOutlined(Offset(x - 8f, top + 14f), Size(16f, 8f), 4f, dark, 2f)
            drawLine(OUT, Offset(x - 3f, top + 3f), Offset(x - 3f, top + 9f), 2f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 3f, top + 3f), Offset(x + 3f, top + 9f), 2f, StrokeCap.Round)
        }
        2 -> {   // dress
            val skirt = Path().apply { moveTo(x - 11f, top + 16f); lineTo(x + 11f, top + 16f); lineTo(x + 20f, y - 4f); lineTo(x - 20f, y - 4f); close() }
            drawPath(skirt, col); drawPath(skirt, OUT, style = Stroke(3f))
            roundRectOutlined(Offset(x - 12f, top), Size(24f, 20f), 9f, col, 3f)
        }
        3 -> {   // overalls
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, Color.White, 3f)
            roundRectOutlined(Offset(x - 14f, top + 12f), Size(28f, 14f), 7f, col, 3f)
            drawLine(OUT, Offset(x - 7f, top + 12f), Offset(x - 7f, top + 3f), 3f, StrokeCap.Round)
            drawLine(OUT, Offset(x + 7f, top + 12f), Offset(x + 7f, top + 3f), 3f, StrokeCap.Round)
            drawCircle(Color(0xFFFFD86B), 2f, Offset(x - 7f, top + 14f))
            drawCircle(Color(0xFFFFD86B), 2f, Offset(x + 7f, top + 14f))
        }
        4 -> {   // sporty stripes
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            drawRect(Color.White, Offset(x - 13f, top + 9f), Size(26f, 4f))
            drawRect(Color.White, Offset(x - 13f, top + 15f), Size(26f, 2.5f))
        }
        else -> {   // cute with a bow
            roundRectOutlined(Offset(x - 14f, top), Size(28f, 26f), 10f, col, 3f)
            val bow = Color(0xFFFF6B9A)
            val bl = Path().apply { moveTo(x, top + 3f); lineTo(x - 9f, top - 1f); lineTo(x - 9f, top + 7f); close() }
            val br = Path().apply { moveTo(x, top + 3f); lineTo(x + 9f, top - 1f); lineTo(x + 9f, top + 7f); close() }
            for (p in listOf(bl, br)) { drawPath(p, bow); drawPath(p, OUT, style = Stroke(2f)) }
            circleOutlined(Offset(x, top + 3f), 3f, bow, 2f)
        }
    }
}

/** A big shiny chibi eye: coloured iris, dark rim, two highlights and an upper lash line. */
private fun DrawScope.irisEye(cx: Float, ey: Float, w: Float, h: Float, ec: Color, left: Boolean) {
    drawOval(OUT, Offset(cx - w / 2f - 1f, ey - h / 2f - 1f), Size(w + 2f, h + 2f))
    drawOval(ec, Offset(cx - w / 2f + 1f, ey - h / 2f + 1f), Size(w - 2f, h - 2f))
    drawOval(shade(ec, 0.55f), Offset(cx - w * 0.3f, ey - h * 0.1f), Size(w * 0.6f, h * 0.5f))        // darker pupil area
    drawOval(Color(ec.red * 0.5f + 0.5f, ec.green * 0.5f + 0.5f, ec.blue * 0.5f + 0.5f, 0.7f), Offset(cx - w * 0.3f, ey + h * 0.15f), Size(w * 0.6f, h * 0.3f))   // lower glow
    drawCircle(Color.White, w * 0.27f, Offset(cx - w * 0.18f, ey - h * 0.22f))                          // big highlight
    drawCircle(Color.White, w * 0.13f, Offset(cx + w * 0.2f, ey + h * 0.25f))                           // small highlight
    val s = if (left) -1f else 1f
    drawLine(OUT, Offset(cx - w / 2f - 1f, ey - h * 0.35f), Offset(cx + w / 2f + 1f, ey - h * 0.5f), 2.6f, StrokeCap.Round)   // upper lash line
    drawLine(OUT, Offset(cx + s * (w / 2f), ey - h * 0.4f), Offset(cx + s * (w / 2f + 2.6f), ey - h * 0.7f), 1.8f, StrokeCap.Round)   // little lash flick
}

internal fun DrawScope.drawEye(look: Look, paints: Paints, cx: Float, ey: Float, left: Boolean, big: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val ec = Color(look.eyeColor)
    when (look.eyes) {
        0 -> drawArc(OUT, 200f, 140f, false, Offset(cx - 5f, ey - 4f), Size(10f, 9f), style = Stroke(3f, cap = StrokeCap.Round))   // happy ^ ^
        1 -> {
            drawArc(ec, 0f, 180f, true, Offset(cx - 5.5f, ey - 4f), Size(11f, 9f)); drawArc(OUT, 0f, 180f, false, Offset(cx - 5.5f, ey - 4f), Size(11f, 9f), style = Stroke(2f))
            drawCircle(Color.White, 1.6f, Offset(cx - 1.5f, ey)); drawLine(OUT, Offset(cx - 6.5f, ey - 4f), Offset(cx + 6.5f, ey - 4f), 3f, StrokeCap.Round)
        }
        2 -> { irisEye(cx, ey, 11f + big, 15f + big, ec, left); sparkle(Offset(cx + 3.5f, ey - 5f), 2.2f, Color.White) }
        3 -> irisEye(cx, ey, 14f + big, 18f + big, ec, left)
        4 -> irisEye(cx, ey, 7f, 9f, ec, left)
        5 -> if (left) drawLine(OUT, Offset(cx - 5f, ey), Offset(cx + 5f, ey), 3f, StrokeCap.Round) else irisEye(cx, ey, 11f, 15f, ec, left)
        6 -> { paints.glyph.textSize = 17f; paints.glyph.color = 0xFFFF4D6D.toInt(); nc.drawText("♥", cx, ey + 6f, paints.glyph) }
        7 -> { paints.glyph.textSize = 17f; paints.glyph.color = 0xFFFFB400.toInt(); nc.drawText("★", cx, ey + 6f, paints.glyph) }
        8 -> {
            drawArc(ec, 0f, 180f, true, Offset(cx - 5f, ey - 4f), Size(10f, 12f)); drawArc(OUT, 0f, 180f, false, Offset(cx - 5f, ey - 4f), Size(10f, 12f), style = Stroke(2f))
            drawLine(OUT, Offset(cx - 6f, ey), Offset(cx + 6f, ey), 2.8f, StrokeCap.Round); drawCircle(Color.White, 1.5f, Offset(cx - 1.5f, ey + 3f))
        }
        9 -> { drawCircle(OUT, 4.8f, Offset(cx, ey)); drawCircle(ec, 3.6f, Offset(cx, ey)); drawCircle(Color.White, 1.5f, Offset(cx - 1.3f, ey - 1.5f)) }
        10 -> {
            irisEye(cx, ey + 1f, 10f, 12f, ec, left)
            val sg = if (left) 1f else -1f
            drawLine(OUT, Offset(cx - 6f * sg, ey - 9f), Offset(cx + 5f * sg, ey - 5f), 3f, StrokeCap.Round)
        }
        else -> {
            drawCircle(Color.White, 6.8f + big / 2f, Offset(cx, ey)); drawCircle(OUT, 6.8f + big / 2f, Offset(cx, ey), style = Stroke(2f))
            drawCircle(ec, 3.4f, Offset(cx, ey)); drawCircle(Color.White, 1.2f, Offset(cx - 1f, ey - 1.2f))
        }
    }
}

internal fun DrawScope.drawBrowsNose(look: Look, x: Float, ey: Float) {
    for (left in listOf(true, false)) {
        val cx = x + (if (left) -9f else 9f)
        val by = ey - 12f
        val s = if (left) 1f else -1f
        when (look.brows) {
            0 -> drawLine(OUT, Offset(cx - 5f, by), Offset(cx + 5f, by), 2f, StrokeCap.Round)
            1 -> drawLine(OUT, Offset(cx - 5f, by), Offset(cx + 5f, by), 4.5f, StrokeCap.Round)
            2 -> drawArc(OUT, 200f, 140f, false, Offset(cx - 5f, by - 2f), Size(10f, 6f), style = Stroke(3f, cap = StrokeCap.Round))
            3 -> drawLine(OUT, Offset(cx - 5f, by - 1f), Offset(cx + 5f, by - 1f), 3f, StrokeCap.Round)
            4 -> drawLine(OUT, Offset(cx - 5f * s, by - 2f), Offset(cx + 5f * s, by + 2f), 3f, StrokeCap.Round)
            else -> drawLine(OUT, Offset(cx - 4f * s, by + 1f), Offset(cx + 4f * s, by - 1f), 2f, StrokeCap.Round)
        }
    }
    val ny = ey + 6f
    when (look.nose) {
        0 -> drawCircle(OUT.copy(alpha = 0.6f), 1.2f, Offset(x, ny))
        1 -> drawCircle(OUT.copy(alpha = 0.7f), 2.6f, Offset(x, ny), style = Stroke(1.6f))
        2 -> {
            val p = Path().apply { moveTo(x - 1f, ny - 2f); lineTo(x + 2f, ny + 2f); lineTo(x - 1f, ny + 2f) }
            drawPath(p, OUT.copy(alpha = 0.7f), style = Stroke(1.6f, cap = StrokeCap.Round))
        }
        else -> { drawCircle(Color(0x33B5651D), 2.4f, Offset(x, ny)); drawCircle(OUT.copy(alpha = 0.5f), 2.4f, Offset(x, ny), style = Stroke(1.2f)) }
    }
}

internal fun DrawScope.drawBlush(look: Look, paints: Paints, x: Float, ey: Float) {
    val nc = drawContext.canvas.nativeCanvas
    for (sg in listOf(-1f, 1f)) {
        val cx = x + sg * 15f
        val cy = ey + 9f
        when (look.blush) {
            1 -> drawCircle(Color(0xFFFF9EC4).copy(alpha = 0.5f), 5.5f, Offset(cx, cy))
            2 -> drawCircle(Color(0xFFFF6B6B).copy(alpha = 0.5f), 5.5f, Offset(cx, cy))
            3 -> { paints.glyph.textSize = 11f; paints.glyph.color = 0xAAFF6B9A.toInt(); nc.drawText("♥", cx, cy + 4f, paints.glyph) }
            4 -> for (d in listOf(-3f to 0f, 1f to -2f, 3f to 2f)) drawCircle(Color(0xFFB5651D).copy(alpha = 0.6f), 1.2f, Offset(cx + d.first, cy + d.second))
        }
    }
}

internal fun DrawScope.drawLookMouth(look: Look, x: Float, ey: Float, joy: Boolean) {
    val pink = Color(0xFFFF8FA3)
    when (look.mouth) {
        0 -> drawArc(OUT, 20f, 140f, false, Offset(x - 5f, ey + 4f), Size(10f, 8f), style = Stroke(if (joy) 3.5f else 2.5f, cap = StrokeCap.Round))
        1 -> drawArc(OUT, 20f, 140f, false, Offset(x - 8f, ey + 3f), Size(16f, 10f), style = Stroke(3f, cap = StrokeCap.Round))
        2 -> { drawOval(OUT, Offset(x - 4f, ey + 6f), Size(8f, 9f)); drawCircle(pink, 2.5f, Offset(x, ey + 13f)) }
        3 -> {
            drawArc(OUT, 0f, 180f, false, Offset(x - 6f, ey + 5f), Size(6f, 6f), style = Stroke(2f, cap = StrokeCap.Round))
            drawArc(OUT, 0f, 180f, false, Offset(x, ey + 5f), Size(6f, 6f), style = Stroke(2f, cap = StrokeCap.Round))
        }
        4 -> drawCircle(OUT.copy(alpha = 0.85f), 2.5f, Offset(x, ey + 9f))
        5 -> drawArc(OUT, 200f, 140f, false, Offset(x - 4f, ey + 8f), Size(8f, 5f), style = Stroke(2.5f, cap = StrokeCap.Round))
        6 -> {
            drawArc(OUT, 20f, 140f, false, Offset(x - 5f, ey + 4f), Size(10f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))
            drawRoundRect(pink, Offset(x - 2.5f, ey + 10f), Size(5f, 6f), CornerRadius(3f))
            drawRoundRect(OUT, Offset(x - 2.5f, ey + 10f), Size(5f, 6f), CornerRadius(3f), style = Stroke(1.5f))
        }
        7 -> {
            drawRoundRect(Color.White, Offset(x - 6f, ey + 5f), Size(12f, 6f), CornerRadius(3f))
            drawRoundRect(OUT, Offset(x - 6f, ey + 5f), Size(12f, 6f), CornerRadius(3f), style = Stroke(2f))
            drawLine(OUT, Offset(x, ey + 5f), Offset(x, ey + 11f), 1.3f)
        }
        8 -> drawLine(OUT, Offset(x - 3f, ey + 9f), Offset(x + 3f, ey + 9f), 2.5f, StrokeCap.Round)
        else -> { drawArc(OUT, 0f, 180f, true, Offset(x - 7f, ey + 3f), Size(14f, 12f)); drawCircle(pink, 3f, Offset(x, ey + 11f)) }
    }
}

/** Little ears peek out at the sides of the head. */
internal fun DrawScope.drawEars(look: Look, x: Float, hy: Float, skin: Color) {
    val hw = faceHW(look.face)
    for (sg in listOf(-1f, 1f)) {
        circleOutlined(Offset(x + sg * (hw - 0.5f), hy + 5f), 5f, skin, 2.6f)
        drawCircle(Color(0xFFFFB3A7).copy(alpha = 0.7f), 2.2f, Offset(x + sg * (hw + 0.5f), hy + 5f))
    }
}

/** Short stubby legs between the body and the shoes. */
internal fun DrawScope.drawLegs(skin: Color, x: Float, y: Float, bob: Float, step: Float) {
    for ((sg, lift) in listOf(-1f to maxOf(0f, step), 1f to maxOf(0f, -step))) {
        val top = Offset(x + sg * 7f, y - 12f - bob)
        val foot = Offset(x + sg * 8f, y - 6f - lift)
        drawLine(OUT, top, foot, 8.5f, StrokeCap.Round)
        drawLine(skin, top, foot, 5.5f, StrokeCap.Round)
    }
}

/** Arms: sleeves in the outfit colour and round little hands. They swing when walking. */
internal fun DrawScope.drawArms(look: Look, skin: Color, x: Float, top: Float, swing: Float, skipRight: Boolean) {
    val sleeve = if (look.garment != 0 && Wardrobe.byId(look.garment)?.style in listOf("tee", "sundress", "nightgown", "jeans", "skirtdenim", "skirtflowy", "shorts", "leggings")) skin else Color(look.outfitColor)
    for (sg in listOf(-1f, 1f)) {
        if (sg > 0f && skipRight) continue
        val sw = swing * 5f * (-sg)
        val shoulder = Offset(x + sg * 13f, top + 7f)
        val hand = Offset(x + sg * 18.5f, top + 19f + sw)
        drawLine(OUT, shoulder, hand, 8.5f, StrokeCap.Round)
        drawLine(sleeve, shoulder, hand, 5.5f, StrokeCap.Round)
        circleOutlined(hand, 3.8f, skin, 2.2f)
    }
}
