package com.cozy.house.game

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Rect
import com.cozy.house.net.Area
import org.json.JSONArray
import org.json.JSONObject

class PlacedItem(val uid: Int, val item: Int, var x: Int, var y: Int, var rot: Int)

/**
 * The shared house: furniture in storage + furniture placed in the world.
 * Same pattern as the farm: every phone keeps a copy, the HOST is the boss and syncs it.
 * Bought furniture is shared by everybody; coins stay personal.
 */
/** A room that starts locked. Unlock with stars (the gate is the door gap). */
class HiddenRoom(val rect: Rect, val title: String, val price: String)

/** A bit of mess on the floor (crumbs, a sock, a toy). Tidy it up with the hand button for a few coins. */
class Mess(val id: Int, val x: Int, val y: Int, val kind: Int)

class RoomGate(val key: String, val name: String, val stars: Int, val coins: Int, val gate: Rect, val needs: String?)

class HouseManager {
    companion object {
        val GATES = listOf(
            RoomGate("BEDROOM", "Bedroom", 1, 0, Rect(788f, 260f, 812f, 380f), null),
            RoomGate("BATHROOM", "Bathroom", 2, 0, Rect(340f, 628f, 460f, 652f), "BEDROOM"),
            RoomGate("PLAYGROUND", "Playground", 3, 0, Rect(1940f, 628f, 2060f, 652f), null),
            RoomGate("GARDEN", "Garden", 0, 30, Rect(1140f, 628f, 1260f, 652f), null),
            RoomGate("TOWN", "Town", 0, 60, Rect(1140f, 1256f, 1260f, 1280f), "GARDEN"),
        )
    }

    /** Rooms already unlocked. New houses start with only the Living Room and Kitchen. */
    val openRooms = mutableStateListOf<String>()

    /** Mess lying around. New houses start with some; houses saved before this update have none. */
    val mess = mutableStateListOf<Mess>()

    fun seedMess() {
        mess.clear()
        val spots = listOf(
            900 to 330, 1000 to 480, 1150 to 380, 1300 to 500, 1450 to 350, 1480 to 560, 950 to 570, 1200 to 590,   // living room
            1700 to 420, 2250 to 350, 2050 to 540,                                                                    // kitchen
        )
        spots.forEachIndexed { i, (x, y) -> mess.add(Mess(i + 1, x, y, i % 6)) }
    }
    val inventory = mutableStateListOf<Int>()        // item ids in storage (the same id can appear many times)
    val placed = mutableStateListOf<PlacedItem>()
    init { rebuild() }          // locks the doors of a brand-new house (must stay below the lists above)

    fun rectOf(pi: PlacedItem, f: Furn): Rect {
        val w = (if (pi.rot % 2 == 0) f.w else f.h) / 2f
        val h = (if (pi.rot % 2 == 0) f.h else f.w) / 2f
        return Rect(pi.x - w, pi.y - h, pi.x + w, pi.y + h)
    }

    /** Solid furniture blocks the player. */
    fun rebuild() {
        World.locked = GATES.filter { it.key !in openRooms }.map { it.gate }
        World.hidden = GATES.filter { it.key !in openRooms }.mapNotNull { g ->
            val r = World.rooms[Area.valueOf(g.key)] ?: return@mapNotNull null
            HiddenRoom(r, g.name, if (g.coins > 0) "${g.coins}🪙" else "${g.stars}⭐")
        }
        World.dynamic = placed.mapNotNull { pi ->
            FurnitureCatalog.byId(pi.item)?.takeIf { it.solid }?.let { f ->
                val r = rectOf(pi, f)
                Rect(r.left + 3f, r.top + 3f, r.right - 3f, r.bottom - 3f)
            }
        }
    }

    /** Same rules on host and clients. Returns true if something changed. */
    fun apply(op: String, item: Int, x: Int, y: Int, rot: Int, uid: Int): Boolean {
        when (op) {
            "CLEAN" -> return mess.removeAll { it.id == item }
            "ROOM" -> {
                val g = GATES.getOrNull(item) ?: return false
                if (g.key in openRooms) return false
                openRooms.add(g.key); rebuild(); return true
            }
            "ADD" -> {
                if (FurnitureCatalog.byId(item) == null) return false
                inventory.add(item)
                return true
            }
            "PLACE" -> {
                val i = inventory.indexOf(item)
                if (i < 0) return false
                inventory.removeAt(i)
                placed.add(PlacedItem(uid, item, x, y, rot and 3))
                rebuild()
                return true
            }
            "STORE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                inventory.add(p.item)
                rebuild()
                return true
            }
            "DELETE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                rebuild()
                return true
            }
            "MOVE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                p.x = x; p.y = y; p.rot = rot and 3
                rebuild()
                return true
            }
        }
        return false
    }

    fun toJson(): JSONObject {
        val pl = JSONArray()
        placed.forEach { pl.put(JSONArray().put(it.uid).put(it.item).put(it.x).put(it.y).put(it.rot)) }
        return JSONObject().put("inv", JSONArray(inventory.toList())).put("pl", pl).put("rooms", JSONArray(openRooms.toList())).put("ms", 1)
            .put("mess", JSONArray().also { a -> mess.forEach { a.put(JSONArray().put(it.id).put(it.x).put(it.y).put(it.kind)) } })
    }

    fun load(o: JSONObject) {
        mess.clear()
        if (o.has("ms")) o.optJSONArray("mess")?.let { a ->
            for (i in 0 until a.length()) a.optJSONArray(i)?.let { r -> mess.add(Mess(r.optInt(0), r.optInt(1), r.optInt(2), r.optInt(3))) }
        }
        openRooms.clear()
        if (o.has("rooms")) o.optJSONArray("rooms")?.let { a -> for (i in 0 until a.length()) openRooms.add(a.optString(i)) }
        else GATES.forEach { openRooms.add(it.key) }      // houses saved before locked rooms: everything stays open
        inventory.clear()
        o.optJSONArray("inv")?.let { a -> for (i in 0 until a.length()) inventory.add(a.optInt(i)) }
        placed.clear()
        o.optJSONArray("pl")?.let { a ->
            for (i in 0 until a.length()) {
                val r = a.optJSONArray(i) ?: continue
                placed.add(PlacedItem(r.optInt(0), r.optInt(1), r.optInt(2), r.optInt(3), r.optInt(4)))
            }
        }
        rebuild()
    }
}
