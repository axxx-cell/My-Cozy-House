# My Cozy House - locked fixes (apply to all parts)

TIME: 1 game day = 30 real min (Morning/Noon/Sunset/Night = 7.5 min each, shown as 6:00 to 6:00).
Game day drives visuals, pet hunger, treasure cooldown only. Daily deal, mailman, login, Grandma gift = real day (local midnight, deal seeded by date so all see the same). Market Day + Grandma = all real Sunday.
Sleep: fade + Energy 100 + Happiness +10 + dream. Does NOT change world time. Alarm: if asleep at Morning, friends can wake you.
Crops/pets/cooldowns use timestamps (keep running while app closed).

STARS (only list): earn = Level Up, Daily Quest, Help Friend 3x, Market Day, FIRST secret treasure (repeat digs = coins), Login Day 3, Birthday (3), rare stickers.
Spend = Fox 3, Panda 5, Rainbow Wallpaper 2, Secret Room Key 3, Golden Crown 2, Golden Bed 3, Galaxy Ceiling 2, Floating Shelf 2.
COINS: Turtle 100 (was 200). x1 solo, x2 with 2-3 players, x3 with 4. Multiplier applies to harvest, cook, mini-game, cafe, pet finds only (not quests/login). Help-friend coins max 5x per real day.
XP: harvest 2, cook 3, mini-game 10, quest 20. Level N needs N*50 XP. Max 20.
INVENTORY: seeds, crops, ingredients = shared house. Coins, stars, outfits, pets, accessories = personal. Bought furniture = shared house.
HOUSE SAVE: host owns/saves the house layout; visitors get a visit copy only.
VOTES: host decides. Proposer counts YES. Need majority of ALL players. Tie = NO. Disconnected = no vote.
CLOUD MERGE: Level/Stars = higher. Owned items = union. Coins = from the newest save (no duplicating coins).
COUNTS: Hair 30 (17 listed + 13 to design), Stickers 30 (13 listed + 17 to design), Glasses 8.
KIDS MODE: LAN only, voice OFF, custom skins OFF, chat = quick phrases only.
BIRTHDAY: optional field in Creator (Google gives none).

NETWORK: ports TCP 8080, UDP 8888, voice UDP 8889, skins TCP 8081 (separate so MOVE never freezes). TCP_NODELAY on. Hold a WifiManager MulticastLock. Manual "enter host IP" fallback for hotspots.
HOST MIGRATION: host sends full snapshot every 5 s; roster includes every player's IP. Next host = earliest joined; it opens the server, re-advertises, others reconnect.
VOICE: 16 kHz mono 16-bit, A-law compressed, UDP 8889.
SKINS: paste-link needs a direct image URL (page links like Pinterest show a hint). ML Kit labeling is a best-effort filter + Report button + parent toggle. 3D-looking "spin" = 4-direction turntable of 2D sprites.
PERMISSIONS: ask at point of use. READ_EXTERNAL_STORAGE only up to Android 12; use the system photo picker.
