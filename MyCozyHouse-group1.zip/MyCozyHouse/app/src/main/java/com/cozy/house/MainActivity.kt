package com.cozy.house

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

// Cute pastel palette, thick dark-plum outlines
private val Cream = Color(0xFFFFF6E9)
private val Outline = Color(0xFF5B3A4A)
private val PastelPink = Color(0xFFFFC8DD)
private val PastelBlue = Color(0xFFBDE0FE)
private val PastelMint = Color(0xFFB9FBC0)
private val PastelYellow = Color(0xFFFFF1A8)

enum class Screen { MENU, CREATE, JOIN, HOW, SETTINGS }

class MainActivity : ComponentActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNetworkPermissions()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = PastelPink, background = Cream)) {
                CozyApp()
            }
        }
    }

    /** Only what LAN needs now. Mic / camera / photos are asked later, when the feature is used. */
    private fun askNetworkPermissions() {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        permLauncher.launch(p.toTypedArray())
    }
}

@Composable
fun CozyApp() {
    var screen by rememberSaveable { mutableStateOf(Screen.MENU) }
    BackHandler(enabled = screen != Screen.MENU) { screen = Screen.MENU }

    Box(Modifier.fillMaxSize().background(Cream).systemBarsPadding()) {
        when (screen) {
            Screen.MENU -> MainMenu(onPick = { screen = it })
            Screen.CREATE -> InfoScreen("Create House", "Lobby host comes in group 2.") { screen = Screen.MENU }
            Screen.JOIN -> InfoScreen("Join House", "House list comes in group 3.") { screen = Screen.MENU }
            Screen.HOW -> InfoScreen(
                "How to Play",
                "1. One friend taps CREATE HOUSE.\n" +
                "2. Everyone else joins the same WiFi or phone hotspot and taps JOIN HOUSE.\n" +
                "3. No internet needed!\n" +
                "4. Farm, cook, play and decorate together."
            ) { screen = Screen.MENU }
            Screen.SETTINGS -> InfoScreen("Settings", "Sound, music and language come later.") { screen = Screen.MENU }
        }
    }
}

@Composable
private fun MainMenu(onPick: (Screen) -> Unit) {
    Row(
        Modifier.fillMaxSize().padding(24.dp),
        horizontalArrangement = Arrangement.spacedBy(24.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("🏠", fontSize = 64.sp)
            Text("My Cozy House", fontSize = 34.sp, fontWeight = FontWeight.ExtraBold,
                color = Outline, textAlign = TextAlign.Center)
            Text("play together, no internet needed", fontSize = 14.sp, color = Outline)
        }
        Column(
            Modifier.weight(1f).verticalScroll(rememberScrollState()),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            CozyButton("CREATE HOUSE", PastelPink) { onPick(Screen.CREATE) }
            CozyButton("JOIN HOUSE", PastelBlue) { onPick(Screen.JOIN) }
            CozyButton("HOW TO PLAY", PastelMint) { onPick(Screen.HOW) }
            CozyButton("SETTINGS", PastelYellow) { onPick(Screen.SETTINGS) }
        }
    }
}

@Composable
fun CozyButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(3.dp, Outline),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Outline)
    ) { Text(label, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Outline)
        Text(body, fontSize = 18.sp, color = Outline)
        CozyButton("BACK", PastelPink, onBack)
    }
}
