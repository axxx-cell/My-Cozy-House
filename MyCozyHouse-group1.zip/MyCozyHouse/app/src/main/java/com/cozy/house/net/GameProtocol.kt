package com.cozy.house.net

import org.json.JSONArray
import org.json.JSONObject

/** Network constants. Host is the authority for all shared state. */
object Net {
    const val TCP_PORT = 8080          // game traffic (JSON lines)
    const val UDP_PORT = 8888          // house discovery broadcast
    const val VOICE_PORT = 8889        // push-to-talk voice (later)
    const val SKIN_PORT = 8081         // custom skin transfer (later, keeps MOVE smooth)
    const val NSD_SERVICE_TYPE = "_myhouse._tcp."
    const val MAX_PLAYERS = 4
    const val PROTOCOL_VERSION = 1
    const val MOVE_HZ = 15
    const val SNAPSHOT_EVERY_MS = 5000L   // host sends full state so any client can become host
    const val PING_EVERY_MS = 2000L
}

enum class Area { LIVING_ROOM, KITCHEN, BEDROOM, GARDEN, PLAYGROUND, BATHROOM, TOWN }

/** The 7 spec types first, then the extras lobby + host migration need. */
enum class MsgType {
    JOIN, LEAVE, MOVE, SYNC, CHAT, BUY, CUSTOM,
    WELCOME,      // host -> new player: assigned id, roster, game time
    LOBBY,        // host -> all: roster changed
    START,        // host -> all: leave lobby, enter the house
    KICK,         // host -> one player
    PING, PONG,
    HOST_CHANGE   // new host announces itself
}

data class PlayerInfo(
    val id: String,
    val name: String,
    val isHost: Boolean = false,
    val ip: String = "",             // lets clients reconnect to the next host
    val avatar: JSONObject = JSONObject(),
) {
    fun toJson() = JSONObject()
        .put("id", id).put("name", name).put("isHost", isHost)
        .put("ip", ip).put("avatar", avatar)

    companion object {
        fun fromJson(o: JSONObject) = PlayerInfo(
            id = o.getString("id"),
            name = o.optString("name", "Player"),
            isHost = o.optBoolean("isHost", false),
            ip = o.optString("ip", ""),
            avatar = o.optJSONObject("avatar") ?: JSONObject(),
        )

        fun listToJson(list: List<PlayerInfo>) = JSONArray().also { a -> list.forEach { a.put(it.toJson()) } }

        fun listFromJson(a: JSONArray?): List<PlayerInfo> =
            if (a == null) emptyList() else (0 until a.length()).map { fromJson(a.getJSONObject(it)) }
    }
}

/**
 * Flat JSON on the wire, one message per line, e.g.
 * {"type":"MOVE","playerId":"p1","x":120,"y":340,"area":"GARDEN"}
 */
data class GameMessage(
    val type: MsgType,
    val playerId: String = "",
    val data: JSONObject = JSONObject(),
) {
    fun encode(): String {
        val o = JSONObject()
        data.keys().forEach { o.put(it, data.get(it)) }
        o.put("type", type.name).put("playerId", playerId)
        return o.toString() + "\n"
    }

    companion object {
        fun decode(line: String): GameMessage? = try {
            val o = JSONObject(line)
            val type = MsgType.valueOf(o.getString("type"))
            val id = o.optString("playerId", "")
            o.remove("type"); o.remove("playerId")
            GameMessage(type, id, o)
        } catch (e: Exception) {
            null // ignore garbage, never crash on a bad packet
        }

        fun join(playerId: String, name: String, avatar: JSONObject = JSONObject()) =
            GameMessage(MsgType.JOIN, playerId, JSONObject()
                .put("name", name).put("avatar", avatar).put("v", Net.PROTOCOL_VERSION))

        fun leave(playerId: String) = GameMessage(MsgType.LEAVE, playerId)

        fun move(playerId: String, x: Int, y: Int, area: Area) =
            GameMessage(MsgType.MOVE, playerId, JSONObject().put("x", x).put("y", y).put("area", area.name))

        fun chat(playerId: String, text: String) =
            GameMessage(MsgType.CHAT, playerId, JSONObject().put("text", text))

        fun lobby(players: List<PlayerInfo>) =
            GameMessage(MsgType.LOBBY, "host", JSONObject().put("players", PlayerInfo.listToJson(players)))

        fun kick(playerId: String) = GameMessage(MsgType.KICK, playerId)
        fun ping(t: Long) = GameMessage(MsgType.PING, "", JSONObject().put("t", t))
        fun pong(t: Long) = GameMessage(MsgType.PONG, "", JSONObject().put("t", t))
    }
}
