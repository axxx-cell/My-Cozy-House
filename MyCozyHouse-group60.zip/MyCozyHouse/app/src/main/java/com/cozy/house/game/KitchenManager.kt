package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Rect
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.max
import kotlin.math.min

/** Crops come from the shared garden harvest, the rest from the fridge (restocked at Fresh Mart later). */
enum class Ing(val emoji: String, val label: String, val farmIdx: Int, val pantryIdx: Int) {
    CARROT("🥕", "Carrot", 0, -1), TOMATO("🍅", "Tomato", 1, -1), CORN("🌽", "Corn", 2, -1),
    STRAWBERRY("🍓", "Strawberry", 3, -1), PUMPKIN("🎃", "Pumpkin", 4, -1),
    MILK("🥛", "Milk", -1, 0), EGGS("🥚", "Eggs", -1, 1), CHEESE("🧀", "Cheese", -1, 2),
    FLOUR("🌾", "Flour", -1, 3), SUGAR("🍬", "Sugar", -1, 4),
}

class Recipe(val emoji: String, val name: String, val needs: List<Ing>, val energy: Int, val happy: Int)

/**
 * Shared kitchen: one stove, a table with up to 4 plates, a sink with dirty dishes.
 * Same idea as the farm: every phone runs the same simple rules, the HOST is the authority and syncs every 2 s.
 *
 * Stove phases: 0 idle, 1 cooking (10 s), 2 ready (burns after 30 s), 3 burnt (throw it away).
 * Unlocks: 3 recipes at the start, +1 for every 3 dishes cooked.
 */
/** One restaurant upgrade. They are bought in this order. */
class RestaurantUp(val key: String, val label: String, val price: Int)

class KitchenManager(private val farm: FarmManager) {
    companion object {
        const val COOK_S = 10f
        const val BURN_S = 30f
        const val MAX_PLATES = 4
        const val ORDER_S = 150f                       // a guest waits 2.5 minutes
        const val MAX_TABLES = 6
        val RUPS = listOf(
            RestaurantUp("BURGER", "Burger recipe 🍔", 50),
            RestaurantUp("T3", "Table 3", 100),
            RestaurantUp("C2", "2nd counter: guests wait 30 s longer", 200),
            RestaurantUp("T4", "Table 4", 300),
            RestaurantUp("STOVE", "Fancy stove: cooking 30% faster 🔥", 400),
            RestaurantUp("T5", "Table 5", 600),
            RestaurantUp("FRIDGE", "Fridge: the pantry refills itself 🧊", 800),
            RestaurantUp("T6", "Table 6", 1000),
            RestaurantUp("DECOR", "Decorations ✨", 1500),
        )
        val GUESTS = listOf("Mia", "Leo", "Nina", "Sam", "Lily", "Max", "Rosa", "Theo")

        val RECIPES = listOf(
            Recipe("🍲", "Tomato Soup", listOf(Ing.TOMATO, Ing.CORN), 20, 10),
            Recipe("🥗", "Salad", listOf(Ing.CARROT, Ing.TOMATO), 15, 8),
            Recipe("🥞", "Pancake", listOf(Ing.FLOUR, Ing.EGGS), 20, 10),
            Recipe("🥤", "Strawberry Milk", listOf(Ing.STRAWBERRY, Ing.MILK), 15, 12),
            Recipe("🍕", "Pizza", listOf(Ing.FLOUR, Ing.TOMATO, Ing.CHEESE), 30, 15),
            Recipe("🍰", "Cake", listOf(Ing.FLOUR, Ing.EGGS, Ing.SUGAR), 25, 18),
            Recipe("🍔", "Burger", listOf(Ing.FLOUR, Ing.CHEESE, Ing.EGGS), 30, 14),
            Recipe("🥧", "Pumpkin Pie", listOf(Ing.PUMPKIN, Ing.FLOUR, Ing.SUGAR), 28, 16),
            Recipe("🧁", "Strawberry Cupcake", listOf(Ing.STRAWBERRY, Ing.FLOUR, Ing.SUGAR), 22, 18),
            Recipe("🍜", "Corn Chowder", listOf(Ing.CORN, Ing.MILK, Ing.CHEESE), 26, 12),
            Recipe("🧀", "Mac & Cheese", listOf(Ing.FLOUR, Ing.CHEESE, Ing.MILK), 30, 15),
            Recipe("🍨", "Ice Cream", listOf(Ing.MILK, Ing.SUGAR, Ing.STRAWBERRY), 18, 20),
        )

        val STOVE: Rect by lazy { World.furniture.first { it.name == "Stove" }.rect }
        val FRIDGE: Rect by lazy { World.furniture.first { it.name == "Fridge" }.rect }
        val TABLE: Rect by lazy { World.furniture.first { it.name == "Table" }.rect }
        val SINK: Rect by lazy { World.furniture.first { it.name == "Kitchen Sink" }.rect }
    }

    val pantry = mutableStateListOf(5, 5, 5, 5, 5)     // milk, eggs, cheese, flour, sugar
    val plates = mutableStateListOf<Int>()              // recipe index per plate on the table
    var cooks by mutableStateOf(0)
    var dirty by mutableStateOf(0)
    var phase by mutableStateOf(0)
    var t = 0f
    var recipe = 0
    var lastServed = 0

    /** Houses saved before "start small" keep the old rule (3 recipes + 1 per 3 meals). New houses start with Salad only. */
    private var legacy = false
    private val order = listOf(1, 0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11)      // Salad first, then the rest in this order

    // ---- the restaurant: guests sit at up to 6 tables. The HOST decides when they arrive; everybody sees the same guests.
    class OrderSlot { var recipe = -1; var left = 0f; var name = ""; var seq = 0; var result = 0 }
    val slots = Array(MAX_TABLES) { OrderSlot() }
    var orderVer by mutableStateOf(0)               // goes up whenever any order starts or ends (so the screen redraws)
    private var nextOrderIn = 25f                   // host only
    private var fridgeT = 0f                        // host only

    /** What you bought for the restaurant, in order. Houses saved before the restaurant upgrades have everything. */
    val rUnlocked = mutableStateListOf<String>()
    private var rLegacy = false

    fun rHas(key: String) = rLegacy || key in rUnlocked
    fun tables() = if (rLegacy) MAX_TABLES else 2 + listOf("T3", "T4", "T5", "T6").count { it in rUnlocked }
    fun counters() = if (rHas("C2")) 2 else 1
    fun rLevel() = if (rLegacy) 10 else min(10, 1 + rUnlocked.size)
    fun nextRUp(): Int = RUPS.indexOfFirst { it.key !in rUnlocked }
    fun cookMul() = if (rHas("STOVE")) 0.7f else 1f
    fun patience() = ORDER_S + if (rHas("C2")) 30f else 0f
    fun spawnEvery(): Float = when (tables()) { 2 -> 40f; 3 -> 35f; 4 -> 30f; 5 -> 25f; else -> 20f }
    /** Restaurant recipes can always be cooked, even if you have not unlocked them for yourself yet. */
    private fun restaurantRecipes(): List<Int> = if (rLegacy) emptyList() else listOf(0) + if ("BURGER" in rUnlocked) listOf(6) else emptyList()
    fun orderPool(): List<Int> = if (rLegacy) RECIPES.indices.filter { isUnlocked(it) } else restaurantRecipes()

    /** The waiting guest whose dish is already on the table (the one who has waited longest first), or -1. */
    fun servableSlot(): Int = slots.indices.filter { slots[it].recipe >= 0 && plates.contains(slots[it].recipe) }.minByOrNull { slots[it].left } ?: -1
    fun anyOrder(): Int = slots.indices.filter { slots[it].recipe >= 0 }.minByOrNull { slots[it].left } ?: -1

    fun tickOrders(dt: Float, isHost: Boolean) {
        for (s in slots) if (s.recipe >= 0) {
            s.left -= dt
            if (s.left <= 0f) { s.recipe = -1; s.result = 2; s.seq += 1; orderVer += 1 }
        }
        if (!isHost) return
        if (rHas("FRIDGE")) {
            fridgeT += dt
            if (fridgeT >= 180f) { fridgeT = 0f; for (i in pantry.indices) if (pantry[i] < 8) pantry[i] = pantry[i] + 1 }
        }
        nextOrderIn -= dt
        if (nextOrderIn <= 0f) {
            val free = (0 until tables()).filter { slots[it].recipe < 0 }
            val pool = orderPool()
            if (free.isNotEmpty() && pool.isNotEmpty()) {
                val s = slots[free.random()]
                s.recipe = pool.random(); s.left = patience(); s.name = GUESTS.random(); s.result = 0; s.seq += 1
                orderVer += 1
            }
            nextOrderIn = spawnEvery() + (Math.random() * 10.0).toFloat()
        }
    }

    /** Recipes found by mixing in the Recipe Book. Shared by the whole house, so nobody discovers the same thing twice. */
    val learned = mutableStateListOf<Int>()

    /** Which recipe these ingredients make (any order), or -1 for a weird mix. */
    fun matchRecipe(list: List<Ing>): Int = RECIPES.indexOfFirst { it.needs.toSet() == list.toSet() }

    fun isUnlocked(i: Int) =
        i in learned || i in restaurantRecipes() || if (legacy) i < min(RECIPES.size, 3 + cooks / 3)
        else order.indexOf(i).let { it in 0 until min(RECIPES.size, 1 + cooks / 2) }

    fun cooksToUnlock(i: Int) =
        if (legacy) max(0, (i - 2) * 3 - cooks)
        else max(0, order.indexOf(i) * 2 - cooks)

    fun have(ing: Ing): Int = if (ing.farmIdx >= 0) farm.harvested[ing.farmIdx] else pantry[ing.pantryIdx]

    private fun take(ing: Ing) {
        if (ing.farmIdx >= 0) farm.harvested[ing.farmIdx] = farm.harvested[ing.farmIdx] - 1
        else pantry[ing.pantryIdx] = pantry[ing.pantryIdx] - 1
    }

    fun canCook(i: Int) = i in RECIPES.indices && isUnlocked(i) && phase == 0 && RECIPES[i].needs.all { have(it) > 0 }

    fun tick(dt: Float) {
        when (phase) {
            1 -> { t += dt; if (t >= COOK_S * cookMul()) { phase = 2; t = 0f } }
            2 -> { t += dt; if (t >= BURN_S) { phase = 3; t = 0f } }
        }
    }

    /** Same rules on host and clients. Returns true if something changed. */
    fun apply(op: String, arg: Int): Boolean = when (op) {
        "COOK" -> if (canCook(arg)) {
            RECIPES[arg].needs.forEach { take(it) }
            recipe = arg; phase = 1; t = 0f
            true
        } else false
        "FINISH" -> if (phase == 1) { phase = 2; t = 0f; true } else false   // cooked by hand in the cooking game
        "SERVE" -> if (phase == 2 && plates.size < MAX_PLATES) {
            plates.add(recipe); lastServed = recipe
            cooks += 1; phase = 0; t = 0f
            true
        } else false
        "TRASH" -> if (phase == 3) { phase = 0; t = 0f; dirty += 1; true } else false
        "EAT" -> if (plates.isNotEmpty()) { plates.removeAt(0); dirty += 1; true } else false
        "WASH" -> if (dirty > 0) { dirty -= 1; true } else false
        "LEARN" -> if (arg in RECIPES.indices && arg !in learned) { learned.add(arg); true } else false
        "ORDER" -> slots.getOrNull(arg).let { s ->
            if (s != null && s.recipe >= 0 && plates.contains(s.recipe)) {
                plates.remove(s.recipe); s.recipe = -1; s.result = 1; s.seq += 1; orderVer += 1; true
            } else false
        }
        "RBUY" -> RUPS.getOrNull(arg).let { u -> if (u != null && !rLegacy && arg == nextRUp()) { rUnlocked.add(u.key); true } else false }
        "STOCK" -> if (arg in 0..4) { pantry[arg] = pantry[arg] + 1; true } else false   // bought at Fresh Mart
        "TAKE" -> if (arg in Ing.values().indices && have(Ing.values()[arg]) > 0) { take(Ing.values()[arg]); true } else false   // pet food
        else -> false
    }

    fun toJson(): JSONObject = JSONObject()
        .put("pan", JSONArray(pantry.toList()))
        .put("cooks", cooks).put("dirty", dirty).put("v", 2).put("lr", JSONArray(learned.toList()))
        .put("ru", JSONArray(rUnlocked.toList()))
        .put("os", JSONArray().also { a -> slots.forEach { a.put(JSONArray().put(it.recipe).put(it.left.toDouble()).put(it.name).put(it.seq).put(it.result)) } })
        .put("ph", phase).put("t", t.toDouble()).put("r", recipe)
        .put("pl", JSONArray(plates.toList()))

    fun load(o: JSONObject) {
        o.optJSONArray("pan")?.let { a -> for (i in 0 until min(a.length(), pantry.size)) pantry[i] = a.optInt(i) }
        cooks = o.optInt("cooks"); dirty = o.optInt("dirty"); legacy = !o.has("v")
        rLegacy = !o.has("ru")
        rUnlocked.clear()
        o.optJSONArray("ru")?.let { a -> for (i in 0 until a.length()) rUnlocked.add(a.optString(i)) }
        o.optJSONArray("os")?.let { a ->
            for (i in 0 until min(a.length(), slots.size)) a.optJSONArray(i)?.let { r ->
                slots[i].recipe = r.optInt(0, -1); slots[i].left = r.optDouble(1, 0.0).toFloat(); slots[i].name = r.optString(2)
                slots[i].seq = r.optInt(3); slots[i].result = r.optInt(4)
            }
        }
        orderVer += 1
        learned.clear()
        o.optJSONArray("lr")?.let { a -> for (i in 0 until a.length()) learned.add(a.optInt(i)) }
        phase = o.optInt("ph"); t = o.optDouble("t", 0.0).toFloat(); recipe = o.optInt("r").coerceIn(0, RECIPES.size - 1)
        plates.clear()
        o.optJSONArray("pl")?.let { a -> for (i in 0 until a.length()) plates.add(a.optInt(i)) }
    }
}
