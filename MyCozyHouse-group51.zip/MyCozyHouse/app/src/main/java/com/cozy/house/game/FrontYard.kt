package com.cozy.house.game

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import kotlin.math.sin

/** Where the front door is along the path, 0..1 of the screen width. */
internal const val YARD_DOOR = 0.6f

/** Every visit starts here: the front of your house. Walk to the door and press the hand to go inside. */
@Composable
internal fun FrontYard(pm: PlayerManager, paints: Paints) {
    Canvas(Modifier.fillMaxSize()) { drawYard(pm, paints) }
}

private fun DrawScope.drawYard(pm: PlayerManager, paints: Paints) {
    val w = size.width
    val h = size.height
    val t = pm.time
    val nc = drawContext.canvas.nativeCanvas
    val outline = Color(0xFF6B3E4E)
    fun X(f: Float) = w * f
    fun Y(f: Float) = h * f

    // sky + clouds
    drawRect(Brush.verticalGradient(listOf(Color(0xFFFFD9E8), Color(0xFFCDEBFF)), 0f, Y(0.62f)), Offset.Zero, Size(w, Y(0.62f)))
    for (i in 0 until 3) {
        val cx = ((t * 6f + i * w * 0.4f) % (w + 200f)) - 100f
        val cy = Y(0.1f + i * 0.07f)
        drawOval(Color.White.copy(alpha = 0.85f), Offset(cx - 60f, cy - 18f), Size(120f, 36f))
        drawOval(Color.White.copy(alpha = 0.85f), Offset(cx - 30f, cy - 32f), Size(70f, 40f))
    }
    // grass + path
    drawRect(Color(0xFFB9E4A2), Offset(0f, Y(0.6f)), Size(w, h - Y(0.6f)))
    drawRect(Color(0xFFE9D2A8), Offset(X(YARD_DOOR) - w * 0.05f, Y(0.6f)), Size(w * 0.1f, h - Y(0.6f)))
    drawRect(Color(0xFFFFF1C9), Offset(0f, Y(0.84f)), Size(w, h * 0.025f))      // sidewalk strip the character walks on

    // the house
    val hx = X(0.6f)
    val bodyL = hx - w * 0.27f
    val bodyW = w * 0.54f
    drawRect(Color(0xFFFFF0DC), Offset(bodyL, Y(0.26f)), Size(bodyW, Y(0.36f)))
    drawRect(outline, Offset(bodyL, Y(0.26f)), Size(bodyW, Y(0.36f)), style = Stroke(5f))
    drawRect(Color(0xFFE8A0B4), Offset(hx + w * 0.14f, Y(0.06f)), Size(w * 0.05f, Y(0.14f)))          // chimney
    val roof = Path().apply {
        moveTo(bodyL - w * 0.03f, Y(0.27f)); lineTo(hx, Y(0.04f)); lineTo(bodyL + bodyW + w * 0.03f, Y(0.27f)); close()
    }
    drawPath(roof, Color(0xFFF26D8F))
    drawPath(roof, outline, style = Stroke(5f))
    // windows with flower boxes
    for (side in listOf(-1f, 1f)) {
        val wx = hx + side * w * 0.17f
        drawRect(Color(0xFFBFE9FF), Offset(wx - w * 0.04f, Y(0.34f)), Size(w * 0.08f, Y(0.14f)))
        drawRect(outline, Offset(wx - w * 0.04f, Y(0.34f)), Size(w * 0.08f, Y(0.14f)), style = Stroke(4f))
        drawRect(Color(0xFFC98A5B), Offset(wx - w * 0.045f, Y(0.49f)), Size(w * 0.09f, Y(0.035f)))
        for (i in 0 until 4) drawCircle(listOf(Color(0xFFFF7BA5), Color(0xFFFFE066))[i % 2], 7f, Offset(wx - w * 0.032f + i * w * 0.021f, Y(0.488f)))
    }
    // the door
    val open = pm.yardFade > 0.02f
    val dw = w * 0.07f
    val dh = Y(0.3f)
    val dTop = Y(0.62f) - dh
    drawRoundRect(if (open) Color(0xFFFFF1A8) else Color(0xFFE88BA8), Offset(hx - dw / 2f, dTop), Size(dw, dh), androidx.compose.ui.geometry.CornerRadius(dw / 2f, dw / 2f))
    drawRoundRect(outline, Offset(hx - dw / 2f, dTop), Size(dw, dh), androidx.compose.ui.geometry.CornerRadius(dw / 2f, dw / 2f), style = Stroke(5f))
    drawCircle(Color(0xFFFFD35C), 6f, Offset(hx + dw * 0.25f, dTop + dh * 0.6f))
    // fence + flowers
    for (i in 0 until 8) {
        val fx = X(0.02f) + i * w * 0.035f
        drawRect(Color(0xFFD9A066), Offset(fx, Y(0.68f)), Size(w * 0.02f, Y(0.12f)))
        drawRect(outline, Offset(fx, Y(0.68f)), Size(w * 0.02f, Y(0.12f)), style = Stroke(3f))
    }
    for (i in 0 until 6) {
        val fx = X(0.82f) + i * w * 0.028f
        drawLine(Color(0xFF5BB36B), Offset(fx, Y(0.8f)), Offset(fx, Y(0.74f) + sin(t * 2f + i) * 2f), 4f)
        drawCircle(listOf(Color(0xFFFF7BA5), Color(0xFFFFFFFF), Color(0xFFFFE066))[i % 3], 9f, Offset(fx, Y(0.73f) + sin(t * 2f + i) * 2f))
    }
    paints.room.alpha = 255
    nc.drawText("My Cozy House", hx, Y(0.2f) - 4f, paints.room)

    // you, walking along the path
    val me = pm.me
    if (me != null) {
        val sc = h * 0.0036f
        withTransform({ translate(X(pm.yardX), Y(0.9f)); scale(sc, sc, Offset.Zero) }) {
            drawPlayer(me, true, false, paints, 0f, 0f, false, false)
        }
    }
    val atDoor = kotlin.math.abs(pm.yardX - YARD_DOOR) < 0.08f
    paints.emoji.alpha = 255
    paints.emoji.textSize = 30f
    if (atDoor && !open) nc.drawText("✋ Press to go in 🚪", hx, dTop - 14f, paints.room)
    else if (!open) nc.drawText("Walk to the front door 🚪", X(0.5f), Y(0.97f), paints.room)
    if (pm.yardFade > 0f) drawRect(Color.Black.copy(alpha = pm.yardFade), Offset.Zero, size)
}
