package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import com.cozy.house.Session
import com.cozy.house.net.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.*

/** One adapter so the game does not care if this phone is the host or a client. */
class GameNet(private val host: LanHostManager?, private val client: LanClientManager?) {
    val myId: String
        get() = host?.players?.value?.firstOrNull { it.isHost }?.id ?: client?.myId ?: "p1"
    val players: StateFlow<List<PlayerInfo>> = host?.players ?: client!!.players
    val events: SharedFlow<GameMessage> = host?.events ?: client!!.events

    fun send(m: GameMessage) {
        if (host != null) host.broadcast(m.copy(playerId = myId)) else client?.send(m)
    }

    companion object {
        fun current(): GameNet? =
            if (Session.host != null || Session.client != null) GameNet(Session.host, Session.client) else null
    }
}

class Dust(var x: Float, var y: Float, var age: Float = 0f)

class PlayerManager {
    val players = LinkedHashMap<String, PlayerState>()
    val dust = ArrayList<Dust>()

    var myId = ""
    var joyX = 0f
    var joyY = 0f

    // Compose state, but only changes when the text changes (cheap)
    var areaName by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    private var toastLeft = 0f

    private var net: GameNet? = null
    private var sendAcc = 0f
    private var keepAliveAcc = 0f
    private var wasMoving = false

    val me: PlayerState? get() = players[myId]

    companion object {
        const val SPEED = 190f          // world units per second (mood changes this in the next group)
    }

    // ------------------------------------------------------------ network

    /** Runs until cancelled. Restart it when the host changes. */
    suspend fun runNetwork(n: GameNet) = coroutineScope {
        net = n
        myId = n.myId
        launch { n.players.collect { syncRoster(it) } }
        launch { n.events.collect { onMessage(it) } }
    }

    private fun syncRoster(list: List<PlayerInfo>) {
        list.forEachIndexed { i, info ->
            val existing = players[info.id]
            if (existing == null) {
                val num = info.id.filter { it.isDigit() }.toIntOrNull() ?: i
                val p = PlayerState(info.id, info.name, num % 4)
                val s = World.spawn(i)
                p.x = s.x; p.y = s.y; p.tx = s.x; p.ty = s.y
                p.area = World.areaAt(p.x, p.y)
                players[info.id] = p
            } else existing.name = info.name
        }
        val ids = list.map { it.id }.toSet()
        players.keys.retainAll(ids)
        myId = net?.myId ?: myId
    }

    private fun onMessage(m: GameMessage) {
        if (m.type != MsgType.MOVE || m.playerId == myId) return
        val p = players[m.playerId] ?: return
        val nx = m.data.optInt("x").toFloat()
        val ny = m.data.optInt("y").toFloat()
        val now = System.currentTimeMillis()

        if (!p.seenMove) {
            p.x = nx; p.y = ny; p.tx = nx; p.ty = ny
            p.rx = nx; p.ry = ny
            p.seenMove = true
        } else {
            // position prediction: guess where they are now from their last speed
            val dtMs = now - p.lastMoveMs
            if (dtMs in 20..500) {
                p.vx = (nx - p.rx) / dtMs * 1000f
                p.vy = (ny - p.ry) / dtMs * 1000f
            }
            val speed = hypot(p.vx, p.vy)
            val cap = if (speed > SPEED * 1.3f) SPEED * 1.3f / speed else 1f
            p.tx = nx + p.vx * cap * 0.07f
            p.ty = ny + p.vy * cap * 0.07f
        }
        p.rx = nx; p.ry = ny
        p.lastMoveMs = now
        p.facing = if (m.data.optInt("f", 1) >= 0) 1 else -1
        p.moving = m.data.optInt("m", 0) == 1
        runCatching { p.area = Area.valueOf(m.data.optString("area")) }
        if (!p.moving) { p.vx = 0f; p.vy = 0f }
    }

    private fun sendMove(p: PlayerState) {
        net?.send(
            GameMessage(
                MsgType.MOVE, myId,
                JSONObject()
                    .put("x", p.x.roundToInt())
                    .put("y", p.y.roundToInt())
                    .put("area", p.area.name)
                    .put("f", p.facing)
                    .put("m", if (p.moving) 1 else 0)
            )
        )
    }

    // ------------------------------------------------------------ per frame

    fun update(dt: Float) {
        val m = me
        if (m != null) moveLocal(m, dt)

        for (p in players.values) {
            if (p.id != myId) {
                val k = 1f - exp(-12f * dt)   // smooth glide (lerp)
                p.x += (p.tx - p.x) * k
                p.y += (p.ty - p.y) * k
                if (p.moving) spawnDust(p, dt, 0f, 0f)
            }
            p.animT += dt
            p.blinkTimer -= dt
            if (p.blinkTimer <= 0f) { p.blinkLeft = 0.12f; p.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
            if (p.blinkLeft > 0f) p.blinkLeft -= dt
        }

        val it = dust.iterator()
        while (it.hasNext()) { val d = it.next(); d.age += dt; if (d.age > 0.5f) it.remove() }

        if (toastLeft > 0f) { toastLeft -= dt; if (toastLeft <= 0f) toast = null }
    }

    private fun moveLocal(m: PlayerState, dt: Float) {
        var jx = joyX
        var jy = joyY
        val len = hypot(jx, jy)
        if (len < 0.12f) { jx = 0f; jy = 0f } else if (len > 1f) { jx /= len; jy /= len }
        val moving = jx != 0f || jy != 0f

        if (moving) {
            val nx = m.x + jx * SPEED * dt
            if (!World.blocked(nx, m.y)) m.x = nx
            val ny = m.y + jy * SPEED * dt
            if (!World.blocked(m.x, ny)) m.y = ny
            if (abs(jx) > 0.15f) m.facing = if (jx > 0f) 1 else -1
            spawnDust(m, dt, jx, jy)
        }
        m.moving = moving
        m.tx = m.x; m.ty = m.y

        val a = World.areaAt(m.x, m.y)
        if (a != m.area || areaName.isEmpty()) { m.area = a; areaName = World.areaLabel(a) }

        // sync 15x per second while moving (+ one last packet when stopping, + 1/sec keep-alive)
        sendAcc += dt
        keepAliveAcc += dt
        if (sendAcc >= 1f / Net.MOVE_HZ) {
            sendAcc = 0f
            if (moving || wasMoving || keepAliveAcc >= 1f) { sendMove(m); keepAliveAcc = 0f }
            wasMoving = moving
        }
    }

    private fun spawnDust(p: PlayerState, dt: Float, jx: Float, jy: Float) {
        p.dustTimer -= dt
        if (p.dustTimer <= 0f) {
            p.dustTimer = 0.12f
            dust.add(Dust(p.x - jx * 8f - p.facing * 4f, p.y - 2f))
        }
    }

    // ------------------------------------------------------------ interact button

    fun interact() {
        val m = me ?: return
        val near = World.furniture
            .filter { it.interactive }
            .minByOrNull { World.distanceTo(it.rect, m.x, m.y) }
        val msg = if (near != null && World.distanceTo(near.rect, m.x, m.y) < 80f)
            "${near.name}: coming soon!" else "Nothing to do here"
        toast = msg
        toastLeft = 2f
    }
}
