package com.cozy.house.game

import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.Cozy
import com.cozy.house.Session
import com.cozy.house.net.Area
import kotlinx.coroutines.launch
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

private val OUT = Color(0xFF5B3A4A)
private val SHIRTS = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B))
private val HAIRS = listOf(Color(0xFF7B4B3A), Color(0xFF2F2A41), Color(0xFFE9A15B), Color(0xFFB57BDB))
private val SKIN = Color(0xFFFFE0C7)

private class Paints {
    val room = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 46f; color = 0x2E5B3A4A }
    val emoji = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER }
    val nameFill = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val nameStroke = Paint().apply {
        isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
}

@Composable
fun GameScreen(onExit: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    val pm = remember { PlayerManager() }
    val paints = remember { Paints() }
    var tick by remember { mutableStateOf(0L) }
    var leaving by remember { mutableStateOf(false) }

    // restarts by itself if the host changes
    LaunchedEffect(Session.host, Session.client) {
        GameNet.current()?.let { pm.runNetwork(it) }
    }
    // game loop, once per screen frame
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) pm.update(((now - last) / 1_000_000_000f).coerceAtMost(0.05f))
                last = now
                tick = now
            }
        }
    }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { leave() }

    Box(Modifier.fillMaxSize().background(Cozy.Cream)) {
        Canvas(Modifier.fillMaxSize()) {
            @Suppress("UNUSED_VARIABLE") val frame = tick // redraw every frame
            val s = size.height / 520f
            val viewW = size.width / s
            val viewH = 520f
            val me = pm.me
            val camX = ((me?.x ?: World.W / 2f) - viewW / 2f).coerceIn(0f, max(0f, World.W - viewW))
            val camY = ((me?.y ?: World.H / 2f) - viewH / 2f).coerceIn(0f, max(0f, World.H - viewH))

            withTransform({
                scale(s, s, Offset.Zero)
                translate(-camX, -camY)
            }) {
                drawWorld(paints)
                for (d in pm.dust) {
                    val life = 1f - d.age / 0.5f
                    drawCircle(Color(0xFFF2E3D0).copy(alpha = 0.6f * life), 3f + d.age * 14f, Offset(d.x, d.y))
                }
                val all = pm.players.values.sortedBy { it.y }
                for (p in all) {
                    val near = pm.players.values.any { o -> o !== p && hypotF(o.x - p.x, o.y - p.y) < 90f }
                    drawPlayer(p, p.id == pm.myId, near, paints)
                }
            }
        }

        // top-left: leave
        Box(
            Modifier.align(Alignment.TopStart).padding(12.dp)
                .background(Cozy.Pink, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                .clickable { leave() }.padding(horizontal = 14.dp, vertical = 6.dp)
        ) { Text("✕ Leave", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }

        // top-center: where am I
        if (pm.areaName.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(12.dp)
                    .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("📍 ${pm.areaName}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // toast from the Interact button
        pm.toast?.let {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)
                    .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(it, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // joystick left, interact right
        Joystick(
            Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 24.dp),
            onMove = { x, y -> pm.joyX = x; pm.joyY = y }
        )
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 36.dp, bottom = 36.dp).size(92.dp)
                .background(Cozy.Mint, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { pm.interact() },
            contentAlignment = Alignment.Center
        ) { Text("✋", fontSize = 36.sp) }
    }
}

private fun hypotF(a: Float, b: Float) = kotlin.math.sqrt(a * a + b * b)

// ------------------------------------------------------------------ joystick

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier.size(150.dp).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f * 0.6f
                fun update(p: Offset) {
                    var d = p - center
                    val len = d.getDistance()
                    if (len > radius) d = d * (radius / len)
                    knob = d
                    onMove(d.x / radius, d.y / radius)
                }
                update(down.position)
                var pressed = true
                while (pressed) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id }
                    if (change != null && change.pressed) {
                        update(change.position)
                        change.consume()
                    } else pressed = false
                }
                knob = Offset.Zero
                onMove(0f, 0f)
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.White.copy(alpha = 0.55f), size.width / 2f - 4f, c)
            drawCircle(OUT, size.width / 2f - 4f, c, style = Stroke(5f))
            drawCircle(Cozy.Pink, 30.dp.toPx(), c + knob)
            drawCircle(OUT, 30.dp.toPx(), c + knob, style = Stroke(5f))
        }
    }
}

// ------------------------------------------------------------------ drawing (world units)

private fun DrawScope.roundRectOutlined(tl: Offset, sz: Size, radius: Float, fill: Color, stroke: Float = 4f) {
    drawRoundRect(fill, tl, sz, CornerRadius(radius))
    drawRoundRect(OUT, tl, sz, CornerRadius(radius), style = Stroke(stroke))
}

private fun DrawScope.circleOutlined(c: Offset, r: Float, fill: Color, stroke: Float = 3f) {
    drawCircle(fill, r, c)
    drawCircle(OUT, r, c, style = Stroke(stroke))
}

private fun floorColor(a: Area) = when (a) {
    Area.BEDROOM -> Color(0xFFFFE3F0)
    Area.LIVING_ROOM -> Color(0xFFFFF3D6)
    Area.KITCHEN -> Color(0xFFE0F7EA)
    Area.BATHROOM -> Color(0xFFE0F0FF)
    Area.GARDEN -> Color(0xFFC9F0B8)
    Area.PLAYGROUND -> Color(0xFFFBE9B7)
    Area.TOWN -> Color(0xFFE8E8E8)
}

private fun DrawScope.drawWorld(paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas

    // floors
    for ((area, r) in World.rooms) {
        drawRect(floorColor(area), r.topLeft, r.size)
        val tiled = area == Area.KITCHEN || area == Area.BATHROOM
        if (tiled) {
            val alt = if (area == Area.KITCHEN) Color(0xFFCFF0DD) else Color(0xFFCDE6FA)
            var iy = 0
            var y = r.top
            while (y < r.bottom) {
                var ix = 0
                var x = r.left
                while (x < r.right) {
                    if ((ix + iy) % 2 == 0) drawRect(alt, Offset(x, y), Size(80f, 80f))
                    x += 80f; ix++
                }
                y += 80f; iy++
            }
        }
        nc.drawText(World.areaLabel(area), r.center.x, r.top + 80f, paints.room)
    }

    // furniture (soft things first so solid ones sit on top)
    for (f in World.furniture.sortedBy { if (it.solid) 1 else 0 }) {
        roundRectOutlined(f.rect.topLeft, f.rect.size, 14f, f.color)
        if (f.emoji.isNotEmpty()) {
            paints.emoji.textSize = minOf(f.rect.width, f.rect.height) * 0.6f
            nc.drawText(f.emoji, f.rect.center.x, f.rect.center.y + paints.emoji.textSize * 0.35f, paints.emoji)
        }
    }

    // walls
    for (w in World.walls) roundRectOutlined(w.topLeft, w.size, 8f, Color(0xFFE9B8CB), 4f)
}

private fun DrawScope.drawPlayer(p: PlayerState, isMe: Boolean, near: Boolean, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val x = p.x
    val y = p.y
    val run = p.animT * 14f
    val bob = if (p.moving) abs(sin(run)) * 5f else sin(p.animT * 2.5f) * 1.5f   // run bounce / idle breathing
    val step = if (p.moving) sin(run) * 5f else 0f
    val shirt = SHIRTS[p.colorIndex % 4]
    val hair = HAIRS[p.colorIndex % 4]

    // shadow
    drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 17f, y - 6f), Size(34f, 12f))

    // feet
    circleOutlined(Offset(x - 8f, y - 4f - max(0f, step)), 7f, Color.White)
    circleOutlined(Offset(x + 8f, y - 4f - max(0f, -step)), 7f, Color.White)

    // body + head (chibi: big head)
    roundRectOutlined(Offset(x - 14f, y - 32f - bob), Size(28f, 26f), 10f, shirt, 3f)
    val headY = y - 52f - bob
    circleOutlined(Offset(x, headY), 22f, SKIN)

    // hair
    drawArc(hair, 180f, 180f, true, Offset(x - 23f, headY - 23f), Size(46f, 46f))
    drawArc(OUT, 180f, 180f, false, Offset(x - 23f, headY - 23f), Size(46f, 46f), style = Stroke(3f))

    // eyes (blink)
    val eyeY = headY + 4f
    for (sx in listOf(-9f, 9f)) {
        val cx = x + sx + 2f * p.facing
        if (p.blinkLeft > 0f) {
            drawLine(OUT, Offset(cx - 5f, eyeY), Offset(cx + 5f, eyeY), 3f, StrokeCap.Round)
        } else {
            drawOval(OUT, Offset(cx - 5f, eyeY - 7f), Size(10f, 14f))
            drawCircle(Color.White, 2.2f, Offset(cx - 1f, eyeY - 3f))
        }
    }
    // blush when a friend is close
    if (near) {
        val blush = Color(0xFFFF7FA5).copy(alpha = 0.65f)
        drawCircle(blush, 6f, Offset(x - 15f, eyeY + 9f))
        drawCircle(blush, 6f, Offset(x + 15f, eyeY + 9f))
    }
    // mouth
    drawArc(OUT, 20f, 140f, false, Offset(x - 5f, eyeY + 4f), Size(10f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))

    // name
    val nameY = headY - 30f
    nc.drawText(p.name, x, nameY, paints.nameStroke)
    nc.drawText(p.name, x, nameY, paints.nameFill)
    if (isMe) drawCircle(Cozy.Pink, 4f, Offset(x, nameY - 20f))
}
