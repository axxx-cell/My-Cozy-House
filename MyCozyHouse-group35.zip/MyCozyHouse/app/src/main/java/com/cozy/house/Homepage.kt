package com.cozy.house

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.Emote
import com.cozy.house.game.HouseSaves
import com.cozy.house.game.Look
import com.cozy.house.game.LocalSave
import com.cozy.house.game.Paints
import com.cozy.house.game.PlayerState
import com.cozy.house.game.drawPlayer
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin
import kotlinx.coroutines.launch

private val BROWN = Color(0xFF6B3F2A)
private val NAVY = Color(0xE6FFF3E4)

/** House colours the player picks when building a house. */
class HouseTheme(val label: String, val roof: Color, val wall: Color, val door: Color, val garden: Boolean = false)

val HOUSE_THEMES = listOf(
    HouseTheme("Pink", Color(0xFFE9809F), Color(0xFFFFB9CB), Color(0xFFFFD6E0)),
    HouseTheme("Garden", Color(0xFF79B955), Color(0xFFFFF0D2), Color(0xFF8CCB6A), garden = true),
    HouseTheme("Blue", Color(0xFF4F80D8), Color(0xFFC3DBF6), Color(0xFF5B8FE0)),
    HouseTheme("Sunny", Color(0xFFF2A93B), Color(0xFFFFEDB5), Color(0xFFFFC857)),
    HouseTheme("Lavender", Color(0xFF9B7FD9), Color(0xFFE6DAFB), Color(0xFFB89BEA)),
)

/** The girl from the picture: long black hair, pink beanie, pink hoodie. */
private fun mascotLook() = Look(
    eyes = 2, brows = 5, blush = 1, hair = 0, hairColor = 0xFF1E1B26.toInt(),
    outfit = 1, outfitColor = 0xFFFF9EC4.toInt(), hat = 2, eyeColor = 0xFF4A3428.toInt()
)

private fun myLook(ctx: android.content.Context): Look =
    LocalSave.load(ctx).optString("look").takeIf { it.isNotEmpty() }?.let { Look.decode(it) } ?: mascotLook()

// ------------------------------------------------------------------ the house, seen from outside

private fun DrawScope.drawHouseScene(th: HouseTheme, t: Float, pv: PlayerState, paints: Paints) {
    val w = size.width
    val h = size.height
    val u = minOf(0.84f * h, w / 1.5f)
    val x0 = (w - 1.5f * u) / 2f
    val y0 = 0.054f * h
    fun X(v: Float) = x0 + v * u
    fun Y(v: Float) = y0 + v * u
    val lw = (u * 0.007f).coerceAtLeast(3f)
    val soft = Color.Black.copy(alpha = 0.10f)

    fun box(x: Float, y: Float, bw: Float, bh: Float, r: Float, c: Color) {
        drawRoundRect(c, Offset(X(x), Y(y)), Size(bw * u, bh * u), CornerRadius(r * u))
        drawRoundRect(BROWN, Offset(X(x), Y(y)), Size(bw * u, bh * u), CornerRadius(r * u), style = Stroke(lw))
    }
    fun ball(cx: Float, cy: Float, r: Float, c: Color) {
        drawCircle(c, r * u, Offset(X(cx), Y(cy)))
        drawCircle(BROWN, r * u, Offset(X(cx), Y(cy)), style = Stroke(lw * 0.8f))
    }
    fun cloud(cx: Float, cy: Float, s: Float) {
        for ((dx, dy, r) in listOf(Triple(-0.07f, 0.01f, 0.045f), Triple(0f, -0.025f, 0.06f), Triple(0.07f, 0f, 0.05f), Triple(0.025f, 0.02f, 0.045f))) {
            drawCircle(Color.White.copy(alpha = 0.95f), r * s * u, Offset(cx + dx * s * u, cy + dy * s * u))
        }
        drawOval(Color(0x22A8C8E8), Offset(cx - 0.09f * s * u, cy + 0.02f * s * u), Size(0.2f * s * u, 0.03f * s * u))
    }

    // --- sky: blue on top, warm cream at the horizon, sun glow, drifting clouds
    drawRect(Brush.verticalGradient(listOf(Color(0xFF7CC6F2), Color(0xFFBEE5FF), Color(0xFFFFF0D2)), 0f, h * 0.66f), size = Size(w, h * 0.66f))
    drawCircle(Brush.radialGradient(listOf(Color(0xCCFFF6C2), Color(0x00FFF6C2)), Offset(w * 0.86f, h * 0.2f), u * 0.55f), u * 0.55f, Offset(w * 0.86f, h * 0.2f))
    drawCircle(Color(0xFFFFF3B0), u * 0.06f, Offset(w * 0.86f, h * 0.2f))
    for ((i, c) in listOf(Triple(0.1f, 0.2f, 1.0f), Triple(0.55f, 0.13f, 0.8f), Triple(1.0f, 0.22f, 1.2f)).withIndex()) {
        val cx = ((c.first + t * (0.004f + i * 0.0015f)) % 1.9f) - 0.2f
        cloud(w * (cx / 1.5f).coerceIn(-0.2f, 1.2f), Y(c.second), c.third)
    }

    // --- layered hills + meadow
    drawCircle(Color(0xFFBDE59A), 0.6f * u, Offset(w * 0.1f, Y(1.0f)))
    drawCircle(Color(0xFFABDB82), 0.65f * u, Offset(w * 0.92f, Y(1.02f)))
    drawCircle(Color(0xFF9BD470), 0.5f * u, Offset(w * 0.5f, Y(1.1f)))
    drawRect(Brush.verticalGradient(listOf(Color(0xFF9FD86E), Color(0xFF6FBA4A)), Y(0.64f), h), Offset(0f, Y(0.64f)), Size(w, h - Y(0.64f)))
    for (k in 0..5) {   // soft mowing stripes
        drawOval(Color.White.copy(alpha = 0.07f), Offset(w * (k / 5f) - 0.2f * u, Y(0.72f + (k % 3) * 0.06f)), Size(0.5f * u, 0.05f * u))
    }

    // --- trees with blossoms
    val rndT = kotlin.random.Random(9)
    for (tx in listOf(0.03f, 1.47f)) {
        drawRoundRect(Brush.horizontalGradient(listOf(Color(0xFFB07A48), Color(0xFF8A5A30)), X(tx) - 0.03f * u, X(tx) + 0.03f * u),
            Offset(X(tx) - 0.025f * u, Y(0.45f)), Size(0.05f * u, 0.25f * u), CornerRadius(10f))
        for ((dx, dy, r) in listOf(Triple(0f, 0.34f, 0.15f), Triple(-0.1f, 0.42f, 0.105f), Triple(0.1f, 0.42f, 0.105f))) {
            drawCircle(Color(0xFF5FAE48), r * u, Offset(X(tx + dx), Y(dy + 0.012f)))
            drawCircle(Color(0xFF7FCB5C), r * u, Offset(X(tx + dx), Y(dy)))
            drawCircle(Color.White.copy(alpha = 0.18f), r * 0.55f * u, Offset(X(tx + dx - 0.03f), Y(dy - 0.035f)))
        }
        repeat(9) {
            val bx = tx + (rndT.nextFloat() - 0.5f) * 0.28f
            val by = 0.26f + rndT.nextFloat() * 0.2f
            drawCircle(th.roof.copy(alpha = 0.9f), 0.011f * u, Offset(X(bx), Y(by)))
        }
    }

    // --- shadow of the house on the grass
    drawOval(Color.Black.copy(alpha = 0.12f), Offset(X(0.3f), Y(0.675f)), Size(0.9f * u, 0.07f * u))

    // --- chimney + puffs of smoke (behind the roof)
    box(1.0f, 0.15f, 0.07f, 0.17f, 0.01f, Color(0xFFB88060))
    box(0.992f, 0.135f, 0.086f, 0.024f, 0.006f, Color(0xFF9C6648))
    for (i in 0..2) {
        val ph = (t * 0.3f + i / 3f) % 1f
        drawCircle(Color.White.copy(alpha = (1f - ph) * 0.85f), (0.016f + 0.022f * ph) * u, Offset(X(1.035f + ph * 0.05f + sin(t + i) * 0.006f), Y(0.12f - ph * 0.13f)))
    }

    // --- walls (light on top, stone base)
    drawRoundRect(Brush.verticalGradient(listOf(th.wall.copy(alpha = 1f), th.wall.copy(alpha = 1f).let { Color(it.red * 0.93f, it.green * 0.93f, it.blue * 0.93f) }), Y(0.44f), Y(0.7f)),
        Offset(X(0.4f), Y(0.44f)), Size(0.7f * u, 0.26f * u), CornerRadius(0.015f * u))
    for (k in 1..4) drawLine(Color.Black.copy(alpha = 0.05f), Offset(X(0.4f), Y(0.44f + k * 0.05f)), Offset(X(1.1f), Y(0.44f + k * 0.05f)), lw * 0.6f)
    drawRect(Color(0xFFC9B8A3), Offset(X(0.4f), Y(0.675f)), Size(0.7f * u, 0.025f * u))
    drawRoundRect(BROWN, Offset(X(0.4f), Y(0.44f)), Size(0.7f * u, 0.26f * u), CornerRadius(0.015f * u), style = Stroke(lw))

    // --- roof with light side, shingle rows and thick trim
    val roofFull = Path().apply { moveTo(X(0.3f), Y(0.48f)); lineTo(X(0.75f), Y(0.11f)); lineTo(X(1.2f), Y(0.48f)); close() }
    drawPath(roofFull, Brush.verticalGradient(listOf(th.roof.copy(alpha = 1f).let { Color(minOf(1f, it.red * 1.12f), minOf(1f, it.green * 1.12f), minOf(1f, it.blue * 1.12f)) }, th.roof), Y(0.11f), Y(0.48f)))
    val lightSide = Path().apply { moveTo(X(0.3f), Y(0.48f)); lineTo(X(0.75f), Y(0.11f)); lineTo(X(0.75f), Y(0.48f)); close() }
    drawPath(lightSide, Color.White.copy(alpha = 0.10f))
    for (k in 1..6) {
        val yy = 0.11f + 0.0575f * k
        val half = (yy - 0.11f) / 0.37f * 0.45f
        drawLine(Color.Black.copy(alpha = 0.16f), Offset(X(0.75f - half + 0.02f), Y(yy)), Offset(X(0.75f + half - 0.02f), Y(yy)), lw * 0.7f)
        var sx = 0.75f - half + 0.05f
        while (sx < 0.75f + half - 0.03f) {
            drawLine(Color.Black.copy(alpha = 0.10f), Offset(X(sx), Y(yy - 0.0575f)), Offset(X(sx), Y(yy)), lw * 0.5f)
            sx += 0.075f
        }
    }
    drawPath(roofFull, BROWN, style = Stroke(lw * 1.4f, join = StrokeJoin.Round))

    // --- attic window
    ball(0.75f, 0.31f, 0.045f, Color(0xFFD9F1FF))
    drawCircle(Color(0x55FFE9A0), 0.036f * u, Offset(X(0.75f), Y(0.31f)))
    drawLine(BROWN, Offset(X(0.705f), Y(0.31f)), Offset(X(0.795f), Y(0.31f)), lw * 0.7f)
    drawLine(BROWN, Offset(X(0.75f), Y(0.265f)), Offset(X(0.75f), Y(0.355f)), lw * 0.7f)

    // --- windows: shutters, curtains, warm glow, flower boxes
    for (wx in listOf(0.47f, 0.87f)) {
        box(wx - 0.035f, 0.5f, 0.03f, 0.13f, 0.005f, th.door)
        box(wx + 0.165f, 0.5f, 0.03f, 0.13f, 0.005f, th.door)
        box(wx, 0.5f, 0.16f, 0.13f, 0.01f, Color(0xFFD9F1FF))
        drawRect(Color(0x55FFE2A0), Offset(X(wx), Y(0.5f)), Size(0.16f * u, 0.13f * u))
        val curtain = Path().apply { moveTo(X(wx), Y(0.5f)); lineTo(X(wx + 0.04f), Y(0.5f)); lineTo(X(wx), Y(0.58f)); close() }
        drawPath(curtain, Color(0xFFFFB6CC).copy(alpha = 0.9f))
        val curtain2 = Path().apply { moveTo(X(wx + 0.16f), Y(0.5f)); lineTo(X(wx + 0.12f), Y(0.5f)); lineTo(X(wx + 0.16f), Y(0.58f)); close() }
        drawPath(curtain2, Color(0xFFFFB6CC).copy(alpha = 0.9f))
        drawLine(BROWN, Offset(X(wx + 0.08f), Y(0.5f)), Offset(X(wx + 0.08f), Y(0.63f)), lw * 0.8f)
        drawLine(BROWN, Offset(X(wx), Y(0.565f)), Offset(X(wx + 0.16f), Y(0.565f)), lw * 0.8f)
        box(wx - 0.01f, 0.63f, 0.18f, 0.04f, 0.008f, Color(0xFFC98B5B))
        val fc = listOf(Color(0xFFFF8FB5), Color(0xFFFFE066), Color(0xFFFFFFFF), Color(0xFFB69CFF))
        for (k in 0..5) {
            drawCircle(Color(0xFF5FB04A), 0.011f * u, Offset(X(wx + 0.01f + k * 0.03f), Y(0.628f)))
            drawCircle(fc[k % 4], 0.014f * u, Offset(X(wx + 0.01f + k * 0.03f), Y(0.618f)))
        }
    }

    // --- door with arch, wreath, step and a glowing lantern
    val door = Path().apply {
        moveTo(X(0.69f), Y(0.7f)); lineTo(X(0.69f), Y(0.56f))
        arcTo(androidx.compose.ui.geometry.Rect(X(0.69f), Y(0.5f), X(0.81f), Y(0.62f)), 180f, 180f, false)
        lineTo(X(0.81f), Y(0.7f)); close()
    }
    drawPath(door, th.door)
    drawLine(Color.Black.copy(alpha = 0.10f), Offset(X(0.75f), Y(0.5f)), Offset(X(0.75f), Y(0.7f)), lw * 0.6f)
    drawPath(door, BROWN, style = Stroke(lw, join = StrokeJoin.Round))
    drawCircle(Color(0xFFFFD25A), 0.01f * u, Offset(X(0.79f), Y(0.62f)))
    drawCircle(Color(0xFF6FBF4F), 0.03f * u, Offset(X(0.75f), Y(0.57f)), style = Stroke(0.013f * u))
    drawCircle(Color(0xFFFF8FB5), 0.008f * u, Offset(X(0.735f), Y(0.56f)))
    drawCircle(Color(0xFFFFE066), 0.008f * u, Offset(X(0.765f), Y(0.58f)))
    box(0.66f, 0.7f, 0.18f, 0.015f, 0.005f, Color(0xFFD9D2C3))
    val glow = 0.7f + 0.3f * sin(t * 3f)
    drawCircle(Brush.radialGradient(listOf(Color(0x88FFE49A).copy(alpha = 0.55f * glow), Color(0x00FFE49A)), Offset(X(0.64f), Y(0.56f)), 0.07f * u), 0.07f * u, Offset(X(0.64f), Y(0.56f)))
    box(0.627f, 0.54f, 0.026f, 0.04f, 0.006f, Color(0xFFFFE28A))

    // --- garden-house pots
    if (th.garden) {
        for (px in listOf(0.52f, 0.9f)) {
            for (k in 0..2) {
                val cx = px + k * 0.05f
                drawCircle(Color(0xFF5FB04A), 0.025f * u, Offset(X(cx), Y(0.668f)))
                box(cx - 0.02f, 0.69f, 0.04f, 0.035f, 0.006f, Color(0xFFD98A5A))
            }
        }
    }

    // --- bushes + flower beds along the house
    for (bx in listOf(0.46f, 0.58f, 0.94f, 1.06f)) {
        drawCircle(Color(0xFF5FAE48), 0.04f * u, Offset(X(bx), Y(0.69f)))
        drawCircle(Color(0xFF79C75A), 0.032f * u, Offset(X(bx - 0.01f), Y(0.683f)))
        val c2 = listOf(Color(0xFFFF8FB5), Color(0xFFFFE066), Color.White)
        for (k in 0..3) drawCircle(c2[(k + (bx * 10).toInt()) % 3], 0.009f * u, Offset(X(bx - 0.03f + k * 0.02f), Y(0.675f + (k % 2) * 0.012f)))
    }

    // --- stone path
    for (k in 0..3) {
        val cy = 0.75f + k * 0.05f
        drawOval(Color(0xFFE4DDCF), Offset(X(0.75f - 0.05f - k * 0.008f), Y(cy)), Size((0.1f + k * 0.016f) * u, 0.035f * u))
        drawOval(BROWN.copy(alpha = 0.45f), Offset(X(0.75f - 0.05f - k * 0.008f), Y(cy)), Size((0.1f + k * 0.016f) * u, 0.035f * u), style = Stroke(lw * 0.5f))
    }

    // --- white fences
    for (side in 0..1) {
        val start = if (side == 0) 0.07f else 1.11f
        for (k in 0 until 8) {
            val fx = start + k * 0.04f
            box(fx, 0.63f, 0.03f, 0.105f, 0.008f, Color(0xFFFFF8EC))
            drawLine(Color(0x22000000), Offset(X(fx + 0.022f), Y(0.635f)), Offset(X(fx + 0.022f), Y(0.73f)), lw * 0.5f)
        }
        drawLine(BROWN, Offset(X(start), Y(0.665f)), Offset(X(start + 0.32f), Y(0.665f)), lw * 0.7f)
    }

    // --- swaying flowers in the meadow
    val rnd = kotlin.random.Random(5)
    val cols = listOf(Color(0xFFFF8FB5), Color(0xFFFFE066), Color(0xFFB69CFF), Color(0xFFFFFFFF), Color(0xFFFFA45C), Color(0xFFFF6F91))
    repeat(60) {
        val fx = rnd.nextFloat() * w
        val fy = Y(0.72f) + rnd.nextFloat() * (h - Y(0.72f))
        val r = (0.012f + 0.016f * ((fy - Y(0.72f)) / (h - Y(0.72f)))) * u
        val sway = sin(t * 1.6f + it) * r * 0.5f
        drawLine(Color(0xFF4C9F3A), Offset(fx, fy + r * 2.2f), Offset(fx + sway, fy), r * 0.3f)
        for (a in 0..4) {
            val ang = a * 1.2566f
            drawCircle(cols[it % cols.size], r * 0.55f, Offset(fx + sway + cos(ang) * r * 0.7f, fy + sin(ang) * r * 0.7f))
        }
        drawCircle(Color(0xFFFFE9A8), r * 0.4f, Offset(fx + sway, fy))
    }

    // --- the character, standing in front of the house
    pv.animT = t
    pv.emote = null
    val sc = u * 0.0033f
    withTransform({ translate(X(0.93f), Y(0.86f)); scale(sc, sc, Offset.Zero) }) {
        drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
    }

    // --- butterflies
    for (i in 0..1) {
        val bx = X(0.3f + i * 0.7f + sin(t * 0.7f + i * 2f) * 0.18f)
        val by = Y(0.45f + i * 0.12f + sin(t * 1.3f + i) * 0.05f)
        val flap = 0.4f + 0.6f * abs(sin(t * 9f + i))
        val c = if (i == 0) Color(0xFFFF9EC4) else Color(0xFFFFD25A)
        drawOval(c, Offset(bx - 0.022f * u * flap, by - 0.012f * u), Size(0.022f * u * flap, 0.026f * u))
        drawOval(c, Offset(bx, by - 0.012f * u), Size(0.022f * u * flap, 0.026f * u))
        drawLine(BROWN, Offset(bx, by - 0.012f * u), Offset(bx, by + 0.016f * u), lw * 0.6f)
    }

    // --- floating petals + twinkles
    for (i in 0 until 14) {
        val py = ((t * 26f + i * h / 14f) % (h * 0.95f))
        val px = (i * w / 14f + sin(t * 0.8f + i) * 22f)
        drawOval(Color(0xFFFFB6CC).copy(alpha = 0.8f), Offset(px, py), Size(9f, 5f))
    }
    for (i in 0 until 7) {
        val a = (0.5f + 0.5f * sin(t * 2.2f + i * 1.7f))
        val sx = w * (0.1f + i * 0.13f)
        val sy = h * (0.2f + ((i * 37) % 30) / 100f)
        drawLine(Color.White.copy(alpha = a), Offset(sx - 7f, sy), Offset(sx + 7f, sy), 3f)
        drawLine(Color.White.copy(alpha = a), Offset(sx, sy - 7f), Offset(sx, sy + 7f), 3f)
    }
}

@Composable
fun HouseScene(theme: Int, look: Look, time: State<Float>, modifier: Modifier = Modifier) {
    val paints = remember { Paints() }
    val pv = remember { PlayerState("home", "", 0) }
    pv.updateLook(look)
    val th = HOUSE_THEMES[theme.coerceIn(0, HOUSE_THEMES.lastIndex)]
    Canvas(modifier) { drawHouseScene(th, time.value, pv, paints) }
}

// ------------------------------------------------------------------ homepage

@Composable
private fun OutlinedText(text: String, size: TextUnit, fill: Color, stroke: Color, width: Float = 12f) {
    Box {
        Text(text, fontSize = size, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
            style = TextStyle(color = stroke, drawStyle = Stroke(width = width, join = StrokeJoin.Round)))
        Text(text, fontSize = size, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, color = fill)
    }
}

@Composable
private fun RoundArrow(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(44.dp).clip(CircleShape).background(Color(0xCCFFF3E4))
            .border(3.dp, Color(0xFFF2A3BC), CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 22.sp, fontWeight = FontWeight.Black, color = BROWN) }
}

@Composable
private fun BottomButton(icon: String, label: String, color: Color, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(54.dp).background(color, RoundedCornerShape(16.dp))
            .border(3.dp, BROWN, RoundedCornerShape(16.dp)).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, fontSize = 20.sp)
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(notice: String?, onPlay: (HouseSaves.Info) -> Unit, onPick: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var houses by remember { mutableStateOf(HouseSaves.list(ctx)) }
    val look = remember { mascotLook() }
    var askDelete by remember { mutableStateOf(false) }
    var menuOpen by remember { mutableStateOf(false) }

    val first = remember { HouseSaves.lastPlayed(ctx)?.let { l -> houses.indexOfFirst { it.id == l.id } }?.coerceAtLeast(0) ?: 0 }
    val pager = rememberPagerState(initialPage = first, pageCount = { maxOf(1, houses.size) })
    val time = rememberInfiniteTransition(label = "t").animateFloat(
        0f, 600f, infiniteRepeatable(tween(600_000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val cur = houses.getOrNull(pager.currentPage)

    Box(Modifier.fillMaxSize()) {
        // the whole house, full screen; swipe sideways for the next one
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            HouseScene(houses.getOrNull(page)?.theme ?: 0, look, time, Modifier.fillMaxSize())
        }

        // slim top bar
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(8.dp)
                .background(NAVY, RoundedCornerShape(20.dp)).border(2.dp, Color(0xFFF2A3BC), RoundedCornerShape(20.dp))
                .padding(horizontal = 12.dp, vertical = 3.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            OutlinedText("🏠 My Cozy House 🏡", 20.sp, Color.White, Color(0xFFE9709A), 10f)
            Spacer(Modifier.weight(1f))
            AvatarBadge(look)
        }
        if (notice != null) {
            Text(notice, Modifier.align(Alignment.TopCenter).padding(top = 64.dp).background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(12.dp)).padding(8.dp),
                fontSize = 13.sp, color = Cozy.Error, textAlign = TextAlign.Center)
        }

        // small arrows at the sides (only when there is more than one house)
        if (houses.size > 1) {
            Box(Modifier.align(Alignment.CenterStart).padding(start = 8.dp)) {
                RoundArrow("‹") { scope.launch { pager.animateScrollToPage((pager.currentPage - 1 + houses.size) % houses.size) } }
            }
            Box(Modifier.align(Alignment.CenterEnd).padding(end = 8.dp)) {
                RoundArrow("›") { scope.launch { pager.animateScrollToPage((pager.currentPage + 1) % houses.size) } }
            }
            Text("Swipe to see next house", Modifier.align(Alignment.TopCenter).padding(top = 62.dp),
                fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White,
                style = TextStyle(shadow = Shadow(BROWN, Offset(1f, 2f), 4f)))
        }

        // retractable menu: Create / Join / How to play / Settings (+ delete)
        AnimatedVisibility(
            menuOpen,
            modifier = Modifier.align(Alignment.BottomEnd).padding(end = 10.dp, bottom = 80.dp),
            enter = fadeIn() + slideInVertically { it / 2 },
            exit = fadeOut() + slideOutVertically { it / 2 }
        ) {
            Row(
                Modifier.background(NAVY, RoundedCornerShape(20.dp)).border(2.dp, Color(0xFFF2A3BC), RoundedCornerShape(20.dp)).padding(8.dp),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                BottomButton("🔨", "CREATE HOUSE", Color(0xFFF2587A), Modifier.width(96.dp)) { menuOpen = false; onPick(Screen.CREATE) }
                BottomButton("👥", "JOIN HOUSE", Color(0xFF3E8EF0), Modifier.width(96.dp)) { menuOpen = false; onPick(Screen.JOIN) }
                BottomButton("📖", "HOW TO PLAY", Color(0xFF52BE34), Modifier.width(96.dp)) { menuOpen = false; onPick(Screen.HOW) }
                BottomButton("⚙️", "SETTINGS", Color(0xFFF2A91B), Modifier.width(96.dp)) { menuOpen = false; onPick(Screen.SETTINGS) }
                if (cur != null) BottomButton("🗑️", "DELETE", Color(0xFF9A7B6A), Modifier.width(80.dp)) { menuOpen = false; askDelete = true }
            }
        }

        // slim bottom strip: house name + dots, PLAY, menu button
        Row(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 8.dp, vertical = 6.dp)
                .background(NAVY, RoundedCornerShape(24.dp)).border(2.dp, Color(0xFFF2A3BC), RoundedCornerShape(24.dp))
                .padding(horizontal = 12.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column(Modifier.weight(1f), horizontalAlignment = Alignment.Start) {
                OutlinedText(cur?.name ?: "No house yet", 20.sp, Color.White, Color(0xFFE9709A), 10f)
                if (houses.size > 1) {
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(top = 2.dp)) {
                        houses.forEachIndexed { i, _ ->
                            Box(Modifier.size(9.dp).clip(CircleShape)
                                .background(if (i == pager.currentPage) Color(0xFFFF6FA0) else Color.Transparent)
                                .border(2.dp, if (i == pager.currentPage) Color(0xFFFF6FA0) else Color.White.copy(alpha = 0.8f), CircleShape))
                        }
                    }
                }
            }
            Box(
                Modifier.background(Brush.verticalGradient(listOf(Color(0xFFFF9DB4), Color(0xFFF2587A))), RoundedCornerShape(26.dp))
                    .border(3.dp, Color(0xFFFFC0D0), RoundedCornerShape(26.dp))
                    .clickable { if (cur != null) onPlay(cur) else onPick(Screen.CREATE) }
                    .padding(horizontal = 40.dp, vertical = 5.dp)
            ) {
                Text(if (cur != null) "▶ PLAY" else "🔨 BUILD", fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White,
                    style = TextStyle(shadow = Shadow(BROWN, Offset(2f, 3f), 4f)))
            }
            Box(Modifier.weight(1f), contentAlignment = Alignment.CenterEnd) {
                Box(
                    Modifier.size(46.dp).clip(CircleShape).background(Color(0xFFFFE08A))
                        .border(3.dp, BROWN, CircleShape).clickable { menuOpen = !menuOpen },
                    contentAlignment = Alignment.Center
                ) { Text(if (menuOpen) "✕" else "☰", fontSize = 22.sp, fontWeight = FontWeight.Black, color = BROWN) }
            }
        }
    }

    if (askDelete && cur != null) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("Delete ${cur.name}?") },
            text = { Text("The whole house is removed from this phone. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = { HouseSaves.delete(ctx, cur.id); houses = HouseSaves.list(ctx); askDelete = false }) { Text("Delete", color = Cozy.Error) }
            },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Keep it") } }
        )
    }
}

/** Round avatar picture for the top bar. */
@Composable
private fun AvatarBadge(look: Look) {
    val paints = remember { Paints() }
    val pv = remember { PlayerState("badge", "", 0) }
    pv.updateLook(look)
    Canvas(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFFFC2D6)).border(3.dp, Color.White, CircleShape)) {
        val sc = size.height / 62f
        withTransform({ translate(size.width / 2f, size.height * 1.12f); scale(sc, sc, Offset.Zero) }) {
            drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
        }
    }
}
