package com.cozy.house.net

import android.content.Context
import android.net.nsd.NsdManager
import android.net.nsd.NsdServiceInfo
import android.net.wifi.WifiManager
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONObject
import java.net.*
import java.util.concurrent.ConcurrentHashMap
import kotlin.coroutines.resume

/** One row of the Join list: House Name, Host, Players 1/4, Ping. */
data class HouseInfo(
    val name: String,
    val host: String,
    val players: Int,      // -1 = unknown (found by NSD only)
    val max: Int,
    val ip: String,
    val port: Int,
    val pingMs: Int = -1,  // -1 = not measured yet
)

/**
 * Finds houses on the same WiFi or hotspot using UDP broadcast (port 8888) AND NSD.
 * Call start() when the Join screen opens, stop() when it closes.
 */
class HouseScanner(context: Context) {
    private val appContext = context.applicationContext
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
    private val found = ConcurrentHashMap<String, HouseInfo>()   // key = ip
    private val lastSeen = ConcurrentHashMap<String, Long>()
    private val _houses = MutableStateFlow<List<HouseInfo>>(emptyList())
    val houses: StateFlow<List<HouseInfo>> = _houses

    private var multicast: WifiManager.MulticastLock? = null
    private var discovery: NsdManager.DiscoveryListener? = null
    private var running = false

    fun start() {
        if (running) return
        running = true
        scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        try {
            val wifi = appContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicast = wifi.createMulticastLock("cozy-scan").apply { setReferenceCounted(false); acquire() }
        } catch (_: Exception) {}
        scope.launch { udpLoop() }
        scope.launch { pingLoop() }
        startNsd()
    }

    fun stop() {
        running = false
        scope.cancel()
        discovery?.let { d ->
            runCatching { (appContext.getSystemService(Context.NSD_SERVICE) as NsdManager).stopServiceDiscovery(d) }
        }
        discovery = null
        runCatching { multicast?.release() }
        multicast = null
    }

    /** Pull-to-refresh: forget everything and let broadcasts refill the list. */
    fun refresh() {
        found.clear(); lastSeen.clear(); publish()
    }

    private fun publish() {
        _houses.value = found.values.sortedBy { it.name.lowercase() }
    }

    private fun upsert(h: HouseInfo, overwriteCounts: Boolean = true) {
        val old = found[h.ip]
        found[h.ip] = when {
            old == null -> h
            overwriteCounts -> h.copy(pingMs = old.pingMs)
            else -> old.copy(pingMs = old.pingMs)   // NSD must not wipe the real player count
        }
        lastSeen[h.ip] = System.currentTimeMillis()
        publish()
    }

    private fun prune() {
        val now = System.currentTimeMillis()
        var changed = false
        for ((ip, t) in lastSeen) {
            if (now - t > 6000) { found.remove(ip); lastSeen.remove(ip); changed = true }
        }
        if (changed) publish()
    }

    // ------------------------------------------------------------ UDP

    private suspend fun udpLoop() {
        try {
            DatagramSocket(null as SocketAddress?).use { s ->
                s.reuseAddress = true
                s.bind(InetSocketAddress(Net.UDP_PORT))
                s.soTimeout = 1000
                val buf = ByteArray(1024)
                while (currentCoroutineContext().isActive) {
                    try {
                        val p = DatagramPacket(buf, buf.size)
                        s.receive(p)
                        val o = JSONObject(String(p.data, 0, p.length))
                        if (o.optString("app") == "myhouse") {
                            val ip = o.optString("ip").ifBlank { p.address.hostAddress ?: "" }
                            if (ip.isNotBlank()) {
                                upsert(HouseInfo(
                                    name = o.optString("name", "House"),
                                    host = o.optString("host", "?"),
                                    players = o.optInt("players", 1),
                                    max = o.optInt("max", Net.MAX_PLAYERS),
                                    ip = ip,
                                    port = o.optInt("port", Net.TCP_PORT),
                                ))
                            }
                        }
                    } catch (_: SocketTimeoutException) {
                    } catch (_: Exception) {
                    }
                    prune()
                }
            }
        } catch (_: Exception) {}
    }

    // ------------------------------------------------------------ Ping (TCP connect time)

    private suspend fun pingLoop() {
        while (currentCoroutineContext().isActive) {
            for (h in found.values.toList()) {
                try {
                    val t0 = System.nanoTime()
                    Socket().use { it.connect(InetSocketAddress(h.ip, h.port), 700) }
                    val ms = ((System.nanoTime() - t0) / 1_000_000).toInt().coerceAtLeast(1)
                    found[h.ip]?.let { found[h.ip] = it.copy(pingMs = ms) }
                    lastSeen[h.ip] = System.currentTimeMillis()
                } catch (_: Exception) {}
            }
            publish()
            delay(3000)
        }
    }

    // ------------------------------------------------------------ NSD

    private fun startNsd() {
        try {
            val nsd = appContext.getSystemService(Context.NSD_SERVICE) as NsdManager
            val queue = Channel<NsdServiceInfo>(Channel.UNLIMITED)

            // NSD can only resolve one service at a time, so resolve through a queue.
            scope.launch {
                for (svc in queue) {
                    val r = withTimeoutOrNull(3000) {
                        suspendCancellableCoroutine<NsdServiceInfo?> { cont ->
                            nsd.resolveService(svc, object : NsdManager.ResolveListener {
                                override fun onResolveFailed(s: NsdServiceInfo, e: Int) { if (cont.isActive) cont.resume(null) }
                                override fun onServiceResolved(s: NsdServiceInfo) { if (cont.isActive) cont.resume(s) }
                            })
                        }
                    } ?: continue
                    val addr = r.host
                    if (addr is Inet4Address) {
                        val ip = addr.hostAddress ?: continue
                        val host = r.attributes["host"]?.toString(Charsets.UTF_8) ?: "?"
                        upsert(HouseInfo(r.serviceName, host, -1, Net.MAX_PLAYERS, ip, r.port), overwriteCounts = false)
                    }
                }
            }

            val l = object : NsdManager.DiscoveryListener {
                override fun onStartDiscoveryFailed(t: String, e: Int) {}
                override fun onStopDiscoveryFailed(t: String, e: Int) {}
                override fun onDiscoveryStarted(t: String) {}
                override fun onDiscoveryStopped(t: String) {}
                override fun onServiceFound(s: NsdServiceInfo) {
                    if (s.serviceType.contains("_myhouse")) queue.trySend(s)
                }
                override fun onServiceLost(s: NsdServiceInfo) {}
            }
            discovery = l
            nsd.discoverServices(Net.NSD_SERVICE_TYPE, NsdManager.PROTOCOL_DNS_SD, l)
        } catch (_: Exception) {
            // UDP + manual IP still work
        }
    }
}
