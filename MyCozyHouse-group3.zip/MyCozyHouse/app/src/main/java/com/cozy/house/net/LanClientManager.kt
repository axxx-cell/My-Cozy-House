package com.cozy.house.net

import android.content.Context
import android.os.SystemClock
import kotlinx.coroutines.*
import kotlinx.coroutines.channels.Channel
import kotlinx.coroutines.flow.*
import org.json.JSONObject
import java.io.BufferedReader
import java.net.InetSocketAddress
import java.net.Socket

enum class ConnState { IDLE, CONNECTING, CONNECTED, RECONNECTING, KICKED, FULL, LOST }

/** Emitted when THIS phone must become the new host. Start a LanHostManager with hostId = myId. */
data class HostHandover(
    val myId: String,
    val myName: String,
    val avatar: JSONObject,
    val state: JSONObject,
    val gameTimeMs: Long,
)

/**
 * Joins a house. Handles the lobby roster, game messages, ping,
 * and automatic host migration (reconnects to the new host, or asks to become it).
 */
class LanClientManager(context: Context) {
    private val appContext = context.applicationContext
    private var scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    private val _state = MutableStateFlow(ConnState.IDLE)
    val state: StateFlow<ConnState> = _state

    private val _players = MutableStateFlow<List<PlayerInfo>>(emptyList())
    val players: StateFlow<List<PlayerInfo>> = _players

    private val _pingMs = MutableStateFlow(-1)
    val pingMs: StateFlow<Int> = _pingMs

    private val _events = MutableSharedFlow<GameMessage>(extraBufferCapacity = 256)
    /** MOVE, CHAT, BUY, CUSTOM, SYNC (non-snapshot), START, JOIN/LEAVE-style relays. */
    val events: SharedFlow<GameMessage> = _events

    private val _becomeHost = MutableSharedFlow<HostHandover>(extraBufferCapacity = 4)
    val becomeHost: SharedFlow<HostHandover> = _becomeHost

    var myId: String = ""
        private set
    var houseName: String = ""
        private set
    var hostName: String = ""
        private set
    /** Latest game clock sent by the host (ms into the 30-minute game day). */
    var gameTimeMs: Long = 0L
        private set
    /** Latest full-state snapshot from the host (every 5 s). */
    var lastState: JSONObject = JSONObject()
        private set

    private class NextHost(val id: String, val name: String, val ip: String, val state: JSONObject?, val gameTimeMs: Long)

    private var socket: Socket? = null
    private var out: Channel<String>? = null
    private var myName = ""
    private var myAvatar = JSONObject()
    private var intentional = false
    private var pendingHost: NextHost? = null

    // ---------------------------------------------------------------- connect

    /** Works for a house from the list OR a manually typed IP. Returns true when the lobby is joined. */
    suspend fun connect(ip: String, name: String, avatar: JSONObject = JSONObject(), port: Int = Net.TCP_PORT): Boolean {
        if (scope.coroutineContext[Job]?.isActive != true) scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)
        intentional = false
        pendingHost = null
        myName = name.take(12)
        myAvatar = avatar
        _state.value = ConnState.CONNECTING
        val ok = openSocket(ip, port, wantedId = "")
        if (!ok && _state.value == ConnState.CONNECTING) _state.value = ConnState.IDLE
        return ok
    }

    private suspend fun openSocket(ip: String, port: Int, wantedId: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val s = Socket()
            s.tcpNoDelay = true
            s.connect(InetSocketAddress(ip, port), 3000)
            s.soTimeout = 5000
            val w = s.getOutputStream()
            val r = s.getInputStream().bufferedReader()
            w.write(GameMessage.join(wantedId, myName, myAvatar).encode().toByteArray())
            w.flush()

            val first = GameMessage.decode(r.readLine() ?: throw IllegalStateException("closed"))
                ?: throw IllegalStateException("bad message")
            when (first.type) {
                MsgType.WELCOME -> {
                    s.soTimeout = 9000 // host talks at least every 5 s; silence = host lost
                    myId = first.playerId
                    houseName = first.data.optString("houseName")
                    hostName = first.data.optString("hostName")
                    gameTimeMs = first.data.optLong("gameTimeMs")
                    lastState = first.data.optJSONObject("state") ?: JSONObject()
                    _players.value = PlayerInfo.listFromJson(first.data.optJSONArray("players"))

                    val ch = Channel<String>(Channel.UNLIMITED)
                    socket = s
                    out = ch
                    _state.value = ConnState.CONNECTED
                    scope.launch {
                        try { for (line in ch) { w.write(line.toByteArray()); w.flush() } } catch (_: Exception) {}
                    }
                    scope.launch { readLoop(s, r) }
                    scope.launch {
                        while (isActive && socket === s) {
                            ch.trySend(GameMessage.ping(SystemClock.elapsedRealtime()).encode())
                            delay(Net.PING_EVERY_MS)
                        }
                    }
                    true
                }
                MsgType.KICK -> {
                    _state.value = if (first.data.optString("reason") == "FULL") ConnState.FULL else ConnState.KICKED
                    runCatching { s.close() }
                    false
                }
                else -> { runCatching { s.close() }; false }
            }
        } catch (e: Exception) {
            false
        }
    }

    // ---------------------------------------------------------------- receive

    private suspend fun readLoop(s: Socket, r: BufferedReader) {
        try {
            while (true) {
                val line = r.readLine() ?: break
                val m = GameMessage.decode(line) ?: continue
                handle(m)
            }
        } catch (_: Exception) {}
        if (socket === s) onDisconnected()
    }

    private fun handle(m: GameMessage) {
        when (m.type) {
            MsgType.LOBBY -> _players.value = PlayerInfo.listFromJson(m.data.optJSONArray("players"))
            MsgType.PONG -> _pingMs.value = (SystemClock.elapsedRealtime() - m.data.optLong("t")).toInt().coerceAtLeast(0)
            MsgType.SYNC -> {
                if (m.data.optString("kind") == "SNAPSHOT") {
                    gameTimeMs = m.data.optLong("gameTimeMs")
                    lastState = m.data.optJSONObject("state") ?: lastState
                } else _events.tryEmit(m)
            }
            MsgType.KICK -> {
                intentional = true
                _state.value = ConnState.KICKED
                closeSocket()
            }
            MsgType.HOST_CHANGE -> pendingHost = NextHost(
                id = m.data.optString("newHostId"),
                name = m.data.optString("newHostName"),
                ip = m.data.optString("newHostIp"),
                state = m.data.optJSONObject("state"),
                gameTimeMs = m.data.optLong("gameTimeMs"),
            )
            MsgType.START, MsgType.MOVE, MsgType.CHAT, MsgType.BUY, MsgType.CUSTOM,
            MsgType.JOIN, MsgType.LEAVE -> _events.tryEmit(m)
            else -> {}
        }
    }

    // ---------------------------------------------------------------- host migration

    private fun onDisconnected() {
        if (intentional) return
        closeSocket()
        _state.value = ConnState.RECONNECTING
        scope.launch { migrate() }
    }

    private suspend fun migrate() {
        val roster = _players.value
        // Planned hand-over names the new host; a host crash falls back to "first player after the host".
        // Every phone has the same roster, so every phone picks the same new host.
        val next = pendingHost ?: roster.firstOrNull { !it.isHost && it.id != "" }?.let {
            NextHost(it.id, it.name, it.ip, null, gameTimeMs)
        }
        if (next == null) { _state.value = ConnState.LOST; return }

        if (next.id == myId) {
            _becomeHost.emit(HostHandover(myId, myName, myAvatar, next.state ?: lastState, next.gameTimeMs))
            _state.value = ConnState.IDLE
            return
        }
        repeat(12) {
            delay(1000) // give the new host time to open its server
            if (openSocket(next.ip, Net.TCP_PORT, wantedId = myId)) { pendingHost = null; return }
        }
        _state.value = ConnState.LOST
    }

    // ---------------------------------------------------------------- send / leave

    fun send(msg: GameMessage) { out?.trySend(msg.copy(playerId = myId).encode()) }

    fun sendMove(x: Int, y: Int, area: Area) = send(GameMessage.move(myId, x, y, area))

    fun sendChat(text: String) = send(GameMessage.chat(myId, text))

    /** Leave on purpose. No host migration is triggered for this phone. */
    suspend fun leave() {
        intentional = true
        out?.trySend(GameMessage.leave(myId).encode())
        delay(200)
        closeSocket()
        _players.value = emptyList()
        _state.value = ConnState.IDLE
    }

    private fun closeSocket() {
        val s = socket
        socket = null
        runCatching { out?.close() }
        out = null
        runCatching { s?.close() }
    }

    /** Call when the screen is destroyed. */
    fun release() {
        intentional = true
        closeSocket()
        scope.cancel()
    }
}
