package com.cozy.house.game

import androidx.compose.runtime.mutableStateListOf
import androidx.compose.ui.geometry.Rect
import org.json.JSONArray
import org.json.JSONObject

class PlacedItem(val uid: Int, val item: Int, var x: Int, var y: Int, var rot: Int)

/**
 * The shared house: furniture in storage + furniture placed in the world.
 * Same pattern as the farm: every phone keeps a copy, the HOST is the boss and syncs it.
 * Bought furniture is shared by everybody; coins stay personal.
 */
/** A room that starts locked. Unlock with stars (the gate is the door gap). */
class RoomGate(val key: String, val name: String, val stars: Int, val gate: Rect, val needs: String?)

class HouseManager {
    companion object {
        val GATES = listOf(
            RoomGate("BEDROOM", "Bedroom", 1, Rect(788f, 260f, 812f, 380f), null),
            RoomGate("BATHROOM", "Bathroom", 2, Rect(340f, 628f, 460f, 652f), "BEDROOM"),
            RoomGate("PLAYGROUND", "Playground", 3, Rect(1940f, 628f, 2060f, 652f), null),
        )
    }

    /** Rooms already unlocked. New houses start with Living Room, Kitchen and Garden only. */
    val openRooms = mutableStateListOf<String>()
    val inventory = mutableStateListOf<Int>()        // item ids in storage (the same id can appear many times)
    val placed = mutableStateListOf<PlacedItem>()
    init { rebuild() }          // locks the doors of a brand-new house (must stay below the lists above)

    fun rectOf(pi: PlacedItem, f: Furn): Rect {
        val w = (if (pi.rot % 2 == 0) f.w else f.h) / 2f
        val h = (if (pi.rot % 2 == 0) f.h else f.w) / 2f
        return Rect(pi.x - w, pi.y - h, pi.x + w, pi.y + h)
    }

    /** Solid furniture blocks the player. */
    fun rebuild() {
        World.locked = GATES.filter { it.key !in openRooms }.map { it.gate }
        World.dynamic = placed.mapNotNull { pi ->
            FurnitureCatalog.byId(pi.item)?.takeIf { it.solid }?.let { f ->
                val r = rectOf(pi, f)
                Rect(r.left + 3f, r.top + 3f, r.right - 3f, r.bottom - 3f)
            }
        }
    }

    /** Same rules on host and clients. Returns true if something changed. */
    fun apply(op: String, item: Int, x: Int, y: Int, rot: Int, uid: Int): Boolean {
        when (op) {
            "ROOM" -> {
                val g = GATES.getOrNull(item) ?: return false
                if (g.key in openRooms) return false
                openRooms.add(g.key); rebuild(); return true
            }
            "ADD" -> {
                if (FurnitureCatalog.byId(item) == null) return false
                inventory.add(item)
                return true
            }
            "PLACE" -> {
                val i = inventory.indexOf(item)
                if (i < 0) return false
                inventory.removeAt(i)
                placed.add(PlacedItem(uid, item, x, y, rot and 3))
                rebuild()
                return true
            }
            "STORE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                inventory.add(p.item)
                rebuild()
                return true
            }
            "DELETE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                placed.remove(p)
                rebuild()
                return true
            }
            "MOVE" -> {
                val p = placed.firstOrNull { it.uid == uid } ?: return false
                p.x = x; p.y = y; p.rot = rot and 3
                rebuild()
                return true
            }
        }
        return false
    }

    fun toJson(): JSONObject {
        val pl = JSONArray()
        placed.forEach { pl.put(JSONArray().put(it.uid).put(it.item).put(it.x).put(it.y).put(it.rot)) }
        return JSONObject().put("inv", JSONArray(inventory.toList())).put("pl", pl).put("rooms", JSONArray(openRooms.toList()))
    }

    fun load(o: JSONObject) {
        openRooms.clear()
        if (o.has("rooms")) o.optJSONArray("rooms")?.let { a -> for (i in 0 until a.length()) openRooms.add(a.optString(i)) }
        else GATES.forEach { openRooms.add(it.key) }      // houses saved before locked rooms: everything stays open
        inventory.clear()
        o.optJSONArray("inv")?.let { a -> for (i in 0 until a.length()) inventory.add(a.optInt(i)) }
        placed.clear()
        o.optJSONArray("pl")?.let { a ->
            for (i in 0 until a.length()) {
                val r = a.optJSONArray(i) ?: continue
                placed.add(PlacedItem(r.optInt(0), r.optInt(1), r.optInt(2), r.optInt(3), r.optInt(4)))
            }
        }
        rebuild()
    }
}
