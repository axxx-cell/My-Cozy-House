package com.cozy.house.game

/** price 0 = free (you own it from the start), price -1 = not for sale (gift: seasonal / birthday). */
class Acc(val cat: String, val id: Int, val name: String, val emoji: String, val price: Int, val stars: Int = 0, val shop: String = "style")

object Accessories {
    val CATS = listOf("hat", "glasses", "earrings", "backpack", "shoes", "handheld")
    val CAT_LABEL = mapOf("hat" to "Hat", "glasses" to "Glasses", "earrings" to "Earrings", "backpack" to "Backpack", "shoes" to "Shoes", "handheld" to "Held")

    val ALL: List<Acc> = listOf(
        // Hats (15). Santa + Pumpkin are free gifts in their season, Birthday Cake Hat is a birthday gift.
        Acc("hat", 1, "Cap", "🧢", 15), Acc("hat", 2, "Beanie", "🧶", 20), Acc("hat", 3, "Cowboy Hat", "🤠", 25),
        Acc("hat", 4, "Flower Crown", "🌸", 25), Acc("hat", 5, "Headphones", "🎧", 30),
        Acc("hat", 6, "Santa Hat", "🎅", -1, shop = "gift"), Acc("hat", 7, "Pumpkin Hat", "🎃", -1, shop = "gift"),
        Acc("hat", 8, "Birthday Cake Hat", "🎂", -1, shop = "gift"),
        Acc("hat", 9, "Fox Ears", "🦊", 25), Acc("hat", 10, "Cat Ears", "🐱", 25), Acc("hat", 11, "Angel Halo", "😇", 30),
        Acc("hat", 12, "Devil Horns", "😈", 30), Acc("hat", 13, "Crown", "👑", 40), Acc("hat", 14, "Golden Crown", "👑", 0, stars = 2),
        Acc("hat", 15, "Party Hat", "🎉", 15),
        // Glasses (8)
        Acc("glasses", 1, "Round Glasses", "👓", 15), Acc("glasses", 2, "Square Glasses", "👓", 15), Acc("glasses", 3, "Sunglasses", "🕶️", 20),
        Acc("glasses", 4, "Heart Glasses", "💗", 20), Acc("glasses", 5, "Star Glasses", "⭐", 20), Acc("glasses", 6, "Sleep Mask", "😴", 15),
        Acc("glasses", 7, "Cat-Eye Glasses", "😺", 20), Acc("glasses", 8, "Goggles", "🥽", 25),
        // Earrings (5, "None" is the default)
        Acc("earrings", 1, "Stud Earrings", "⚪", 10), Acc("earrings", 2, "Hoop Earrings", "⭕", 12),
        Acc("earrings", 3, "Star Earrings", "⭐", 15), Acc("earrings", 4, "Heart Earrings", "❤️", 15),
        // Backpacks (6, "None" is the default)
        Acc("backpack", 1, "Cat Backpack", "🐱", 30), Acc("backpack", 2, "Dog Backpack", "🐶", 30), Acc("backpack", 3, "Bunny Backpack", "🐰", 30),
        Acc("backpack", 4, "Star Backpack", "⭐", 25), Acc("backpack", 5, "School Backpack", "🎒", 25),
        // Shoes (5; id 0 = the starter white shoes, Barefoot is free)
        Acc("shoes", 1, "Sneakers", "👟", 20), Acc("shoes", 2, "Boots", "🥾", 25), Acc("shoes", 3, "Sandals", "🩴", 15),
        Acc("shoes", 4, "Slippers", "🩰", 15), Acc("shoes", 5, "Barefoot", "🦶", 0),
        // Handheld: Style Star sells 3, the Toy Shop sells the toys
        Acc("handheld", 2, "Balloon", "🎈", 10), Acc("handheld", 3, "Lollipop", "🍭", 8), Acc("handheld", 4, "Book", "📖", 12),
        Acc("handheld", 1, "Bubble Wand", "🫧", 15, shop = "toy"), Acc("handheld", 5, "Ball", "⚽", 15, shop = "toy"),
        Acc("handheld", 6, "Kite", "🪁", 20, shop = "toy"), Acc("handheld", 7, "Water Gun", "🔫", 20, shop = "toy"),
    )

    fun of(cat: String) = ALL.filter { it.cat == cat }
}

fun Look.accOf(cat: String): Int = when (cat) {
    "hat" -> hat; "glasses" -> glasses; "earrings" -> earrings; "backpack" -> backpack; "shoes" -> shoes; else -> handheld
}

fun Look.withAcc(cat: String, id: Int): Look = when (cat) {
    "hat" -> copy(hat = id); "glasses" -> copy(glasses = id); "earrings" -> copy(earrings = id)
    "backpack" -> copy(backpack = id); "shoes" -> copy(shoes = id); else -> copy(handheld = id)
}
