package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.cozy.house.Session
import com.cozy.house.net.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import kotlin.math.*

/** One adapter so the game does not care if this phone is the host or a client. */
class GameNet(private val host: LanHostManager?, private val client: LanClientManager?) {
    val myId: String
        get() = host?.players?.value?.firstOrNull { it.isHost }?.id ?: client?.myId ?: "p1"
    val isHost: Boolean get() = host != null
    val players: StateFlow<List<PlayerInfo>> = host?.players ?: client!!.players
    val events: SharedFlow<GameMessage> = host?.events ?: client!!.events

    fun send(m: GameMessage) {
        if (host != null) host.broadcast(m.copy(playerId = myId)) else client?.send(m)
    }

    companion object {
        fun current(): GameNet? =
            if (Session.host != null || Session.client != null) GameNet(Session.host, Session.client) else null
    }
}

class Dust(var x: Float, var y: Float, var age: Float = 0f)

/** "+5 Coins!" text that rises, then a coin flies to the top bar. */
class Floater(val text: String, val emoji: String, val x: Float, val y: Float, val t0: Float)

/** kind 0 = heart, 1 = confetti */
class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    val life: Float, val kind: Int, val color: Color, var age: Float = 0f, val spin: Float = 0f,
)

class PlayerManager {
    val players = LinkedHashMap<String, PlayerState>()
    val dust = ArrayList<Dust>()
    val particles = ArrayList<Particle>()

    // ---- farm + garden life
    val farm = FarmManager()
    val kitchen = KitchenManager(farm)
    var panel by mutableStateOf<String?>(null)   // "FRIDGE" or "RECIPES"
    var fridgeOpenT = 0f
    var dialog by mutableStateOf<String?>(null)   // "SLEEP"
    var cookIndex by mutableStateOf(0)             // recipe being cooked in the cooking game
    var tv by mutableStateOf(0)                   // 0..2 channels, 3 = off
    var tvStatic = 0f
    val mg = MinigameManager()
    val clock = DayClock()
    // ---- coins, stars, daily login, local save
    val floaters = ArrayList<Floater>()
    var coinBump by mutableStateOf(0)
    var starBump by mutableStateOf(0)
    var bonusText by mutableStateOf("")
    private var bonusLeft = 0f
    private var appCtx: android.content.Context? = null
    private var saveAcc = 0f
    private var pendingPetKind = -1
    private var loginChecked = false
    private var loginStreak = 0
    private var lastLoginDay = -1L
    var outfitVouchers = 0
    var myLook by mutableStateOf(Look.default(0))
    val ownedGarments = mutableStateListOf<Int>()      // clothes bought at Style Star (personal)
    val ownedAcc = mutableStateListOf<String>()        // accessories, e.g. "hat:6" (personal)
    val votes = HouseVoteManager()                      // shared "move it here?" votes (host counts)
    var decoSel by mutableStateOf(0)                    // uid of the piece being moved in Decorate Mode
    var decoX by mutableStateOf(0)
    var decoY by mutableStateOf(0)
    var decoRot by mutableStateOf(0)
    val house = HouseManager()                          // shared furniture (host is the boss)
    private var pendingBedRect: androidx.compose.ui.geometry.Rect? = null
    private var seasonChecked = false
    val savedLooks = mutableStateListOf("", "", "", "", "")     // 5 saved looks: School, Party, Sleep, Farming, Town
    private val twinCd = HashMap<String, Float>()
    private var lookApplied = false
    private var hasSavedLook = false
    // ---- Town
    val shopkeepers = TownData.shops.map { s ->
        PlayerState("shop_${s.id}", s.keeper, s.colorIdx).apply {
            x = s.x + 140f; y = 1478f; facing = 1; happiness = 50
            val i = TownData.shops.indexOf(s)
            updateLook(Look.default(s.colorIdx).copy(hair = (i * 5 + 2) % 30, skin = i % 8, eyes = (i * 3) % 12, mouth = (i * 2) % 10, outfit = i % 6))
        }
    }
    val walkers = listOf(
        PlayerState("walker1", "Resident", 2).apply { x = 400f; y = 1475f; facing = 1; happiness = 50 },
        PlayerState("walker2", "Resident", 0).apply { x = 1500f; y = 1650f; facing = -1; happiness = 50 },
        PlayerState("walker3", "Resident", 3).apply { x = 2000f; y = 1650f; facing = -1; happiness = 50 },
    )
    var shopId by mutableStateOf("")
    var riding by mutableStateOf(false)
    private var busLeft = 0f
    private var busDest: Offset? = null
    private val honkCd = FloatArray(4)
    val ownedPets = mutableStateListOf<Int>()
    val petStock = mutableStateListOf(-1, -1, -1, -1, -1, 1, 1)      // -1 = always in stock; Fox and Panda: 1 each
    private var lastStockDay = 1
    private var prevPet = -1
    // ---- NPCs, secrets, seasons
    val grandma = PlayerState("npc_grandma", "Grandma", 3).apply {
        x = 1150f; y = 1170f; facing = 1; happiness = 50
        updateLook(Look.default(3).copy(hair = 13, hairColor = 0xFFEDEDED.toInt(), skin = 1, outfit = 2, outfitColor = 0xFFB57BDB.toInt(), eyes = 1, mouth = 0))
    }
    val mailman = PlayerState("npc_mail", "Mailman", 1).apply {
        y = 1228f; happiness = 50
        updateLook(Look.default(1).copy(hair = 9, outfit = 4, outfitColor = 0xFF6BB3FF.toInt(), skin = 4))
    }
    var grandmaOn = false
    var mailmanOn = false
    var npcName by mutableStateOf("")
    var npcText by mutableStateOf("")
    var rainbowT = 0f
    var seasonOverride by mutableStateOf(-1)      // -1 = real date, tap the clock 7x to preview seasons
    private var rosterReady = false
    private var lastGrandmaDay = -1L
    private var lastMailDay = -1L
    private var lastBrokeDay = -1L
    private var treasureDay = -1
    private var treasureStar = false
    private var digs = 0
    private var prevWeather = Weather.SUNNY
    private var rainbowCheered = true
    private var lastKPhase = 0
    private var clockTaps = 0
    private var lastClockTap = 0L
    // ---- my pet
    var petKind by mutableStateOf(-1)
    val hasPet: Boolean get() = petKind >= 0
    var petName by mutableStateOf("")
    var petHunger by mutableStateOf(100)
    var petHappy by mutableStateOf(100)
    var nearPet by mutableStateOf(false)
    private var petHungerF = 100f
    private var petHappyF = 100f
    private var petIdle = 0f
    private var petDig = 0f
    private var digTimer = 25f
    private var petStuck = 0f
    private var petCd = 0f
    val quests = QuestManager()
    var xp by mutableStateOf(0)
    var level by mutableStateOf(1)
    var stars by mutableStateOf(0)
    var clockText by mutableStateOf("")
    var clockFrac by mutableStateOf(0f)
    private var clockSyncAcc = 0f
    private var ambientAcc = 3f
    private var mgSyncAcc = 0f
    private var mgRewardRound = -1
    private var mgTeleportRound = -1
    private var lastBeepSec = -1
    private var lastFin = 0
    var onToy by mutableStateOf(false)            // swing or seesaw: show "Get off"
    private var lastSwingSign = 0
    private var seeLastY = 0f
    private var seeLastDir = 0
    var fogT = 0f
    var catWagT = 0f
    private var standPos: Offset? = null
    private var pendingBed: String? = null
    private var lastBrushMs = 0L
    private var crackleAcc = 0f
    private var sizzleAcc = 0f
    private val eatLog = ArrayList<Long>()
    val critters = ArrayList<Critter>()
    var time = 0f
    var camX = 0f
    var camY = 0f
    var viewScale = 1f
    // ---- camera: pinch to zoom, two fingers to look around, tilt for a 3D-ish view
    var camZoom = 1f
    var camPanX = 0f
    var camPanY = 0f
    var camTilt by mutableStateOf(0f)
    fun zoomBy(f: Float) { camZoom = (camZoom * f).coerceIn(0.45f, 2.6f) }
    fun panBy(dxPx: Float, dyPx: Float) {
        camPanX = (camPanX - dxPx / viewScale).coerceIn(-800f, 800f)
        camPanY = (camPanY - dyPx / viewScale).coerceIn(-600f, 600f)
    }
    fun cycleTilt() { camTilt = if (camTilt < 10f) 28f else if (camTilt < 40f) 48f else 0f }
    fun resetCamera() { camZoom = 1f; camPanX = 0f; camPanY = 0f; camTilt = 0f }
    private var farmSyncAcc = 0f
    private var rainAcc = 0f

    init {
        repeat(3) { critters.add(Critter(0, Critter.X0 + Math.random().toFloat() * 700f, Critter.Y0 + Math.random().toFloat() * 500f)) }
        repeat(2) { critters.add(Critter(1, 900f + Math.random().toFloat() * 300f, 720f + Math.random().toFloat() * 200f)) }
        repeat(2) { critters.add(Critter(2, Critter.X0 + Math.random().toFloat() * 700f, Critter.Y0 + Math.random().toFloat() * 500f)) }
    }

    var myId = ""
    var joyX = 0f
    var joyY = 0f

    // ---- stats (floats inside, ints for the UI so it only redraws when a number changes)
    private var energyF = 100f
    private var hungerF = 100f
    private var happyF = 100f
    var energy by mutableStateOf(100)
    var hunger by mutableStateOf(100)
    var happiness by mutableStateOf(100)
    var coins by mutableStateOf(0)

    // ---- UI state
    var areaName by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    var nearbyFriend by mutableStateOf<String?>(null)
    var carryingId by mutableStateOf<String?>(null)
    var carriedById by mutableStateOf<String?>(null)

    // ---- chat
    val chatLog = mutableStateListOf<String>()
    var unread by mutableStateOf(0)
    @Volatile var rosterInfo: List<PlayerInfo> = emptyList()
    private var toastLeft = 0f

    private var net: GameNet? = null
    private var sendAcc = 0f
    private var keepAliveAcc = 0f
    private var wasMoving = false
    private var actionCd = 0f
    private var hungryNag = 0f

    val me: PlayerState? get() = players[myId]

    companion object {
        const val SPEED = 190f
        val SWING_X = floatArrayOf(1940f, 2060f)
        const val SWING_Y = 756f
        const val SWING_L = 74f
        val SEE_X = floatArrayOf(1960f, 2120f)
        const val SEE_Y = 1060f
        const val SEE_A = 22f
        private val CONFETTI = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFFD9B3FF))
    }

    /** Mood decides speed: sad = slow, happy = fast, no energy = 20% slower (never blocked). */
    private fun mySpeed(): Float {
        var s = SPEED
        if (happyF > 80f) s *= 1.2f else if (happyF < 30f) s *= 0.7f
        if (energyF <= 0f) s *= 0.8f
        if (me?.carrying != null) s *= 0.85f
        if (myLook.personality == 1) s *= 1.05f          // Energetic
        if (mg.game == MinigameManager.TAG && mg.phase == 2 && mg.itId == myId) s *= 1.15f   // IT is a bit faster
        return s
    }

    private fun addHappy(n: Float) { happyF = min(100f, happyF + n) }

    // ------------------------------------------------------------ network

    suspend fun runNetwork(n: GameNet) = coroutineScope {
        net = n
        myId = n.myId
        launch { n.players.collect { syncRoster(it) } }
        launch { n.events.collect { onMessage(it) } }
    }

    private fun syncRoster(list: List<PlayerInfo>) {
        rosterInfo = list
        list.forEachIndexed { i, info ->
            val existing = players[info.id]
            if (existing == null) {
                val num = info.id.filter { it.isDigit() }.toIntOrNull() ?: i
                val p = PlayerState(info.id, info.name, num % 4)
                val s = World.spawn(i)
                p.x = s.x; p.y = s.y; p.tx = s.x; p.ty = s.y
                p.area = World.areaAt(p.x, p.y)
                players[info.id] = p
                if (rosterReady && info.id != myId) {          // wave when a friend joins
                    me?.let { it.emote = Emote.WAVE; it.emoteT = 0f }
                    showToast("👋 ${info.name} joined!")
                }
            } else existing.name = info.name
        }
        rosterReady = true
        players.keys.retainAll(list.map { it.id }.toSet())
        myId = net?.myId ?: myId
        for (p in players.values) {          // someone left while carrying / being carried
            if (p.carriedBy != null && players[p.carriedBy!!] == null) p.carriedBy = null
            if (p.carrying != null && players[p.carrying!!] == null) p.carrying = null
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun onMessage(m: GameMessage) {
        when (m.type) {
            MsgType.MOVE -> onMove(m)
            MsgType.CUSTOM -> onCustom(m)
            MsgType.CHAT -> onChat(m)
            else -> {}
        }
    }

    private fun onMove(m: GameMessage) {
        if (m.playerId == myId) return
        val p = players[m.playerId] ?: return
        val nx = m.data.optInt("x").toFloat()
        val ny = m.data.optInt("y").toFloat()
        val now = System.currentTimeMillis()

        if (!p.seenMove) {
            p.x = nx; p.y = ny; p.tx = nx; p.ty = ny
            p.seenMove = true
        } else {
            val dtMs = now - p.lastMoveMs
            if (dtMs in 20..500) {
                p.vx = (nx - p.rx) / dtMs * 1000f
                p.vy = (ny - p.ry) / dtMs * 1000f
            }
            val speed = hypot(p.vx, p.vy)
            val cap = if (speed > SPEED * 1.5f) SPEED * 1.5f / speed else 1f
            p.tx = nx + p.vx * cap * 0.07f
            p.ty = ny + p.vy * cap * 0.07f
        }
        p.rx = nx; p.ry = ny
        p.lastMoveMs = now
        p.facing = if (m.data.optInt("f", 1) >= 0) 1 else -1
        p.moving = m.data.optInt("m", 0) == 1
        p.happiness = m.data.optInt("hp", 100)
        p.z = m.data.optInt("z").toFloat()
        p.combo = m.data.optInt("cb")
        val lk = m.data.optString("lk")
        if (lk.isNotEmpty() && lk != p.lookStr) Look.decode(lk)?.let { p.look = it; p.lookStr = lk }
        p.petType = m.data.optInt("pt", -1)
        if (p.petType >= 0) {
            val ox = m.data.optInt("pxx").toFloat()
            val oy = m.data.optInt("pyy").toFloat()
            if (!p.petSeen) { p.petX = ox; p.petY = oy; p.petSeen = true }
            p.petTx = ox; p.petTy = oy
            p.petSleep = m.data.optInt("ps") == 1
            p.petName = m.data.optString("pn")
        }
        runCatching { p.area = Area.valueOf(m.data.optString("area")) }
        if (!p.moving) { p.vx = 0f; p.vy = 0f }
    }

    private fun onCustom(m: GameMessage) {
        val sender = players[m.playerId]
        when (m.data.optString("kind")) {
            "EMOTE" -> {
                val e = Emote.values().firstOrNull { it.name == m.data.optString("emote") } ?: return
                sender?.emote = e; sender?.emoteT = 0f
                SoundFx.emote(e.ordinal)
            }
            "HUG", "HIGHFIVE" -> {
                val hug = m.data.optString("kind") == "HUG"
                val target = players[m.data.optString("target")]
                if (sender == null || target == null) return
                if (hug) { hearts(sender.x, sender.y - 60f); hearts(target.x, target.y - 60f); sender.blushT = 3f; target.blushT = 3f; SoundFx.hug() }
                else { confetti((sender.x + target.x) / 2f, min(sender.y, target.y) - 50f); SoundFx.highFive() }
                if (target.id == myId) {
                    addHappy(if (hug) 10f else 5f)
                    if (hug) { target.emote = Emote.LOVE; target.emoteT = 0f }
                }
            }
            "SHOP_STATE" -> if (net?.isHost != true) m.data.optJSONArray("stock")?.let { a ->
                for (i in 0 until minOf(a.length(), petStock.size)) petStock[i] = a.optInt(i)
            }
            "SHOP_REQ" -> if (net?.isHost == true && m.data.optString("op") == "BUYPET") {
                val t = m.data.optInt("type")
                if (t in 5..6 && petStock[t] > 0) { petStock[t] = petStock[t] - 1; broadcastShop() }
                else sendCustom(JSONObject().put("kind", "SHOP_DENY").put("to", m.playerId).put("type", t))
            }
            "SHOP_DENY" -> if (m.data.optString("to") == myId) {          // somebody else got the last one first
                val t = m.data.optInt("type")
                val d = PetCatalog.list.getOrNull(t)
                if (d != null) { if (d.stars > 0) stars += d.stars else coins += price(d.coins, "pet$t") }
                ownedPets.remove(t)
                if (me?.petType == t) { if (prevPet >= 0) switchPet(prevPet) else { me?.petType = -1; petKind = -1; petName = "" } }
                showToast("Sold out! Someone just bought it. You got a refund 💸")
            }
            "CAFE_TREAT" -> if (m.playerId != myId) {
                val mm = me
                if (mm != null && hypot(mm.x - m.data.optInt("x"), mm.y - m.data.optInt("y")) < 160f) {
                    eatEffect(m.data.optInt("e"), m.data.optInt("h"))
                    showToast("${sender?.name ?: "A friend"} shared a treat! 😋 +Energy +Happiness")
                }
            }
            "HOUSE_STATE" -> if (net?.isHost != true) house.load(m.data.optJSONObject("state") ?: return)
            "HOUSE_ACT" -> if (net?.isHost == true) {
                val op = m.data.optString("op")
                if (op != "DELETE" && op != "MOVE" && house.apply(op, m.data.optInt("item"), m.data.optInt("x"), m.data.optInt("y"), m.data.optInt("rot"), m.data.optInt("uid"))) broadcastHouse()
            }
            "VOTE_REQ" -> if (net?.isHost == true) hostStartVote(m.data.optInt("uid"), m.data.optInt("x"), m.data.optInt("y"), m.data.optInt("rot"), m.playerId)
            "VOTE_CAST" -> if (net?.isHost == true) {
                val r = votes.cast(m.data.optInt("id"), m.playerId, m.data.optInt("yes") == 1, players.keys.toSet())
                if (r != null) finishVote(r) else broadcastVote()
            }
            "VOTE_STATE" -> if (net?.isHost != true) votes.current = VoteState.fromJson(m.data.optJSONObject("state") ?: return)
            "VOTE_END" -> if (net?.isHost != true) {
                val v = votes.current
                votes.current = null
                if (m.data.optInt("ok") == 1) {
                    if (v != null) confetti(v.x.toFloat(), v.y - 50f)
                    showToast("🎉 Moved! The house said YES!")
                } else showToast("The house said no. It stays here 🙅")
            }
            "VOTE_DENY" -> if (m.data.optString("to") == myId) showToast(m.data.optString("msg"))
            "CLOCK" -> if (net?.isHost != true) clock.load(m.data.optJSONObject("state") ?: return)
            "MG_REQ" -> if (net?.isHost == true) {
                when (m.data.optString("op")) {
                    "START" -> mg.start(m.data.optInt("game"), players.keys.toList())
                    "POP" -> mg.popRequest(m.data.optInt("idx"), m.playerId)
                }
            }
            "MG_STATE" -> if (net?.isHost != true) mg.load(m.data.optJSONObject("state") ?: return)
            "PLAY_ACT" -> {
                when (m.data.optString("op")) {
                    "SWING_ON" -> sender?.let { it.swing = m.data.optInt("arg"); it.swingAng = 0f }
                    "SWING_OFF" -> sender?.swing = -1
                    "SEE_ON" -> sender?.seesaw = m.data.optInt("arg")
                    "SEE_OFF" -> sender?.seesaw = -1
                    "PUSH" -> if (m.data.optString("target") == myId) me?.let {
                        if (it.swing >= 0) { it.swingVel += if (it.swingVel >= 0f) 2.6f else -2.6f; SoundFx.squeak() }
                    }
                    "SLIDE" -> SoundFx.whoosh()
                }
            }
            "ROOM_ACT" -> {
                when (m.data.optString("op")) {
                    "SLEEP" -> sender?.let { it.sleeping = true; it.sleepT = 0f; it.dream = m.data.optInt("arg") }
                    "WAKE" -> sender?.sleeping = false
                    "SIT" -> sender?.seated = true
                    "STAND" -> sender?.seated = false
                    "SHOWER" -> { sender?.let { it.showerT = 4f; it.busyT = 4f }; fogT = 20f }
                    "BATH" -> sender?.let { it.bathT = 6f; it.busyT = 6f }
                    "TV" -> { tv = m.data.optInt("arg"); tvStatic = 0.5f }
                    "WAKE_OTHER" -> if (m.data.optString("target") == myId && me?.sleeping == true) {
                        wake(false)
                        showToast("⏰ ${sender?.name ?: "A friend"} woke you up!")
                    }
                }
            }
            "KITCHEN_ACT" -> {
                val op = m.data.optString("op")
                if (sender != null) kitchenFx(sender, op)
                if (net?.isHost == true && kitchen.apply(op, m.data.optInt("arg"))) { broadcastKitchen(); broadcastFarm() }
            }
            "KITCHEN_STATE" -> if (net?.isHost != true) kitchen.load(m.data.optJSONObject("state") ?: return)
            "FARM_ACT" -> {
                val op = m.data.optString("op")
                val idx = m.data.optInt("plot")
                if (sender != null) farmFx(sender, op, idx)
                if (net?.isHost == true && farm.apply(op, idx, m.data.optInt("crop"))) broadcastFarm()
            }
            "FARM_STATE" -> if (net?.isHost != true) farm.load(m.data.optJSONObject("state") ?: return)
            "CARRY" -> applyCarry(m.data.optString("carrier"), m.data.optString("carried"), m.data.optInt("on") == 1)
        }
    }

    private fun applyCarry(carrierId: String, carriedId: String, on: Boolean) {
        val carrier = players[carrierId] ?: return
        val carried = players[carriedId] ?: return
        if (on) {
            carrier.carrying = carriedId; carried.carriedBy = carrierId
        } else {
            carrier.carrying = null; carried.carriedBy = null
            // put down next to the carrier
            carried.x = carrier.x + 34f * carrier.facing; carried.y = carrier.y
            if (World.blocked(carried.x, carried.y)) { carried.x = carrier.x; carried.y = carrier.y }
            carried.tx = carried.x; carried.ty = carried.y; carried.rx = carried.x; carried.ry = carried.y
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun onChat(m: GameMessage) {
        val p = players[m.playerId] ?: return
        val text = m.data.optString("text").trim().take(60)
        if (text.isEmpty()) return
        p.chat = text; p.chatT = 0f
        addLog("${p.name}: $text")
        unread += 1
        SoundFx.pop()
    }

    private fun addLog(line: String) {
        chatLog.add(line)
        while (chatLog.size > 30) chatLog.removeAt(0)
    }

    fun sendChat(raw: String) {
        val m = me ?: return
        val text = raw.trim().take(60)
        if (text.isEmpty()) return
        m.chat = text; m.chatT = 0f
        addLog("${m.name}: $text")
        net?.send(GameMessage.chat(myId, text))
    }

    /** Voice goes straight to every other player's phone. */
    fun peerIps(): List<String> = rosterInfo.filter { it.id != myId && it.ip.isNotBlank() }.map { it.ip }

    fun myNumber(): Int = myId.filter { it.isDigit() }.toIntOrNull() ?: 0

    private fun sendCustom(o: JSONObject) {
        net?.send(GameMessage(MsgType.CUSTOM, myId, o))
    }

    private fun sendMove(p: PlayerState) {
        net?.send(
            GameMessage(
                MsgType.MOVE, myId,
                JSONObject()
                    .put("x", p.x.roundToInt())
                    .put("y", p.y.roundToInt())
                    .put("area", p.area.name)
                    .put("f", p.facing)
                    .put("m", if (p.moving) 1 else 0)
                    .put("hp", happyF.roundToInt())
                    .put("z", p.z.roundToInt())
                    .put("cb", p.combo)
                    .put("lk", p.lookStr)
                    .put("pt", p.petType)
                    .put("pxx", p.petX.roundToInt())
                    .put("pyy", p.petY.roundToInt())
                    .put("ps", if (p.petSleep) 1 else 0)
                    .put("pn", p.petName)
            )
        )
    }

    // ------------------------------------------------------------ per frame

    fun update(dt: Float) {
        voteUpdate(dt)
        val m = me
        if (m != null) {
            updateStats(m, dt)
            playUpdate(m, dt)
            moveLocal(m, dt)
            updateNearby(m)
        }

        for (p in players.values) {
            if (p.id != myId) {
                val k = 1f - exp(-12f * dt)
                p.x += (p.tx - p.x) * k
                p.y += (p.ty - p.y) * k
                if (p.moving && p.carriedBy == null) spawnDust(p, dt, 0f, 0f)
            }
            p.animT += dt
            p.blinkTimer -= dt
            if (p.blinkTimer <= 0f) { p.blinkLeft = 0.12f; p.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
            if (p.blinkLeft > 0f) p.blinkLeft -= dt
            if (p.emote != null) { p.emoteT += dt; if (p.emoteT > 2.5f) p.emote = null }
            if (p.chat != null) { p.chatT += dt; if (p.chatT > 5f) p.chat = null }
            if (p.tool != null) { p.toolT -= dt; if (p.toolT <= 0f) p.tool = null }
            if (p.sitT > 0f) p.sitT -= dt
            if (p.busyT > 0f) p.busyT -= dt
            if (p.sleeping) p.sleepT += dt
            if (p.bathT > 0f) {
                p.bathT -= dt
                if (Math.random() < dt * 8f) particles.add(Particle(p.x + (Math.random().toFloat() - 0.5f) * 80f, p.y - 20f, 0f, -45f, 0.9f, 2, Color.White))
                if (p.bathT <= 0f && p.id == myId) {
                    val tub = roomRect("Bathtub")
                    if (tub != null) teleport(p, Offset(tub.center.x, tub.bottom + 30f))
                }
            }
            if (p.showerT > 0f) {
                p.showerT -= dt
                if (Math.random() < dt * 30f) particles.add(Particle(p.x + (Math.random().toFloat() - 0.5f) * 30f, p.y - 100f, 0f, 100f, 0.5f, 2, Color.White))
            }
        }

        // farm: same rules everywhere, host is the boss and syncs every 2 s
        time += dt
        val isHost = net?.isHost == true
        farm.tick(dt, isHost)
        kitchen.tick(dt)
        mgUpdate(dt)
        dayUpdate(dt)
        petUpdate(dt)
        econUpdate(dt)
        npcUpdate(dt)
        townUpdate(dt)
        if (fogT > 0f) fogT -= dt
        if (tvStatic > 0f) tvStatic -= dt
        if (catWagT > 0f) catWagT -= dt
        m?.let { if (it.sleeping && it.sleepT >= 6f) wake(true) }
        if (eatSeat && m != null && m.seated && m.sitT <= 0f) { eatSeat = false; stand() }
        if (m != null && !m.seated) eatSeat = false
        if (me?.area == Area.LIVING_ROOM) {          // fireplace crackle
            crackleAcc -= dt
            if (crackleAcc <= 0f) { crackleAcc = 1.2f + Math.random().toFloat() * 2f; SoundFx.crackle() }
        }
        if (fridgeOpenT > 0f) fridgeOpenT -= dt
        if (kitchen.phase == 1 && me?.area == Area.KITCHEN) {      // sizzling
            sizzleAcc -= dt
            if (sizzleAcc <= 0f) { sizzleAcc = 1f; SoundFx.sizzle() }
        }
        if (isHost) {
            farmSyncAcc += dt
            if (farmSyncAcc >= 2f) { farmSyncAcc = 0f; broadcastFarm(); broadcastKitchen(); broadcastShop(); broadcastHouse() }
        }
        val mx = m?.x ?: 0f
        val my = m?.y ?: 0f
        for (c in critters) c.update(dt, mx, my)
        if (farm.weather == Weather.RAINY) {           // splashes on the plots
            rainAcc -= dt
            if (rainAcc <= 0f) {
                rainAcc = 0.08f
                val r = World.plots[(Math.random() * World.plots.size).toInt()]
                particles.add(Particle(r.left + Math.random().toFloat() * r.width, r.top + Math.random().toFloat() * r.height,
                    (Math.random().toFloat() - 0.5f) * 30f, -60f, 0.5f, 2, Color.White))
            }
        }

        val di = dust.iterator()
        while (di.hasNext()) { val d = di.next(); d.age += dt; if (d.age > 0.5f) di.remove() }

        val pi = particles.iterator()
        while (pi.hasNext()) {
            val q = pi.next()
            q.age += dt
            q.x += q.vx * dt; q.y += q.vy * dt
            if (q.kind != 0) q.vy += 260f * dt
            if (q.age > q.life) pi.remove()
        }

        if (actionCd > 0f) actionCd -= dt
        if (toastLeft > 0f) { toastLeft -= dt; if (toastLeft <= 0f) toast = null }
    }

    private fun updateStats(m: PlayerState, dt: Float) {
        // slow and gentle: nothing ever blocks you
        happyF = max(0f, happyF - dt / 5f)
        hungerF = max(0f, hungerF - dt / 12f)
        energyF = max(0f, energyF - dt / (if (m.moving) 12f else 40f))
        m.happiness = happyF.roundToInt()

        val e = energyF.roundToInt(); if (e != energy) energy = e
        val h = hungerF.roundToInt(); if (h != hunger) hunger = h
        val hp = happyF.roundToInt(); if (hp != happiness) happiness = hp

        // hunger 0: "I'm hungry" + sad face, but you can still play
        if (hungerF <= 0f) {
            hungryNag -= dt
            if (hungryNag <= 0f) { hungryNag = 30f; emote(Emote.HUNGRY) }
        }
    }

    private fun moveLocal(m: PlayerState, dt: Float) {
        var moving = false
        var jx = 0f
        var jy = 0f

        val carrier = m.carriedBy?.let { players[it] }
        if (m.carriedBy != null && carrier == null) { m.carriedBy = null; carriedById = null }

        if (carrier != null) {
            m.x = carrier.x; m.y = carrier.y          // riding on their back
        } else if (m.sitT > 0f || m.busyT > 0f || m.sleeping || m.seated || m.swing >= 0 || m.seesaw >= 0 || m.slideT > 0f || mg.lockedFor(myId)) {
            // seated at the table: no walking while eating
        } else {
            jx = joyX; jy = joyY
            val len = hypot(jx, jy)
            if (len < 0.12f) { jx = 0f; jy = 0f } else if (len > 1f) { jx /= len; jy /= len }
            moving = jx != 0f || jy != 0f
            if (moving) {
                val sp = mySpeed()
                val nx = m.x + jx * sp * dt
                if (!World.blocked(nx, m.y)) m.x = nx
                val ny = m.y + jy * sp * dt
                if (!World.blocked(m.x, ny)) m.y = ny
                if (abs(jx) > 0.15f) m.facing = if (jx > 0f) 1 else -1
                spawnDust(m, dt, jx, jy)
            }
        }
        m.moving = moving
        m.tx = m.x; m.ty = m.y

        val a = World.areaAt(m.x, m.y)
        if (a != m.area || areaName.isEmpty()) { m.area = a; areaName = World.areaLabel(a) }

        // sync 15x per second while moving (+ last packet when stopping, + 1/sec keep-alive)
        sendAcc += dt
        keepAliveAcc += dt
        if (sendAcc >= 1f / Net.MOVE_HZ) {
            sendAcc = 0f
            if (moving || wasMoving || m.z > 0f || m.swing >= 0 || m.seesaw >= 0 || m.slideT > 0f || m.petMoving || keepAliveAcc >= 1f) { sendMove(m); keepAliveAcc = 0f }
            wasMoving = moving
        }
    }

    private fun updateNearby(m: PlayerState) {
        val id = if (m.carriedBy != null) null else
            players.values
                .filter { it.id != myId && it.carriedBy == null }
                .minByOrNull { hypot(it.x - m.x, it.y - m.y) }
                ?.takeIf { hypot(it.x - m.x, it.y - m.y) < 75f }?.id
        if (id != nearbyFriend) nearbyFriend = id
    }

    private fun spawnDust(p: PlayerState, dt: Float, jx: Float, jy: Float) {
        p.dustTimer -= dt
        if (p.dustTimer <= 0f) {
            p.dustTimer = 0.12f
            dust.add(Dust(p.x - jx * 8f - p.facing * 4f, p.y - 2f))
        }
    }

    // ------------------------------------------------------------ particles

    private fun hearts(x: Float, y: Float) {
        repeat(6) {
            particles.add(Particle(
                x + (Math.random().toFloat() - 0.5f) * 40f, y,
                (Math.random().toFloat() - 0.5f) * 30f, -40f - Math.random().toFloat() * 30f,
                1.5f, 0, Color.White
            ))
        }
    }

    private fun confetti(x: Float, y: Float) {
        repeat(26) {
            val a = Math.random().toFloat() * 6.283f
            val sp = 60f + Math.random().toFloat() * 120f
            particles.add(Particle(
                x, y, cos(a) * sp, sin(a) * sp - 120f, 1.4f, 1,
                CONFETTI[(Math.random() * CONFETTI.size).toInt()], spin = Math.random().toFloat() * 720f
            ))
        }
    }

    // ------------------------------------------------------------ buttons

    // ------------------------------------------------------------ coins, stars, daily login, save

    /** All earnings go through here: friend bonus (2+ players x2, 4 players x3), floating text, coin sound. */
    fun earn(n: Int, bonus: Boolean = true) {
        val mult = if (!bonus) 1 else if (players.size >= 4) 3 else if (players.size >= 2) 2 else 1
        val total = n * mult
        coins += total
        coinBump += 1
        me?.let { floaters.add(Floater("+$total Coins!", "🪙", it.x, it.y - 70f, time)) }
        if (mult > 1) { bonusText = "🎉 Friend Bonus x$mult!"; bonusLeft = 2f }
        SoundFx.coin()
    }

    fun gainStars(n: Int) {
        stars += n
        starBump += 1
        me?.let { floaters.add(Floater("+$n Star!", "⭐", it.x, it.y - 70f, time)) }
        SoundFx.coin()
    }

    // ------------------------------------------------------------ wardrobe

    fun garmentPrice(g: Garment) = price(g.price, "garment${g.id}")

    // ---- accessories: hats, glasses, earrings, backpacks, shoes, things in your hand
    fun ownsAcc(a: Acc) = (a.price == 0 && a.stars == 0) || "${a.cat}:${a.id}" in ownedAcc
    fun accPrice(a: Acc) = price(a.price, "acc${a.cat}${a.id}")

    fun equipAcc(cat: String, id: Int) {
        if (id != 0) {
            val a = Accessories.ALL.firstOrNull { it.cat == cat && it.id == id } ?: return
            if (!ownsAcc(a)) return
        }
        applyLook(myLook.withAcc(cat, id))
        saveNow()
    }

    fun buyAcc(a: Acc) {
        if (ownsAcc(a)) { equipAcc(a.cat, a.id); return }
        if (a.price < 0) { showToast("This one is a special gift 🎁"); return }
        if (a.stars > 0) {
            if (stars < a.stars) { showToast("Need ${a.stars - stars} more ⭐!"); return }
            stars -= a.stars
        } else if (!spendCoins(accPrice(a))) return
        ownedAcc.add("${a.cat}:${a.id}")
        equipAcc(a.cat, a.id)
        me?.let { confetti(it.x, it.y - 50f) }
        SoundFx.harvest()
        showToast("🎁 You got the ${a.name}!")
    }

    private fun grantAcc(cat: String, id: Int, msg: String) {
        val key = "$cat:$id"
        if (key in ownedAcc) return
        ownedAcc.add(key)
        showToast(msg)
        saveNow()
    }

    /** Free seasonal hats: Santa Hat (Christmas), Pumpkin Hat (Halloween). */
    private fun grantSeasonHat() {
        when (season()) {
            1 -> grantAcc("hat", 7, "🎃 Free Pumpkin Hat! Wear it from the Wardrobe")
            2 -> grantAcc("hat", 6, "🎅 Free Santa Hat! Wear it from the Wardrobe")
        }
    }

    // ---- furniture: buy at Cozy Home -> shared House Inventory -> place in the house
    fun isHostNow() = net?.isHost == true

    private fun broadcastHouse() {
        sendCustom(JSONObject().put("kind", "HOUSE_STATE").put("state", house.toJson()))
    }

    private fun houseAct(op: String, item: Int, x: Int = 0, y: Int = 0, rot: Int = 0, uid: Int = 0) {
        sendCustom(JSONObject().put("kind", "HOUSE_ACT").put("op", op).put("item", item).put("x", x).put("y", y).put("rot", rot).put("uid", uid))
        if (net?.isHost == true) broadcastHouse()
    }

    fun buyFurniture(f: Furn) {
        if (f.stars > 0) {
            if (stars < f.stars) { showToast("Need ${f.stars - stars} more ⭐!"); return }
            stars -= f.stars
        } else if (!spendCoins(price(f.price, "home${f.id}"))) return
        house.apply("ADD", f.id, 0, 0, 0, 0)
        houseAct("ADD", f.id)
        SoundFx.harvest()
        showToast("${f.emoji} ${f.name} is in the House Inventory!")
    }

    private fun snap(v: Float) = (v / 20f).roundToInt() * 20

    /** Put a piece from storage down just in front of you. */
    fun placeFurniture(item: Int) {
        val m = me ?: return
        val f = FurnitureCatalog.byId(item) ?: return
        val x = snap(m.x + m.facing * (f.w / 2f + 40f))
        val y = snap(m.y - 10f)
        val uid = (Math.random() * 1_000_000_000).toInt()
        if (house.apply("PLACE", item, x, y, 0, uid)) {
            houseAct("PLACE", item, x, y, 0, uid)
            SoundFx.pop()
            showToast("${f.emoji} ${f.name} placed!")
        }
    }

    // ---- Decorate Mode + shared voting
    fun decoSelect(uid: Int) {
        val pi = house.placed.firstOrNull { it.uid == uid } ?: return
        decoSel = uid; decoX = pi.x; decoY = pi.y; decoRot = pi.rot
    }

    fun decoNudge(dx: Int, dy: Int) {
        decoX = (decoX + dx * 20).coerceIn(20, World.W.toInt() - 20)
        decoY = (decoY + dy * 20).coerceIn(20, World.H.toInt() - 20)
    }

    fun decoTurn() { decoRot = (decoRot + 1) and 3 }

    /** "Move here": asks the house. On your own it just happens. */
    fun proposeMove() {
        val pi = house.placed.firstOrNull { it.uid == decoSel } ?: return
        if (pi.x == decoX && pi.y == decoY && pi.rot == decoRot) { showToast("Move the pink box first!"); return }
        if (net?.isHost == true) hostStartVote(pi.uid, decoX, decoY, decoRot, myId)
        else {
            sendCustom(JSONObject().put("kind", "VOTE_REQ").put("uid", pi.uid).put("x", decoX).put("y", decoY).put("rot", decoRot))
            showToast("🗳️ Asking the house…")
        }
    }

    private fun hostStartVote(uid: Int, x: Int, y: Int, rot: Int, proposer: String) {
        if (players.size <= 1) {                         // alone in the house: no vote needed
            if (house.apply("MOVE", 0, x, y, rot, uid)) { broadcastHouse(); SoundFx.pop(); showToast("Moved!") }
            return
        }
        val err = votes.start(house, uid, x, y, rot, proposer, players[proposer]?.name ?: "A friend")
        if (err != null) {
            if (proposer == myId) showToast(err)
            else sendCustom(JSONObject().put("kind", "VOTE_DENY").put("to", proposer).put("msg", err))
            return
        }
        broadcastVote()
    }

    private fun broadcastVote() {
        val v = votes.current ?: return
        sendCustom(JSONObject().put("kind", "VOTE_STATE").put("state", v.toJson()))
    }

    private fun finishVote(ok: Boolean) {
        val v = votes.current ?: return
        votes.current = null
        val still = house.placed.any { it.uid == v.uid }
        if (ok && still && house.apply("MOVE", 0, v.x, v.y, v.rot, v.uid)) {
            broadcastHouse()
            confetti(v.x.toFloat(), v.y - 50f)
            SoundFx.harvest()
            showToast("🎉 Moved! The house said YES!")
            sendCustom(JSONObject().put("kind", "VOTE_END").put("ok", 1))
        } else {
            showToast("The house said no. It stays here 🙅")
            sendCustom(JSONObject().put("kind", "VOTE_END").put("ok", 0))
        }
    }

    fun castVote(yes: Boolean) {
        val v = votes.current ?: return
        if (myId in v.yes || myId in v.no) return
        if (net?.isHost == true) {
            val r = votes.cast(v.id, myId, yes, players.keys.toSet())
            if (r != null) finishVote(r) else broadcastVote()
        } else {
            votes.current = if (yes) v.copy(yes = v.yes + myId) else v.copy(no = v.no + myId)
            sendCustom(JSONObject().put("kind", "VOTE_CAST").put("id", v.id).put("yes", if (yes) 1 else 0))
        }
    }

    private fun voteUpdate(dt: Float) {
        if (votes.current == null) return
        votes.tick(dt)
        if (net?.isHost == true) {
            val r = votes.decide(players.keys.toSet(), timeUp = (votes.current?.left ?: 1f) <= 0f)
            if (r != null) finishVote(r)
        }
    }

    fun storeFurniture(uid: Int) {
        if (house.apply("STORE", 0, 0, 0, 0, uid)) { houseAct("STORE", 0, uid = uid); SoundFx.pop() }
    }

    /** Only the host can delete furniture for good. */
    fun deleteFurniture(uid: Int) {
        if (net?.isHost != true) { showToast("Only the host can delete furniture 🔒"); return }
        if (house.apply("DELETE", 0, 0, 0, 0, uid)) { houseAct("DELETE", 0, uid = uid); SoundFx.pop() }
    }

    /** ✋ near sofas, beds, wardrobes, mirrors and fridges that you placed. */
    private fun placedInteract(m: PlayerState): Boolean {
        var best: Triple<PlacedItem, Furn, Float>? = null
        for (pi in house.placed) {
            val f = FurnitureCatalog.byId(pi.item) ?: continue
            if (f.kind == "decor" || f.kind == "lamp") continue
            val d = World.distanceTo(house.rectOf(pi, f), m.x, m.y)
            if (d < 85f && (best == null || d < best.third)) best = Triple(pi, f, d)
        }
        val (pi, f, _) = best ?: return false
        val r = house.rectOf(pi, f)
        when (f.kind) {
            "sofa" -> {
                sitOnSofa(m, r)
            }
            "bed" -> { pendingBedRect = r; pendingBed = null; dialog = "SLEEP" }
            "wardrobe" -> panel = "WARDROBE"
            "mirror" -> { emote(Emote.WAVE); panel = "CREATOR" }
            "fridge" -> { fridgeOpenT = 1.6f; SoundFx.fridge(); panel = "FRIDGE" }
            else -> showToast("${f.emoji} ${f.name} (the secret room opens in a later update!)")
        }
        return true
    }

    // ---- saved looks, surprise outfit, twins, photos
    fun saveLookSlot(i: Int) {
        savedLooks[i] = myLook.encode()
        showToast("💾 Look saved!")
        saveNow()
    }

    /** A saved look may contain things you don't own (any more): those parts are dropped. */
    private fun sanitize(l: Look): Look {
        var r = l
        if (r.garment != 0 && r.garment !in ownedGarments) r = r.copy(garment = 0)
        for (cat in Accessories.CATS) {
            val id = r.accOf(cat)
            if (id != 0) {
                val a = Accessories.ALL.firstOrNull { it.cat == cat && it.id == id }
                if (a == null || !ownsAcc(a)) r = r.withAcc(cat, 0)
            }
        }
        return r
    }

    fun wearLookSlot(i: Int) {
        val l = Look.decode(savedLooks[i]) ?: return
        applyLook(sanitize(l))
        saveNow()
    }

    /** The dice: a random outfit + accessories from what you own. */
    fun surprise() {
        val r = java.util.Random()
        val gs = listOf(0) + ownedGarments.toList()
        var l = myLook.copy(garment = gs[r.nextInt(gs.size)], outfit = r.nextInt(6), outfitColor = Look.OUTFIT_COLORS[r.nextInt(20)])
        for (cat in Accessories.CATS) {
            val opts = listOf(0) + Accessories.of(cat).filter { ownsAcc(it) }.map { it.id }
            l = l.withAcc(cat, opts[r.nextInt(opts.size)])
        }
        applyLook(l)
        saveNow()
        showToast("🎲 New look!")
    }

    /** Two friends wearing the same outfit and colour, standing close: Twins! */
    private fun twinsCheck(m: PlayerState, dt: Float) {
        for (k in twinCd.keys.toList()) twinCd[k] = (twinCd[k] ?: 0f) - dt
        for (o in players.values) {
            if (o.id == myId || hypot(o.x - m.x, o.y - m.y) > 90f) continue
            if ((twinCd[o.id] ?: 0f) > 0f) continue
            val a = m.look
            val b = o.look
            if (a.garment == b.garment && (a.garment > 0 || a.outfit == b.outfit) && a.outfitColor == b.outfitColor) {
                twinCd[o.id] = 90f
                addHappy(10f)
                confetti((m.x + o.x) / 2f, m.y - 50f)
                SoundFx.harvest()
                showToast("👯 Twins with ${o.name}! +Happiness")
            }
        }
    }

    fun photoSaved(ok: Boolean) {
        if (ok) { SoundFx.harvest(); showToast("📸 Saved to the Photo Wall!") } else showToast("Couldn't save the photo 😿")
    }

    /** For the sound system later: which sound set the footsteps should use (shoes + floor). */
    fun footstepKind(): String {
        val floor = when (me?.area) {
            Area.KITCHEN, Area.BATHROOM -> "tile"
            Area.GARDEN, Area.PLAYGROUND -> "grass"
            Area.TOWN -> "stone"
            else -> "wood"
        }
        return "${myLook.shoes}-$floor"
    }

    /** Wear a piece you own (id 0 = the starter outfit). Wearing is free. */
    fun equipGarment(id: Int) {
        if (id != 0 && id !in ownedGarments) return
        val g = Wardrobe.byId(id)
        applyLook(myLook.copy(garment = id, outfitColor = g?.color ?: myLook.outfitColor))
        saveNow()
    }

    /** Buy with coins, or use the free outfit voucher from the daily login. */
    fun buyGarment(id: Int, voucher: Boolean) {
        val g = Wardrobe.byId(id) ?: return
        if (id in ownedGarments) { showToast("You already own ${g.name}"); return }
        if (voucher) {
            if (outfitVouchers <= 0) return
            outfitVouchers -= 1
        } else if (!spendCoins(garmentPrice(g))) return
        ownedGarments.add(id)
        equipGarment(id)
        me?.let { confetti(it.x, it.y - 50f) }
        SoundFx.harvest()
        showToast("👗 You got ${g.name}!")
    }

    /** Change how my avatar looks (live, everybody sees it). */
    fun applyLook(l: Look) {
        myLook = l
        SoundFx.voice = l.voice
        me?.updateLook(l)
    }

    fun attach(ctx: android.content.Context) {
        if (appCtx != null) return
        appCtx = ctx.applicationContext
        val o = LocalSave.load(ctx)
        coins = o.optInt("coins", 40)               // a new game starts with 40 coins: buy something fun in 5 minutes!
        stars = o.optInt("stars", 0)
        level = o.optInt("level", 1)
        xp = o.optInt("xp", 0)
        o.optJSONArray("pets")?.let { a -> for (i in 0 until a.length()) ownedPets.add(a.optInt(i)) }
        pendingPetKind = o.optInt("petKind", -1)
        petHungerF = o.optDouble("petH", 100.0).toFloat()
        petHappyF = o.optDouble("petA", 100.0).toFloat()
        treasureStar = o.optBoolean("tstar", false)
        lastGrandmaDay = o.optLong("gDay", -1L)
        lastMailDay = o.optLong("mDay", -1L)
        lastBrokeDay = o.optLong("bDay", -1L)
        loginStreak = o.optInt("streak", 0)
        lastLoginDay = o.optLong("loginDay", -1L)
        outfitVouchers = o.optInt("vouchers", 0)
        o.optString("look").takeIf { it.isNotEmpty() }?.let { s -> Look.decode(s)?.let { myLook = it; hasSavedLook = true } }
        o.optJSONArray("garments")?.let { a -> for (i in 0 until a.length()) ownedGarments.add(a.optInt(i)) }
        o.optJSONArray("acc")?.let { a -> for (i in 0 until a.length()) ownedAcc.add(a.optString(i)) }
        o.optJSONArray("slots")?.let { a -> for (i in 0 until minOf(a.length(), 5)) savedLooks[i] = a.optString(i) }
        // the host loads the saved house it opened (friends get it from the host)
        if (Session.host != null && Session.houseId.isNotBlank()) HouseSaves.load(ctx, Session.houseId)?.let { loadHouseData(it) }
    }

    private fun loadHouseData(o: JSONObject) {
        o.optJSONObject("house")?.let { house.load(it) }
        o.optJSONObject("farm")?.let { farm.load(it) }
        o.optJSONObject("kitchen")?.let { kitchen.load(it) }
        o.optJSONObject("clock")?.let { clock.load(it) }
        o.optJSONArray("stock")?.let { a -> for (i in 0 until minOf(a.length(), petStock.size)) petStock[i] = a.optInt(i) }
    }

    fun saveNow() {
        val c = appCtx ?: return
        LocalSave.save(c, LocalSave.load(c)
            .put("coins", coins).put("stars", stars).put("level", level).put("xp", xp)
            .put("pets", JSONArray(ownedPets.toList())).put("petKind", petKind)
            .put("petH", petHungerF.toDouble()).put("petA", petHappyF.toDouble())
            .put("tstar", treasureStar).put("gDay", lastGrandmaDay).put("mDay", lastMailDay).put("bDay", lastBrokeDay)
            .put("streak", loginStreak).put("loginDay", lastLoginDay).put("vouchers", outfitVouchers).put("look", myLook.encode()).put("garments", JSONArray(ownedGarments.toList())).put("acc", JSONArray(ownedAcc.toList())).put("slots", JSONArray(savedLooks.toList())))
        val hid = Session.houseId
        if (net?.isHost == true && hid.isNotBlank()) {
            HouseSaves.save(c, hid, JSONObject()
                .put("house", house.toJson()).put("farm", farm.toJson()).put("kitchen", kitchen.toJson())
                .put("clock", clock.toJson()).put("stock", JSONArray(petStock.toList())))
        }
    }

    private fun econUpdate(dt: Float) {
        floaters.removeAll { time - it.t0 > 1.6f }
        if (bonusLeft > 0f) { bonusLeft -= dt; if (bonusLeft <= 0f) bonusText = "" }
        val m = me
        if (m != null && appCtx != null && !lookApplied) {         // first time: character creator opens
            lookApplied = true
            if (!hasSavedLook) { myLook = Look.default(m.colorIndex); panel = "CREATOR" }
            m.updateLook(myLook)
            SoundFx.voice = myLook.voice
        }
        if (m != null && pendingPetKind >= 0) {                  // bring the saved pet back
            val t = pendingPetKind.coerceIn(0, 6)
            pendingPetKind = -1
            m.petType = t; petKind = t
            petName = PetCatalog.names[t]; m.petName = petName
            m.petX = m.x + 30f; m.petY = m.y; m.petTx = m.petX; m.petTy = m.petY; m.petSeen = true
        }
        if (m != null && appCtx != null && !loginChecked && panel != "CREATOR") { loginChecked = true; checkDailyLogin() }
        if (m != null && appCtx != null && !seasonChecked) { seasonChecked = true; grantSeasonHat() }
        if (m != null) twinsCheck(m, dt)
        saveAcc += dt
        if (saveAcc >= 10f) { saveAcc = 0f; saveNow() }
    }

    /** Day 1: 30 coins. Day 2: 50 coins + outfit voucher. Day 3: 1 Star. Then it repeats; a missed day or a new week starts over. */
    private fun checkDailyLogin() {
        val today = realDay()
        if (lastLoginDay == today) return
        val sameWeek = (lastLoginDay + 3) / 7 == (today + 3) / 7
        loginStreak = if (lastLoginDay == today - 1 && sameWeek) loginStreak + 1 else 1
        lastLoginDay = today
        val title = "🎁 Daily Login · Day $loginStreak"
        when (((loginStreak - 1) % 3) + 1) {
            1 -> { earn(30, false); talk(title, "Welcome back! Here are 30 coins. 🪙\nCome back tomorrow for more!") }
            2 -> { earn(50, false); outfitVouchers += 1; talk(title, "50 coins and a free outfit voucher! 👗\n(You can use it when the Wardrobe opens.)") }
            else -> { gainStars(1); talk(title, "A shiny Star for you! ⭐\nStars unlock rare things like the Fox and Panda.") }
        }
        saveNow()
    }

    // ------------------------------------------------------------ pets

    private fun petSound(type: Int) { when (type) { 0 -> SoundFx.meow(); 1 -> SoundFx.bark(); else -> SoundFx.pop() } }

    fun adoptPet(type: Int) {
        val m = me ?: return
        val t = type.coerceIn(0, 6)
        if (t !in ownedPets) ownedPets.add(t)
        m.petType = t; petKind = t
        petName = PetCatalog.names[t]
        m.petName = petName
        m.petX = m.x + 40f; m.petY = m.y; m.petTx = m.petX; m.petTy = m.petY; m.petSeen = true
        petHungerF = 100f; petHappyF = 100f
        panel = null
        confetti(m.x, m.y - 50f)
        hearts(m.petX, m.petY - 30f)
        petSound(t)
        showToast("🎉 You adopted $petName!")
    }

    fun petPet() {
        val m = me ?: return
        if (!hasPet || !nearPet) { showToast("Go closer to your pet 🐾"); return }
        if (petCd > 0f) return
        petCd = 1.2f
        petHappyF = min(100f, petHappyF + 10f)
        addHappy(2f)
        m.petSleep = false; petIdle = 0f
        hearts(m.petX, m.petY - 30f)
        petSound(m.petType)
        showToast("$petName loves you! 💕")
    }

    fun feedPet() {
        val m = me ?: return
        if (!hasPet) { showToast("Adopt a pet first! 🐾"); return }
        if (!nearPet) { showToast("Go closer to $petName"); return }
        val pref = when (m.petType) {
            0 -> listOf(Ing.MILK, Ing.EGGS)
            1 -> listOf(Ing.CHEESE, Ing.EGGS)
            3 -> listOf(Ing.CORN, Ing.CARROT)
            4 -> listOf(Ing.STRAWBERRY)
            5 -> listOf(Ing.EGGS, Ing.CHEESE)
            6 -> listOf(Ing.CARROT, Ing.PUMPKIN)
            else -> listOf(Ing.CARROT, Ing.STRAWBERRY)
        }
        val ing = pref.firstOrNull { kitchen.have(it) > 0 } ?: Ing.values().firstOrNull { kitchen.have(it) > 0 }
        if (ing == null) { showToast("No food in the fridge! 🍽️ Harvest some crops first"); return }
        val liked = ing in pref
        if (!kitchen.apply("TAKE", ing.ordinal)) return
        kitchenAct("TAKE", ing.ordinal)
        petHungerF = min(100f, petHungerF + if (liked) 45f else 30f)
        petHappyF = min(100f, petHappyF + if (liked) 12f else 4f)
        m.petSleep = false; petIdle = 0f
        m.petBubble = ing.emoji; m.petBubbleT = 1.5f
        hearts(m.petX, m.petY - 30f)
        petSound(m.petType)
        showToast("$petName loved the ${ing.emoji}!")
    }

    /** Follows you, sleeps when you rest, digs up coins in the garden. Remote pets just glide. */
    private fun petUpdate(dt: Float) {
        if (petCd > 0f) petCd -= dt
        for (p in players.values) {
            if (p.petBubbleT > 0f) p.petBubbleT -= dt
            if (p.blushT > 0f) p.blushT -= dt
            if (p.id == myId || p.petType < 0) continue
            val k = 1f - exp(-10f * dt)
            val dx = p.petTx - p.petX
            val dy = p.petTy - p.petY
            p.petX += dx * k; p.petY += dy * k
            if (abs(dx) > 0.5f) p.petFace = if (dx > 0f) 1 else -1
            p.petMoving = hypot(dx, dy) > 1.5f
        }
        val m = me
        if (m == null || m.petType < 0) { nearPet = false; return }

        if (m.moving) petIdle = 0f else petIdle += dt
        val sleepNow = m.sleeping || (petIdle > 10f && petDig <= 0f)
        if (sleepNow != m.petSleep) m.petSleep = sleepNow

        petHungerF = max(0f, petHungerF - dt / 20f)
        petHappyF = max(0f, petHappyF - dt / 25f)
        val ph = petHungerF.roundToInt(); if (ph != petHunger) petHunger = ph
        val pa = petHappyF.roundToInt(); if (pa != petHappy) petHappy = pa

        var moved = false
        if (!m.petSleep && petDig <= 0f) {
            val tx = m.x - m.facing * 34f
            val ty = m.y + 6f
            val dx = tx - m.petX
            val dy = ty - m.petY
            val d = hypot(dx, dy)
            if (d > 400f) { m.petX = tx; m.petY = ty }
            else if (d > 38f) {
                val step = min(d - 30f, (if (m.petType == 1) 175f else 150f) * dt)
                val nx = m.petX + dx / d * step
                val ny = m.petY + dy / d * step
                var ok = false
                if (!World.blocked(nx, m.petY, 8f)) { m.petX = nx; ok = true }
                if (!World.blocked(m.petX, ny, 8f)) { m.petY = ny; ok = true }
                moved = ok
                if (abs(dx) > 1f) m.petFace = if (dx > 0f) 1 else -1
                petStuck = if (ok) 0f else petStuck + dt
                if (petStuck > 1.2f) { m.petX = m.x; m.petY = m.y; petStuck = 0f }   // stuck behind a wall: pop to you
            }
        }
        m.petMoving = moved

        // finds coins in the garden: 1 to 10, only when awake and fed
        if (m.area == Area.GARDEN && !m.petSleep && petHungerF > 0f && petDig <= 0f) {
            digTimer -= dt
            if (digTimer <= 0f) { digTimer = 40f + Math.random().toFloat() * 50f; petDig = 2f }
        }
        if (petDig > 0f) {
            petDig -= dt
            if (Math.random() < dt * 10f) dust.add(Dust(m.petX + (Math.random().toFloat() - 0.5f) * 16f, m.petY))
            if (petDig <= 0f) {
                val n = 1 + (Math.random() * 10).toInt()
                earn(n)
                addXp(1)
                m.petBubble = "💰"; m.petBubbleT = 2f
                confetti(m.petX, m.petY - 30f)
                SoundFx.harvest()
                showToast("🐾 $petName found $n coins!")
            }
        }
        nearPet = hypot(m.petX - m.x, m.petY - m.y) < 90f
    }

    // ------------------------------------------------------------ Town

    private fun npcAnim(n: PlayerState, dt: Float, m: PlayerState?) {
        n.animT += dt
        n.chatT += dt                                  // doubles as "last waved" timer
        n.blinkTimer -= dt
        if (n.blinkTimer <= 0f) { n.blinkLeft = 0.12f; n.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
        if (n.blinkLeft > 0f) n.blinkLeft -= dt
        if (n.emote != null) { n.emoteT += dt; if (n.emoteT > 2.5f) n.emote = null }
        else if (m != null && n.chatT > 12f && hypot(n.x - m.x, n.y - m.y) < 130f) {
            n.emote = Emote.WAVE; n.emoteT = 0f; n.chatT = 0f      // people wave at you
        }
    }

    private fun townUpdate(dt: Float) {
        val m = me
        for (k in shopkeepers) npcAnim(k, dt, m)
        for (w in walkers) {
            w.moving = true
            w.x += w.facing * 45f * dt
            if (w.x > 2250f) w.facing = -1
            if (w.x < 150f) w.facing = 1
            npcAnim(w, dt, m)
        }
        // cars honk when they pass you
        if (m?.area == Area.TOWN) {
            for (i in 0..3) {
                honkCd[i] -= dt
                if (honkCd[i] <= 0f && abs(TownData.carX(i, time) - m.x) < 100f && abs(TownData.carY(i) - m.y) < 140f) {
                    honkCd[i] = 8f
                    SoundFx.honk()
                }
            }
        }
        // bus ride: 5 seconds, then you arrive
        if (busLeft > 0f) {
            busLeft -= dt
            if (busLeft <= 0f) {
                busDest?.let { d -> me?.let { teleport(it, d) } }
                riding = false
                showToast("🚌 Arrived!")
            }
        }
    }

    private fun townInteract(m: PlayerState): Boolean {
        for ((i, k) in shopkeepers.withIndex()) {
            if (hypot(k.x - m.x, k.y - m.y) < 90f) {
                val s = TownData.shops[i]
                shopId = s.id
                npcName = "${k.name} · ${s.name}"
                npcText = s.lines[(Math.random() * s.lines.size).toInt()]
                dialog = "SHOPKEEPER"
                k.emote = Emote.HAPPY; k.emoteT = 0f
                SoundFx.pop()
                return true
            }
        }
        val fountain = roomRect("Fountain")
        if (fountain != null && World.distanceTo(fountain, m.x, m.y) < 90f) {
            if (coins < 1) { showToast("Throw a coin to make a wish! You have none 🪙"); return true }
            coins -= 1
            addHappy(5f)
            confetti(fountain.center.x, fountain.top - 10f)
            SoundFx.harvest()
            showToast("✨ You made a wish!")
            return true
        }
        val cart = roomRect("Ice Cream Cart")
        if (cart != null && World.distanceTo(cart, m.x, m.y) < 90f) { buyCafe(3); return true }
        val home = roomRect("Bus Stop Home")
        val town = roomRect("Bus Stop Town")
        if (home != null && World.distanceTo(home, m.x, m.y) < 90f) {
            busDest = Offset(2315f, 1520f)
            npcName = "Bus stop 🚌"; npcText = "Ride the bus to Town? It costs 5 coins and takes 5 seconds. Walking is free (through the garden gate)!"
            dialog = "BUS"
            return true
        }
        if (town != null && World.distanceTo(town, m.x, m.y) < 90f) {
            busDest = Offset(1035f, 1170f)
            npcName = "Bus stop 🚌"; npcText = "Ride the bus home to the garden? It costs 5 coins and takes 5 seconds."
            dialog = "BUS"
            return true
        }
        return false
    }

    fun rideBus() {
        dialog = null
        val m = me ?: return
        if (busDest == null) return
        if (coins < 5) { showToast("Need 5 coins! Walking is free 🚶"); return }
        coins -= 5
        busLeft = 5f
        riding = true
        m.busyT = 5.3f
        SoundFx.whoosh()
    }

    fun openShop() { dialog = null; panel = "SHOP" }

    // ------------------------------------------------------------ shops

    fun marketDay() = isSunday()          // Market Day: every real Sunday, all shops 20% off

    /** One random Fresh Mart item is 50% off each real day (same for everybody). */
    fun dealKey(): String {
        val keys = (0..5).map { "seed$it" } + (0..4).map { "ing$it" }
        return keys[java.util.Random(realDay()).nextInt(keys.size)]
    }

    fun price(base: Int, key: String): Int {
        var p = base.toFloat()
        if (marketDay()) p *= 0.8f
        if (key == dealKey()) p *= 0.5f
        return max(1, ceil(p).toInt())
    }

    private fun spendCoins(n: Int): Boolean {
        if (coins < n) { showToast("Need ${n - coins} more! 🪙"); return false }
        coins -= n
        return true
    }

    fun buyItem(key: String, base: Int) {
        if (!spendCoins(price(base, key))) return
        if (key.startsWith("seed")) {
            val c = key.removePrefix("seed").toInt()
            farm.apply("GIVE", 0, c); farmAct("GIVE", 0, c)
            showToast("🌱 Bought ${Crop.values()[c].label} seeds!")
        } else {
            val k = key.removePrefix("ing").toInt()
            kitchen.apply("STOCK", k); kitchenAct("STOCK", k)
            showToast("Bought ${Ing.values().first { it.pantryIdx == k }.label}!")
        }
        SoundFx.harvest()
    }

    private fun eatEffect(energy: Int, happy: Int) {
        energyF = min(100f, energyF + energy)
        hungerF = min(100f, hungerF + 25f)
        addHappy(happy.toFloat())
        me?.let { hearts(it.x, it.y - 60f) }
        SoundFx.hug()
    }

    /** Cafe food: you eat it, and everybody sitting near you shares it (+Energy +Happiness for all). */
    fun buyCafe(i: Int) {
        val items = listOf(Triple("🍰", 15, 18), Triple("🍕", 30, 12), Triple("🧋", 10, 20), Triple("🍨", 8, 22))
        val (emoji, en, hp) = items[i.coerceIn(0, 3)]
        if (!spendCoins(price(10, "cafe$i"))) return
        eatEffect(en, hp)
        me?.let {
            sendCustom(JSONObject().put("kind", "CAFE_TREAT").put("x", it.x.roundToInt()).put("y", it.y.roundToInt()).put("e", en).put("h", hp))
            it.tool = emoji; it.toolT = 1.5f
        }
        showToast("$emoji Yum! Friends nearby share it 💕")
    }

    fun playArcade() {
        if (!spendCoins(price(10, "arcade"))) return
        addXp(1)
        if (Math.random() < 0.35) {
            earn(30, false)
            me?.let { confetti(it.x, it.y - 50f) }
            SoundFx.harvest()
            showToast("🎉 You won a prize! +30 coins")
        } else { SoundFx.pop(); showToast("So close! Try again 🕹️") }
    }

    private fun broadcastShop() {
        sendCustom(JSONObject().put("kind", "SHOP_STATE").put("stock", JSONArray(petStock.toList())))
    }

    fun switchPet(t: Int) {
        val m = me ?: return
        if (t !in ownedPets) return
        m.petType = t; petKind = t
        petName = PetCatalog.names[t.coerceIn(0, 6)]
        m.petName = petName
        m.petX = m.x + 30f; m.petY = m.y; m.petTx = m.petX; m.petTy = m.petY
        petSound(t)
    }

    fun buyPet(def: PetDef) {
        if (def.type in ownedPets) { switchPet(def.type); showToast("${def.emoji} ${def.name} is with you now!"); return }
        if (def.rare && petStock[def.type] <= 0) { showToast("Sold out! New pets arrive tomorrow 🐾"); return }
        if (def.stars > 0) {
            if (stars < def.stars) { showToast("Need ${def.stars - stars} more ⭐!"); return }
            stars -= def.stars
        } else if (!spendCoins(price(def.coins, "pet${def.type}"))) return
        prevPet = if (hasPet) petKind else -1
        if (def.rare) {
            petStock[def.type] = petStock[def.type] - 1
            if (net?.isHost == true) broadcastShop()
            else sendCustom(JSONObject().put("kind", "SHOP_REQ").put("op", "BUYPET").put("type", def.type))
        }
        adoptPet(def.type)
    }

    // ------------------------------------------------------------ NPCs, secrets, reactions

    private fun realDay() = (System.currentTimeMillis() + java.util.TimeZone.getDefault().rawOffset) / 86_400_000L
    private fun isSunday() = java.util.Calendar.getInstance().get(java.util.Calendar.DAY_OF_WEEK) == java.util.Calendar.SUNDAY
    fun mailReady() = lastMailDay != realDay()

    private fun npcUpdate(dt: Float) {
        val day = realDay()
        // Grandma visits on Sundays, and comes by whenever you are out of coins
        grandmaOn = (isSunday() && lastGrandmaDay != day) || (coins == 0 && lastBrokeDay != day)
        mailmanOn = clock.phase() == 0
        grandma.animT += dt
        mailman.animT += dt
        mailman.moving = true
        mailman.x = 1000f + 250f * (1f + sin(time * 0.3f))
        mailman.facing = if (cos(time * 0.3f) >= 0f) 1 else -1
        for (n in listOf(grandma, mailman)) {
            n.blinkTimer -= dt
            if (n.blinkTimer <= 0f) { n.blinkLeft = 0.12f; n.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
            if (n.blinkLeft > 0f) n.blinkLeft -= dt
        }

        // umbrellas when it rains outside
        for (p in players.values) p.umbrella = farm.weather == Weather.RAINY && (p.area == Area.GARDEN || p.area == Area.PLAYGROUND || p.area == Area.TOWN)

        // rainbow after the rain
        if (prevWeather == Weather.RAINY && farm.weather != Weather.RAINY) { rainbowT = 45f; rainbowCheered = false }
        prevWeather = farm.weather
        if (rainbowT > 0f) {
            rainbowT -= dt
            val m = me
            if (!rainbowCheered && m != null && (m.area == Area.GARDEN || m.area == Area.PLAYGROUND || m.area == Area.TOWN)) {
                rainbowCheered = true
                addHappy(10f)
                showToast("🌈 A rainbow! +Happiness")
            }
        }

        // cough when the food burns
        if (kitchen.phase == 3 && lastKPhase != 3 && me?.area == Area.KITCHEN) {
            me?.let { it.chat = "*cough cough* 😷"; it.chatT = 0f }
            showToast("Cough cough! The food burned 😷")
        }
        lastKPhase = kitchen.phase
    }

    private fun farmGive(crop: Int) {
        farm.apply("GIVE", 0, crop)
        farmAct("GIVE", 0, crop)
    }

    private fun talk(name: String, text: String) {
        npcName = name; npcText = text; dialog = "NPC"
        SoundFx.pop()
    }

    private fun npcInteract(m: PlayerState): Boolean {
        val day = realDay()
        if (grandmaOn && hypot(grandma.x - m.x, grandma.y - m.y) < 90f) {
            if (coins == 0 && lastBrokeDay != day) {
                lastBrokeDay = day
                earn(50, false)
                farmGive(0); farmGive(1); farmGive(2)
                talk("Grandma 👵", "Oh dear, your pockets are empty! Here, sweetheart: 50 coins and a few seeds. 🪙🌱")
            } else {
                lastGrandmaDay = day
                repeat(3) { farmGive((Math.random() * 6).toInt()) }
                val stories = listOf(
                    "When I was little, a tiny carrot seed grew into a carrot as big as my arm! Plant, water, and be patient. 🥕",
                    "Long ago a sunflower in this garden glowed at night. Some say it still does… 🌻",
                    "There is a treasure buried under the big tree. Dig three times, and be kind to your friends! 🌳",
                )
                talk("Grandma 👵", "Happy Sunday! Here are 3 seeds for the garden.\n\n" + stories[(Math.random() * stories.size).toInt()])
            }
            return true
        }
        val box = roomRect("Mailbox")
        val nearMailman = mailmanOn && hypot(mailman.x - m.x, mailman.y - m.y) < 90f
        val nearBox = box != null && World.distanceTo(box, m.x, m.y) < 85f
        if (nearMailman || nearBox) {
            if (!mailReady()) { showToast("No new mail today 📪 Come back tomorrow!"); return true }
            lastMailDay = day
            val letters = listOf("Dear friend, keep smiling! 💌", "Hello neighbour! The garden looks lovely. 🌷", "A little gift for the cozy house! 🎁")
            val gift = (Math.random() * 3).toInt()
            val note = when (gift) {
                0 -> { earn(20, false); "+20 coins 🪙" }
                1 -> { farmGive((Math.random() * 6).toInt()); farmGive((Math.random() * 6).toInt()); "2 free seeds 🌱" }
                else -> { earn(10, false); farmGive((Math.random() * 6).toInt()); "10 coins + a seed 🪙🌱" }
            }
            talk("Mailman 📬", letters[(Math.random() * letters.size).toInt()] + "\n\nGift: " + note)
            return true
        }
        return false
    }

    /** Treasure under the big tree: dig 3 times, once per game day. The first one ever also gives a Star. */
    private fun secretInteract(m: PlayerState): Boolean {
        val tree = roomRect("Big tree") ?: return false
        if (World.distanceTo(tree, m.x, m.y) > 85f) return false
        if (treasureDay == clock.day) {
            showToast("Nothing more here today 🌳 Come back in ${((1f - clock.frac()) * 30f).toInt() + 1} mins")
            return true
        }
        digs += 1
        m.tool = "⛏️"; m.toolT = 0.8f
        repeat(4) { dust.add(Dust(m.x + (Math.random().toFloat() - 0.5f) * 30f, m.y)) }
        SoundFx.pop()
        if (digs < 3) { showToast("Dig… $digs/3 ⛏️"); return true }
        digs = 0
        treasureDay = clock.day
        earn(40, false)
        addXp(5)
        if (!treasureStar) { treasureStar = true; gainStars(1); showToast("🏴‍☠️ Treasure! +40 coins +1 ⭐") }
        else showToast("🏴‍☠️ Treasure! +40 coins")
        confetti(m.x, m.y - 40f)
        SoundFx.harvest()
        return true
    }

    // ------------------------------------------------------------ time, levels, quests

    private fun dayUpdate(dt: Float) {
        clock.tick(dt)
        if (net?.isHost == true && clock.day != lastStockDay) {      // rare pets are restocked every game day
            lastStockDay = clock.day
            petStock[5] = 1; petStock[6] = 1
            broadcastShop()
        }
        if (net?.isHost == true) {
            clockSyncAcc += dt
            if (clockSyncAcc >= 2f) {
                clockSyncAcc = 0f
                sendCustom(JSONObject().put("kind", "CLOCK").put("state", clock.toJson()))
            }
        }
        val txt = "${DayClock.EMOJI[clock.phase()]} ${DayClock.NAMES[clock.phase()]} ${clock.hourText()}"
        if (txt != clockText) clockText = txt
        val fr = (clock.frac() * 100f).toInt() / 100f
        if (fr != clockFrac) clockFrac = fr

        val outdoors = me?.area == Area.GARDEN || me?.area == Area.PLAYGROUND || me?.area == Area.TOWN
        if (outdoors) {                                  // crickets at night, birds in the morning
            ambientAcc -= dt
            if (ambientAcc <= 0f) {
                ambientAcc = 2f + Math.random().toFloat() * 3f
                if (clock.nightFactor() > 0.5f) SoundFx.cricket() else if (clock.phase() == 0) SoundFx.bird()
            }
        }
    }

    fun clockTap() {
        val now = System.currentTimeMillis()
        if (now - lastClockTap > 3000) clockTaps = 0
        lastClockTap = now
        clockTaps += 1
        if (clockTaps >= 7) {            // secret: preview the seasons (Halloween / Christmas)
            clockTaps = 0
            seasonOverride = when (seasonOverride) { -1 -> 1; 1 -> 2; else -> -1 }
            grantSeasonHat()
            showToast(when (seasonOverride) { 1 -> "🎃 Halloween preview"; 2 -> "🎄 Christmas preview"; else -> "Season: real date" })
            return
        }
        showToast("Next: ${DayClock.NAMES[(clock.phase() + 1) % 4]} in ${clock.minsToNext()} mins")
    }

    /** 0 none, 1 Halloween (Oct 25-31), 2 Christmas (Dec 20-26). */
    fun season(): Int {
        if (seasonOverride >= 0) return seasonOverride
        val c = java.util.Calendar.getInstance()
        val mo = c.get(java.util.Calendar.MONTH)
        val d = c.get(java.util.Calendar.DAY_OF_MONTH)
        return if (mo == java.util.Calendar.OCTOBER && d >= 25) 1 else if (mo == java.util.Calendar.DECEMBER && d in 20..26) 2 else 0
    }

    /** Level N needs N x 50 XP. Every level up gives 1 Star. */
    fun addXp(n: Int) {
        xp += n
        while (level < 20 && xp >= level * 50) {
            xp -= level * 50
            level += 1
            gainStars(1)
            showToast("⭐ Level Up! You are level $level (+1 Star)")
            me?.let { confetti(it.x, it.y - 50f) }
            SoundFx.harvest()
        }
    }

    fun claimQuest(q: Quest) {
        if (q.claimed || q.progress < q.goal) return
        q.claimed = true
        earn(50, false)
        gainStars(1)
        addXp(20)
        showToast("Quest done! +50 coins +1 ⭐")
        me?.let { confetti(it.x, it.y - 50f) }
        SoundFx.harvest()
    }

    // ------------------------------------------------------------ mini-games

    private fun mgInteract(m: PlayerState): Boolean {
        val r = roomRect("Game Board") ?: return false
        if (World.distanceTo(r, m.x, m.y) > 95f) return false
        if (mg.phase != 0) showToast("A game is running! 🎮") else panel = "GAMES"
        return true
    }

    fun requestGame(g: Int) {
        panel = null
        if (net?.isHost == true) {
            if (!mg.start(g, players.keys.toList())) showToast("Can't start that game right now")
        } else {
            sendCustom(JSONObject().put("kind", "MG_REQ").put("op", "START").put("game", g))
            showToast("Asking the host to start…")
        }
    }

    private fun mgUpdate(dt: Float) {
        if (net?.isHost == true) {
            mg.tickHost(dt, players)
            mgSyncAcc += dt
            if (mg.changed || (mg.phase != 0 && mgSyncAcc >= 0.25f)) {
                mg.changed = false
                mgSyncAcc = 0f
                sendCustom(JSONObject().put("kind", "MG_STATE").put("state", mg.toJson()))
            }
        } else mg.clientTick(dt)

        // 3-2-1 beeps
        if (mg.phase == 1 && mg.game != MinigameManager.HIDE && mg.sec != lastBeepSec) {
            lastBeepSec = mg.sec
            if (mg.sec in 1..3) SoundFx.tick()
        }
        // race: line everybody up at the start
        if (mg.game == MinigameManager.RACE && mg.phase == 1 && mgTeleportRound != mg.round) {
            mgTeleportRound = mg.round
            me?.let { m -> teleport(m, Offset(860f, 975f + max(0, mg.ids.indexOf(myId)) * 24f)) }
        }
        // hats, ghosts, crowns
        for (p in players.values) {
            p.isIt = mg.game == MinigameManager.TAG && mg.phase == 2 && mg.itId == p.id
            p.ghost = mg.game == MinigameManager.HIDE && mg.phase in 1..2 && p.id in mg.ghosts
            if (p.crownT > 0f) p.crownT -= dt
        }
        // confetti for everyone who crosses the finish line
        if (mg.finish.size != lastFin) {
            for (i in lastFin until mg.finish.size) players[mg.finish[i]]?.let { confetti(it.x, it.y - 40f) }
            if (mg.finish.size > lastFin) SoundFx.harvest()
            lastFin = mg.finish.size
        }
        // result: winner crown + 20 coins (Balloon Pop also gives 1 coin per pop)
        if (mg.phase == 3 && mgRewardRound != mg.round) {
            mgRewardRound = mg.round
            mg.winners.forEach { players[it]?.crownT = 12f }
            val m = me
            if (m != null && myId in mg.ids) {
                quests.bump("GAME"); addXp(10)
                var gain = 0
                if (myId in mg.winners) gain += 20
                if (mg.game == MinigameManager.BALLOON) gain += mg.scores[myId] ?: 0
                if (gain > 0) {
                    earn(gain)
                    showToast(if (myId in mg.winners) "🏆 You won! +$gain coins" else "+$gain coins for popping 🎈")
                    confetti(m.x, m.y - 40f)
                    SoundFx.harvest()
                }
            }
        }
    }

    // ------------------------------------------------------------ playground

    private val SWING_SEAT_X = SWING_X

    private fun sendPlay(op: String, arg: Int = 0, target: String = "") {
        sendCustom(JSONObject().put("kind", "PLAY_ACT").put("op", op).put("arg", arg).put("target", target))
    }

    private fun playInteract(m: PlayerState): Boolean {
        // push a friend who is on the swing
        val s = players.values.firstOrNull { it.id != myId && it.swing >= 0 && hypot(it.x - m.x, it.y - m.y) < 110f }
        if (s != null) {
            sendPlay("PUSH", target = s.id)
            SoundFx.pop()
            showToast("Wheee! You pushed ${s.name} 🌬️")
            return true
        }
        val st = listOf("Swing", "Seesaw", "Slide")
            .mapNotNull { n -> roomRect(n)?.let { n to World.distanceTo(it, m.x, m.y) } }
            .filter { it.second < 95f }
            .minByOrNull { it.second }?.first ?: return false
        when (st) {
            "Swing" -> {
                val taken = players.values.filter { it.swing >= 0 }.map { it.swing }.toSet()
                val seat = listOf(0, 1).sortedBy { abs(SWING_SEAT_X[it] - m.x) }.firstOrNull { it !in taken }
                if (seat == null) { showToast("Both swings are busy! 🎠"); return true }
                m.swing = seat; m.swingAng = 0.3f; m.swingVel = 1.5f
                onToy = true
                sendPlay("SWING_ON", seat)
                showToast("Press ✋ to push yourself, friends can push you too!")
            }
            "Seesaw" -> {
                val taken = players.values.filter { it.seesaw >= 0 }.map { it.seesaw }.toSet()
                val seat = listOf(if (m.x < 2040f) 0 else 1, if (m.x < 2040f) 1 else 0).firstOrNull { it !in taken }
                if (seat == null) { showToast("The seesaw is full! 🎪"); return true }
                m.seesaw = seat
                m.facing = if (seat == 0) 1 else -1
                onToy = true
                sendPlay("SEE_ON", seat)
                if (taken.isEmpty()) showToast("The seesaw needs 2 players! Ask a friend 🎪")
            }
            else -> {
                val sr = roomRect("Slide") ?: return true
                m.slideT = 0.001f
                m.facing = 1
                m.x = sr.left + sr.width * 0.46f; m.y = sr.top + 24f; m.tx = m.x; m.ty = m.y
                sendMove(m)
                SoundFx.whoosh()
                sendPlay("SLIDE")
            }
        }
        return true
    }

    fun getOffToy() {
        val m = me ?: return
        if (m.swing >= 0) {
            val ax = SWING_X[m.swing]
            m.swing = -1
            teleport(m, Offset(ax, 880f))
            sendPlay("SWING_OFF")
        }
        if (m.seesaw >= 0) {
            val sx = SEE_X[m.seesaw]
            m.seesaw = -1
            teleport(m, Offset(sx, 1135f))
            sendPlay("SEE_OFF")
        }
        onToy = false
    }

    /** Swing physics, seesaw bounce, slide ride, trampoline combos. Runs before walking. */
    private fun playUpdate(m: PlayerState, dt: Float) {
        // swing: a pendulum you can push
        if (m.swing >= 0) {
            val ax = SWING_X[m.swing]
            m.swingVel += (-9f * sin(m.swingAng) - 0.12f * m.swingVel) * dt
            m.swingAng = (m.swingAng + m.swingVel * dt).coerceIn(-1.2f, 1.2f)
            val sign = if (m.swingVel >= 0f) 1 else -1
            if (sign != lastSwingSign && lastSwingSign != 0 && abs(m.swingAng) > 0.3f) SoundFx.squeak()
            lastSwingSign = sign
            m.x = ax + SWING_L * sin(m.swingAng)
            m.y = SWING_Y + SWING_L * cos(m.swingAng)
            m.tx = m.x; m.ty = m.y
        }
        // seesaw: left rider drives, right rider mirrors; alone = your side stays down
        if (m.seesaw >= 0) {
            val partner = players.values.firstOrNull { it.id != myId && it.seesaw == 1 - m.seesaw }
            val target = when {
                partner == null -> SEE_Y + SEE_A
                m.seesaw == 0 -> SEE_Y + SEE_A * sin(time * 3.2f)
                else -> 2f * SEE_Y - partner.y
            }
            m.x = SEE_X[m.seesaw]
            m.y += (target - m.y) * min(1f, 10f * dt)
            m.tx = m.x; m.ty = m.y
            val dir = if (m.y > seeLastY + 0.05f) 1 else if (m.y < seeLastY - 0.05f) -1 else 0
            if (partner != null && dir != 0 && seeLastDir != 0 && dir != seeLastDir) SoundFx.giggle()
            if (dir != 0) seeLastDir = dir
            seeLastY = m.y
        }
        // slide: climb the top, whoosh down, dust at the bottom
        if (m.slideT > 0f) {
            val sr = roomRect("Slide")
            m.slideT += dt
            val f = (m.slideT / 1.2f).coerceAtMost(1f)
            if (sr != null) {
                // top of the slope -> bottom of the slope (the drawing runs down and to the right)
                m.x = sr.left + sr.width * (0.46f + 0.34f * f)
                m.y = sr.top + 24f + (sr.height - 14f) * f * f
                m.tx = m.x; m.ty = m.y
                spawnDust(m, dt, 0f, 0f)
                if (f >= 1f) {
                    m.slideT = 0f
                    m.x = sr.left + sr.width * 0.8f; m.y = sr.bottom + 34f; m.tx = m.x; m.ty = m.y
                    repeat(6) { dust.add(Dust(m.x + (Math.random().toFloat() - 0.5f) * 40f, m.y - 4f)) }
                    sendMove(m)
                }
            } else m.slideT = 0f
        }
        // trampoline: every bounce goes higher, combo counts up
        if (m.swing < 0 && m.seesaw < 0 && m.slideT <= 0f) {
            val tr = roomRect("Trampoline")
            val inTramp = tr != null && tr.contains(Offset(m.x, m.y))
            if (m.z > 0f || m.vz > 0f || inTramp) {
                if (m.z <= 0f && inTramp && m.vz <= 0f) {
                    m.combo += 1
                    m.vz = 230f + min(m.combo, 7) * 40f
                    SoundFx.boing()
                    repeat(3) { dust.add(Dust(m.x + (Math.random().toFloat() - 0.5f) * 30f, m.y)) }
                }
                m.vz -= 720f * dt
                m.z = max(0f, m.z + m.vz * dt)
                if (m.z == 0f && m.vz < 0f) m.vz = 0f
                m.comboT = 1.2f
            } else if (m.combo > 0) {
                m.comboT -= dt
                if (m.comboT <= 0f) m.combo = 0
            }
        }
    }

    // ------------------------------------------------------------ living room, bedroom, bathroom

    private fun sendRoom(op: String, arg: Int = 0, target: String = "") {
        sendCustom(JSONObject().put("kind", "ROOM_ACT").put("op", op).put("arg", arg).put("target", target))
    }

    private fun teleport(m: PlayerState, o: Offset) {
        m.x = o.x; m.y = o.y; m.tx = o.x; m.ty = o.y
        sendMove(m)
    }

    private fun roomRect(name: String) = World.furniture.firstOrNull { it.name == name }?.rect

    private fun roomInteract(m: PlayerState): Boolean {
        // wake a sleeping friend (they get woken, you do a happy hop)
        val sleeper = players.values.firstOrNull { it.id != myId && it.sleeping && hypot(it.x - m.x, it.y - m.y) < 110f }
        if (sleeper != null) {
            sendRoom("WAKE_OTHER", target = sleeper.id)
            m.emote = Emote.HAPPY; m.emoteT = 0f
            showToast("⏰ Wake up, ${sleeper.name}!")
            return true
        }
        if (placedInteract(m)) return true
        val st = listOf("Bed", "Bed 2", "Sofa", "TV", "Cat", "Mirror", "Wardrobe", "Photo Wall", "Shower", "Sink", "Bathtub")
            .mapNotNull { n -> roomRect(n)?.let { n to World.distanceTo(it, m.x, m.y) } }
            .filter { it.second < 85f }
            .minByOrNull { it.second }?.first ?: return false
        val r = roomRect(st) ?: return false
        when (st) {
            "Bed", "Bed 2" -> { pendingBed = st; pendingBedRect = null; dialog = "SLEEP" }
            "Sofa" -> {
                sitOnSofa(m, r)
            }
            "TV" -> {
                changeTv()
                showToast(if (tv == 3) "📺 TV off" else "📺 Channel ${tv + 1}")
            }
            "Cat" -> {
                catWagT = 2f
                hearts(r.center.x, r.center.y - 30f)
                addHappy(2f)
                SoundFx.meow()
                quests.bump("CAT")
                showToast("Purr… 🐱")
            }
            "Mirror" -> { emote(Emote.WAVE); panel = "CREATOR" }
            "Wardrobe" -> panel = "WARDROBE"
            "Photo Wall" -> panel = "PHOTOS"
            "Shower" -> {
                teleport(m, r.center)
                m.busyT = 4f; m.showerT = 4f
                fogT = 20f
                addHappy(5f)
                SoundFx.splash()
                sendRoom("SHOWER")
                showToast("Ahh, warm water! 🚿 +Happiness")
            }
            "Sink" -> panel = "TEETH"
            "Bathtub" -> {
                teleport(m, r.center)
                m.busyT = 6f; m.bathT = 6f
                addHappy(8f)
                SoundFx.splash()
                sendRoom("BATH")
                showToast("Bubble bath! 🛁 +Happiness")
            }
        }
        return true
    }

    /** Sofas seat up to 3 friends (2 on a small one). Each takes the free spot closest to them. */
    private fun sitOnSofa(m: PlayerState, r: Rect) {
        val n = if (r.width >= 150f) 3 else 2
        val slots = List(n) { Offset(r.left + r.width * (it * 2 + 1) / (2f * n), r.center.y - 4f) }
        val free = slots.filter { s -> players.values.none { it.id != myId && it.seated && hypot(it.x - s.x, it.y - s.y) < 22f } }
        val seat = free.minByOrNull { hypot(it.x - m.x, it.y - m.y) }
        if (seat == null) { showToast("The sofa is full! 🛋️"); return }
        standPos = Offset(seat.x, r.bottom + 26f)
        teleport(m, seat)
        m.seated = true
        sendRoom("SIT")
        showToast("Cozy! Watch the TV above 📺 · ✋ to get up")
    }

    fun changeTv() {
        tv = (tv + 1) % 4
        tvStatic = 0.5f
        SoundFx.pop()
        sendRoom("TV", tv)
    }

    fun startSleep() {
        dialog = null
        val m = me ?: return
        val r = pendingBedRect ?: roomRect(pendingBed ?: return) ?: return
        pendingBedRect = null
        standPos = Offset(r.center.x, r.bottom + 28f)
        val pillowY = r.top + r.height * 0.25f
        val head = if (r.width > 140f) {
            val a = Offset(r.left + r.width * 0.25f, pillowY)
            val b = Offset(r.left + r.width * 0.75f, pillowY)
            if (hypot(m.x - a.x, m.y - a.y) <= hypot(m.x - b.x, m.y - b.y)) a else b
        } else Offset(r.center.x, pillowY)
        teleport(m, head)                       // head on the pillow, body under the quilt
        m.sleeping = true; m.sleepT = 0f
        m.dream = (Math.random() * 6).toInt()
        sendRoom("SLEEP", m.dream)
    }

    /** Sleep never changes world time: fade, refill Energy, +Happiness, dream bubble. */
    fun wake(full: Boolean) {
        val m = me ?: return
        if (!m.sleeping) return
        m.sleeping = false
        standPos?.let { teleport(m, it) }
        energyF = if (full) 100f else min(100f, energyF + 40f)
        if (full) addHappy(10f)
        showToast(if (full) (if (clock.phase() == 0) "☀️ Good morning! +Energy +Happiness" else "😊 Nice rest! +Energy +Happiness") else "Oh! You woke up early 🥱")
        sendRoom("WAKE")
    }

    private fun stand() {
        val m = me ?: return
        m.seated = false
        standPos?.let { teleport(m, it) }
        sendRoom("STAND")
    }

    fun finishBrush() {
        if (panel != "TEETH") return
        panel = null
        val m = me ?: return
        val now = System.currentTimeMillis()
        if (now - lastBrushMs > 20_000) { addHappy(15f); showToast("Sparkly clean teeth! ✨ +Happiness") }
        else showToast("Already sparkly! ✨")
        lastBrushMs = now
        SoundFx.harvest()
        m.emote = Emote.HAPPY; m.emoteT = 0f
    }

    // ------------------------------------------------------------ kitchen

    private fun broadcastKitchen() {
        sendCustom(JSONObject().put("kind", "KITCHEN_STATE").put("state", kitchen.toJson()))
    }

    private fun kitchenAct(op: String, arg: Int = 0) {
        sendCustom(JSONObject().put("kind", "KITCHEN_ACT").put("op", op).put("arg", arg))
        if (net?.isHost == true) { broadcastKitchen(); broadcastFarm() }
    }

    /** What everyone sees when someone cooks, serves, eats or washes. */
    private fun kitchenFx(p: PlayerState, op: String) {
        when (op) {
            "COOK" -> { p.tool = "🍳"; p.toolT = 1f }
            "SERVE" -> { p.tool = "🍽️"; p.toolT = 1f }
            "TRASH" -> { p.tool = "🗑️"; p.toolT = 1f }
            "WASH" -> { p.tool = "🧽"; p.toolT = 1f }
            "EAT" -> { p.tool = "🍴"; p.toolT = 2.5f; p.sitT = 2.5f; hearts(p.x, p.y - 60f) }
        }
    }

    /** ✋ near the fridge, stove, table or sink. */
    private fun kitchenInteract(m: PlayerState): Boolean {
        val station = listOf("Fridge", "Stove", "Table", "Kitchen Sink")
            .mapNotNull { n -> World.furniture.firstOrNull { it.name == n }?.let { n to World.distanceTo(it.rect, m.x, m.y) } }
            .filter { it.second < 85f }
            .minByOrNull { it.second }?.first ?: return false
        when (station) {
            "Fridge" -> { fridgeOpenT = 1.6f; SoundFx.fridge(); panel = "FRIDGE" }
            "Stove" -> stoveAction(m)
            "Table" -> eat(m)
            else -> wash(m)
        }
        return true
    }

    private fun stoveAction(m: PlayerState) {
        when (kitchen.phase) {
            0 -> panel = "RECIPES"
            1 -> showToast("Cooking… ${(KitchenManager.COOK_S - kitchen.t).toInt() + 1}s 🍲")
            2 -> {
                if (kitchen.apply("SERVE", 0)) {
                    earn(10)
                    addXp(3); quests.bump("COOK")
                    showToast("${KitchenManager.RECIPES[kitchen.lastServed].emoji} Served at the table! +10 coins")
                    kitchenFx(m, "SERVE")
                    confetti(m.x, m.y - 40f)
                    SoundFx.harvest()
                    kitchenAct("SERVE")
                } else showToast("The table is full! Eat something first 😋")
            }
            else -> {
                kitchen.apply("TRASH", 0)
                showToast("Yuck! Burnt food 😵 Thrown away")
                kitchenFx(m, "TRASH")
                SoundFx.pop()
                kitchenAct("TRASH")
            }
        }
    }

    /** Opens the hands-on cooking game for a recipe (nothing is used up until the dish is done). */
    fun startCooking(i: Int) {
        if (!kitchen.canCook(i)) { showToast("Can't cook that right now"); return }
        cookIndex = i
        panel = "COOKING"
    }

    /** The dish is done: take the ingredients, put it on the table, pay coins by how well you cooked (1-3 stars). */
    fun finishCooking(i: Int, stars: Int) {
        val m = me ?: return
        panel = null
        val r = KitchenManager.RECIPES.getOrNull(i) ?: return
        if (!kitchen.apply("COOK", i)) { showToast("Someone is using the stove right now 🍳"); return }
        kitchenAct("COOK", i)
        kitchen.apply("FINISH", 0); kitchenAct("FINISH")
        if (kitchen.apply("SERVE", 0)) {
            val pay = 8 + stars * 4
            earn(pay)
            addXp(3); quests.bump("COOK")
            showToast("${r.emoji} ${r.name} is ready! ${"⭐".repeat(stars)} +$pay coins")
            kitchenFx(m, "SERVE")
            confetti(m.x, m.y - 40f)
            SoundFx.harvest()
            kitchenAct("SERVE")
        } else showToast("The table is full! Press ✋ at the stove to serve it later 😋")
    }

    fun cook(i: Int) {
        val m = me ?: return
        panel = null
        val r = KitchenManager.RECIPES.getOrNull(i) ?: return
        if (kitchen.apply("COOK", i)) {
            showToast("${r.emoji} Cooking ${r.name}… ready in 10s")
            kitchenFx(m, "COOK")
            SoundFx.plant()
            kitchenAct("COOK", i)
        } else showToast("Can't cook that right now")
    }

    private fun eat(m: PlayerState) {
        val plate = kitchen.plates.firstOrNull()
        if (plate == null) { showToast("Nothing to eat yet. Cook at the stove! 🍳"); return }
        if (!kitchen.apply("EAT", 0)) return
        sitAtTable(m)
        val r = KitchenManager.RECIPES[plate]
        energyF = min(100f, energyF + r.energy)
        hungerF = min(100f, hungerF + 30f)
        addHappy(r.happy.toFloat())
        kitchenFx(m, "EAT")
        SoundFx.hug()
        quests.bump("EAT")
        showToast("Yum! ${r.emoji}  +Energy +Happiness")
        kitchenAct("EAT")
        val now = System.currentTimeMillis()
        eatLog.add(now)
        eatLog.removeAll { now - it > 45_000 }
        if (eatLog.size >= 3) {                 // overeating = burp
            eatLog.clear()
            sendChat("*burp* 💨")
            showToast("Burp! You ate a lot 😅")
        }
    }

    private var eatSeat = false

    /** Sit on the closest free chair (3 above, 3 below the table). You stand up by yourself after eating. */
    private fun sitAtTable(m: PlayerState) {
        val tbl = World.furniture.firstOrNull { it.name == "Table" }?.rect ?: return
        val slots = List(6) { i ->
            val x = tbl.left + tbl.width * ((i % 3) * 2 + 1) / 6f
            if (i < 3) Offset(x, tbl.top - 4f) else Offset(x, tbl.bottom + 30f)
        }
        val free = slots.filter { s -> players.values.none { it.id != myId && it.seated && hypot(it.x - s.x, it.y - s.y) < 22f } }
        val seat = free.minByOrNull { hypot(it.x - m.x, it.y - m.y) } ?: return
        standPos = Offset(seat.x, if (seat.y < tbl.top) tbl.top - 50f else tbl.bottom + 62f)
        teleport(m, seat)
        m.seated = true
        eatSeat = true
        sendRoom("SIT")
    }

    private fun wash(m: PlayerState) {
        if (kitchen.apply("WASH", 0)) {
            kitchenFx(m, "WASH")
            SoundFx.splash()
            showToast(if (kitchen.dirty > 0) "Scrub scrub! ✨ ${kitchen.dirty} dishes left" else "All clean! ✨")
            kitchenAct("WASH")
        } else showToast("No dirty dishes 🧽")
    }

    private fun broadcastFarm() {
        sendCustom(JSONObject().put("kind", "FARM_STATE").put("state", farm.toJson()))
    }

    private fun farmAct(op: String, plot: Int, crop: Int) {
        sendCustom(JSONObject().put("kind", "FARM_ACT").put("op", op).put("plot", plot).put("crop", crop))
        if (net?.isHost == true) broadcastFarm()
    }

    /** Tool in hand + water droplets. Everyone sees it, also for friends' actions. */
    private fun farmFx(p: PlayerState, op: String, idx: Int) {
        p.tool = when (op) { "WATER" -> "🚿"; "PLANT" -> "🌱"; else -> "🧺" }
        p.toolT = 0.8f
        if (op == "WATER" && idx in World.plots.indices) {
            val r = World.plots[idx]
            repeat(10) {
                particles.add(Particle(r.left + Math.random().toFloat() * r.width, r.top - 24f - Math.random().toFloat() * 14f,
                    (Math.random().toFloat() - 0.5f) * 20f, 30f, 0.7f, 2, Color.White))
            }
        }
    }

    /** The ✋ button on a farm plot: harvest if ready, water if dry, plant if empty. */
    private fun farmInteract(m: PlayerState): Boolean {
        val idx = farm.nearestPlot(m.x, m.y) ?: return false
        val pl = farm.plots[idx]
        when {
            pl.crop >= 0 && pl.ready() -> {
                val crop = pl.crop
                if (farm.apply("HARVEST", idx, crop)) {
                    earn(5)
                    addXp(2); quests.bump("HARVEST")
                    showToast("${Crop.values()[crop].emoji} Harvested! +5 coins")
                    farmFx(m, "HARVEST", idx)
                    confetti(World.plots[idx].center.x, World.plots[idx].top - 20f)
                    SoundFx.harvest()
                    farmAct("HARVEST", idx, crop)
                }
            }
            pl.crop >= 0 && pl.wetMs <= 0f -> {
                farm.apply("WATER", idx, pl.crop)
                quests.bump("WATER")
                farmFx(m, "WATER", idx)
                SoundFx.splash()
                showToast("Splash! 💧")
                farmAct("WATER", idx, pl.crop)
            }
            pl.crop >= 0 -> showToast(if (farm.weather == Weather.RAINY) "The rain is watering it 🌧️" else "Growing… 🌱")
            else -> {
                val c = farm.selectedSeed
                if (farm.apply("PLANT", idx, c)) {
                    farmFx(m, "PLANT", idx)
                    SoundFx.plant()
                    showToast("Planted ${Crop.values()[c].label}!")
                    farmAct("PLANT", idx, c)
                } else showToast("No ${Crop.values()[c].label} seeds! Pick another in the 🌱 bag")
            }
        }
        return true
    }

    /** Tap on the screen: butterflies follow you for 10 seconds. */
    fun tapScreen(sx: Float, sy: Float) {
        val wx = sx / viewScale + camX
        val wy = sy / viewScale + camY
        if (mg.game == MinigameManager.BALLOON && mg.phase == 2) {      // tap a balloon to pop it
            val el = mg.elapsed()
            for (i in 0 until 32) {
                if (i in mg.popped) continue
                val b = mg.balloonAt(i, el) ?: continue
                if (hypot(b.x - wx, b.y - wy) < 40f) {
                    SoundFx.pop()
                    if (net?.isHost == true) mg.popRequest(i, myId)
                    else { mg.popped.add(i); sendCustom(JSONObject().put("kind", "MG_REQ").put("op", "POP").put("idx", i)) }
                    return
                }
            }
        }
        val c = critters.firstOrNull { it.kind == 0 && hypot(it.x - wx, it.y - wy) < 40f } ?: return
        c.follow = 10f
        showToast("🦋 A butterfly is following you!")
        SoundFx.pop()
    }

    fun interact() {
        val m = me ?: return
        if (m.sleeping) { wake(false); return }
        if (m.seated) { stand(); return }
        if (m.swing >= 0) { m.swingVel += if (m.swingVel >= 0f) 2.2f else -2.2f; SoundFx.squeak(); return }
        if (m.seesaw >= 0) { showToast("Bounce bounce! 🎪 Tap Get off to leave"); return }
        if (farmInteract(m)) return
        if (kitchenInteract(m)) return
        if (roomInteract(m)) return
        if (playInteract(m)) return
        if (mgInteract(m)) return
        if (townInteract(m)) return
        if (npcInteract(m)) return
        if (secretInteract(m)) return
        val near = World.furniture
            .filter { it.interactive }
            .minByOrNull { World.distanceTo(it.rect, m.x, m.y) }
        showToast(
            if (near != null && World.distanceTo(near.rect, m.x, m.y) < 80f) "${near.name}: coming soon!"
            else "Nothing to do here"
        )
    }

    private fun showToast(t: String) { toast = t; toastLeft = 2f }

    fun emote(e: Emote) {
        val m = me ?: return
        m.emote = e; m.emoteT = 0f
        SoundFx.emote(e.ordinal)
        sendCustom(JSONObject().put("kind", "EMOTE").put("emote", e.name))
    }

    fun hug() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(10f)
        m.emote = Emote.LOVE; m.emoteT = 0f
        hearts(m.x, m.y - 60f); hearts(t.x, t.y - 60f)
        m.blushT = 3f; t.blushT = 3f
        SoundFx.hug()
        quests.bump("HUG")
        sendCustom(JSONObject().put("kind", "HUG").put("target", t.id))
    }

    fun highFive() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(5f)
        confetti((m.x + t.x) / 2f, min(m.y, t.y) - 50f)
        SoundFx.highFive()
        sendCustom(JSONObject().put("kind", "HIGHFIVE").put("target", t.id))
    }

    /** Pick up the nearby friend, or put down whoever I carry. */
    fun toggleCarry() {
        val m = me ?: return
        val carrying = m.carrying
        if (carrying != null) {
            applyCarry(myId, carrying, false)
            sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", carrying).put("on", 0))
            return
        }
        val t = players[nearbyFriend ?: return] ?: return
        if (t.carrying != null) return
        applyCarry(myId, t.id, true)
        SoundFx.pop()
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", t.id).put("on", 1))
    }

    /** I am being carried and want to get down. */
    fun getDown() {
        val carrier = me?.carriedBy ?: return
        applyCarry(carrier, myId, false)
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", carrier).put("carried", myId).put("on", 0))
    }
}
