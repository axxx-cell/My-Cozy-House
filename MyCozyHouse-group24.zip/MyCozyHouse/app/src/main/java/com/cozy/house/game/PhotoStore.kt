package com.cozy.house.game

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.ImageBitmap
import androidx.compose.ui.graphics.asAndroidBitmap
import androidx.compose.ui.graphics.drawscope.CanvasDrawScope
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Density
import androidx.compose.ui.unit.LayoutDirection
import java.io.File
import java.io.FileOutputStream
import kotlin.math.sin

/** Photo Mode pictures are saved on this phone (max 50, the oldest are removed). They show on the Photo Wall. */
object PhotoStore {
    val POSES = listOf("Wave", "Dance", "Heart", "Sit")
    val BACKGROUNDS = listOf("Pink", "Sky", "Garden", "Night", "Rainbow")

    private fun dir(ctx: Context) = File(ctx.filesDir, "photos").apply { mkdirs() }

    fun list(ctx: Context): List<File> =
        dir(ctx).listFiles { f -> f.extension == "png" }?.sortedByDescending { it.lastModified() } ?: emptyList()

    fun save(ctx: Context, bmp: ImageBitmap): Boolean = try {
        val f = File(dir(ctx), "photo_${System.currentTimeMillis()}.png")
        FileOutputStream(f).use { bmp.asAndroidBitmap().compress(Bitmap.CompressFormat.PNG, 100, it) }
        list(ctx).drop(50).forEach { it.delete() }
        true
    } catch (e: Exception) { false }

    fun render(look: Look, name: String, pose: Int, bg: Int, paints: Paints): ImageBitmap {
        val w = 640
        val h = 640
        val bmp = ImageBitmap(w, h)
        val canvas = androidx.compose.ui.graphics.Canvas(bmp)
        CanvasDrawScope().draw(Density(1f), LayoutDirection.Ltr, canvas, Size(w.toFloat(), h.toFloat())) {
            drawPhotoScene(look, name, pose, bg, paints, w.toFloat(), h.toFloat(), withCaption = true)
        }
        return bmp
    }
}

private fun applyPose(pv: PlayerState, pose: Int) {
    pv.animT = 1.2f
    pv.facing = 1
    pv.emote = when (pose) { 0 -> Emote.WAVE; 1 -> Emote.DANCE; 2 -> Emote.LOVE; else -> null }
    pv.emoteT = 0.9f
    pv.sitT = if (pose == 3) 5f else 0f
}

/** The same picture is used for the live preview and for the saved photo. */
internal fun DrawScope.drawPhotoScene(look: Look, name: String, pose: Int, bg: Int, paints: Paints, w: Float, h: Float, withCaption: Boolean = false) {
    val nc = drawContext.canvas.nativeCanvas
    // background
    when (bg) {
        0 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFFFE3F0), Color(0xFFFFC8DD))), Offset.Zero, Size(w, h))
            for (i in 0 until 12) drawCircle(Color.White.copy(alpha = 0.5f), w * 0.02f + (i % 3) * 4f, Offset(w * ((i * 0.37f) % 1f), h * ((i * 0.23f + 0.1f) % 0.8f)))
        }
        1 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF8EC9FF), Color(0xFFE3F4FF))), Offset.Zero, Size(w, h))
            drawCircle(Color(0xFFFFE066), w * 0.09f, Offset(w * 0.8f, h * 0.18f))
            for ((cx, cy) in listOf(0.2f to 0.2f, 0.55f to 0.12f, 0.35f to 0.38f)) {
                drawCircle(Color.White, w * 0.06f, Offset(w * cx, h * cy)); drawCircle(Color.White, w * 0.05f, Offset(w * (cx + 0.06f), h * cy + 6f)); drawCircle(Color.White, w * 0.045f, Offset(w * (cx - 0.06f), h * cy + 8f))
            }
        }
        2 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFBDE9FF), Color(0xFFE9F9FF))), Offset.Zero, Size(w, h * 0.6f))
            drawRect(Color(0xFFC9F0B8), Offset(0f, h * 0.6f), Size(w, h * 0.4f))
            for (i in 0 until 14) {
                val fx = w * ((i * 0.171f) % 1f)
                val fy = h * (0.66f + ((i * 0.31f) % 0.3f))
                drawCircle(listOf(Color(0xFFFF9EC4), Color(0xFFFFE066), Color(0xFFD9B3FF), Color.White)[i % 4], 9f, Offset(fx, fy))
                drawCircle(Color(0xFFFFB400), 3f, Offset(fx, fy))
            }
        }
        3 -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFF0B1B4D), Color(0xFF3A2D6B))), Offset.Zero, Size(w, h))
            for (i in 0 until 40) drawCircle(Color.White.copy(alpha = 0.4f + 0.6f * ((i * 0.37f) % 1f)), 1.5f + (i % 3), Offset(w * ((i * 0.618f) % 1f), h * ((i * 0.382f + 0.1f) % 0.8f)))
            drawCircle(Color(0xFFFFF4C2), w * 0.08f, Offset(w * 0.78f, h * 0.2f))
            drawCircle(Color(0xFF1A2760), w * 0.07f, Offset(w * 0.8f, h * 0.18f))
        }
        else -> {
            drawRect(Brush.verticalGradient(listOf(Color(0xFFFFF1F8), Color(0xFFE8F4FF))), Offset.Zero, Size(w, h))
            val cols = listOf(0xFFFF6B6B, 0xFFFFA94D, 0xFFFFE066, 0xFF8EE6A0, 0xFF74C0FC, 0xFF9775FA, 0xFFD0A2F7)
            for ((i, c) in cols.withIndex()) {
                val r = w * 0.48f - i * w * 0.035f
                drawArc(Color(c), 180f, 180f, false, Offset(w / 2f - r, h * 0.62f - r), Size(r * 2f, r * 2f), style = Stroke(w * 0.03f))
            }
        }
    }
    // the avatar
    val pv = PlayerState("photo", name, 0)
    pv.updateLook(look)
    applyPose(pv, pose)
    val sc = h / 150f
    withTransform({ translate(w / 2f, h * 0.9f); scale(sc, sc, Offset.Zero) }) {
        drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
    }
    if (pose == 2) {   // heart pose: floating hearts
        paints.glyph.color = 0xFFFF4D8D.toInt()
        for (i in 0 until 7) {
            paints.glyph.textSize = h * (0.05f + 0.01f * (i % 3))
            nc.drawText("♥", w * (0.2f + 0.1f * i) , h * (0.2f + 0.05f * sin(i * 1.7f)), paints.glyph)
        }
    }
    if (withCaption) {
        drawRoundRect(OUT, Offset(8f, 8f), Size(w - 16f, h - 16f), CornerRadius(28f), style = Stroke(10f))
        paints.nameFill.textSize = 22f
        val date = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.US).format(java.util.Date())
        nc.drawText("$name · $date", w / 2f, h - 26f, paints.nameFill)
        paints.nameFill.textSize = 15f
    }
}
