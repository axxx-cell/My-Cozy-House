package com.cozy.house.game

/** Cute things for your pet. Bought with hearts, which you earn by petting and feeding a happy pet. */
class PetItem(val id: Int, val emoji: String, val name: String, val cost: Int, val neck: Boolean)

object PetStuff {
    val ALL = listOf(
        PetItem(1, "🎀", "Bow", 5, false),
        PetItem(2, "🔔", "Bell collar", 8, true),
        PetItem(3, "🌸", "Flower", 6, false),
        PetItem(4, "🧣", "Scarf", 10, true),
        PetItem(5, "🕶️", "Shades", 12, false),
        PetItem(6, "👑", "Crown", 15, false),
    )
    const val DAILY_MAX = 15
    fun get(id: Int) = ALL.firstOrNull { it.id == id }
}
