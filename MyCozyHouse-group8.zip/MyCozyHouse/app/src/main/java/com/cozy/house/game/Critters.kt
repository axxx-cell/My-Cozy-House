package com.cozy.house.game

import kotlin.math.cos
import kotlin.math.hypot
import kotlin.math.sin

/**
 * Garden life (only for looks, not synced). kind 0 = butterfly, 1 = bee, 2 = bird.
 * Tap a butterfly and it follows you for 10 seconds.
 */
class Critter(val kind: Int, var x: Float, var y: Float) {
    var tx = x
    var ty = y
    var follow = 0f
    var wait = 0f
    var phase = Math.random().toFloat() * 6.28f

    companion object {
        const val X0 = 850f; const val X1 = 1550f
        const val Y0 = 700f; const val Y1 = 1220f
    }

    private fun rnd(a: Float, b: Float) = a + Math.random().toFloat() * (b - a)

    fun update(dt: Float, meX: Float, meY: Float) {
        phase += dt
        if (follow > 0f) {
            follow -= dt
            tx = meX + 40f * sin(phase * 1.5f)
            ty = meY - 60f + 10f * cos(phase * 2f)
            moveToward(dt, 120f)
            return
        }
        if (wait > 0f) { wait -= dt; return }
        if (hypot(tx - x, ty - y) < 6f) {
            when (kind) {
                2 -> { tx = (x + rnd(-70f, 70f)).coerceIn(X0, X1); ty = (y + rnd(-50f, 50f)).coerceIn(Y0, Y1); wait = rnd(1f, 3f) }
                1 -> { tx = rnd(860f, 1260f); ty = rnd(700f, 950f) }
                else -> { tx = rnd(X0, X1); ty = rnd(Y0, Y1) }
            }
        }
        moveToward(dt, when (kind) { 0 -> 45f; 1 -> 85f; else -> 35f })
    }

    private fun moveToward(dt: Float, speed: Float) {
        val dx = tx - x
        val dy = ty - y
        val d = hypot(dx, dy)
        if (d > 1f) {
            val step = minOf(d, speed * dt)
            x += dx / d * step
            y += dy / d * step
        }
    }
}
