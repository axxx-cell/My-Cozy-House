package com.cozy.house.game

import androidx.compose.ui.graphics.Color

class ShopDef(
    val id: String, val name: String, val emoji: String, val x: Int,
    val color: Color, val colorIdx: Int, val keeper: String, val lines: List<String>,
)

/** The Town sits south of the garden. Walk through the garden gate (x 1140..1260) or take the bus. */
object TownData {
    const val BUILDING_TOP = 1296
    const val BUILDING_BOTTOM = 1450
    const val WIDTH = 280

    val shops = listOf(
        ShopDef("pet", "Paws & Tails", "🐾", 100, Color(0xFFFFC8DD), 0, "Penny",
            listOf("Welcome to Paws & Tails! 🐾", "New pets arrive every day!", "Why did the cat sit on the computer? To keep an eye on the mouse! 🐭")),
        ShopDef("home", "Cozy Home", "🛋️", 420, Color(0xFFB9FBC0), 1, "Mr. Oak",
            listOf("Welcome to Cozy Home! 🛋️", "New sofas in stock today!", "I'd tell you a sofa joke, but it's a bit of a couch potato one. 🥔")),
        ShopDef("mart", "Fresh Mart", "🛒", 800, Color(0xFFFFF1A8), 3, "Freddie",
            listOf("Welcome to Fresh Mart! 🛒", "Fresh seeds and ingredients!", "What do you call a sad strawberry? A blueberry! 🍓")),
        ShopDef("style", "Style Star", "👗", 1340, Color(0xFFD9C2F0), 2, "Stella",
            listOf("Welcome to Style Star! ✨", "New outfits just arrived!", "I'm feeling a little shy... I need to come out of my shell! 🐚")),
        ShopDef("cafe", "Meow Cafe", "☕", 1660, Color(0xFFFFD1A9), 0, "Mochi",
            listOf("Welcome to Meow Cafe! ☕", "Fresh cake today! 🍰", "What's a cat's favorite drink? Purr-sian tea! 🐱")),
        ShopDef("toy", "Toy Shop & Arcade", "🕹️", 1980, Color(0xFFBDE0FE), 1, "Pixel",
            listOf("Welcome to the Toy Shop! 🕹️", "Try the arcade for 10 coins!", "Why did the ball go to school? To get a little more bounce! ⚽")),
    )

    val carColors = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFFFFD86B), Color(0xFF8EE6A0))

    /** Cars drive along the road, even ones east, odd ones west. */
    fun carX(i: Int, t: Float): Float {
        val raw = (t * (90f + i * 25f) + i * 700f) % 2800f
        return if (i % 2 == 0) raw - 200f else 2600f - raw
    }
    fun carY(i: Int) = if (i % 2 == 0) 1590f else 1530f
}

class PetDef(val type: Int, val emoji: String, val name: String, val coins: Int, val stars: Int, val rare: Boolean)

/** Pet Shop "Paws & Tails". Fox and Panda are rare: only 1 each, restocked every game day. */
object PetCatalog {
    val list = listOf(
        PetDef(0, "🐱", "Cat", 50, 0, false), PetDef(1, "🐶", "Dog", 80, 0, false), PetDef(2, "🐰", "Bunny", 40, 0, false),
        PetDef(3, "🐹", "Hamster", 50, 0, false), PetDef(4, "🐢", "Turtle", 100, 0, false),
        PetDef(5, "🦊", "Fox", 0, 3, true), PetDef(6, "🐼", "Panda", 0, 5, true),
    )
    val names = listOf("Mochi", "Biscuit", "Clover", "Nibbles", "Shelly", "Rusty", "Bamboo")
}
