package com.cozy.house.game

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.cozy.house.Cozy
import com.cozy.house.Session
import com.cozy.house.net.Area
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

private val OUT = Color(0xFF5B3A4A)
private val SHIRTS = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B))
private val HAIRS = listOf(Color(0xFF7B4B3A), Color(0xFF2F2A41), Color(0xFFE9A15B), Color(0xFFB57BDB))
private val SKIN = Color(0xFFFFE0C7)

private class Paints {
    val room = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 46f; color = 0x2E5B3A4A }
    val chat = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 14f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val emoji = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER }
    val nameFill = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val nameStroke = Paint().apply {
        isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
}

@Composable
fun GameScreen(onExit: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    val pm = remember { PlayerManager() }
    val paints = remember { Paints() }
    var tick by remember { mutableStateOf(0L) }
    var leaving by remember { mutableStateOf(false) }
    var showEmotes by remember { mutableStateOf(false) }
    var chatOpen by remember { mutableStateOf(false) }
    var chatText by remember { mutableStateOf("") }
    var bagOpen by remember { mutableStateOf(false) }
    val ctx = LocalContext.current
    val voice = remember { VoiceManager() }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pm.toast = if (granted) "Mic ready! Hold 🎤 to talk" else "Mic is off. You can still chat with text!"
    }
    DisposableEffect(Unit) {
        voice.start(myNumber = { pm.myNumber() }, peers = { pm.peerIps() })
        onDispose { voice.stop() }
    }

    LaunchedEffect(Session.host, Session.client) {
        GameNet.current()?.let { pm.runNetwork(it) }
    }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) pm.update(((now - last) / 1_000_000_000f).coerceAtMost(0.05f))
                last = now
                tick = now
            }
        }
    }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { if (pm.dialog != null) pm.dialog = null else if (pm.panel != null) pm.panel = null else if (chatOpen) chatOpen = false else if (showEmotes) showEmotes = false else leave() }

    Box(Modifier.fillMaxSize().background(Cozy.Cream)) {
        Canvas(Modifier.fillMaxSize().pointerInput(Unit) { detectTapGestures { off -> pm.tapScreen(off.x, off.y) } }) {
            @Suppress("UNUSED_VARIABLE") val frame = tick
            val s = size.height / 520f
            val viewW = size.width / s
            val viewH = 520f
            val me = pm.me
            val camX = ((me?.x ?: World.W / 2f) - viewW / 2f).coerceIn(0f, max(0f, World.W - viewW))
            val camY = ((me?.y ?: World.H / 2f) - viewH / 2f).coerceIn(0f, max(0f, World.H - viewH))
            pm.camX = camX; pm.camY = camY; pm.viewScale = s

            withTransform({
                scale(s, s, Offset.Zero)
                translate(-camX, -camY)
            }) {
                drawWorld(paints, pm.farm, pm.time)
                drawKitchenFx(pm, paints)
                drawRoomFx(pm, paints)
                drawPlayFx(pm, paints)
                for (d in pm.dust) {
                    val life = 1f - d.age / 0.5f
                    drawCircle(Color(0xFFF2E3D0).copy(alpha = 0.6f * life), 3f + d.age * 14f, Offset(d.x, d.y))
                }

                // carried players are drawn right after (on top of) their carrier
                val all = pm.players.values.sortedBy { p ->
                    val c = p.carriedBy?.let { pm.players[it] }
                    if (c != null) c.y + 0.5f else p.y
                }
                for (p in all) {
                    val c = p.carriedBy?.let { pm.players[it] }
                    val near = pm.players.values.any { o -> o !== p && hyp(o.x - p.x, o.y - p.y) < 90f }
                    val talk = if (p.id == pm.myId) voice.talking else voice.isSpeaking(p.id)
                    if (c != null) drawPlayer(p, p.id == pm.myId, near, paints, c.x + 8f, c.y - 36f, carried = true, speaking = talk)
                    else if (p.swing >= 0) {
                        val ax = PlayerManager.SWING_X[p.swing.coerceIn(0, 1)]
                        val th = if (p.id == pm.myId) p.swingAng else asin(((p.x - ax) / PlayerManager.SWING_L).coerceIn(-1f, 1f))
                        withTransform({ rotate(-th * 57.29578f, Offset(ax, PlayerManager.SWING_Y)) }) {
                            drawPlayer(p, p.id == pm.myId, near, paints, ax, PlayerManager.SWING_Y + PlayerManager.SWING_L, carried = false, speaking = talk)
                        }
                    }
                    else if (p.sleeping) withTransform({ rotate(-90f, Offset(p.x, p.y - 22f)) }) {
                        drawPlayer(p, p.id == pm.myId, near, paints, p.x, p.y, carried = false, speaking = talk)
                    }
                    else drawPlayer(p, p.id == pm.myId, near, paints, p.x, p.y, carried = false, speaking = talk)
                }
                drawCritters(pm, paints)
                for (q in pm.particles) drawParticle(q, paints)
                drawWeather(pm, camX, camY, viewW, viewH)
                drawSleepFx(pm, paints)
                if (me?.sleeping == true) drawRect(Color(0x990F1030), Offset(camX, camY), Size(viewW, viewH))
            }
        }

        // ---- top-left: leave
        Box(
            Modifier.align(Alignment.TopStart).padding(12.dp)
                .background(Cozy.Pink, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                .clickable { leave() }.padding(horizontal = 14.dp, vertical = 6.dp)
        ) { Text("✕ Leave", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }

        // ---- top-center: where am I
        if (pm.areaName.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(12.dp)
                    .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("📍 ${pm.areaName}  ${pm.farm.weather.emoji}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- top-right: stats
        Row(
            Modifier.align(Alignment.TopEnd).padding(12.dp)
                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatBar("⚡", pm.energy, Color(0xFFFFD86B))
            StatBar("🍙", pm.hunger, Color(0xFFFFA97A))
            StatBar("😊", pm.happiness, Color(0xFFFF9EC4))
            Text("🪙 ${pm.coins}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
        }

        // ---- left side: chat, push-to-talk, mute
        Column(
            Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 58.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Box(
                    Modifier.size(44.dp).background(Cozy.Blue, CircleShape).border(3.dp, OUT, CircleShape)
                        .clickable { chatOpen = !chatOpen; if (chatOpen) pm.unread = 0 },
                    contentAlignment = Alignment.Center
                ) { Text("💬", fontSize = 20.sp) }
                if (pm.unread > 0 && !chatOpen) {
                    Box(Modifier.size(14.dp).background(Color(0xFFFF4D6D), CircleShape).border(2.dp, OUT, CircleShape))
                }
            }
            Box(
                Modifier.size(44.dp)
                    .background(if (voice.talking) Cozy.Pink else Cozy.Mint, CircleShape)
                    .border(3.dp, OUT, CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                voice.startTalking()
                                tryAwaitRelease()
                                voice.stopTalking()
                            } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Text("🎤", fontSize = 20.sp) }
            Box(
                Modifier.size(44.dp).background(if (voice.muted) Cozy.Pink else Cozy.Yellow, CircleShape)
                    .border(3.dp, OUT, CircleShape).clickable { voice.toggleMute() },
                contentAlignment = Alignment.Center
            ) { Text(if (voice.muted) "🔇" else "🔊", fontSize = 20.sp) }
        }

        // ---- chat panel
        if (chatOpen) {
            Column(
                Modifier.align(Alignment.TopCenter).padding(top = 56.dp).width(340.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(18.dp))
                    .border(3.dp, OUT, RoundedCornerShape(18.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (pm.chatLog.isEmpty()) Text("Say hi to your friends! 👋", fontSize = 13.sp, color = OUT)
                pm.chatLog.takeLast(4).forEach { Text(it, fontSize = 13.sp, color = OUT) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = chatText,
                        onValueChange = { if (it.length <= 60) chatText = it },
                        singleLine = true,
                        placeholder = { Text("Say something…", fontSize = 13.sp) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Pill("Send") { pm.sendChat(chatText); chatText = ""; chatOpen = false }
                }
            }
        }

        // ---- seed bag (shared farm inventory)
        Column(
            Modifier.align(Alignment.TopEnd).padding(top = 64.dp, end = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val sel = pm.farm.selectedSeed
            Pill("🌱 ${Crop.values()[sel].emoji} ×${pm.farm.seeds[sel]}") { bagOpen = !bagOpen }
            if (bagOpen) {
                Column(
                    Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(16.dp))
                        .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Shared with all friends", fontSize = 11.sp, color = OUT)
                    Crop.values().forEachIndexed { i, c ->
                        Row(
                            Modifier.background(if (i == sel) Cozy.Pink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { pm.farm.selectedSeed = i }.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${c.emoji} ${c.label}", fontSize = 13.sp, color = OUT)
                            Text("🌱${pm.farm.seeds[i]}  🧺${pm.farm.harvested[i]}", fontSize = 13.sp, color = OUT)
                        }
                    }
                }
            }
        }

        // ---- kitchen panels (fridge / recipe book)
        when (pm.panel) {
            "RECIPES" -> Box(Modifier.align(Alignment.Center)) { RecipePanel(pm) }
            "FRIDGE" -> Box(Modifier.align(Alignment.Center)) { FridgePanel(pm) }
            "TEETH" -> Box(Modifier.align(Alignment.Center)) { TeethPanel(pm) }
        }

        // ---- sleep question
        if (pm.dialog == "SLEEP") {
            Column(
                Modifier.align(Alignment.Center)
                    .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("😴 Sleep until Morning?", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill("YES") { pm.startSleep() }
                    Pill("NO") { pm.dialog = null }
                }
            }
        }

        // ---- toast
        pm.toast?.let {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)
                    .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(it, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- friend actions (only when a friend is close, or while carrying / carried)
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                pm.onToy -> Pill("⬇️ Get off") { pm.getOffToy() }
                pm.carriedById != null -> Pill("⬇️ Get down") { pm.getDown() }
                pm.carryingId != null -> Pill("⬇️ Put down") { pm.toggleCarry() }
                pm.nearbyFriend != null -> {
                    Pill("🤗 Hug") { pm.hug() }
                    Pill("🙌 High five") { pm.highFive() }
                    Pill("🎒 Carry") { pm.toggleCarry() }
                }
            }
        }

        // ---- emotes
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 52.dp, bottom = 140.dp).size(64.dp)
                .background(Cozy.Yellow, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { showEmotes = !showEmotes },
            contentAlignment = Alignment.Center
        ) { Text("😊", fontSize = 28.sp) }

        if (showEmotes) {
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 124.dp, bottom = 120.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Emote.values().toList().chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { e ->
                            Box(
                                Modifier.size(44.dp).background(Cozy.Cream, CircleShape).border(2.dp, OUT, CircleShape)
                                    .clickable { pm.emote(e); showEmotes = false },
                                contentAlignment = Alignment.Center
                            ) { Text(e.emoji, fontSize = 22.sp) }
                        }
                    }
                }
            }
        }

        // ---- joystick left, interact right
        Joystick(
            Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 24.dp),
            onMove = { x, y -> pm.joyX = x; pm.joyY = y }
        )
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 36.dp, bottom = 36.dp).size(92.dp)
                .background(Cozy.Mint, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { pm.interact() },
            contentAlignment = Alignment.Center
        ) { Text("✋", fontSize = 36.sp) }
    }
}

private fun hyp(a: Float, b: Float) = sqrt(a * a + b * b)

@Composable
private fun StatBar(icon: String, value: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 16.sp)
        Box(
            Modifier.width(52.dp).height(12.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(6.dp))
                .border(2.dp, OUT, RoundedCornerShape(6.dp))
        ) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0, 100) / 100f).background(color, RoundedCornerShape(6.dp)))
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
}

// ------------------------------------------------------------------ joystick

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier.size(150.dp).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f * 0.6f
                fun update(p: Offset) {
                    var d = p - center
                    val len = d.getDistance()
                    if (len > radius) d = d * (radius / len)
                    knob = d
                    onMove(d.x / radius, d.y / radius)
                }
                update(down.position)
                var pressed = true
                while (pressed) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id }
                    if (change != null && change.pressed) {
                        update(change.position)
                        change.consume()
                    } else pressed = false
                }
                knob = Offset.Zero
                onMove(0f, 0f)
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.White.copy(alpha = 0.55f), size.width / 2f - 4f, c)
            drawCircle(OUT, size.width / 2f - 4f, c, style = Stroke(5f))
            drawCircle(Cozy.Pink, 30.dp.toPx(), c + knob)
            drawCircle(OUT, 30.dp.toPx(), c + knob, style = Stroke(5f))
        }
    }
}

// ------------------------------------------------------------------ drawing (world units)

private fun DrawScope.roundRectOutlined(tl: Offset, sz: Size, radius: Float, fill: Color, stroke: Float = 4f) {
    drawRoundRect(fill, tl, sz, CornerRadius(radius))
    drawRoundRect(OUT, tl, sz, CornerRadius(radius), style = Stroke(stroke))
}

private fun DrawScope.circleOutlined(c: Offset, r: Float, fill: Color, stroke: Float = 3f) {
    drawCircle(fill, r, c)
    drawCircle(OUT, r, c, style = Stroke(stroke))
}

private fun floorColor(a: Area) = when (a) {
    Area.BEDROOM -> Color(0xFFFFE3F0)
    Area.LIVING_ROOM -> Color(0xFFFFF3D6)
    Area.KITCHEN -> Color(0xFFE0F7EA)
    Area.BATHROOM -> Color(0xFFE0F0FF)
    Area.GARDEN -> Color(0xFFC9F0B8)
    Area.PLAYGROUND -> Color(0xFFFBE9B7)
    Area.TOWN -> Color(0xFFE8E8E8)
}

private fun DrawScope.drawWorld(paints: Paints, farm: FarmManager, time: Float) {
    val nc = drawContext.canvas.nativeCanvas

    for ((area, r) in World.rooms) {
        drawRect(floorColor(area), r.topLeft, r.size)
        if (area == Area.KITCHEN || area == Area.BATHROOM) {
            val alt = if (area == Area.KITCHEN) Color(0xFFCFF0DD) else Color(0xFFCDE6FA)
            var iy = 0
            var y = r.top
            while (y < r.bottom) {
                var ix = 0
                var x = r.left
                while (x < r.right) {
                    if ((ix + iy) % 2 == 0) drawRect(alt, Offset(x, y), Size(80f, 80f))
                    x += 80f; ix++
                }
                y += 80f; iy++
            }
        }
        nc.drawText(World.areaLabel(area), r.center.x, r.top + 80f, paints.room)
    }

    for (f in World.furniture.sortedBy { if (it.solid) 1 else 0 }) {
        if (f.name.startsWith("Plot ")) { drawPlot(f, farm, paints, time); continue }
        if (f.name == "Scarecrow") { drawScarecrow(f.rect.center.x, f.rect.top, time); continue }
        if (f.name == "Cat" || f.name == "Bath Mirror" || f.name == "Swing" || f.name == "Seesaw" || f.name == "Trampoline") continue
        roundRectOutlined(f.rect.topLeft, f.rect.size, 14f, f.color)
        if (f.emoji.isNotEmpty()) {
            paints.emoji.alpha = 255
            paints.emoji.textSize = min(f.rect.width, f.rect.height) * 0.6f
            nc.drawText(f.emoji, f.rect.center.x, f.rect.center.y + paints.emoji.textSize * 0.35f, paints.emoji)
        }
    }

    for (w in World.walls) roundRectOutlined(w.topLeft, w.size, 8f, Color(0xFFE9B8CB), 4f)
}

private fun DrawScope.drawParticle(q: Particle, paints: Paints) {
    val life = (1f - q.age / q.life).coerceIn(0f, 1f)
    if (q.kind == 0) {
        val nc = drawContext.canvas.nativeCanvas
        paints.emoji.textSize = 20f
        paints.emoji.alpha = (255 * life).toInt()
        nc.drawText("💗", q.x, q.y, paints.emoji)
        paints.emoji.alpha = 255
    } else if (q.kind == 2) {
        drawCircle(Color(0xFF7CC4FF).copy(alpha = life), 2.8f, Offset(q.x, q.y))
    } else {
        val c = q.color.copy(alpha = life)
        withTransform({ rotate(q.spin * q.age, Offset(q.x, q.y)) }) {
            drawRect(c, Offset(q.x - 4f, q.y - 2.5f), Size(8f, 5f))
        }
    }
}

private fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    drawLine(color, Offset(c.x - r, c.y), Offset(c.x + r, c.y), 2.5f, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y - r), Offset(c.x, c.y + r), 2.5f, StrokeCap.Round)
}

private fun wrapChat(text: String, paint: Paint, maxW: Float): List<String> {
    val lines = ArrayList<String>()
    var cur = ""
    for (w in text.split(" ").flatMap { it.chunked(18) }) {
        val trial = if (cur.isEmpty()) w else "$cur $w"
        if (cur.isEmpty() || paint.measureText(trial) <= maxW) cur = trial else { lines.add(cur); cur = w }
        if (lines.size >= 3) break
    }
    if (cur.isNotEmpty() && lines.size < 3) lines.add(cur)
    return lines
}

private fun DrawScope.drawPlayer(
    p: PlayerState, isMe: Boolean, near: Boolean, paints: Paints,
    px: Float, py: Float, carried: Boolean, speaking: Boolean
) {
    val nc = drawContext.canvas.nativeCanvas
    val t = p.animT
    val emote = p.emote
    val et = p.emoteT
    val happy = p.happiness
    val sad = happy < 30
    val joy = happy > 80

    val run = t * (if (joy) 17f else 14f)
    var bob = if (p.moving && !carried) abs(sin(run)) * 5f else sin(t * 2.5f) * 1.5f
    val step = if (p.moving && !carried) sin(run) * 5f else 0f

    // emote body animations
    var dx = 0f
    if (emote != null) {
        if (et < 0.4f) bob += abs(sin(et / 0.4f * PI.toFloat())) * 10f      // little hop for every emote
        when (emote) {
            Emote.DANCE -> { dx = sin(et * 10f) * 6f; bob += abs(sin(et * 10f)) * 6f }
            Emote.LAUGH, Emote.ANGRY -> dx = sin(et * 40f) * 1.5f
            else -> {}
        }
    }
    val x = px + dx
    val y = py - p.z + (if (p.sitT > 0f || p.seated || p.seesaw >= 0) 8f else 0f)

    val shirt = SHIRTS[p.colorIndex % 4]
    val hair = HAIRS[p.colorIndex % 4]
    val headY = y - 52f - bob

    // shadow + feet (not for carried: they sit on a back)
    if (!carried) {
        drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 17f, y - 6f + p.z), Size(34f, 12f))
        circleOutlined(Offset(x - 8f, y - 4f - max(0f, step)), 7f, Color.White)
        circleOutlined(Offset(x + 8f, y - 4f - max(0f, -step)), 7f, Color.White)
    } else {
        circleOutlined(Offset(x - 8f, y - 4f), 6f, Color.White)
        circleOutlined(Offset(x + 8f, y - 4f), 6f, Color.White)
    }

    // body + head
    roundRectOutlined(Offset(x - 14f, y - 32f - bob), Size(28f, 26f), 10f, shirt, 3f)
    circleOutlined(Offset(x, headY), 22f, SKIN)
    drawArc(hair, 180f, 180f, true, Offset(x - 23f, headY - 23f), Size(46f, 46f))
    drawArc(OUT, 180f, 180f, false, Offset(x - 23f, headY - 23f), Size(46f, 46f), style = Stroke(3f))

    // eyes
    val eyeY = headY + 4f
    if (emote == Emote.COOL) {
        roundRectOutlined(Offset(x - 17f, eyeY - 7f), Size(34f, 13f), 6f, Color(0xFF2F2A41), 2.5f)
    } else {
        for (sx in listOf(-9f, 9f)) {
            val cx = x + sx + 2f * p.facing
            val closed = p.blinkLeft > 0f || emote == Emote.LAUGH || emote == Emote.SLEEPY
            if (closed) {
                drawLine(OUT, Offset(cx - 5f, eyeY), Offset(cx + 5f, eyeY), 3f, StrokeCap.Round)
            } else {
                val big = if (emote == Emote.SURPRISE) 3f else 0f
                drawOval(OUT, Offset(cx - 5f - big / 2f, eyeY - 7f - big), Size(10f + big, 14f + big))
                drawCircle(Color.White, 2.2f, Offset(cx - 1f, eyeY - 3f))
            }
            if (emote == Emote.ANGRY) {
                val s = if (sx < 0) 1f else -1f
                drawLine(OUT, Offset(cx - 6f * s, eyeY - 13f), Offset(cx + 5f * s, eyeY - 8f), 3f, StrokeCap.Round)
            }
            if (emote == Emote.CRY) {
                val ty = eyeY + 6f + (et * 40f) % 22f
                drawCircle(Color(0xFF7CC4FF), 3f, Offset(cx, ty))
            }
        }
    }

    // cheeks: blush near friends, red when angry, green when sick
    val cheek = when {
        emote == Emote.ANGRY -> Color(0xFFFF4D4D).copy(alpha = 0.6f)
        emote == Emote.SICK -> Color(0xFF8FD18F).copy(alpha = 0.8f)
        near -> Color(0xFFFF7FA5).copy(alpha = 0.65f)
        else -> null
    }
    if (cheek != null) {
        drawCircle(cheek, 6f, Offset(x - 15f, eyeY + 9f))
        drawCircle(cheek, 6f, Offset(x + 15f, eyeY + 9f))
    }

    // mouth: sad frown, surprised O, happy smile
    when {
        emote == Emote.SURPRISE -> circleOutlined(Offset(x, eyeY + 10f), 3.5f, Color.White, 2f)
        sad || emote == Emote.CRY || emote == Emote.SICK ->
            drawArc(OUT, 200f, 140f, false, Offset(x - 5f, eyeY + 8f), Size(10f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))
        else ->
            drawArc(OUT, 20f, 140f, false, Offset(x - 5f, eyeY + 4f), Size(10f, 8f), style = Stroke(if (joy) 3.5f else 2.5f, cap = StrokeCap.Round))
    }

    // wave hand
    if (emote == Emote.WAVE) {
        val hx = x + 24f
        val hy = headY + 6f + sin(et * 14f) * 7f
        drawLine(OUT, Offset(x + 14f, y - 26f - bob), Offset(hx, hy), 5f, StrokeCap.Round)
        circleOutlined(Offset(hx, hy), 6f, SKIN, 2.5f)
    }
    // tool in hand (watering can, seeds, basket)
    val tool = p.tool
    if (tool != null) {
        paints.emoji.textSize = 22f
        paints.emoji.alpha = 255
        nc.drawText(tool, x + 26f * p.facing, headY + 24f - bob, paints.emoji)
    }
    // sleepy Zz
    if (emote == Emote.SLEEPY) {
        nc.drawText("Z", x + 24f, headY - 8f - (et * 14f) % 18f, paints.nameFill)
        nc.drawText("z", x + 34f, headY - 18f - (et * 14f) % 18f, paints.nameFill)
    }

    // name
    val nameY = headY - 30f
    nc.drawText(p.name, x, nameY, paints.nameStroke)
    nc.drawText(p.name, x, nameY, paints.nameFill)
    if (isMe) drawCircle(Cozy.Pink, 4f, Offset(x, nameY - 20f))
    if (p.combo >= 2) nc.drawText("x${p.combo}", x + 32f, headY, paints.nameFill)
    if (speaking) {
        paints.emoji.textSize = 15f
        paints.emoji.alpha = 255
        nc.drawText("🔊", x + paints.nameFill.measureText(p.name) / 2f + 14f, nameY, paints.emoji)
    }

    // happy sparkles
    if (joy) {
        for (i in 0..2) {
            val a = t * 2f + i * 2.1f
            val tw = 0.5f + 0.5f * sin(t * 6f + i)
            sparkle(Offset(x + cos(a) * 32f, headY + sin(a) * 20f), 3f + 3f * tw, Color(0xFFFFC93C).copy(alpha = 0.6f + 0.4f * tw))
        }
    }
    // sad rain cloud + rain
    if (sad) {
        val cy = headY - 58f
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(OUT, r + 2.5f, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(Color(0xFFC5CFE0), r, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for (i in 0..2) {
            val ry = (t * 60f + i * 13f) % 24f
            drawLine(Color(0xFF7CC4FF), Offset(x - 10f + i * 10f, cy + 12f + ry), Offset(x - 10f + i * 10f, cy + 17f + ry), 2f, StrokeCap.Round)
        }
    }

    // chat bubble (5 seconds, fades out)
    val chat = p.chat
    if (chat != null) {
        val lines = wrapChat(chat, paints.chat, 150f)
        val w = (lines.maxOfOrNull { paints.chat.measureText(it) } ?: 0f) + 18f
        val h = lines.size * 17f + 10f
        val a = if (p.chatT > 4.5f) ((5f - p.chatT) / 0.5f).coerceIn(0f, 1f) else 1f
        val bottom = headY - 100f
        val top = bottom - h
        roundRectOutlined(Offset(x - w / 2f, top), Size(w, h), 12f, Color.White.copy(alpha = a), 3f)
        val tail = Path().apply { moveTo(x - 6f, bottom - 1f); lineTo(x + 6f, bottom - 1f); lineTo(x, bottom + 8f); close() }
        drawPath(tail, Color.White.copy(alpha = a))
        drawLine(OUT.copy(alpha = a), Offset(x - 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        drawLine(OUT.copy(alpha = a), Offset(x + 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        paints.chat.alpha = (255 * a).toInt()
        lines.forEachIndexed { i, l -> nc.drawText(l, x, top + 18f + i * 17f, paints.chat) }
        paints.chat.alpha = 255
    }

    // emote bubble (pops in, floats, fades out)
    if (emote != null) {
        val pop = if (et < 0.2f) 0.4f + (et / 0.2f) * 0.8f else if (et < 0.3f) 1.2f - (et - 0.2f) * 2f else 1f
        val alpha = if (et > 2.1f) ((2.5f - et) / 0.4f).coerceIn(0f, 1f) else 1f
        val bx = x
        val by = headY - 78f - min(et, 1f) * 6f
        withTransform({ scale(pop, pop, Offset(bx, by)) }) {
            roundRectOutlined(Offset(bx - 20f, by - 18f), Size(40f, 34f), 14f, Color.White.copy(alpha = alpha), 3f)
            paints.emoji.textSize = 24f
            paints.emoji.alpha = (255 * alpha).toInt()
            nc.drawText(emote.emoji, bx, by + 8f, paints.emoji)
            paints.emoji.alpha = 255
        }
    }
}

// ------------------------------------------------------------------ farm + garden drawing

private fun DrawScope.drawPlot(f: Furniture, farm: FarmManager, paints: Paints, time: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val pl = farm.plots[f.name.removePrefix("Plot ").toInt() - 1]
    val wet = pl.wetMs > 0f
    roundRectOutlined(f.rect.topLeft, f.rect.size, 12f, if (wet) Color(0xFF7A5238) else Color(0xFFD2A679))   // dark = watered, light = dry
    if (pl.crop < 0) return

    val c = Crop.values()[pl.crop]
    val ready = pl.ready()
    val cx = f.rect.center.x
    val cy = f.rect.center.y
    val (emoji, size) = when {
        ready -> c.emoji to 46f                                  // Full
        pl.growMs / FarmManager.GROW_MS >= 0.5f -> "🌿" to 34f   // Small
        else -> "🌱" to 24f                                      // Sprout
    }
    if (ready && pl.crop == Crop.SUNFLOWER.ordinal) drawCircle(Color(0xFFFFE066).copy(alpha = 0.35f), 36f, Offset(cx, cy))
    paints.emoji.alpha = 255
    paints.emoji.textSize = size
    nc.drawText(emoji, cx, cy + size * 0.35f - (if (ready) 4f else 0f), paints.emoji)

    if (ready) {
        for (i in 0..2) {
            val a = time * 2.5f + i * 2.1f
            val tw = 0.5f + 0.5f * sin(time * 7f + i)
            sparkle(Offset(cx + cos(a) * 26f, cy - 6f + sin(a) * 18f), 3f + 3f * tw, Color(0xFFFFC93C).copy(alpha = 0.6f + 0.4f * tw))
        }
    } else if (!wet) {
        paints.emoji.textSize = 16f
        nc.drawText("💧", cx + 24f, f.rect.top - 4f + sin(time * 4f) * 3f, paints.emoji)   // "water me"
    }
}

private fun DrawScope.drawScarecrow(cx: Float, top: Float, time: Float) {
    val wood = Color(0xFFB07A4F)
    val straw = Color(0xFFF2D16B)
    roundRectOutlined(Offset(cx - 3f, top + 14f), Size(6f, 50f), 3f, wood, 3f)                 // pole
    roundRectOutlined(Offset(cx - 28f, top + 26f), Size(56f, 7f), 3f, wood, 3f)                // cross bar
    val wave = sin(time * 4f) * 9f
    drawLine(OUT, Offset(cx + 24f, top + 29f), Offset(cx + 34f, top + 14f + wave), 5f, StrokeCap.Round) // waving arm
    circleOutlined(Offset(cx + 34f, top + 12f + wave), 5f, straw, 2.5f)
    circleOutlined(Offset(cx, top + 10f), 11f, straw)                                          // head
    drawCircle(OUT, 1.8f, Offset(cx - 4f, top + 9f)); drawCircle(OUT, 1.8f, Offset(cx + 4f, top + 9f))
    drawArc(OUT, 20f, 140f, false, Offset(cx - 4f, top + 10f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
    roundRectOutlined(Offset(cx - 15f, top - 1f), Size(30f, 5f), 2f, Color(0xFFE9B44C), 2.5f)  // hat brim
    roundRectOutlined(Offset(cx - 8f, top - 13f), Size(16f, 13f), 4f, Color(0xFFE9B44C), 2.5f) // hat top
}

private fun DrawScope.drawCritters(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    for (c in pm.critters) {
        val t = c.phase
        paints.emoji.alpha = 255
        when (c.kind) {
            0 -> {   // butterfly: wings flap
                paints.emoji.textSize = 22f
                val sx = 0.55f + 0.45f * abs(sin(t * 14f))
                withTransform({ scale(sx, 1f, Offset(c.x, c.y)) }) { nc.drawText("🦋", c.x, c.y + sin(t * 3f) * 4f, paints.emoji) }
            }
            1 -> {   // bee: fast buzz
                paints.emoji.textSize = 17f
                nc.drawText("🐝", c.x + sin(t * 30f) * 1.5f, c.y + cos(t * 22f) * 2f, paints.emoji)
            }
            else -> {   // bird
                drawOval(Color.Black.copy(alpha = 0.12f), Offset(c.x - 8f, c.y + 2f), Size(16f, 6f))
                paints.emoji.textSize = 20f
                nc.drawText("🐦", c.x, c.y - (if (c.wait > 0f) abs(sin(t * 8f)) * 3f else 0f), paints.emoji)
            }
        }
    }
}

private fun DrawScope.drawWeather(pm: PlayerManager, camX: Float, camY: Float, viewW: Float, viewH: Float) {
    val me = pm.me
    val outdoors = me == null || me.area == Area.GARDEN || me.area == Area.PLAYGROUND
    if (!outdoors) return
    when (pm.farm.weather) {
        Weather.SUNNY -> {}
        Weather.CLOUDY -> drawRect(Color(0x143A4B63), Offset(camX, camY), Size(viewW, viewH))
        Weather.RAINY -> {
            drawRect(Color(0x223A4B63), Offset(camX, camY), Size(viewW, viewH))
            val rain = Color(0xAA7CC4FF)
            for (i in 0 until 70) {
                val fx = (i * 0.6180339f) % 1f
                val x = camX + fx * viewW
                val y = camY + (pm.time * 420f + i * 57f) % viewH
                drawLine(rain, Offset(x, y), Offset(x - 4f, y + 14f), 2f, StrokeCap.Round)
            }
        }
    }
}

// ------------------------------------------------------------------ kitchen panels

@Composable
private fun RecipePanel(pm: PlayerManager) {
    val k = pm.kitchen
    Column(
        Modifier.width(400.dp).heightIn(max = 300.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📖 Recipe Book  (${k.cooks} dishes cooked)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            KitchenManager.RECIPES.forEachIndexed { i, r ->
                Row(
                    Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!k.isUnlocked(i)) {
                        Text("🔒 ???  cook ${k.cooksToUnlock(i)} more dishes to unlock", fontSize = 12.sp, color = OUT)
                    } else {
                        Column(Modifier.weight(1f)) {
                            Text("${r.emoji} ${r.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                r.needs.forEach {
                                    Text("${it.emoji}×${k.have(it)}", fontSize = 12.sp,
                                        color = if (k.have(it) > 0) OUT else Color(0xFFB3261E))
                                }
                            }
                        }
                        if (k.canCook(i)) Pill("COOK") { pm.cook(i) }
                        else Text("need more", fontSize = 11.sp, color = Color(0xFFB3261E))
                    }
                }
            }
        }
    }
}

@Composable
private fun FridgePanel(pm: PlayerManager) {
    val k = pm.kitchen
    Column(
        Modifier.width(360.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🧊 Fridge (shared)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Ing.values().toList().chunked(5).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { ing ->
                    Column(
                        Modifier.width(60.dp).background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(ing.emoji, fontSize = 22.sp)
                        Text("×${k.have(ing)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                        Text(ing.label, fontSize = 9.sp, color = OUT)
                    }
                }
            }
        }
        Text("Crops come from the garden. Buy more ingredients at Fresh Mart in Town (coming soon).", fontSize = 11.sp, color = OUT)
    }
}

// ------------------------------------------------------------------ kitchen world effects

private fun DrawScope.drawKitchenFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val k = pm.kitchen
    val t = pm.time
    val stove = KitchenManager.STOVE
    val cx = stove.center.x
    val cy = stove.center.y

    // ---- pot on the stove
    if (k.phase != 0) {
        roundRectOutlined(Offset(cx - 22f, cy - 14f), Size(44f, 28f), 8f, if (k.phase == 3) Color(0xFF3B3B3B) else Color(0xFF9AA5B8), 3f)
        drawLine(OUT, Offset(cx - 28f, cy - 8f), Offset(cx - 22f, cy - 8f), 4f, StrokeCap.Round)
        drawLine(OUT, Offset(cx + 22f, cy - 8f), Offset(cx + 28f, cy - 8f), 4f, StrokeCap.Round)
    }
    when (k.phase) {
        1 -> {   // bubbling + steam + progress
            for (i in 0..2) {
                val b = (t * 1.6f + i * 0.37f) % 1f
                drawCircle(Color.White.copy(alpha = 0.85f * (1f - b)), 3f + 3f * b, Offset(cx - 10f + i * 10f, cy - 6f - b * 14f))
                val s = (t * 0.8f + i * 0.33f) % 1f
                drawCircle(Color.White.copy(alpha = 0.55f * (1f - s)), 6f + 8f * s, Offset(cx - 8f + i * 8f + sin(t * 3f + i) * 3f, cy - 22f - s * 40f))
            }
            val frac = (k.t / KitchenManager.COOK_S).coerceIn(0f, 1f)
            drawRoundRect(Color.White, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f))
            drawRoundRect(Color(0xFF7ED67E), Offset(cx - 25f, cy - 62f), Size(50f * frac, 8f), CornerRadius(4f))
            drawRoundRect(OUT, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f), style = Stroke(2f))
        }
        2 -> {   // ready! hurry before it burns
            val r = KitchenManager.RECIPES[k.recipe.coerceIn(0, KitchenManager.RECIPES.size - 1)]
            paints.emoji.alpha = 255
            paints.emoji.textSize = 28f
            nc.drawText(r.emoji, cx, cy - 30f - abs(sin(t * 4f)) * 6f, paints.emoji)
            sparkle(Offset(cx + 22f, cy - 44f), 4f + 3f * abs(sin(t * 6f)), Color(0xFFFFC93C))
            val left = (1f - k.t / KitchenManager.BURN_S).coerceIn(0f, 1f)
            val bar = if (left > 0.4f) Color(0xFFFFD86B) else Color(0xFFFF6B6B)
            drawRoundRect(Color.White, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f))
            drawRoundRect(bar, Offset(cx - 25f, cy - 62f), Size(50f * left, 8f), CornerRadius(4f))
            drawRoundRect(OUT, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f), style = Stroke(2f))
        }
        3 -> {   // burnt: black smoke + funny face
            for (i in 0..4) {
                val s = (t * 0.7f + i * 0.2f) % 1f
                drawCircle(Color(0xFF2B2B2B).copy(alpha = 0.6f * (1f - s)), 8f + 14f * s, Offset(cx + sin(t * 2f + i) * 8f, cy - 18f - s * 60f))
            }
            paints.emoji.alpha = 255
            paints.emoji.textSize = 28f
            nc.drawText("🤪", cx, cy - 26f, paints.emoji)
        }
    }

    // ---- plates on the table
    val table = KitchenManager.TABLE
    val slots = listOf(
        Offset(table.left + 45f, table.top + 40f), Offset(table.right - 45f, table.top + 40f),
        Offset(table.left + 45f, table.bottom - 36f), Offset(table.right - 45f, table.bottom - 36f),
    )
    k.plates.forEachIndexed { i, rIdx ->
        if (i < slots.size) {
            circleOutlined(slots[i], 20f, Color.White, 3f)
            paints.emoji.alpha = 255
            paints.emoji.textSize = 26f
            nc.drawText(KitchenManager.RECIPES[rIdx.coerceIn(0, KitchenManager.RECIPES.size - 1)].emoji, slots[i].x, slots[i].y + 9f, paints.emoji)
        }
    }

    // ---- dirty dishes at the sink (flies when it piles up)
    val sink = KitchenManager.SINK
    val px = sink.center.x
    val py = sink.bottom + 22f
    for (i in 0 until minOf(k.dirty, 5)) {
        paints.emoji.alpha = 255
        paints.emoji.textSize = 22f
        nc.drawText("🍽️", px, py - i * 7f, paints.emoji)
    }
    if (k.dirty >= 4) {
        for (i in 0..2) {
            val a = t * 4f + i * 2.1f
            val fx = px + cos(a) * 28f
            val fy = py - 14f + sin(a * 1.3f) * 16f
            drawCircle(OUT, 2.4f, Offset(fx, fy))
            drawCircle(Color.White.copy(alpha = 0.7f), 2f, Offset(fx - 2f, fy - 2.5f))
        }
    }

    // ---- fridge opens: ingredients bounce out
    if (pm.fridgeOpenT > 0f) {
        val f = KitchenManager.FRIDGE
        drawRoundRect(Color(0xFFBFE9FF), Offset(f.left - 14f, f.top + 6f), Size(14f, f.height - 12f), CornerRadius(4f))
        drawRoundRect(OUT, Offset(f.left - 14f, f.top + 6f), Size(14f, f.height - 12f), CornerRadius(4f), style = Stroke(3f))
        val items = listOf("🥛", "🥚", "🧀")
        items.forEachIndexed { i, e ->
            paints.emoji.alpha = 255
            paints.emoji.textSize = 20f
            nc.drawText(e, f.center.x + (i - 1) * 24f, f.bottom + 26f - abs(sin(t * 9f + i)) * 16f, paints.emoji)
        }
    }
}

// ------------------------------------------------------------------ living room, bedroom, bathroom

private val DREAMS = listOf("🌈", "🍰", "🦄", "🐶", "☁️", "🎠")

@Composable
private fun TeethPanel(pm: PlayerManager) {
    var progress by remember { mutableStateOf(0f) }
    var brushX by remember { mutableStateOf(0.5f) }
    Column(
        Modifier.width(340.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🪥 Swipe left and right to brush!", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Box(
            Modifier.fillMaxWidth().height(120.dp).pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    brushX = (change.position.x / size.width).coerceIn(0f, 1f)
                    progress = min(1f, progress + abs(drag.x) / 2600f)
                    if (progress >= 1f) pm.finishBrush()
                }
            }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawRoundRect(Color(0xFFFFB3C6), Offset(0f, h * 0.15f), Size(w, h * 0.7f), CornerRadius(h * 0.35f))
                drawRoundRect(OUT, Offset(0f, h * 0.15f), Size(w, h * 0.7f), CornerRadius(h * 0.35f), style = Stroke(5f))
                val tw = w / 7.8f
                for (i in 0..5) {
                    val x = w * 0.07f + i * (tw + w * 0.02f)
                    drawRoundRect(Color.White, Offset(x, h * 0.25f), Size(tw, h * 0.5f), CornerRadius(16f))
                    drawRoundRect(OUT, Offset(x, h * 0.25f), Size(tw, h * 0.5f), CornerRadius(16f), style = Stroke(3f))
                    drawCircle(Color(0xFFD9B26F).copy(alpha = (1f - progress).coerceIn(0f, 1f)), 7f, Offset(x + tw / 2f, h * 0.42f + (i % 2) * 18f))
                    if (progress > 0.85f) sparkle(Offset(x + tw * 0.75f, h * 0.3f), 6f, Color(0xFFFFC93C))
                }
                for (i in 0..5) {   // foam
                    drawCircle(Color.White.copy(alpha = 0.85f), 5f + i % 3 * 2f, Offset(brushX * w + (i - 3) * 9f, h * 0.5f + (i % 2) * 14f - 7f))
                }
                drawRoundRect(Color(0xFF8EC9FF), Offset(brushX * w - 9f, h * 0.02f), Size(18f, h * 0.5f), CornerRadius(8f))
                drawRoundRect(OUT, Offset(brushX * w - 9f, h * 0.02f), Size(18f, h * 0.5f), CornerRadius(8f), style = Stroke(3f))
            }
        }
        Box(Modifier.fillMaxWidth().height(12.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(6.dp)).border(2.dp, OUT, RoundedCornerShape(6.dp))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).background(Cozy.Mint, RoundedCornerShape(6.dp)))
        }
    }
}

private fun DrawScope.drawRoomFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time

    // ---- TV: 3 cartoon channels (+ static while changing, black when off)
    val tv = World.furniture.first { it.name == "TV" }.rect
    drawRoundRect(Color(0xFF2B2B3A), Offset(tv.left + 6f, tv.top + 4f), Size(tv.width - 12f, tv.height - 8f), CornerRadius(8f))
    val sx = tv.left + 12f; val sy = tv.top + 10f; val sw = tv.width - 24f; val sh = tv.height - 20f
    when {
        pm.tv == 3 -> drawRoundRect(Color(0xFF1A1A24), Offset(sx, sy), Size(sw, sh), CornerRadius(6f))
        pm.tvStatic > 0f -> for (i in 0 until 12) {
            val g = (sin(t * 50f + i * 7.3f) + 1f) / 2f
            drawRect(Color(g, g, g), Offset(sx, sy + i * sh / 12f), Size(sw, sh / 12f))
        }
        pm.tv == 0 -> {   // bouncing ball
            drawRect(Color(0xFFBDE0FE), Offset(sx, sy), Size(sw, sh))
            val u = (t * 0.5f) % 2f
            val fx = if (u < 1f) u else 2f - u
            circleOutlined(Offset(sx + 10f + fx * (sw - 20f), sy + sh - 12f - abs(sin(t * 4f)) * (sh - 24f)), 8f, Color(0xFFFF6B6B), 2f)
        }
        pm.tv == 1 -> {   // sunny sky with clouds
            drawRect(Color(0xFFFFF1A8), Offset(sx, sy), Size(sw, sh))
            circleOutlined(Offset(sx + sw * 0.25f, sy + sh * 0.45f), 10f, Color(0xFFFFA94D), 2f)
            for (i in 0..1) {
                val cx = sx + 8f + ((t * 22f + i * sw / 2f) % (sw - 16f))
                drawCircle(Color.White, 7f, Offset(cx, sy + sh * 0.3f + i * 14f))
                drawCircle(Color.White, 5f, Offset(cx + 7f, sy + sh * 0.3f + i * 14f + 2f))
            }
        }
        else -> {         // dancing bars
            drawRect(Color(0xFF3A2D6B), Offset(sx, sy), Size(sw, sh))
            val cols = listOf(Color(0xFFFF9EC4), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFF8EC9FF))
            val bw = (sw - 16f) / 8f
            for (i in 0..7) {
                val bh = (0.3f + 0.7f * abs(sin(t * 3f + i))) * (sh - 8f)
                drawRect(cols[i % 4], Offset(sx + 8f + i * bw, sy + sh - 4f - bh), Size(bw - 2f, bh))
            }
        }
    }

    // ---- fireplace flicker
    val fp = World.furniture.first { it.name == "Fireplace" }.rect
    for (i in 0..2) {
        val fx = fp.center.x - 20f + i * 20f
        val fh = 16f + 9f * abs(sin(t * 9f + i * 2f))
        drawCircle(Color(0xFFFF8A3D), 9f, Offset(fx, fp.bottom - 16f - fh / 2f))
        drawCircle(Color(0xFFFFD86B), 5f, Offset(fx, fp.bottom - 14f - fh / 3f))
        val sp = (t * 1.5f + i * 0.33f) % 1f
        drawCircle(Color(0xFFFFD86B).copy(alpha = 1f - sp), 2f, Offset(fx + sin(t * 4f + i) * 6f, fp.bottom - 24f - sp * 30f))
    }

    // ---- sleeping cat on the rug (wags its tail when petted)
    val cat = World.furniture.first { it.name == "Cat" }.rect
    val cx = cat.center.x
    val cy = cat.center.y
    val wag = pm.catWagT > 0f
    val a = if (wag) sin(t * 14f) * 0.6f else sin(t * 1.5f) * 0.08f
    drawLine(OUT, Offset(cx - 26f, cy + 2f), Offset(cx - 26f - 22f * cos(a), cy - 8f - 22f * sin(a)), 9f, StrokeCap.Round)
    drawLine(Color(0xFFF4B26B), Offset(cx - 26f, cy + 2f), Offset(cx - 26f - 22f * cos(a), cy - 8f - 22f * sin(a)), 5f, StrokeCap.Round)
    drawOval(OUT, Offset(cx - 30f, cy - 19f), Size(60f, 38f))
    drawOval(Color(0xFFF4B26B), Offset(cx - 28f, cy - 17f), Size(56f, 34f))
    drawLine(Color(0xFFD98B3A), Offset(cx - 8f, cy - 15f), Offset(cx - 8f, cy - 4f), 3f, StrokeCap.Round)
    drawLine(Color(0xFFD98B3A), Offset(cx + 2f, cy - 16f), Offset(cx + 2f, cy - 5f), 3f, StrokeCap.Round)
    circleOutlined(Offset(cx + 24f, cy - 2f), 14f, Color(0xFFF4B26B), 3f)
    val ear = Path().apply { moveTo(cx + 12f, cy - 12f); lineTo(cx + 15f, cy - 26f); lineTo(cx + 22f, cy - 14f); close() }
    val ear2 = Path().apply { moveTo(cx + 28f, cy - 14f); lineTo(cx + 34f, cy - 26f); lineTo(cx + 37f, cy - 10f); close() }
    drawPath(ear, Color(0xFFF4B26B)); drawPath(ear2, Color(0xFFF4B26B))
    if (wag) {
        drawArc(OUT, 200f, 140f, false, Offset(cx + 15f, cy - 8f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
        drawArc(OUT, 200f, 140f, false, Offset(cx + 27f, cy - 8f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
    } else {
        drawLine(OUT, Offset(cx + 16f, cy - 5f), Offset(cx + 22f, cy - 5f), 2.5f, StrokeCap.Round)   // sleeping eyes
        drawLine(OUT, Offset(cx + 28f, cy - 5f), Offset(cx + 34f, cy - 5f), 2.5f, StrokeCap.Round)
        nc.drawText("z", cx + 38f, cy - 22f - (t * 10f) % 14f, paints.nameFill)
    }

    // ---- bathroom: mirror that fogs up after a shower, rubber duck in the tub
    val bm = World.furniture.first { it.name == "Bath Mirror" }.rect
    roundRectOutlined(bm.topLeft, bm.size, 10f, Color(0xFFE8F8FF), 4f)
    drawLine(Color.White, Offset(bm.left + 14f, bm.bottom - 6f), Offset(bm.left + 34f, bm.top + 6f), 4f, StrokeCap.Round)
    val fog = (pm.fogT / 5f).coerceIn(0f, 0.9f)
    if (fog > 0f) drawRoundRect(Color.White.copy(alpha = fog), bm.topLeft, bm.size, CornerRadius(10f))
    val tub = World.furniture.first { it.name == "Bathtub" }.rect
    paints.emoji.alpha = 255
    paints.emoji.textSize = 26f
    nc.drawText("🦆", tub.center.x + sin(t * 1.2f) * 30f, tub.center.y + 8f + sin(t * 2.4f) * 3f, paints.emoji)
}

private fun DrawScope.drawSleepFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time
    for (p in pm.players.values) {
        if (!p.sleeping) continue
        paints.emoji.alpha = 255
        paints.emoji.textSize = 20f
        nc.drawText("💤", p.x + 20f, p.y - 70f - (t * 14f) % 16f, paints.emoji)
        drawCircle(Color.White, 3f, Offset(p.x + 14f, p.y - 96f))
        drawCircle(Color.White, 5f, Offset(p.x + 22f, p.y - 108f))
        roundRectOutlined(Offset(p.x + 16f, p.y - 150f), Size(44f, 36f), 14f, Color.White, 3f)
        paints.emoji.textSize = 24f
        nc.drawText(DREAMS[(p.dream + (p.sleepT / 3f).toInt()) % DREAMS.size], p.x + 38f, p.y - 124f, paints.emoji)
    }
}

// ------------------------------------------------------------------ playground drawing

private fun DrawScope.drawPlayFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas

    // ---- trampoline
    val tr = World.furniture.first { it.name == "Trampoline" }.rect
    drawOval(OUT, Offset(tr.left - 3f, tr.top - 3f), Size(tr.width + 6f, tr.height + 6f))
    drawOval(Color(0xFFFF9EC4), Offset(tr.left, tr.top), Size(tr.width, tr.height))
    drawOval(Color(0xFF8EC9FF), Offset(tr.left + 14f, tr.top + 12f), Size(tr.width - 28f, tr.height - 24f))
    drawOval(OUT, Offset(tr.left + 14f, tr.top + 12f), Size(tr.width - 28f, tr.height - 24f), style = Stroke(3f))

    // ---- swing frame + chains (chains follow whoever is swinging)
    for (xs in listOf(1905f, 2095f)) {
        drawLine(OUT, Offset(xs, 740f), Offset(xs - 16f, 905f), 6f, StrokeCap.Round)
        drawLine(OUT, Offset(xs, 740f), Offset(xs + 16f, 905f), 6f, StrokeCap.Round)
    }
    roundRectOutlined(Offset(1895f, 734f), Size(210f, 14f), 6f, Color(0xFFB07A4F), 3f)
    for (s in 0..1) {
        val ax = PlayerManager.SWING_X[s]
        val occ = pm.players.values.firstOrNull { it.swing == s }
        val th = occ?.let {
            if (it.id == pm.myId) it.swingAng else asin(((it.x - ax) / PlayerManager.SWING_L).coerceIn(-1f, 1f))
        } ?: 0f
        val sx = ax + PlayerManager.SWING_L * sin(th)
        val sy = PlayerManager.SWING_Y + PlayerManager.SWING_L * cos(th)
        drawLine(OUT, Offset(ax - 8f, PlayerManager.SWING_Y), Offset(sx - 8f, sy), 2.5f)
        drawLine(OUT, Offset(ax + 8f, PlayerManager.SWING_Y), Offset(sx + 8f, sy), 2.5f)
        roundRectOutlined(Offset(sx - 14f, sy - 2f), Size(28f, 7f), 3f, Color(0xFFFFD86B), 2.5f)
    }

    // ---- seesaw: the plank follows the riders
    val l = pm.players.values.firstOrNull { it.seesaw == 0 }
    val r = pm.players.values.firstOrNull { it.seesaw == 1 }
    val base = PlayerManager.SEE_Y
    val yL = l?.y ?: if (r != null) base - PlayerManager.SEE_A else base
    val yR = r?.y ?: if (l != null) base - PlayerManager.SEE_A else base
    val a = Offset(PlayerManager.SEE_X[0] - 30f, yL + 12f)
    val b = Offset(PlayerManager.SEE_X[1] + 30f, yR + 12f)
    drawLine(OUT, a, b, 17f, StrokeCap.Round)
    drawLine(Color(0xFFFFB38A), a, b, 11f, StrokeCap.Round)
    val pivot = Path().apply { moveTo(2018f, 1102f); lineTo(2062f, 1102f); lineTo(2040f, 1062f); close() }
    drawPath(pivot, Color(0xFFFFD86B))
    drawPath(pivot, OUT, style = Stroke(3f))
    if ((l == null) != (r == null)) {
        val lone = l ?: r!!
        nc.drawText("needs a friend!", lone.x, lone.y - 86f, paints.nameFill)
    }
}
