package com.cozy.house.game

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import com.cozy.house.net.Area
import kotlin.math.max

data class Furniture(
    val name: String,
    val rect: Rect,
    val color: Color,
    val emoji: String,
    val solid: Boolean = true,
    val interactive: Boolean = true,
)

private fun r(l: Int, t: Int, rt: Int, b: Int) = Rect(l.toFloat(), t.toFloat(), rt.toFloat(), b.toFloat())

/**
 * ONE big map, no loading. Door gaps are 120 wide (player is 36 wide).
 *
 *   BEDROOM    | LIVING ROOM | KITCHEN        y 0..640   (indoor)
 *   BATHROOM   | GARDEN      | PLAYGROUND     y 640..1280
 *   0..800       800..1600     1600..2400
 *
 * Part 7 adds the Town east of the playground / through the garden gate.
 */
object World {
    const val W = 2400f
    const val H = 1280f
    const val PLAYER_R = 18f

    val rooms: Map<Area, Rect> = linkedMapOf(
        Area.BEDROOM to r(0, 0, 800, 640),
        Area.LIVING_ROOM to r(800, 0, 1600, 640),
        Area.KITCHEN to r(1600, 0, 2400, 640),
        Area.BATHROOM to r(0, 640, 800, 1280),
        Area.GARDEN to r(800, 640, 1600, 1280),
        Area.PLAYGROUND to r(1600, 640, 2400, 1280),
    )

    val walls: List<Rect> = listOf(
        // outer
        r(0, 0, 2400, 24), r(0, 1256, 2400, 1280), r(0, 0, 24, 1280), r(2376, 0, 2400, 1280),
        // bedroom | living (door y 260..380)
        r(788, 0, 812, 260), r(788, 380, 812, 640),
        // living | kitchen (door y 260..380)
        r(1588, 0, 1612, 260), r(1588, 380, 1612, 640),
        // bedroom -> bathroom (door x 340..460)
        r(0, 628, 340, 652), r(460, 628, 800, 652),
        // living -> garden (door x 1140..1260)
        r(800, 628, 1140, 652), r(1260, 628, 1600, 652),
        // kitchen -> playground back door (x 1940..2060)
        r(1600, 628, 1940, 652), r(2060, 628, 2400, 652),
        // bathroom | garden (solid)
        r(788, 640, 812, 1280),
    )

    val furniture: List<Furniture> = buildList {
        // Bedroom
        add(Furniture("Bed", r(60, 60, 260, 200), Color(0xFFFFB3D1), "🛏️"))
        add(Furniture("Bed 2", r(300, 60, 500, 200), Color(0xFFBDE0FE), "🛏️"))
        add(Furniture("Mirror", r(560, 40, 640, 110), Color(0xFFE6F4FF), "🪞"))
        add(Furniture("Wardrobe", r(690, 50, 770, 200), Color(0xFFD9C2F0), "🧥"))
        add(Furniture("Toy box", r(60, 500, 160, 580), Color(0xFFFFE08A), "🧸"))
        // Living room
        add(Furniture("Sofa", r(900, 430, 1100, 510), Color(0xFFFFC2D9), "🛋️"))
        add(Furniture("TV", r(1150, 50, 1350, 110), Color(0xFFBDE0FE), "📺"))
        add(Furniture("Fireplace", r(1450, 50, 1550, 130), Color(0xFFFFB38A), "🔥"))
        add(Furniture("Rug", r(1000, 200, 1400, 380), Color(0xFFFFD9E8), "", solid = false, interactive = false))
        add(Furniture("Cat", r(1190, 270, 1270, 330), Color.Transparent, "", solid = false))
        add(Furniture("Photo Wall", r(900, 40, 1100, 70), Color(0xFFFFF0F5), "🖼️", solid = false))
        // Kitchen
        add(Furniture("Fridge", r(1650, 50, 1730, 150), Color(0xFFD6F3FF), "🧊"))
        add(Furniture("Stove", r(1760, 50, 1860, 120), Color(0xFFE8E8F0), "🍳"))
        add(Furniture("Counter", r(1890, 50, 2200, 110), Color(0xFFFFE9C7), ""))
        add(Furniture("Kitchen Sink", r(2230, 50, 2340, 120), Color(0xFFD6EEFF), "🚰"))
        add(Furniture("Table", r(2000, 300, 2200, 440), Color(0xFFF3D9B1), "🍽️"))
        // Bathroom
        add(Furniture("Bathtub", r(50, 680, 250, 800), Color(0xFFCDEBFF), "🛁"))
        add(Furniture("Sink", r(600, 680, 740, 740), Color(0xFFE6F2FF), "🚰"))
        add(Furniture("Shower", r(60, 1040, 180, 1200), Color(0xFFD6EEFF), "🚿", solid = false))
        add(Furniture("Bath Mirror", r(330, 660, 450, 700), Color.Transparent, "", solid = false, interactive = false))
        // Garden: 8 plots (Part 3 makes them farmable)
        for (row in 0..1) for (col in 0..3) {
            val x = 860 + col * 100
            val y = 720 + row * 120
            add(Furniture("Plot ${row * 4 + col + 1}", r(x, y, x + 70, y + 70), Color(0xFFB98B6B), "", solid = false))
        }
        add(Furniture("Big tree", r(1450, 1000, 1560, 1110), Color(0xFF9ADFA0), "🌳"))
        add(Furniture("Scarecrow", r(1296, 1040, 1340, 1100), Color(0xFFE9C46A), ""))
        // Playground
        add(Furniture("Slide", r(1700, 760, 1800, 900), Color(0xFFFFD1A9), "🎢"))
        add(Furniture("Swing", r(1900, 740, 2100, 756), Color(0xFFB07A4F), ""))
        add(Furniture("Seesaw", r(2030, 1050, 2050, 1080), Color(0xFFFFD86B), ""))
        add(Furniture("Trampoline", r(1690, 1040, 1830, 1160), Color(0xFFFF9EC4), "", solid = false, interactive = false))
    }

    /** The 8 farm plots, in order (Plot 1..8). */
    val plots: List<Rect> = furniture.filter { it.name.startsWith("Plot ") }.map { it.rect }

    private val blockers: List<Rect> = walls + furniture.filter { it.solid }.map { it.rect }

    fun areaAt(x: Float, y: Float): Area =
        rooms.entries.firstOrNull { it.value.contains(Offset(x, y)) }?.key ?: Area.GARDEN

    /** Circle (player) vs every wall / solid furniture, plus the world edge. */
    fun blocked(x: Float, y: Float, radius: Float = PLAYER_R): Boolean {
        if (x < radius || y < radius || x > W - radius || y > H - radius) return true
        for (b in blockers) {
            val cx = x.coerceIn(b.left, b.right)
            val cy = y.coerceIn(b.top, b.bottom)
            val dx = x - cx
            val dy = y - cy
            if (dx * dx + dy * dy < radius * radius) return true
        }
        return false
    }

    fun distanceTo(rect: Rect, x: Float, y: Float): Float {
        val dx = max(max(rect.left - x, 0f), x - rect.right)
        val dy = max(max(rect.top - y, 0f), y - rect.bottom)
        return kotlin.math.sqrt(dx * dx + dy * dy)
    }

    /** Where player number [i] appears: living room, spread out. */
    fun spawn(i: Int): Offset = Offset(1000f + (i % 4) * 100f, 300f + (i / 4) * 80f)

    fun areaLabel(a: Area): String = when (a) {
        Area.LIVING_ROOM -> "Living Room"
        Area.KITCHEN -> "Kitchen"
        Area.BEDROOM -> "Bedroom"
        Area.GARDEN -> "Garden"
        Area.PLAYGROUND -> "Playground"
        Area.BATHROOM -> "Bathroom"
        Area.TOWN -> "Town"
    }
}

enum class Emote(val emoji: String, val label: String) {
    HAPPY("😊", "Happy"), LOVE("😍", "Love"), LAUGH("😂", "Laugh"), CRY("😭", "Cry"),
    ANGRY("😠", "Angry"), SLEEPY("😴", "Sleepy"), HUNGRY("🤤", "Hungry"), DANCE("💃", "Dance"),
    WAVE("👋", "Wave"), SURPRISE("😮", "Surprise"), SICK("🤢", "Sick"), COOL("😎", "Cool"),
}

/** Everything about one player that the world needs. Stats (energy, hunger...) come in the next group. */
class PlayerState(val id: String, var name: String, val colorIndex: Int) {
    var x = 0f
    var y = 0f
    // where the network says this player is (remote players glide toward it)
    var tx = 0f
    var ty = 0f
    var vx = 0f
    var vy = 0f
    // last position actually received (used to estimate speed)
    var rx = 0f
    var ry = 0f
    var facing = 1
    var moving = false
    var area: Area = Area.LIVING_ROOM

    var happiness = 100            // synced so everyone sees rain clouds / sparkles
    var emote: Emote? = null
    var emoteT = 0f
    var carriedBy: String? = null  // id of the player carrying me
    var carrying: String? = null   // id of the player I carry
    var chat: String? = null       // text bubble over the head
    var tool: String? = null       // emoji of the tool in my hand (watering can...)
    var toolT = 0f
    var sitT = 0f                  // sitting at the table while eating
    var sleeping = false
    var sleepT = 0f
    var dream = 0
    var seated = false             // on the sofa
    var busyT = 0f                 // locked in place (shower)
    var showerT = 0f
    var swing = -1                 // swing seat 0/1 or -1
    var swingAng = 0f
    var swingVel = 0f
    var seesaw = -1                // seesaw seat 0/1 or -1
    var slideT = 0f
    var z = 0f                     // height above ground (trampoline)
    var vz = 0f
    var combo = 0
    var comboT = 0f
    var chatT = 0f

    var seenMove = false
    var lastMoveMs = 0L

    // animation
    var animT = 0f
    var blinkTimer = 2f
    var blinkLeft = 0f
    var dustTimer = 0f
}
