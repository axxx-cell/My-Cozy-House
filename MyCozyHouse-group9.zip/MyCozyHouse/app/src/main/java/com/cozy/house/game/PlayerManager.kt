package com.cozy.house.game

import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import com.cozy.house.Session
import com.cozy.house.net.*
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.launch
import org.json.JSONObject
import kotlin.math.*

/** One adapter so the game does not care if this phone is the host or a client. */
class GameNet(private val host: LanHostManager?, private val client: LanClientManager?) {
    val myId: String
        get() = host?.players?.value?.firstOrNull { it.isHost }?.id ?: client?.myId ?: "p1"
    val isHost: Boolean get() = host != null
    val players: StateFlow<List<PlayerInfo>> = host?.players ?: client!!.players
    val events: SharedFlow<GameMessage> = host?.events ?: client!!.events

    fun send(m: GameMessage) {
        if (host != null) host.broadcast(m.copy(playerId = myId)) else client?.send(m)
    }

    companion object {
        fun current(): GameNet? =
            if (Session.host != null || Session.client != null) GameNet(Session.host, Session.client) else null
    }
}

class Dust(var x: Float, var y: Float, var age: Float = 0f)

/** kind 0 = heart, 1 = confetti */
class Particle(
    var x: Float, var y: Float, var vx: Float, var vy: Float,
    val life: Float, val kind: Int, val color: Color, var age: Float = 0f, val spin: Float = 0f,
)

class PlayerManager {
    val players = LinkedHashMap<String, PlayerState>()
    val dust = ArrayList<Dust>()
    val particles = ArrayList<Particle>()

    // ---- farm + garden life
    val farm = FarmManager()
    val kitchen = KitchenManager(farm)
    var panel by mutableStateOf<String?>(null)   // "FRIDGE" or "RECIPES"
    var fridgeOpenT = 0f
    private var sizzleAcc = 0f
    private val eatLog = ArrayList<Long>()
    val critters = ArrayList<Critter>()
    var time = 0f
    var camX = 0f
    var camY = 0f
    var viewScale = 1f
    private var farmSyncAcc = 0f
    private var rainAcc = 0f

    init {
        repeat(3) { critters.add(Critter(0, Critter.X0 + Math.random().toFloat() * 700f, Critter.Y0 + Math.random().toFloat() * 500f)) }
        repeat(2) { critters.add(Critter(1, 900f + Math.random().toFloat() * 300f, 720f + Math.random().toFloat() * 200f)) }
        repeat(2) { critters.add(Critter(2, Critter.X0 + Math.random().toFloat() * 700f, Critter.Y0 + Math.random().toFloat() * 500f)) }
    }

    var myId = ""
    var joyX = 0f
    var joyY = 0f

    // ---- stats (floats inside, ints for the UI so it only redraws when a number changes)
    private var energyF = 100f
    private var hungerF = 100f
    private var happyF = 100f
    var energy by mutableStateOf(100)
    var hunger by mutableStateOf(100)
    var happiness by mutableStateOf(100)
    var coins by mutableStateOf(0)

    // ---- UI state
    var areaName by mutableStateOf("")
    var toast by mutableStateOf<String?>(null)
    var nearbyFriend by mutableStateOf<String?>(null)
    var carryingId by mutableStateOf<String?>(null)
    var carriedById by mutableStateOf<String?>(null)

    // ---- chat
    val chatLog = mutableStateListOf<String>()
    var unread by mutableStateOf(0)
    @Volatile var rosterInfo: List<PlayerInfo> = emptyList()
    private var toastLeft = 0f

    private var net: GameNet? = null
    private var sendAcc = 0f
    private var keepAliveAcc = 0f
    private var wasMoving = false
    private var actionCd = 0f
    private var hungryNag = 0f

    val me: PlayerState? get() = players[myId]

    companion object {
        const val SPEED = 190f
        private val CONFETTI = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFFD9B3FF))
    }

    /** Mood decides speed: sad = slow, happy = fast, no energy = 20% slower (never blocked). */
    private fun mySpeed(): Float {
        var s = SPEED
        if (happyF > 80f) s *= 1.2f else if (happyF < 30f) s *= 0.7f
        if (energyF <= 0f) s *= 0.8f
        if (me?.carrying != null) s *= 0.85f
        return s
    }

    private fun addHappy(n: Float) { happyF = min(100f, happyF + n) }

    // ------------------------------------------------------------ network

    suspend fun runNetwork(n: GameNet) = coroutineScope {
        net = n
        myId = n.myId
        launch { n.players.collect { syncRoster(it) } }
        launch { n.events.collect { onMessage(it) } }
    }

    private fun syncRoster(list: List<PlayerInfo>) {
        rosterInfo = list
        list.forEachIndexed { i, info ->
            val existing = players[info.id]
            if (existing == null) {
                val num = info.id.filter { it.isDigit() }.toIntOrNull() ?: i
                val p = PlayerState(info.id, info.name, num % 4)
                val s = World.spawn(i)
                p.x = s.x; p.y = s.y; p.tx = s.x; p.ty = s.y
                p.area = World.areaAt(p.x, p.y)
                players[info.id] = p
            } else existing.name = info.name
        }
        players.keys.retainAll(list.map { it.id }.toSet())
        myId = net?.myId ?: myId
        for (p in players.values) {          // someone left while carrying / being carried
            if (p.carriedBy != null && players[p.carriedBy!!] == null) p.carriedBy = null
            if (p.carrying != null && players[p.carrying!!] == null) p.carrying = null
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun onMessage(m: GameMessage) {
        when (m.type) {
            MsgType.MOVE -> onMove(m)
            MsgType.CUSTOM -> onCustom(m)
            MsgType.CHAT -> onChat(m)
            else -> {}
        }
    }

    private fun onMove(m: GameMessage) {
        if (m.playerId == myId) return
        val p = players[m.playerId] ?: return
        val nx = m.data.optInt("x").toFloat()
        val ny = m.data.optInt("y").toFloat()
        val now = System.currentTimeMillis()

        if (!p.seenMove) {
            p.x = nx; p.y = ny; p.tx = nx; p.ty = ny
            p.seenMove = true
        } else {
            val dtMs = now - p.lastMoveMs
            if (dtMs in 20..500) {
                p.vx = (nx - p.rx) / dtMs * 1000f
                p.vy = (ny - p.ry) / dtMs * 1000f
            }
            val speed = hypot(p.vx, p.vy)
            val cap = if (speed > SPEED * 1.5f) SPEED * 1.5f / speed else 1f
            p.tx = nx + p.vx * cap * 0.07f
            p.ty = ny + p.vy * cap * 0.07f
        }
        p.rx = nx; p.ry = ny
        p.lastMoveMs = now
        p.facing = if (m.data.optInt("f", 1) >= 0) 1 else -1
        p.moving = m.data.optInt("m", 0) == 1
        p.happiness = m.data.optInt("hp", 100)
        runCatching { p.area = Area.valueOf(m.data.optString("area")) }
        if (!p.moving) { p.vx = 0f; p.vy = 0f }
    }

    private fun onCustom(m: GameMessage) {
        val sender = players[m.playerId]
        when (m.data.optString("kind")) {
            "EMOTE" -> {
                val e = Emote.values().firstOrNull { it.name == m.data.optString("emote") } ?: return
                sender?.emote = e; sender?.emoteT = 0f
                SoundFx.emote(e.ordinal)
            }
            "HUG", "HIGHFIVE" -> {
                val hug = m.data.optString("kind") == "HUG"
                val target = players[m.data.optString("target")]
                if (sender == null || target == null) return
                if (hug) { hearts(sender.x, sender.y - 60f); hearts(target.x, target.y - 60f); SoundFx.hug() }
                else { confetti((sender.x + target.x) / 2f, min(sender.y, target.y) - 50f); SoundFx.highFive() }
                if (target.id == myId) {
                    addHappy(if (hug) 10f else 5f)
                    if (hug) { target.emote = Emote.LOVE; target.emoteT = 0f }
                }
            }
            "KITCHEN_ACT" -> {
                val op = m.data.optString("op")
                if (sender != null) kitchenFx(sender, op)
                if (net?.isHost == true && kitchen.apply(op, m.data.optInt("arg"))) { broadcastKitchen(); broadcastFarm() }
            }
            "KITCHEN_STATE" -> if (net?.isHost != true) kitchen.load(m.data.optJSONObject("state") ?: return)
            "FARM_ACT" -> {
                val op = m.data.optString("op")
                val idx = m.data.optInt("plot")
                if (sender != null) farmFx(sender, op, idx)
                if (net?.isHost == true && farm.apply(op, idx, m.data.optInt("crop"))) broadcastFarm()
            }
            "FARM_STATE" -> if (net?.isHost != true) farm.load(m.data.optJSONObject("state") ?: return)
            "CARRY" -> applyCarry(m.data.optString("carrier"), m.data.optString("carried"), m.data.optInt("on") == 1)
        }
    }

    private fun applyCarry(carrierId: String, carriedId: String, on: Boolean) {
        val carrier = players[carrierId] ?: return
        val carried = players[carriedId] ?: return
        if (on) {
            carrier.carrying = carriedId; carried.carriedBy = carrierId
        } else {
            carrier.carrying = null; carried.carriedBy = null
            // put down next to the carrier
            carried.x = carrier.x + 34f * carrier.facing; carried.y = carrier.y
            if (World.blocked(carried.x, carried.y)) { carried.x = carrier.x; carried.y = carrier.y }
            carried.tx = carried.x; carried.ty = carried.y; carried.rx = carried.x; carried.ry = carried.y
        }
        carryingId = me?.carrying
        carriedById = me?.carriedBy
    }

    private fun onChat(m: GameMessage) {
        val p = players[m.playerId] ?: return
        val text = m.data.optString("text").trim().take(60)
        if (text.isEmpty()) return
        p.chat = text; p.chatT = 0f
        addLog("${p.name}: $text")
        unread += 1
        SoundFx.pop()
    }

    private fun addLog(line: String) {
        chatLog.add(line)
        while (chatLog.size > 30) chatLog.removeAt(0)
    }

    fun sendChat(raw: String) {
        val m = me ?: return
        val text = raw.trim().take(60)
        if (text.isEmpty()) return
        m.chat = text; m.chatT = 0f
        addLog("${m.name}: $text")
        net?.send(GameMessage.chat(myId, text))
    }

    /** Voice goes straight to every other player's phone. */
    fun peerIps(): List<String> = rosterInfo.filter { it.id != myId && it.ip.isNotBlank() }.map { it.ip }

    fun myNumber(): Int = myId.filter { it.isDigit() }.toIntOrNull() ?: 0

    private fun sendCustom(o: JSONObject) {
        net?.send(GameMessage(MsgType.CUSTOM, myId, o))
    }

    private fun sendMove(p: PlayerState) {
        net?.send(
            GameMessage(
                MsgType.MOVE, myId,
                JSONObject()
                    .put("x", p.x.roundToInt())
                    .put("y", p.y.roundToInt())
                    .put("area", p.area.name)
                    .put("f", p.facing)
                    .put("m", if (p.moving) 1 else 0)
                    .put("hp", happyF.roundToInt())
            )
        )
    }

    // ------------------------------------------------------------ per frame

    fun update(dt: Float) {
        val m = me
        if (m != null) {
            updateStats(m, dt)
            moveLocal(m, dt)
            updateNearby(m)
        }

        for (p in players.values) {
            if (p.id != myId) {
                val k = 1f - exp(-12f * dt)
                p.x += (p.tx - p.x) * k
                p.y += (p.ty - p.y) * k
                if (p.moving && p.carriedBy == null) spawnDust(p, dt, 0f, 0f)
            }
            p.animT += dt
            p.blinkTimer -= dt
            if (p.blinkTimer <= 0f) { p.blinkLeft = 0.12f; p.blinkTimer = 2.5f + Math.random().toFloat() * 3f }
            if (p.blinkLeft > 0f) p.blinkLeft -= dt
            if (p.emote != null) { p.emoteT += dt; if (p.emoteT > 2.5f) p.emote = null }
            if (p.chat != null) { p.chatT += dt; if (p.chatT > 5f) p.chat = null }
            if (p.tool != null) { p.toolT -= dt; if (p.toolT <= 0f) p.tool = null }
            if (p.sitT > 0f) p.sitT -= dt
        }

        // farm: same rules everywhere, host is the boss and syncs every 2 s
        time += dt
        val isHost = net?.isHost == true
        farm.tick(dt, isHost)
        kitchen.tick(dt)
        if (fridgeOpenT > 0f) fridgeOpenT -= dt
        if (kitchen.phase == 1 && me?.area == Area.KITCHEN) {      // sizzling
            sizzleAcc -= dt
            if (sizzleAcc <= 0f) { sizzleAcc = 1f; SoundFx.sizzle() }
        }
        if (isHost) {
            farmSyncAcc += dt
            if (farmSyncAcc >= 2f) { farmSyncAcc = 0f; broadcastFarm(); broadcastKitchen() }
        }
        val mx = m?.x ?: 0f
        val my = m?.y ?: 0f
        for (c in critters) c.update(dt, mx, my)
        if (farm.weather == Weather.RAINY) {           // splashes on the plots
            rainAcc -= dt
            if (rainAcc <= 0f) {
                rainAcc = 0.08f
                val r = World.plots[(Math.random() * World.plots.size).toInt()]
                particles.add(Particle(r.left + Math.random().toFloat() * r.width, r.top + Math.random().toFloat() * r.height,
                    (Math.random().toFloat() - 0.5f) * 30f, -60f, 0.5f, 2, Color.White))
            }
        }

        val di = dust.iterator()
        while (di.hasNext()) { val d = di.next(); d.age += dt; if (d.age > 0.5f) di.remove() }

        val pi = particles.iterator()
        while (pi.hasNext()) {
            val q = pi.next()
            q.age += dt
            q.x += q.vx * dt; q.y += q.vy * dt
            if (q.kind != 0) q.vy += 260f * dt
            if (q.age > q.life) pi.remove()
        }

        if (actionCd > 0f) actionCd -= dt
        if (toastLeft > 0f) { toastLeft -= dt; if (toastLeft <= 0f) toast = null }
    }

    private fun updateStats(m: PlayerState, dt: Float) {
        // slow and gentle: nothing ever blocks you
        happyF = max(0f, happyF - dt / 5f)
        hungerF = max(0f, hungerF - dt / 12f)
        energyF = max(0f, energyF - dt / (if (m.moving) 12f else 40f))
        m.happiness = happyF.roundToInt()

        val e = energyF.roundToInt(); if (e != energy) energy = e
        val h = hungerF.roundToInt(); if (h != hunger) hunger = h
        val hp = happyF.roundToInt(); if (hp != happiness) happiness = hp

        // hunger 0: "I'm hungry" + sad face, but you can still play
        if (hungerF <= 0f) {
            hungryNag -= dt
            if (hungryNag <= 0f) { hungryNag = 30f; emote(Emote.HUNGRY) }
        }
    }

    private fun moveLocal(m: PlayerState, dt: Float) {
        var moving = false
        var jx = 0f
        var jy = 0f

        val carrier = m.carriedBy?.let { players[it] }
        if (m.carriedBy != null && carrier == null) { m.carriedBy = null; carriedById = null }

        if (carrier != null) {
            m.x = carrier.x; m.y = carrier.y          // riding on their back
        } else if (m.sitT > 0f) {
            // seated at the table: no walking while eating
        } else {
            jx = joyX; jy = joyY
            val len = hypot(jx, jy)
            if (len < 0.12f) { jx = 0f; jy = 0f } else if (len > 1f) { jx /= len; jy /= len }
            moving = jx != 0f || jy != 0f
            if (moving) {
                val sp = mySpeed()
                val nx = m.x + jx * sp * dt
                if (!World.blocked(nx, m.y)) m.x = nx
                val ny = m.y + jy * sp * dt
                if (!World.blocked(m.x, ny)) m.y = ny
                if (abs(jx) > 0.15f) m.facing = if (jx > 0f) 1 else -1
                spawnDust(m, dt, jx, jy)
            }
        }
        m.moving = moving
        m.tx = m.x; m.ty = m.y

        val a = World.areaAt(m.x, m.y)
        if (a != m.area || areaName.isEmpty()) { m.area = a; areaName = World.areaLabel(a) }

        // sync 15x per second while moving (+ last packet when stopping, + 1/sec keep-alive)
        sendAcc += dt
        keepAliveAcc += dt
        if (sendAcc >= 1f / Net.MOVE_HZ) {
            sendAcc = 0f
            if (moving || wasMoving || keepAliveAcc >= 1f) { sendMove(m); keepAliveAcc = 0f }
            wasMoving = moving
        }
    }

    private fun updateNearby(m: PlayerState) {
        val id = if (m.carriedBy != null) null else
            players.values
                .filter { it.id != myId && it.carriedBy == null }
                .minByOrNull { hypot(it.x - m.x, it.y - m.y) }
                ?.takeIf { hypot(it.x - m.x, it.y - m.y) < 75f }?.id
        if (id != nearbyFriend) nearbyFriend = id
    }

    private fun spawnDust(p: PlayerState, dt: Float, jx: Float, jy: Float) {
        p.dustTimer -= dt
        if (p.dustTimer <= 0f) {
            p.dustTimer = 0.12f
            dust.add(Dust(p.x - jx * 8f - p.facing * 4f, p.y - 2f))
        }
    }

    // ------------------------------------------------------------ particles

    private fun hearts(x: Float, y: Float) {
        repeat(6) {
            particles.add(Particle(
                x + (Math.random().toFloat() - 0.5f) * 40f, y,
                (Math.random().toFloat() - 0.5f) * 30f, -40f - Math.random().toFloat() * 30f,
                1.5f, 0, Color.White
            ))
        }
    }

    private fun confetti(x: Float, y: Float) {
        repeat(26) {
            val a = Math.random().toFloat() * 6.283f
            val sp = 60f + Math.random().toFloat() * 120f
            particles.add(Particle(
                x, y, cos(a) * sp, sin(a) * sp - 120f, 1.4f, 1,
                CONFETTI[(Math.random() * CONFETTI.size).toInt()], spin = Math.random().toFloat() * 720f
            ))
        }
    }

    // ------------------------------------------------------------ buttons

    // ------------------------------------------------------------ kitchen

    private fun broadcastKitchen() {
        sendCustom(JSONObject().put("kind", "KITCHEN_STATE").put("state", kitchen.toJson()))
    }

    private fun kitchenAct(op: String, arg: Int = 0) {
        sendCustom(JSONObject().put("kind", "KITCHEN_ACT").put("op", op).put("arg", arg))
        if (net?.isHost == true) { broadcastKitchen(); broadcastFarm() }
    }

    /** What everyone sees when someone cooks, serves, eats or washes. */
    private fun kitchenFx(p: PlayerState, op: String) {
        when (op) {
            "COOK" -> { p.tool = "🍳"; p.toolT = 1f }
            "SERVE" -> { p.tool = "🍽️"; p.toolT = 1f }
            "TRASH" -> { p.tool = "🗑️"; p.toolT = 1f }
            "WASH" -> { p.tool = "🧽"; p.toolT = 1f }
            "EAT" -> { p.tool = "🍴"; p.toolT = 2.5f; p.sitT = 2.5f; hearts(p.x, p.y - 60f) }
        }
    }

    /** ✋ near the fridge, stove, table or sink. */
    private fun kitchenInteract(m: PlayerState): Boolean {
        val station = listOf("Fridge", "Stove", "Table", "Kitchen Sink")
            .mapNotNull { n -> World.furniture.firstOrNull { it.name == n }?.let { n to World.distanceTo(it.rect, m.x, m.y) } }
            .filter { it.second < 85f }
            .minByOrNull { it.second }?.first ?: return false
        when (station) {
            "Fridge" -> { fridgeOpenT = 1.6f; SoundFx.fridge(); panel = "FRIDGE" }
            "Stove" -> stoveAction(m)
            "Table" -> eat(m)
            else -> wash(m)
        }
        return true
    }

    private fun stoveAction(m: PlayerState) {
        when (kitchen.phase) {
            0 -> panel = "RECIPES"
            1 -> showToast("Cooking… ${(KitchenManager.COOK_S - kitchen.t).toInt() + 1}s 🍲")
            2 -> {
                if (kitchen.apply("SERVE", 0)) {
                    coins += 10
                    showToast("${KitchenManager.RECIPES[kitchen.lastServed].emoji} Served at the table! +10 coins")
                    kitchenFx(m, "SERVE")
                    confetti(m.x, m.y - 40f)
                    SoundFx.harvest()
                    kitchenAct("SERVE")
                } else showToast("The table is full! Eat something first 😋")
            }
            else -> {
                kitchen.apply("TRASH", 0)
                showToast("Yuck! Burnt food 😵 Thrown away")
                kitchenFx(m, "TRASH")
                SoundFx.pop()
                kitchenAct("TRASH")
            }
        }
    }

    fun cook(i: Int) {
        val m = me ?: return
        panel = null
        val r = KitchenManager.RECIPES.getOrNull(i) ?: return
        if (kitchen.apply("COOK", i)) {
            showToast("${r.emoji} Cooking ${r.name}… ready in 10s")
            kitchenFx(m, "COOK")
            SoundFx.plant()
            kitchenAct("COOK", i)
        } else showToast("Can't cook that right now")
    }

    private fun eat(m: PlayerState) {
        val plate = kitchen.plates.firstOrNull()
        if (plate == null) { showToast("Nothing to eat yet. Cook at the stove! 🍳"); return }
        if (!kitchen.apply("EAT", 0)) return
        val r = KitchenManager.RECIPES[plate]
        energyF = min(100f, energyF + r.energy)
        hungerF = min(100f, hungerF + 30f)
        addHappy(r.happy.toFloat())
        kitchenFx(m, "EAT")
        SoundFx.hug()
        showToast("Yum! ${r.emoji}  +Energy +Happiness")
        kitchenAct("EAT")
        val now = System.currentTimeMillis()
        eatLog.add(now)
        eatLog.removeAll { now - it > 45_000 }
        if (eatLog.size >= 3) {                 // overeating = burp
            eatLog.clear()
            sendChat("*burp* 💨")
            showToast("Burp! You ate a lot 😅")
        }
    }

    private fun wash(m: PlayerState) {
        if (kitchen.apply("WASH", 0)) {
            kitchenFx(m, "WASH")
            SoundFx.splash()
            showToast(if (kitchen.dirty > 0) "Scrub scrub! ✨ ${kitchen.dirty} dishes left" else "All clean! ✨")
            kitchenAct("WASH")
        } else showToast("No dirty dishes 🧽")
    }

    private fun broadcastFarm() {
        sendCustom(JSONObject().put("kind", "FARM_STATE").put("state", farm.toJson()))
    }

    private fun farmAct(op: String, plot: Int, crop: Int) {
        sendCustom(JSONObject().put("kind", "FARM_ACT").put("op", op).put("plot", plot).put("crop", crop))
        if (net?.isHost == true) broadcastFarm()
    }

    /** Tool in hand + water droplets. Everyone sees it, also for friends' actions. */
    private fun farmFx(p: PlayerState, op: String, idx: Int) {
        p.tool = when (op) { "WATER" -> "🚿"; "PLANT" -> "🌱"; else -> "🧺" }
        p.toolT = 0.8f
        if (op == "WATER" && idx in World.plots.indices) {
            val r = World.plots[idx]
            repeat(10) {
                particles.add(Particle(r.left + Math.random().toFloat() * r.width, r.top - 24f - Math.random().toFloat() * 14f,
                    (Math.random().toFloat() - 0.5f) * 20f, 30f, 0.7f, 2, Color.White))
            }
        }
    }

    /** The ✋ button on a farm plot: harvest if ready, water if dry, plant if empty. */
    private fun farmInteract(m: PlayerState): Boolean {
        val idx = farm.nearestPlot(m.x, m.y) ?: return false
        val pl = farm.plots[idx]
        when {
            pl.crop >= 0 && pl.ready() -> {
                val crop = pl.crop
                if (farm.apply("HARVEST", idx, crop)) {
                    coins += 5
                    showToast("${Crop.values()[crop].emoji} Harvested! +5 coins")
                    farmFx(m, "HARVEST", idx)
                    confetti(World.plots[idx].center.x, World.plots[idx].top - 20f)
                    SoundFx.harvest()
                    farmAct("HARVEST", idx, crop)
                }
            }
            pl.crop >= 0 && pl.wetMs <= 0f -> {
                farm.apply("WATER", idx, pl.crop)
                farmFx(m, "WATER", idx)
                SoundFx.splash()
                showToast("Splash! 💧")
                farmAct("WATER", idx, pl.crop)
            }
            pl.crop >= 0 -> showToast(if (farm.weather == Weather.RAINY) "The rain is watering it 🌧️" else "Growing… 🌱")
            else -> {
                val c = farm.selectedSeed
                if (farm.apply("PLANT", idx, c)) {
                    farmFx(m, "PLANT", idx)
                    SoundFx.plant()
                    showToast("Planted ${Crop.values()[c].label}!")
                    farmAct("PLANT", idx, c)
                } else showToast("No ${Crop.values()[c].label} seeds! Pick another in the 🌱 bag")
            }
        }
        return true
    }

    /** Tap on the screen: butterflies follow you for 10 seconds. */
    fun tapScreen(sx: Float, sy: Float) {
        val wx = sx / viewScale + camX
        val wy = sy / viewScale + camY
        val c = critters.firstOrNull { it.kind == 0 && hypot(it.x - wx, it.y - wy) < 40f } ?: return
        c.follow = 10f
        showToast("🦋 A butterfly is following you!")
        SoundFx.pop()
    }

    fun interact() {
        val m = me ?: return
        if (farmInteract(m)) return
        if (kitchenInteract(m)) return
        val near = World.furniture
            .filter { it.interactive }
            .minByOrNull { World.distanceTo(it.rect, m.x, m.y) }
        showToast(
            if (near != null && World.distanceTo(near.rect, m.x, m.y) < 80f) "${near.name}: coming soon!"
            else "Nothing to do here"
        )
    }

    private fun showToast(t: String) { toast = t; toastLeft = 2f }

    fun emote(e: Emote) {
        val m = me ?: return
        m.emote = e; m.emoteT = 0f
        SoundFx.emote(e.ordinal)
        sendCustom(JSONObject().put("kind", "EMOTE").put("emote", e.name))
    }

    fun hug() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(10f)
        m.emote = Emote.LOVE; m.emoteT = 0f
        hearts(m.x, m.y - 60f); hearts(t.x, t.y - 60f)
        SoundFx.hug()
        sendCustom(JSONObject().put("kind", "HUG").put("target", t.id))
    }

    fun highFive() {
        val m = me ?: return
        val t = players[nearbyFriend ?: return] ?: return
        if (actionCd > 0f) return
        actionCd = 1.5f
        addHappy(5f)
        confetti((m.x + t.x) / 2f, min(m.y, t.y) - 50f)
        SoundFx.highFive()
        sendCustom(JSONObject().put("kind", "HIGHFIVE").put("target", t.id))
    }

    /** Pick up the nearby friend, or put down whoever I carry. */
    fun toggleCarry() {
        val m = me ?: return
        val carrying = m.carrying
        if (carrying != null) {
            applyCarry(myId, carrying, false)
            sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", carrying).put("on", 0))
            return
        }
        val t = players[nearbyFriend ?: return] ?: return
        if (t.carrying != null) return
        applyCarry(myId, t.id, true)
        SoundFx.pop()
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", myId).put("carried", t.id).put("on", 1))
    }

    /** I am being carried and want to get down. */
    fun getDown() {
        val carrier = me?.carriedBy ?: return
        applyCarry(carrier, myId, false)
        sendCustom(JSONObject().put("kind", "CARRY").put("carrier", carrier).put("carried", myId).put("on", 0))
    }
}
