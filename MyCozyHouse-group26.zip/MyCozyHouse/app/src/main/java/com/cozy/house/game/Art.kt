package com.cozy.house.game

import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.sin

// ============================================================================
// Hand-drawn chibi furniture (no emoji). Every function draws into a Rect.
// ============================================================================

private fun DrawScope.rr(x: Float, y: Float, w: Float, h: Float, rad: Float, c: Color, st: Float = 3f) =
    roundRectOutlined(Offset(x, y), Size(w, h), rad, c, st)

private fun DrawScope.ov(x: Float, y: Float, w: Float, h: Float, c: Color, st: Float = 3f) {
    drawOval(c, Offset(x, y), Size(w, h))
    if (st > 0f) drawOval(OUT, Offset(x, y), Size(w, h), style = Stroke(st))
}

private fun DrawScope.ci(x: Float, y: Float, r: Float, c: Color, st: Float = 3f) {
    drawCircle(c, r, Offset(x, y))
    if (st > 0f) drawCircle(OUT, r, Offset(x, y), style = Stroke(st))
}

private fun DrawScope.ln(x1: Float, y1: Float, x2: Float, y2: Float, w: Float = 2.5f, c: Color = OUT) =
    drawLine(c, Offset(x1, y1), Offset(x2, y2), w, StrokeCap.Round)

private fun DrawScope.poly(c: Color, st: Float, vararg p: Float) {
    val path = Path().apply {
        moveTo(p[0], p[1])
        var i = 2
        while (i < p.size) { lineTo(p[i], p[i + 1]); i += 2 }
        close()
    }
    drawPath(path, c)
    if (st > 0f) drawPath(path, OUT, style = Stroke(st))
}

private fun DrawScope.heart(cx: Float, cy: Float, s: Float, c: Color) {
    drawCircle(c, s * 0.3f, Offset(cx - s * 0.25f, cy - s * 0.12f))
    drawCircle(c, s * 0.3f, Offset(cx + s * 0.25f, cy - s * 0.12f))
    val p = Path().apply { moveTo(cx - s * 0.52f, cy - s * 0.02f); lineTo(cx + s * 0.52f, cy - s * 0.02f); lineTo(cx, cy + s * 0.5f); close() }
    drawPath(p, c)
}

private fun DrawScope.star(cx: Float, cy: Float, ro: Float, c: Color, st: Float = 2.5f) {
    val path = Path()
    for (i in 0 until 10) {
        val a = -PI / 2 + i * PI / 5
        val r = if (i % 2 == 0) ro else ro * 0.45f
        val px = cx + (cos(a) * r).toFloat()
        val py = cy + (sin(a) * r).toFloat()
        if (i == 0) path.moveTo(px, py) else path.lineTo(px, py)
    }
    path.close()
    drawPath(path, c)
    if (st > 0f) drawPath(path, OUT, style = Stroke(st))
}

private val WOOD = Color(0xFFD9A066)
private val METAL = Color(0xFFD7DCE6)

// ------------------------------------------------------------------ living room

private fun DrawScope.artSofa(r: Rect, c: Color, name: String) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    val d = shade(c, 0.85f); val li = shade(c, 1.1f)
    if (name.contains("Cat")) {
        poly(d, 3f, l + w * 0.12f, t + 6f, l + w * 0.17f, t - h * 0.22f, l + w * 0.29f, t + 6f)
        poly(d, 3f, l + w * 0.71f, t + 6f, l + w * 0.83f, t - h * 0.22f, l + w * 0.88f, t + 6f)
    }
    rr(l + w * 0.04f, t, w * 0.92f, h * 0.62f, h * 0.22f, d)
    if (name.contains("Cloud")) for (i in 0..3) ci(l + w * (0.2f + i * 0.2f), t + 3f, h * 0.15f, li, 2.5f)
    if (name.contains("Rainbow")) {
        val cols = listOf(Color(0xFFFF8A8A), Color(0xFFFFD86B), Color(0xFF8EE6A0), Color(0xFF8EC9FF))
        cols.forEachIndexed { i, cc -> ln(l + w * 0.14f, t + h * (0.1f + i * 0.09f), l + w * 0.86f, t + h * (0.1f + i * 0.09f), 4f, cc) }
    }
    rr(l, t + h * 0.28f, w * 0.15f, h * 0.7f, h * 0.14f, c)
    rr(l + w * 0.85f, t + h * 0.28f, w * 0.15f, h * 0.7f, h * 0.14f, c)
    rr(l + w * 0.12f, t + h * 0.4f, w * 0.76f, h * 0.55f, h * 0.14f, li)
    ln(l + w * 0.5f, t + h * 0.46f, l + w * 0.5f, t + h * 0.9f, 2f)
    if (name.contains("Heart")) heart(l + w * 0.5f, t + h * 0.22f, h * 0.45f, Color(0xFFFF6B9A))
    ci(l + w * 0.24f, t + h * 0.55f, h * 0.13f, shade(c, 1.2f), 2.5f)     // cushion
}

private fun DrawScope.artBed(r: Rect, c: Color, name: String) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    val wood = if (name.contains("Golden")) Color(0xFFFFC93C) else if (name.contains("Princess")) Color(0xFFFFD1E8) else WOOD
    if (name.contains("Cat") || name.contains("Cloud")) {      // round pet-style / cloud bed
        ov(l, t + h * 0.1f, w, h * 0.85f, c)
        ov(l + w * 0.12f, t + h * 0.22f, w * 0.76f, h * 0.6f, shade(c, 1.12f))
        if (name.contains("Cat")) { poly(c, 3f, l + w * 0.1f, t + h * 0.25f, l + w * 0.15f, t - 2f, l + w * 0.32f, t + h * 0.15f); poly(c, 3f, l + w * 0.68f, t + h * 0.15f, l + w * 0.85f, t - 2f, l + w * 0.9f, t + h * 0.25f) }
        return
    }
    rr(l, t, w, h * 0.16f, 10f, wood)                                  // headboard
    rr(l + 3f, t + h * 0.1f, w - 6f, h * 0.88f, 12f, Color.White)      // mattress
    rr(l + 3f, t + h * 0.42f, w - 6f, h * 0.56f, 12f, c)               // blanket
    ln(l + 6f, t + h * 0.5f, l + w - 6f, t + h * 0.5f, 3f, shade(c, 1.2f))
    val pw = if (w > 140f) w * 0.4f else w * 0.7f
    rr(l + w * 0.5f - (if (w > 140f) w * 0.45f else pw / 2f), t + h * 0.15f, pw, h * 0.2f, 8f, Color(0xFFFFF1F8), 2.5f)
    if (w > 140f) rr(l + w * 0.55f, t + h * 0.15f, pw, h * 0.2f, 8f, Color(0xFFFFF1F8), 2.5f)
    if (name.contains("Bunk")) {
        ln(l + 2f, t, l + 2f, t + h, 5f, wood); ln(l + w - 2f, t, l + w - 2f, t + h, 5f, wood)
        for (i in 1..4) ln(l + 2f, t + h * i / 5f, l + w - 2f, t + h * i / 5f, 3f, wood)
    }
    if (name.contains("Princess")) { poly(Color(0xFFFFC93C), 3f, l + w * 0.25f, t + 2f, l + w * 0.3f, t - 14f, l + w * 0.4f, t - 4f, l + w * 0.5f, t - 18f, l + w * 0.6f, t - 4f, l + w * 0.7f, t - 14f, l + w * 0.75f, t + 2f) }
    if (name.contains("Car")) { ci(l + w * 0.18f, t + h * 0.98f, 9f, Color(0xFF3B3355)); ci(l + w * 0.82f, t + h * 0.98f, 9f, Color(0xFF3B3355)); ci(l + w * 0.3f, t + 4f, 6f, Color(0xFFFFF59D)); ci(l + w * 0.7f, t + 4f, 6f, Color(0xFFFFF59D)) }
    if (name.contains("Hammock")) { ln(l, t, l + w, t + h, 4f, WOOD) }
}

private fun DrawScope.artWardrobe(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 10f, c)
    rr(l + w * 0.06f, t + h * 0.1f, w * 0.41f, h * 0.8f, 6f, shade(c, 1.1f), 2.5f)
    rr(l + w * 0.53f, t + h * 0.1f, w * 0.41f, h * 0.8f, 6f, shade(c, 1.1f), 2.5f)
    ci(l + w * 0.42f, t + h * 0.5f, 3f, Color(0xFFFFC93C), 1.5f)
    ci(l + w * 0.58f, t + h * 0.5f, 3f, Color(0xFFFFC93C), 1.5f)
    rr(l - 2f, t - 4f, w + 4f, h * 0.12f, 5f, shade(c, 0.85f), 2.5f)
}

private fun DrawScope.artToyBox(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ci(l + w * 0.5f, t + h * 0.2f, h * 0.24f, Color(0xFFB07A4F), 2.5f)         // teddy peeking out
    ci(l + w * 0.34f, t + h * 0.04f, h * 0.1f, Color(0xFFB07A4F), 2f); ci(l + w * 0.66f, t + h * 0.04f, h * 0.1f, Color(0xFFB07A4F), 2f)
    rr(l, t + h * 0.3f, w, h * 0.7f, 10f, c)
    rr(l - 2f, t + h * 0.26f, w + 4f, h * 0.18f, 6f, shade(c, 0.88f), 2.5f)
    star(l + w * 0.5f, t + h * 0.68f, h * 0.17f, Color(0xFFFFFFFF), 2f)
}

private fun DrawScope.artTv(r: Rect, c: Color, name: String) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    if (name.contains("Old")) { ln(l + w * 0.5f, t, l + w * 0.3f, t - h * 0.3f, 2.5f); ln(l + w * 0.5f, t, l + w * 0.7f, t - h * 0.3f, 2.5f) }
    rr(l, t, w, h * 0.82f, 8f, if (name.contains("Cat")) c else Color(0xFF2F2A41))
    if (name.contains("Cat")) { poly(c, 3f, l + w * 0.1f, t + 4f, l + w * 0.18f, t - h * 0.25f, l + w * 0.3f, t + 4f); poly(c, 3f, l + w * 0.7f, t + 4f, l + w * 0.82f, t - h * 0.25f, l + w * 0.9f, t + 4f) }
    rr(l + w * 0.07f, t + h * 0.1f, w * 0.86f, h * 0.6f, 5f, Color(0xFFBDE9FF), 2f)
    ln(l + w * 0.14f, t + h * 0.2f, l + w * 0.3f, t + h * 0.14f, 3f, Color.White.copy(alpha = 0.8f))
    rr(l + w * 0.35f, t + h * 0.84f, w * 0.3f, h * 0.16f, 4f, Color(0xFF2F2A41), 2f)
}

private fun DrawScope.artFireplace(r: Rect, t0: Float) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 8f, Color(0xFFC96F55))
    for (i in 0 until 4) for (j in 0 until 3) { val bx = l + 4f + i * (w - 8f) / 4f + (j % 2) * 6f; ln(bx, t + 12f + j * h * 0.22f, bx + (w - 8f) / 4f - 4f, t + 12f + j * h * 0.22f, 1.5f, Color(0xFFE8B8A0)) }
    rr(l - 5f, t - 6f, w + 10f, h * 0.18f, 5f, Color(0xFF8B5A3C))               // mantel
    rr(l + w * 0.2f, t + h * 0.34f, w * 0.6f, h * 0.64f, 14f, Color(0xFF3B2A2A))   // opening
    for (i in 0..2) {
        val fx = l + w * (0.33f + i * 0.17f)
        val fh = h * (0.22f + 0.07f * abs(sin(t0 * 9f + i * 2f)))
        ov(fx - 8f, t + h * 0.92f - fh, 16f, fh, Color(0xFFFF8A3D), 0f)
        ov(fx - 4f, t + h * 0.92f - fh * 0.6f, 8f, fh * 0.6f, Color(0xFFFFD86B), 0f)
    }
}

private fun DrawScope.artTableSmall(r: Rect, c: Color, round: Boolean) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    if (round) ov(l, t, w, h, c) else rr(l, t, w, h, 8f, c)
    ln(l + w * 0.2f, t + h * 0.8f, l + w * 0.2f, t + h + 4f, 4f, WOOD); ln(l + w * 0.8f, t + h * 0.8f, l + w * 0.8f, t + h + 4f, 4f, WOOD)
}

private fun DrawScope.artTvStand(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 8f, c)
    rr(l + w * 0.06f, t + h * 0.2f, w * 0.42f, h * 0.6f, 4f, shade(c, 1.1f), 2f)
    rr(l + w * 0.52f, t + h * 0.2f, w * 0.42f, h * 0.6f, 4f, shade(c, 1.1f), 2f)
    ci(l + w * 0.43f, t + h * 0.5f, 2.5f, Color(0xFFFFC93C), 1.2f); ci(l + w * 0.57f, t + h * 0.5f, 2.5f, Color(0xFFFFC93C), 1.2f)
}

private fun DrawScope.artLamp(r: Rect, c: Color, name: String) {
    val cx = r.center.x; val t = r.top; val h = r.height; val w = r.width
    ln(cx, t + h * 0.4f, cx, t + h * 0.92f, 4f, METAL)
    ov(cx - w * 0.3f, t + h * 0.84f, w * 0.6f, h * 0.16f, Color(0xFF8E8EA0), 2.5f)
    when {
        name.contains("Mushroom") -> { ov(cx - w * 0.5f, t, w, h * 0.5f, Color(0xFFFF6B6B)); for (p in listOf(-0.2f to 0.15f, 0.1f to 0.1f, 0.25f to 0.25f)) drawCircle(Color.White, 3f, Offset(cx + w * p.first, t + h * (p.second + 0.1f))) }
        name.contains("Star") -> star(cx, t + h * 0.25f, h * 0.34f, Color(0xFFFFE066))
        name.contains("Heart") -> heart(cx, t + h * 0.25f, h * 0.7f, Color(0xFFFF6B9A))
        else -> poly(c, 3f, cx - w * 0.28f, t, cx + w * 0.28f, t, cx + w * 0.45f, t + h * 0.45f, cx - w * 0.45f, t + h * 0.45f)
    }
}

private fun DrawScope.artFairy(r: Rect, t0: Float) {
    val y = r.center.y
    ln(r.left, y - 4f, r.right, y - 4f, 2.5f)
    val n = (r.width / 18f).toInt().coerceAtLeast(3)
    for (i in 0 until n) {
        val x = r.left + (i + 0.5f) * r.width / n
        val tw = 0.6f + 0.4f * sin(t0 * 4f + i)
        drawCircle(Color(0xFFFFE066).copy(alpha = 0.35f * tw), 8f, Offset(x, y + 4f))
        ci(x, y + 4f, 3.5f, Color(0xFFFFF59D), 1.5f)
    }
}

private fun DrawScope.artRug(r: Rect, c: Color, name: String) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    val d = shade(c, 0.88f)
    when {
        name.contains("Round") -> { ov(l, t, w, h, c); ov(l + w * 0.12f, t + h * 0.12f, w * 0.76f, h * 0.76f, d, 2f); ov(l + w * 0.3f, t + h * 0.3f, w * 0.4f, h * 0.4f, c, 2f) }
        name.contains("Heart") -> { heart(l + w * 0.5f, t + h * 0.42f, minOf(w, h) * 1.1f, Color(0xFFFF8FB1)); heart(l + w * 0.5f, t + h * 0.42f, minOf(w, h) * 0.6f, Color(0xFFFFC8DD)) }
        name.contains("Star") -> { star(l + w * 0.5f, t + h * 0.52f, minOf(w, h) * 0.58f, Color(0xFFFFE066), 3f) }
        name.contains("Cat") -> {
            ov(l + w * 0.1f, t + h * 0.12f, w * 0.8f, h * 0.82f, c)
            poly(c, 3f, l + w * 0.14f, t + h * 0.3f, l + w * 0.2f, t - h * 0.04f, l + w * 0.4f, t + h * 0.15f)
            poly(c, 3f, l + w * 0.6f, t + h * 0.15f, l + w * 0.8f, t - h * 0.04f, l + w * 0.86f, t + h * 0.3f)
            ci(l + w * 0.36f, t + h * 0.45f, 4f, OUT, 0f); ci(l + w * 0.64f, t + h * 0.45f, 4f, OUT, 0f)
            drawCircle(Color(0xFFFF8FA3), 4f, Offset(l + w * 0.5f, t + h * 0.6f))
        }
        name.contains("Rainbow") -> {
            val cols = listOf(Color(0xFFFF8A8A), Color(0xFFFFD86B), Color(0xFF8EE6A0), Color(0xFF8EC9FF), Color(0xFFD9B3FF))
            cols.forEachIndexed { i, cc -> val k = i * 0.09f; ov(l + w * k, t + h * k, w * (1f - 2 * k), h * (1f - 2 * k), cc, if (i == 0) 3f else 0f) }
        }
        name.contains("Cloud") -> { for (p in listOf(0.25f to 0.55f, 0.5f to 0.4f, 0.75f to 0.55f, 0.4f to 0.65f, 0.62f to 0.66f)) ci(l + w * p.first, t + h * p.second, h * 0.28f, Color(0xFFF1F8FF), 2.5f) }
        name.contains("Flower") -> {
            for (i in 0 until 6) { val a = i * PI / 3; ci(l + w * 0.5f + (cos(a) * w * 0.22f).toFloat(), t + h * 0.5f + (sin(a) * h * 0.26f).toFloat(), h * 0.2f, Color(0xFFFFB3D1), 2.5f) }
            ci(l + w * 0.5f, t + h * 0.5f, h * 0.17f, Color(0xFFFFD86B), 2.5f)
        }
        name.contains("Checker") -> {
            rr(l, t, w, h, 6f, Color.White)
            val n = 6
            for (i in 0 until n) for (j in 0 until 4) if ((i + j) % 2 == 0) drawRect(Color(0xFFB0B7C3), Offset(l + i * w / n, t + j * h / 4f), Size(w / n, h / 4f))
            drawRoundRect(OUT, Offset(l, t), Size(w, h), androidx.compose.ui.geometry.CornerRadius(6f), style = Stroke(3f))
        }
        else -> { rr(l, t, w, h, 18f, c); rr(l + 8f, t + 8f, w - 16f, h - 16f, 12f, d, 2f); ln(l + 18f, t + h * 0.5f, l + w - 18f, t + h * 0.5f, 2f, shade(c, 1.2f)) }
    }
}

private fun DrawScope.artPlant(r: Rect, c: Color, name: String) {
    val cx = r.center.x; val t = r.top; val h = r.height; val w = r.width; val b = r.bottom
    val green = Color(0xFF5FBF6A); val dark = Color(0xFF3E9E52)
    // pot
    poly(Color(0xFFD9805A), 3f, cx - w * 0.28f, b - h * 0.34f, cx + w * 0.28f, b - h * 0.34f, cx + w * 0.2f, b, cx - w * 0.2f, b)
    rr(cx - w * 0.31f, b - h * 0.4f, w * 0.62f, h * 0.1f, 4f, Color(0xFFE79A74), 2.5f)
    val py = b - h * 0.4f
    when {
        name.contains("Cactus") -> { rr(cx - 7f, t + h * 0.12f, 14f, py - t - h * 0.12f, 7f, green); rr(cx - 17f, t + h * 0.3f, 10f, 8f, 4f, green, 2.5f); rr(cx - 17f, t + h * 0.22f, 7f, 16f, 4f, green, 2.5f); rr(cx + 8f, t + h * 0.38f, 10f, 8f, 4f, green, 2.5f); rr(cx + 11f, t + h * 0.3f, 7f, 16f, 4f, green, 2.5f); ci(cx, t + h * 0.12f, 3f, Color(0xFFFF9EC4), 1.5f) }
        name.contains("Tulip") -> for (i in -1..1) { ln(cx + i * 9f, py, cx + i * 9f, t + h * 0.3f + abs(i) * 6f, 3f, dark); poly(listOf(Color(0xFFFF6B9A), Color(0xFFFFD86B), Color(0xFFFF8A8A))[i + 1], 2.5f, cx + i * 9f - 6f, t + h * 0.3f + abs(i) * 6f, cx + i * 9f - 3f, t + h * 0.12f + abs(i) * 6f, cx + i * 9f, t + h * 0.24f + abs(i) * 6f, cx + i * 9f + 3f, t + h * 0.12f + abs(i) * 6f, cx + i * 9f + 6f, t + h * 0.3f + abs(i) * 6f) }
        name.contains("Sunflower") -> { ln(cx, py, cx, t + h * 0.25f, 4f, dark); for (i in 0 until 8) { val a = i * PI / 4; ci(cx + (cos(a) * 11f).toFloat(), t + h * 0.25f + (sin(a) * 11f).toFloat(), 6f, Color(0xFFFFD86B), 2f) }; ci(cx, t + h * 0.25f, 7f, Color(0xFF8B5A3C), 2f) }
        name.contains("Rose") -> { ln(cx, py, cx, t + h * 0.3f, 3f, dark); ci(cx, t + h * 0.26f, 9f, Color(0xFFE63946), 2.5f); ci(cx, t + h * 0.26f, 4.5f, Color(0xFFFF6B7A), 1.5f); ov(cx + 3f, t + h * 0.5f, 12f, 7f, green, 2f) }
        name.contains("Bamboo") -> for (i in -1..1) { rr(cx + i * 9f - 3.5f, t + h * 0.1f + abs(i) * 6f, 7f, py - t - h * 0.1f - abs(i) * 6f, 3f, Color(0xFF7ED67E), 2.5f); for (k in 1..3) ln(cx + i * 9f - 3.5f, t + h * (0.1f + k * 0.17f) + abs(i) * 6f, cx + i * 9f + 3.5f, t + h * (0.1f + k * 0.17f) + abs(i) * 6f, 2f) }
        name.contains("Palm") -> { ln(cx, py, cx + 4f, t + h * 0.3f, 5f, Color(0xFFB07A4F)); for (i in 0 until 5) { val a = PI + i * PI / 4; ln(cx + 4f, t + h * 0.3f, cx + 4f + (cos(a) * w * 0.45f).toFloat(), t + h * 0.3f + (sin(a) * h * 0.25f).toFloat() + 6f, 5f, green) } }
        name.contains("Bonsai") -> { rr(cx - 4f, t + h * 0.4f, 8f, py - t - h * 0.4f, 3f, Color(0xFF8B5A3C), 2.5f); ci(cx - 10f, t + h * 0.3f, 11f, green, 2.5f); ci(cx + 9f, t + h * 0.26f, 12f, dark, 2.5f); ci(cx, t + h * 0.14f, 10f, green, 2.5f) }
        name.contains("Mini") -> { poly(dark, 2.5f, cx - 14f, py, cx + 14f, py, cx, t + h * 0.3f); poly(green, 2.5f, cx - 11f, t + h * 0.55f, cx + 11f, t + h * 0.55f, cx, t + h * 0.12f); star(cx, t + h * 0.1f, 6f, Color(0xFFFFE066), 1.5f) }
        name.contains("Monstera") -> { ov(cx - 18f, t + h * 0.2f, 20f, 26f, green, 2.5f); ov(cx - 2f, t + h * 0.12f, 20f, 28f, dark, 2.5f); ov(cx - 8f, t + h * 0.38f, 18f, 22f, green, 2.5f); ln(cx - 8f, t + h * 0.3f, cx - 3f, t + h * 0.4f, 2f) }
        else -> for (i in -2..2) { val a = -PI / 2 + i * 0.5; ln(cx, py, cx + (cos(a) * w * 0.5f).toFloat(), py + (sin(a) * (py - t)).toFloat(), 5f, if (i % 2 == 0) green else dark) }   // fern
    }
}

private fun DrawScope.artFrame(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 4f, Color(0xFFB07A4F))
    drawRect(c, Offset(l + 3f, t + 3f), Size(w - 6f, h - 6f))
    drawCircle(Color(0xFFFFF1A8), minOf(w, h) * 0.14f, Offset(l + w * 0.72f, t + h * 0.35f))
    poly(Color(0xFF9ADFA0), 1.5f, l + 3f, t + h - 3f, l + w * 0.4f, t + h * 0.45f, l + w * 0.7f, t + h - 3f)
}

private fun DrawScope.artPhotoWall(r: Rect) {
    val n = 4
    for (i in 0 until n) {
        val x = r.left + i * r.width / n + 4f
        val fw = r.width / n - 8f
        rr(x, r.top - 4f, fw, r.height + 8f, 3f, Color(0xFFFFF0F5), 2.5f)
        drawRect(listOf(Color(0xFFFFC8DD), Color(0xFFBDE0FE), Color(0xFFB9FBC0), Color(0xFFFFE066))[i], Offset(x + 3f, r.top - 1f), Size(fw - 6f, r.height + 2f))
    }
}

private fun DrawScope.artCurtains(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ln(l - 4f, t, l + w + 4f, t, 4f, Color(0xFFB07A4F))
    poly(c, 3f, l, t, l + w * 0.46f, t, l + w * 0.34f, t + h * 3.2f, l + w * 0.04f, t + h * 3.4f)
    poly(c, 3f, l + w * 0.54f, t, l + w, t, l + w * 0.96f, t + h * 3.4f, l + w * 0.66f, t + h * 3.2f)
    for (i in 1..2) { ln(l + w * 0.1f * i, t + 4f, l + w * 0.1f * i, t + h * 3f, 1.5f, shade(c, 0.8f)); ln(l + w * (1f - 0.1f * i), t + 4f, l + w * (1f - 0.1f * i), t + h * 3f, 1.5f, shade(c, 0.8f)) }
}

private fun DrawScope.artMirror(r: Rect, name: String) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    if (name.contains("Heart")) { heart(r.center.x, r.center.y, minOf(w * 1.2f, 70f), Color(0xFFFF8FB1)); heart(r.center.x, r.center.y, minOf(w * 0.9f, 52f), Color(0xFFE8F6FF)) }
    else if (name.contains("Star")) { star(r.center.x, r.center.y, minOf(w * 0.7f, 40f), Color(0xFFFFD86B), 3f); star(r.center.x, r.center.y, minOf(w * 0.42f, 24f), Color(0xFFE8F6FF), 0f) }
    else { ov(l - 2f, t - h * 0.3f, w + 4f, h * 2.6f, Color(0xFFD9A066)); ov(l + 3f, t - h * 0.15f, w - 6f, h * 2.3f, Color(0xFFE8F6FF), 2f); ln(l + w * 0.28f, t + h * 0.1f, l + w * 0.4f, t + h * 0.9f, 3f, Color.White) }
}

private fun DrawScope.artDesk(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h * 0.3f, 6f, c)
    rr(l + 4f, t + h * 0.28f, w * 0.26f, h * 0.7f, 4f, shade(c, 0.9f), 2.5f); ln(l + 12f, t + h * 0.55f, l + w * 0.2f, t + h * 0.55f, 2.5f)
    ln(l + w - 8f, t + h * 0.28f, l + w - 8f, t + h, 5f, c); ln(l + w * 0.55f, t + h * 0.28f, l + w * 0.55f, t + h, 5f, c)
    rr(l + w * 0.62f, t - h * 0.1f, w * 0.28f, h * 0.3f, 3f, Color(0xFF2F2A41), 2f)
}

private fun DrawScope.artChair(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l + w * 0.1f, t, w * 0.8f, h * 0.45f, 5f, shade(c, 0.9f))
    rr(l, t + h * 0.4f, w, h * 0.3f, 5f, c)
    ln(l + 4f, t + h * 0.68f, l + 4f, t + h, 4f, c); ln(l + w - 4f, t + h * 0.68f, l + w - 4f, t + h, 4f, c)
}

private fun DrawScope.artBookshelf(r: Rect) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 6f, WOOD)
    val cols = listOf(Color(0xFFFF8A8A), Color(0xFF8EC9FF), Color(0xFFFFD86B), Color(0xFF8EE6A0), Color(0xFFD9B3FF), Color(0xFFFFA97A))
    val n = (w / 12f).toInt().coerceAtLeast(4)
    for (i in 0 until n) { val bh = h * (0.5f + 0.25f * ((i * 37) % 3) / 2f); rr(l + 4f + i * (w - 8f) / n, t + h - 6f - bh, (w - 8f) / n - 2f, bh, 2f, cols[i % 6], 2f) }
}

// ------------------------------------------------------------------ kitchen + bathroom

private fun DrawScope.artFridge(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 10f, c)
    ln(l + 4f, t + h * 0.36f, l + w - 4f, t + h * 0.36f, 3f)
    rr(l + w * 0.8f, t + h * 0.12f, 5f, h * 0.18f, 2f, Color(0xFF8E8EA0), 1.5f)
    rr(l + w * 0.8f, t + h * 0.5f, 5f, h * 0.3f, 2f, Color(0xFF8E8EA0), 1.5f)
    ci(l + w * 0.25f, t + h * 0.55f, 5f, Color(0xFFFF8FB1), 1.5f); ci(l + w * 0.36f, t + h * 0.68f, 5f, Color(0xFF8EC9FF), 1.5f)
}

private fun DrawScope.artStove(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 8f, c)
    for (i in 0..1) for (j in 0..1) { ci(l + w * (0.3f + i * 0.4f), t + h * (0.22f + j * 0.2f), minOf(w, h) * 0.12f, Color(0xFF3B3355), 2f) }
    rr(l + w * 0.1f, t + h * 0.58f, w * 0.8f, h * 0.36f, 4f, Color(0xFF4B4568), 2.5f)
    rr(l + w * 0.2f, t + h * 0.64f, w * 0.6f, h * 0.2f, 3f, Color(0xFFFFE8B0), 1.5f)
    for (i in 0..3) ci(l + w * (0.2f + i * 0.2f), t + h * 0.5f, 2.5f, Color(0xFFFFC93C), 1.2f)
}

private fun DrawScope.artCounter(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t + h * 0.18f, w, h * 0.82f, 6f, shade(c, 0.9f))
    rr(l - 3f, t, w + 6f, h * 0.26f, 5f, Color(0xFFFFF4DD), 2.5f)
    val n = (w / 46f).toInt().coerceAtLeast(2)
    for (i in 0 until n) { rr(l + 5f + i * (w - 10f) / n, t + h * 0.32f, (w - 10f) / n - 4f, h * 0.58f, 4f, c, 2f); ci(l + 5f + (i + 0.5f) * (w - 10f) / n, t + h * 0.55f, 2f, Color(0xFFFFC93C), 1f) }
}

private fun DrawScope.artSink(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t + h * 0.2f, w, h * 0.8f, 6f, shade(c, 0.95f))
    rr(l - 2f, t, w + 4f, h * 0.28f, 5f, Color(0xFFF1F5FA), 2.5f)
    ov(l + w * 0.18f, t + h * 0.04f, w * 0.64f, h * 0.2f, Color(0xFFBFE3FF), 2f)
    ln(r.center.x, t + h * 0.02f, r.center.x, t - h * 0.2f, 4f, METAL); ln(r.center.x, t - h * 0.2f, r.center.x + 10f, t - h * 0.2f, 4f, METAL)
}

private fun DrawScope.artTable(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    for (sx in listOf(0.18f, 0.5f, 0.82f)) { rr(l + w * sx - 10f, t - 2f, 20f, 16f, 5f, WOOD, 2.5f); rr(l + w * sx - 10f, t + h - 14f, 20f, 16f, 5f, WOOD, 2.5f) }
    rr(l + 4f, t + h * 0.14f, w - 8f, h * 0.72f, 14f, c)
    rr(l + 14f, t + h * 0.26f, w - 28f, h * 0.48f, 8f, shade(c, 1.08f), 2f)
}

private fun DrawScope.artBathtub(r: Rect, c: Color, t0: Float) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ln(l + 12f, t + h, l + 12f, t + h + 6f, 5f, METAL); ln(l + w - 12f, t + h, l + w - 12f, t + h + 6f, 5f, METAL)
    rr(l, t + h * 0.1f, w, h * 0.9f, h * 0.35f, c)
    ov(l + w * 0.07f, t + h * 0.22f, w * 0.86f, h * 0.6f, Color(0xFF9ADBFF), 2.5f)
    for (i in 0..3) drawCircle(Color.White.copy(alpha = 0.85f), 5f + (i % 2) * 3f, Offset(l + w * (0.3f + i * 0.14f), t + h * 0.42f + sin(t0 * 2f + i) * 3f))
    ln(l + w * 0.1f, t + h * 0.1f, l + w * 0.1f, t - 6f, 4f, METAL); ln(l + w * 0.1f, t - 6f, l + w * 0.2f, t - 6f, 4f, METAL)
}

private fun DrawScope.artShower(r: Rect, t0: Float) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 10f, Color(0xFFD6EEFF).copy(alpha = 0.6f), 3.5f)
    rr(l + w * 0.1f, t + 6f, w * 0.8f, h * 0.06f, 3f, METAL, 2f)
    ci(r.center.x, t + h * 0.13f, minOf(w, h) * 0.12f, METAL, 2.5f)
    for (i in -2..2) { val ph = (t0 * 1.6f + i * 0.2f) % 1f; ln(r.center.x + i * w * 0.08f, t + h * 0.2f + ph * h * 0.6f, r.center.x + i * w * 0.08f, t + h * 0.28f + ph * h * 0.6f, 2f, Color(0xFF5CB7FF)) }
}

private fun DrawScope.artDuck(r: Rect, c: Color) {
    val cx = r.center.x; val cy = r.center.y; val s = minOf(r.width, r.height)
    ov(cx - s * 0.4f, cy - s * 0.05f, s * 0.8f, s * 0.5f, c)
    ci(cx + s * 0.18f, cy - s * 0.18f, s * 0.22f, c)
    poly(Color(0xFFFF9A3C), 2f, cx + s * 0.36f, cy - s * 0.2f, cx + s * 0.55f, cy - s * 0.15f, cx + s * 0.36f, cy - s * 0.08f)
    drawCircle(OUT, 1.8f, Offset(cx + s * 0.22f, cy - s * 0.24f))
}

private fun DrawScope.artTowel(r: Rect, c: Color) {
    rr(r.left, r.top, r.width, r.height, 5f, c)
    for (i in 1..3) ln(r.left + 4f, r.top + r.height * i / 4f, r.right - 4f, r.top + r.height * i / 4f, 2f, Color.White.copy(alpha = 0.7f))
}

// ------------------------------------------------------------------ garden, town, playground

private fun DrawScope.artTree(r: Rect) {
    val cx = r.center.x; val w = r.width; val h = r.height
    rr(cx - w * 0.09f, r.top + h * 0.5f, w * 0.18f, h * 0.5f, 4f, Color(0xFF8B5A3C))
    ci(cx - w * 0.22f, r.top + h * 0.42f, w * 0.26f, Color(0xFF6BCB77))
    ci(cx + w * 0.22f, r.top + h * 0.42f, w * 0.26f, Color(0xFF5FBF6A))
    ci(cx, r.top + h * 0.26f, w * 0.3f, Color(0xFF79D68A))
    drawCircle(Color(0xFFE63946), 3.5f, Offset(cx - w * 0.15f, r.top + h * 0.34f)); drawCircle(Color(0xFFE63946), 3.5f, Offset(cx + w * 0.18f, r.top + h * 0.45f))
}

private fun DrawScope.artBench(r: Rect) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h * 0.38f, 4f, Color(0xFFC98D58))
    rr(l - 2f, t + h * 0.44f, w + 4f, h * 0.34f, 4f, WOOD)
    ln(l + 8f, t + h * 0.78f, l + 8f, t + h + 6f, 4f, Color(0xFF6B4A33)); ln(l + w - 8f, t + h * 0.78f, l + w - 8f, t + h + 6f, 4f, Color(0xFF6B4A33))
}

private fun DrawScope.artStreetLamp(r: Rect, t0: Float) {
    val cx = r.center.x; val b = r.bottom
    rr(cx - 3f, b - 62f, 6f, 62f, 3f, Color(0xFF4B4568))
    ov(cx - 9f, b - 6f, 18f, 8f, Color(0xFF4B4568), 2f)
    rr(cx - 10f, b - 78f, 20f, 18f, 8f, Color(0xFFFFF1A8))
    poly(Color(0xFF4B4568), 2.5f, cx - 12f, b - 78f, cx + 12f, b - 78f, cx, b - 90f)
}

private fun DrawScope.artFountain(r: Rect, t0: Float) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ov(l, t + h * 0.25f, w, h * 0.75f, Color(0xFFCFD6E0))
    ov(l + w * 0.08f, t + h * 0.33f, w * 0.84f, h * 0.55f, Color(0xFF9ADBFF), 2.5f)
    rr(r.center.x - 6f, t + h * 0.08f, 12f, h * 0.4f, 5f, Color(0xFFCFD6E0), 2.5f)
    ov(r.center.x - 16f, t + h * 0.02f, 32f, 12f, Color(0xFFCFD6E0), 2.5f)
    for (i in 0..4) { val u = (t0 * 1.2f + i * 0.2f) % 1f; drawCircle(Color(0xFF8EC9FF).copy(alpha = 1f - u), 3f, Offset(r.center.x + (i - 2) * 8f * u, t + h * 0.02f + u * h * 0.35f - sin(u * 3.14159f) * 8f)) }
}

private fun DrawScope.artPond(r: Rect, t0: Float) {
    ov(r.left, r.top, r.width, r.height, Color(0xFF8EC9FF), 4f)
    ov(r.left + r.width * 0.12f, r.top + r.height * 0.15f, r.width * 0.76f, r.height * 0.7f, Color(0xFFAADCFF), 0f)
    ov(r.left + r.width * 0.55f, r.top + r.height * 0.3f, r.width * 0.2f, r.height * 0.16f, Color(0xFF6BCB77), 2f)
    drawOval(Color.White.copy(alpha = 0.7f), Offset(r.left + r.width * (0.2f + 0.05f * sin(t0 * 2f)), r.top + r.height * 0.4f), Size(r.width * 0.3f, r.height * 0.2f), style = Stroke(2f))
}

private fun DrawScope.artFence(r: Rect, c: Color) {
    val n = (r.width / 16f).toInt().coerceAtLeast(3)
    ln(r.left, r.top + r.height * 0.3f, r.right, r.top + r.height * 0.3f, 4f, shade(c, 0.8f)); ln(r.left, r.top + r.height * 0.75f, r.right, r.top + r.height * 0.75f, 4f, shade(c, 0.8f))
    for (i in 0 until n) { val x = r.left + (i + 0.5f) * r.width / n; poly(c, 2.5f, x - 5f, r.bottom, x - 5f, r.top + 5f, x, r.top - 2f, x + 5f, r.top + 5f, x + 5f, r.bottom) }
}

private fun DrawScope.artPath(r: Rect, c: Color, name: String) {
    rr(r.left, r.top, r.width, r.height, 10f, shade(c, 0.95f), 2.5f)
    when {
        name.contains("Wood") -> for (i in 1..3) ln(r.left + 4f, r.top + r.height * i / 4f, r.right - 4f, r.top + r.height * i / 4f, 2f, WOOD)
        name.contains("Flower") -> for (i in 0..4) ci(r.left + r.width * (0.12f + i * 0.19f), r.top + r.height * (0.3f + 0.4f * (i % 2)), 5f, listOf(Color(0xFFFF8FB1), Color(0xFFFFD86B), Color(0xFFD9B3FF))[i % 3], 1.5f)
        name.contains("Rainbow") -> listOf(Color(0xFFFF8A8A), Color(0xFFFFD86B), Color(0xFF8EE6A0), Color(0xFF8EC9FF)).forEachIndexed { i, cc -> drawRect(cc, Offset(r.left + 4f, r.top + 4f + i * (r.height - 8f) / 4f), Size(r.width - 8f, (r.height - 8f) / 4f)) }
        else -> for (i in 0..4) ov(r.left + 6f + i * (r.width - 12f) / 5f, r.top + r.height * (0.2f + 0.3f * (i % 2)), (r.width - 12f) / 5f - 3f, r.height * 0.4f, Color(0xFFBFC5CF), 2f)
    }
}

private fun DrawScope.artFlowerBed(r: Rect) {
    rr(r.left, r.top + r.height * 0.3f, r.width, r.height * 0.7f, 10f, Color(0xFF8B5A3C))
    val n = (r.width / 22f).toInt().coerceAtLeast(3)
    for (i in 0 until n) {
        val x = r.left + (i + 0.5f) * r.width / n
        ln(x, r.top + r.height * 0.55f, x, r.top + r.height * 0.15f, 3f, Color(0xFF4FAE5A))
        ci(x, r.top + r.height * 0.12f, 6.5f, listOf(Color(0xFFFF8FB1), Color(0xFFFFD86B), Color(0xFFD9B3FF), Color(0xFFFF8A8A))[i % 4], 2f)
        drawCircle(Color(0xFFFFF59D), 2.2f, Offset(x, r.top + r.height * 0.12f))
    }
}

private fun DrawScope.artMailbox(r: Rect, flagUp: Boolean) {
    val cx = r.center.x
    rr(cx - 3f, r.top + r.height * 0.4f, 6f, r.height * 0.6f, 2f, Color(0xFF8B5A3C), 2f)
    rr(cx - r.width * 0.42f, r.top, r.width * 0.84f, r.height * 0.5f, 10f, Color(0xFF6BB3FF))
    rr(cx + r.width * 0.34f, r.top - 8f, 4f, 16f, 1.5f, if (flagUp) Color(0xFFFF4D6D) else Color(0xFF8E8EA0), 1.5f)
    ln(cx - r.width * 0.2f, r.top + r.height * 0.2f, cx + r.width * 0.2f, r.top + r.height * 0.2f, 2f, Color.White)
}

private fun DrawScope.artCart(r: Rect) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    // striped umbrella
    for (i in 0 until 6) {
        val c = if (i % 2 == 0) Color(0xFFFF9EC4) else Color.White
        poly(c, 1.5f, l + w * i / 6f, t + h * 0.3f, l + w * (i + 1) / 6f, t + h * 0.3f, r.center.x, t - h * 0.5f)
    }
    ln(r.center.x, t - h * 0.5f, r.center.x, t + h * 0.4f, 3f)
    rr(l + w * 0.05f, t + h * 0.38f, w * 0.9f, h * 0.45f, 8f, Color(0xFFFFE9F2))
    ci(l + w * 0.25f, t + h * 0.92f, 7f, Color(0xFF4B4568), 2f); ci(l + w * 0.75f, t + h * 0.92f, 7f, Color(0xFF4B4568), 2f)
    for (i in 0..2) { ci(l + w * (0.25f + i * 0.25f), t + h * 0.5f, 6f, listOf(Color(0xFFFF9EC4), Color(0xFFFFE066), Color(0xFF8EE6A0))[i], 1.8f) }   // ice cream scoops
}

private fun DrawScope.artBusStop(r: Rect) {
    val cx = r.center.x
    rr(cx - 3f, r.top + r.height * 0.3f, 6f, r.height * 0.7f, 2f, Color(0xFF8E8EA0), 2f)
    ci(cx, r.top + r.height * 0.22f, minOf(r.width, r.height) * 0.4f, Color(0xFFFFD86B), 3f)
    rr(cx - 9f, r.top + r.height * 0.12f, 18f, 11f, 3f, Color(0xFF4D79FF), 2f)
    ci(cx - 5f, r.top + r.height * 0.28f, 2.2f, OUT, 0f); ci(cx + 5f, r.top + r.height * 0.28f, 2.2f, OUT, 0f)
}

private fun DrawScope.artSlide(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ln(l + w * 0.08f, t + h * 0.05f, l + w * 0.08f, t + h, 5f, WOOD); ln(l + w * 0.3f, t + h * 0.05f, l + w * 0.3f, t + h, 5f, WOOD)
    for (i in 1..5) ln(l + w * 0.08f, t + h * (0.05f + i * 0.17f), l + w * 0.3f, t + h * (0.05f + i * 0.17f), 3f, WOOD)
    rr(l, t, w * 0.4f, h * 0.1f, 4f, Color(0xFFB07A4F), 2.5f)
    poly(c, 3f, l + w * 0.38f, t + h * 0.05f, l + w * 0.55f, t + h * 0.05f, l + w * 0.95f, t + h * 0.95f, l + w * 0.62f, t + h * 0.98f)
    ln(l + w * 0.42f, t + h * 0.1f, l + w * 0.72f, t + h * 0.9f, 2f, Color.White.copy(alpha = 0.7f))
}

private fun DrawScope.artSwingSet(r: Rect, c: Color) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    ln(l + w * 0.05f, t, l + w * 0.0f, t + h, 5f, WOOD); ln(l + w * 0.95f, t, l + w, t + h, 5f, WOOD)
    rr(l, t - 3f, w, 8f, 4f, Color(0xFFB07A4F), 2.5f)
    for (sx in listOf(0.3f, 0.7f)) { ln(l + w * sx - 6f, t + 5f, l + w * sx - 6f, t + h * 0.8f, 2f); ln(l + w * sx + 6f, t + 5f, l + w * sx + 6f, t + h * 0.8f, 2f); rr(l + w * sx - 10f, t + h * 0.78f, 20f, 6f, 3f, c, 2.5f) }
}

private fun DrawScope.artTramp(r: Rect, c: Color) {
    ov(r.left, r.top, r.width, r.height, OUT, 0f)
    ov(r.left + 2f, r.top + 2f, r.width - 4f, r.height - 4f, c, 0f)
    ov(r.left + r.width * 0.12f, r.top + r.height * 0.12f, r.width * 0.76f, r.height * 0.76f, shade(c, 1.15f), 3f)
}

private fun DrawScope.artFlag(r: Rect, c: Color) {
    rr(r.left + r.width * 0.2f, r.top, 4f, r.height, 2f, Color(0xFF8E8EA0), 2f)
    poly(c, 2.5f, r.left + r.width * 0.2f + 4f, r.top + 2f, r.right, r.top + r.height * 0.2f, r.left + r.width * 0.2f + 4f, r.top + r.height * 0.42f)
}

private fun DrawScope.artArcade(r: Rect) {
    val l = r.left; val t = r.top; val w = r.width; val h = r.height
    rr(l, t, w, h, 10f, Color(0xFF7B5EA7))
    rr(l + w * 0.1f, t + h * 0.1f, w * 0.8f, h * 0.45f, 5f, Color(0xFF1F1B3A), 2.5f)
    drawRect(Color(0xFF5CF2C8), Offset(l + w * 0.25f, t + h * 0.22f), Size(w * 0.18f, h * 0.12f)); drawRect(Color(0xFFFF6B9A), Offset(l + w * 0.55f, t + h * 0.3f), Size(w * 0.16f, h * 0.1f))
    ln(l + w * 0.3f, t + h * 0.8f, l + w * 0.3f, t + h * 0.68f, 3f); ci(l + w * 0.3f, t + h * 0.66f, 4f, Color(0xFFFF4D6D), 1.5f)
    ci(l + w * 0.6f, t + h * 0.78f, 4f, Color(0xFFFFD86B), 1.5f); ci(l + w * 0.78f, t + h * 0.78f, 4f, Color(0xFF8EE6A0), 1.5f)
}

private fun DrawScope.artPans(r: Rect) {
    for (i in 0..2) { val x = r.left + (i + 0.5f) * r.width / 3f; ln(x, r.top, x, r.top + 6f, 2f); ci(x, r.top + 14f, 8f, Color(0xFF8E8EA0), 2.5f) }
}

private fun DrawScope.artBoard(r: Rect) {
    rr(r.left, r.top, r.width, r.height, 3f, Color(0xFFC98D58))
    for (i in 0..2) drawRect(listOf(Color(0xFFFFF1A8), Color(0xFFFFC8DD), Color(0xFFBDE0FE))[i], Offset(r.left + 5f + i * r.width / 3.2f, r.top + 4f), Size(r.width / 4f, r.height - 8f))
}

private fun DrawScope.artKey(r: Rect) {
    ci(r.center.x - 6f, r.center.y, 7f, Color(0xFFFFD700), 2.5f); ln(r.center.x + 1f, r.center.y, r.center.x + 12f, r.center.y, 4f, Color(0xFFFFD700)); ln(r.center.x + 9f, r.center.y, r.center.x + 9f, r.center.y + 6f, 3f, Color(0xFFFFD700))
}

private fun DrawScope.artGalaxy(r: Rect) {
    rr(r.left, r.top, r.width, r.height, 5f, Color(0xFF241B5A))
    for (i in 0 until 10) drawCircle(Color.White, 1.6f, Offset(r.left + r.width * ((i * 0.37f) % 1f), r.top + r.height * ((i * 0.61f + 0.1f) % 1f)))
}

private fun DrawScope.artShelf(r: Rect) {
    rr(r.left, r.top + r.height * 0.5f, r.width, r.height * 0.5f, 4f, WOOD)
    val cols = listOf(Color(0xFFFF8A8A), Color(0xFF8EC9FF), Color(0xFFFFD86B), Color(0xFF8EE6A0))
    for (i in 0 until 5) rr(r.left + 6f + i * (r.width - 12f) / 5f, r.top - 6f, (r.width - 12f) / 5f - 2f, r.height * 0.55f + 6f, 2f, cols[i % 4], 2f)
}

private fun DrawScope.artRainbowStrip(r: Rect) {
    val cols = listOf(Color(0xFFFF8A8A), Color(0xFFFFD86B), Color(0xFF8EE6A0), Color(0xFF8EC9FF), Color(0xFFD9B3FF))
    cols.forEachIndexed { i, cc -> drawRect(cc, Offset(r.left + i * r.width / 5f, r.top), Size(r.width / 5f, r.height)) }
    drawRect(OUT, Offset(r.left, r.top), Size(r.width, r.height), style = Stroke(2.5f))
}

// ------------------------------------------------------------------ dispatcher

/** Names of the built-in (World.furniture) pieces -> art key. */
internal fun staticArtKey(name: String): String? = when {
    name.startsWith("Bed") -> "bed"
    name.startsWith("Wardrobe") -> "wardrobe"
    name == "Toy box" -> "toybox"
    name == "Sofa" -> "sofa"
    name == "TV" -> "tv"
    name == "Fireplace" -> "fireplace"
    name == "Rug" -> "rug"
    name == "Fridge" -> "fridge"
    name == "Stove" -> "stove"
    name == "Counter" -> "counter"
    name == "Table" -> "table"
    name == "Kitchen Sink" || name == "Sink" -> "sink"
    name == "Bathtub" -> "bathtub"
    name == "Shower" -> "shower"
    name == "Mirror" -> "mirror"
    name == "Big tree" || name.startsWith("Park Tree") -> "tree"
    name == "Slide" -> "slide"
    name == "Game Board" -> "arcade"
    name == "Lamp" || name == "Night Lamp" -> "lamp"
    name.startsWith("Street Lamp") -> "streetlamp"
    name == "Fountain" -> "fountain"
    name.startsWith("Bench") -> "bench"
    name == "Ice Cream Cart" -> "cart"
    name.startsWith("Bus Stop") -> "busstop"
    name == "Mailbox" -> "mailbox"
    name == "Photo Wall" -> "photowall"
    else -> null
}

/** Catalog pieces (Cozy Home) -> art key. */
internal fun catalogArtKey(f: Furn): String = when (f.cat) {
    "Sofa" -> "sofa"
    "Table" -> if (f.name.startsWith("Coffee")) "coffeetable" else if (f.name.startsWith("Side")) "sidetable" else "tvstand"
    "TV" -> "tv"
    "Lamp" -> if (f.name.contains("Fairy") || f.name.contains("String")) "fairy" else if (f.name.contains("Jar")) "jar" else "lamp"
    "Rug" -> "rug"
    "Plant" -> "plant"
    "Curtains" -> "curtains"
    "Wall Art", "Poster" -> "frame"
    "Bed" -> "bed"
    "Wardrobe" -> "wardrobe"
    "Mirror" -> "mirror"
    "Fridge" -> "fridge"
    "Stove" -> "stove"
    "Fence" -> "fence"
    "Path" -> "path"
    "Scarecrow" -> "scarecrow"
    "Slide" -> "slide"
    "Swing" -> "swingset"
    "Trampoline" -> "tramp"
    "Bathtub" -> "bathtub"
    "Towel" -> "towel"
    else -> when {
        f.name == "Photo Wall" -> "photowall"
        f.name == "Bookshelf" -> "bookshelf"
        f.name == "Fireplace" -> "fireplace"
        f.name == "Pond" -> "pond"
        f.name == "Fountain" -> "fountain"
        f.name == "Flower Bed" -> "flowerbed"
        f.name == "Big Tree" -> "tree"
        f.name == "House Flag" -> "flag"
        f.name.contains("Duck") -> "duck"
        f.name == "Desk" -> "desk"
        f.name == "Chair" -> "chair"
        f.name == "Toy Box" -> "toybox"
        f.name == "Kitchen Sink" -> "sink"
        f.name == "Counter" -> "counter"
        f.name.startsWith("Table") -> "table"
        f.name == "Shower" -> "shower"
        f.name == "Hanging Pans" -> "pans"
        f.name == "Recipe Board" -> "board"
        f.name == "Rainbow Wallpaper" -> "rainbowstrip"
        f.name == "Secret Room Key" -> "key"
        f.name == "Galaxy Ceiling" -> "galaxy"
        f.name == "Floating Shelf" -> "shelf"
        else -> "plain"
    }
}

/** Draws one piece of furniture as real-looking vector art. Returns false if there is no art for [key]. */
internal fun DrawScope.drawFurnitureArt(key: String, name: String, r: Rect, color: Color, t: Float): Boolean {
    when (key) {
        "sofa" -> artSofa(r, color, name)
        "bed" -> artBed(r, color, name)
        "wardrobe" -> artWardrobe(r, color)
        "toybox" -> artToyBox(r, color)
        "tv" -> artTv(r, color, name)
        "fireplace" -> artFireplace(r, t)
        "coffeetable" -> artTableSmall(r, color, false)
        "sidetable" -> artTableSmall(r, color, true)
        "tvstand" -> artTvStand(r, color)
        "lamp" -> artLamp(r, color, name)
        "fairy" -> artFairy(r, t)
        "jar" -> { rr(r.left + 4f, r.top + 6f, r.width - 8f, r.height - 6f, 8f, Color(0xFFE8F6FF).copy(alpha = 0.85f), 2.5f); for (i in 0..2) drawCircle(Color(0xFFFFF59D).copy(alpha = 0.6f + 0.4f * sin(t * 3f + i)), 3f, Offset(r.center.x + (i - 1) * 6f, r.center.y + sin(t * 2f + i) * 4f)) }
        "rug" -> artRug(r, color, name)
        "plant" -> artPlant(r, color, name)
        "curtains" -> artCurtains(r, color)
        "frame" -> artFrame(r, color)
        "photowall" -> artPhotoWall(r)
        "mirror" -> artMirror(r, name)
        "desk" -> artDesk(r, color)
        "chair" -> artChair(r, color)
        "bookshelf" -> artBookshelf(r)
        "fridge" -> artFridge(r, color)
        "stove" -> artStove(r, color)
        "counter" -> artCounter(r, color)
        "sink" -> artSink(r, color)
        "table" -> artTable(r, color)
        "bathtub" -> artBathtub(r, color, t)
        "shower" -> artShower(r, t)
        "duck" -> artDuck(r, color)
        "towel" -> artTowel(r, color)
        "tree" -> artTree(r)
        "bench" -> artBench(r)
        "streetlamp" -> artStreetLamp(r, t)
        "fountain" -> artFountain(r, t)
        "pond" -> artPond(r, t)
        "fence" -> artFence(r, color)
        "path" -> artPath(r, color, name)
        "flowerbed" -> artFlowerBed(r)
        "mailbox" -> artMailbox(r, false)
        "cart" -> artCart(r)
        "busstop" -> artBusStop(r)
        "slide" -> artSlide(r, color)
        "swingset" -> artSwingSet(r, color)
        "tramp" -> artTramp(r, color)
        "flag" -> artFlag(r, color)
        "arcade" -> artArcade(r)
        "pans" -> artPans(r)
        "board" -> artBoard(r)
        "key" -> artKey(r)
        "galaxy" -> artGalaxy(r)
        "shelf" -> artShelf(r)
        "rainbowstrip" -> artRainbowStrip(r)
        "scarecrow" -> drawScarecrow(r.center.x, r.top, t)
        else -> return false
    }
    return true
}
