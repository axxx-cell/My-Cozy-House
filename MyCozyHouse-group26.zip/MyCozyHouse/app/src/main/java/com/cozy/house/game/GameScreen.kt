package com.cozy.house.game

import android.Manifest
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.spring
import androidx.compose.animation.core.tween
import androidx.compose.ui.draw.scale
import android.content.pm.PackageManager
import android.graphics.Paint
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.detectDragGestures
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Slider
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.PathEffect
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import com.cozy.house.Cozy
import com.cozy.house.Session
import com.cozy.house.net.Area
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.asin
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sin
import kotlin.math.sqrt

internal val OUT = Color(0xFF5B3A4A)
private val SHIRTS = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B))
private val HAIRS = listOf(Color(0xFF7B4B3A), Color(0xFF2F2A41), Color(0xFFE9A15B), Color(0xFFB57BDB))
private val SKIN = Color(0xFFFFE0C7)

internal class Paints {
    val room = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 46f; color = 0x2E5B3A4A }
    val glyph = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 14f; isFakeBoldText = true }
    val chat = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 14f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val emoji = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER }
    val nameFill = Paint().apply { isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true; color = 0xFF5B3A4A.toInt() }
    val nameStroke = Paint().apply {
        isAntiAlias = true; textAlign = Paint.Align.CENTER; textSize = 15f; isFakeBoldText = true
        color = 0xFFFFFFFF.toInt(); style = Paint.Style.STROKE; strokeWidth = 4f
    }
}

@Composable
fun GameScreen(onExit: (String?) -> Unit) {
    val scope = rememberCoroutineScope()
    val pm = remember { PlayerManager() }
    val paints = remember { Paints() }
    var tick by remember { mutableStateOf(0L) }
    var leaving by remember { mutableStateOf(false) }
    var showEmotes by remember { mutableStateOf(false) }
    var chatOpen by remember { mutableStateOf(false) }
    var chatText by remember { mutableStateOf("") }
    var bagOpen by remember { mutableStateOf(false) }
    val coinPulse = remember { Animatable(1f) }
    val starPulse = remember { Animatable(1f) }
    LaunchedEffect(pm.coinBump) { if (pm.coinBump > 0) { coinPulse.animateTo(1.35f, tween(90)); coinPulse.animateTo(1f, spring()) } }
    LaunchedEffect(pm.starBump) { if (pm.starBump > 0) { starPulse.animateTo(1.5f, tween(90)); starPulse.animateTo(1f, spring()) } }
    val saveCtx = LocalContext.current
    LaunchedEffect(Unit) { pm.attach(saveCtx) }
    DisposableEffect(Unit) { onDispose { pm.saveNow() } }
    val ctx = LocalContext.current
    val voice = remember { VoiceManager() }
    val micLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        pm.toast = if (granted) "Mic ready! Hold 🎤 to talk" else "Mic is off. You can still chat with text!"
    }
    DisposableEffect(Unit) {
        voice.start(myNumber = { pm.myNumber() }, peers = { pm.peerIps() })
        onDispose { voice.stop() }
    }

    LaunchedEffect(Session.host, Session.client) {
        GameNet.current()?.let { pm.runNetwork(it) }
    }
    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            withFrameNanos { now ->
                if (last != 0L) pm.update(((now - last) / 1_000_000_000f).coerceAtMost(0.05f))
                last = now
                tick = now
            }
        }
    }

    fun leave() {
        if (leaving) return
        leaving = true
        scope.launch { Session.leaveAll(); onExit(null) }
    }
    BackHandler { if (pm.dialog != null) pm.dialog = null else if (pm.panel != null) pm.panel = null else if (chatOpen) chatOpen = false else if (showEmotes) showEmotes = false else leave() }

    Box(Modifier.fillMaxSize().background(Cozy.Cream)) {
        Canvas(
            Modifier.fillMaxSize()
                .graphicsLayer {                       // tilt = a slanted, 3D-ish view
                    rotationX = pm.camTilt
                    val k = 1f + pm.camTilt / 100f
                    scaleX = k; scaleY = k
                    cameraDistance = 14f * density
                    transformOrigin = TransformOrigin(0.5f, 0.5f)
                }
                .pointerInput(Unit) { detectTapGestures { off -> pm.tapScreen(off.x, off.y) } }
                .pointerInput(Unit) {                  // two fingers: pinch to zoom + drag to look around
                    awaitEachGesture {
                        awaitFirstDown(requireUnconsumed = false)
                        var prevDist = 0f
                        var prevCenter = Offset.Zero
                        do {
                            val event = awaitPointerEvent()
                            val down = event.changes.filter { it.pressed }
                            if (down.size >= 2) {
                                val a = down[0].position
                                val b = down[1].position
                                val dist = (a - b).getDistance()
                                val center = (a + b) / 2f
                                if (prevDist > 0f) {
                                    pm.zoomBy(dist / prevDist)
                                }
                                prevDist = dist
                                prevCenter = center
                                down.forEach { it.consume() }
                            } else prevDist = 0f
                        } while (event.changes.any { it.pressed })
                    }
                }
        ) {
            @Suppress("UNUSED_VARIABLE") val frame = tick
            val s = size.height / 520f * pm.camZoom
            val viewW = size.width / s
            val viewH = size.height / s
            val me = pm.me
            // the camera always follows you: your character stays exactly in the middle of the screen
            val camX = (me?.x ?: World.W / 2f) - viewW / 2f
            val camY = (me?.y ?: World.H / 2f) - 36f - viewH / 2f
            pm.camX = camX; pm.camY = camY; pm.viewScale = s

            withTransform({
                scale(s, s, Offset.Zero)
                translate(-camX, -camY)
            }) {
                drawWorld(paints, pm.farm, pm.time)
                drawHouseItems(pm, paints)
                drawKitchenFx(pm, paints)
                drawRoomFx(pm, paints)
                drawDayFx(pm)
                drawTownFx(pm, paints)
                drawNpcFx(pm, paints)
                drawRainbow(pm)
                drawPlayFx(pm, paints)
                drawMinigameFx(pm, paints)
                for (d in pm.dust) {
                    val life = 1f - d.age / 0.5f
                    drawCircle(Color(0xFFF2E3D0).copy(alpha = 0.6f * life), 3f + d.age * 14f, Offset(d.x, d.y))
                }

                for (p in pm.players.values) if (p.petType >= 0) drawPet(p, paints, pm.time)
                for (n in pm.shopkeepers + pm.walkers) drawPlayer(n, false, false, paints, n.x, n.y, carried = false, speaking = false)
                if (pm.grandmaOn) drawPlayer(pm.grandma, false, false, paints, pm.grandma.x, pm.grandma.y, carried = false, speaking = false)
                if (pm.mailmanOn) drawPlayer(pm.mailman, false, false, paints, pm.mailman.x, pm.mailman.y, carried = false, speaking = false)
                // carried players are drawn right after (on top of) their carrier
                val all = pm.players.values.sortedBy { p ->
                    val c = p.carriedBy?.let { pm.players[it] }
                    if (c != null) c.y + 0.5f else p.y
                }
                for (p in all) {
                    val c = p.carriedBy?.let { pm.players[it] }
                    val near = p.blushT > 0f || pm.players.values.any { o -> o !== p && hyp(o.x - p.x, o.y - p.y) < 90f }
                    val talk = if (p.id == pm.myId) voice.talking else voice.isSpeaking(p.id)
                    if (c != null) drawPlayer(p, p.id == pm.myId, near, paints, c.x + 8f, c.y - 36f, carried = true, speaking = talk)
                    else if (p.swing >= 0) {
                        val ax = PlayerManager.SWING_X[p.swing.coerceIn(0, 1)]
                        val th = if (p.id == pm.myId) p.swingAng else asin(((p.x - ax) / PlayerManager.SWING_L).coerceIn(-1f, 1f))
                        withTransform({ rotate(-th * 57.29578f, Offset(ax, PlayerManager.SWING_Y)) }) {
                            drawPlayer(p, p.id == pm.myId, near, paints, ax, PlayerManager.SWING_Y + PlayerManager.SWING_L, carried = false, speaking = talk)
                        }
                    }
                    else if (p.sleeping) withTransform({ rotate(-90f, Offset(p.x, p.y - 22f)) }) {
                        drawPlayer(p, p.id == pm.myId, near, paints, p.x, p.y, carried = false, speaking = talk)
                    }
                    else drawPlayer(p, p.id == pm.myId, near, paints, p.x, p.y, carried = false, speaking = talk)
                }
                drawCritters(pm, paints)
                for (q in pm.particles) drawParticle(q, paints)
                drawFloaters(pm, paints, camX, camY, s, size.width)
                drawWeather(pm, camX, camY, viewW, viewH)
                drawDayNight(pm, camX, camY, viewW, viewH)
                drawSeasonFx(pm, paints, camX, camY, viewW, viewH)
                drawSleepFx(pm, paints)
                if (me?.sleeping == true) drawRect(Color(0x990F1030), Offset(camX, camY), Size(viewW, viewH))
                if (pm.mg.game == MinigameManager.HIDE && pm.mg.itId == pm.myId && me != null) {   // seeker: blind, then flashlight
                    if (pm.mg.phase == 1) drawRect(Color.Black, Offset(camX, camY), Size(viewW, viewH))
                    else if (pm.mg.phase == 2) drawRect(
                        brush = Brush.radialGradient(
                            0f to Color.Transparent, 0.5f to Color.Transparent, 1f to Color(0xF2000014),
                            center = Offset(me.x, me.y - 30f), radius = 240f
                        ),
                        topLeft = Offset(camX, camY), size = Size(viewW, viewH)
                    )
                }
            }
        }

        // ---- top-left: leave
        Box(
            Modifier.align(Alignment.TopStart).padding(12.dp)
                .background(Cozy.Pink, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                .clickable { leave() }.padding(horizontal = 14.dp, vertical = 6.dp)
        ) { Text("✕ Leave", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }

        // ---- quests button + game clock (tap the clock to see what comes next)
        Box(
            Modifier.align(Alignment.TopStart).padding(start = 112.dp, top = 12.dp).size(34.dp)
                .background(Cozy.Yellow, CircleShape).border(3.dp, OUT, CircleShape).clickable { pm.panel = "QUESTS" },
            contentAlignment = Alignment.Center
        ) { Text("📜", fontSize = 16.sp) }
        Column(
            Modifier.align(Alignment.TopStart).padding(start = 154.dp, top = 12.dp)
                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(14.dp))
                .border(3.dp, OUT, RoundedCornerShape(14.dp)).clickable { pm.clockTap() }
                .padding(horizontal = 10.dp, vertical = 3.dp)
        ) {
            Text(pm.clockText, fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
            Box(Modifier.width(84.dp).height(5.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(3.dp))) {
                Box(Modifier.fillMaxHeight().fillMaxWidth(pm.clockFrac.coerceIn(0f, 1f)).background(Cozy.Pink, RoundedCornerShape(3.dp)))
            }
        }

        // ---- top-center: where am I
        if (pm.areaName.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(12.dp)
                    .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 14.dp, vertical = 6.dp)
            ) { Text("📍 ${pm.areaName}  ${pm.farm.weather.emoji}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- top-right: stats
        Row(
            Modifier.align(Alignment.TopEnd).padding(12.dp)
                .background(Color.White.copy(alpha = 0.85f), RoundedCornerShape(16.dp))
                .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 10.dp, vertical = 6.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            StatBar("⚡", pm.energy, Color(0xFFFFD86B))
            StatBar("🍙", pm.hunger, Color(0xFFFFA97A))
            StatBar("😊", pm.happiness, Color(0xFFFF9EC4))
            Text("🪙 ${pm.coins}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.scale(coinPulse.value))
            Text("⭐ ${pm.stars}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.scale(starPulse.value))
            Text("Lv ${pm.level}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
        }

        // ---- left side: chat, push-to-talk, mute
        Column(
            Modifier.align(Alignment.TopStart).padding(start = 12.dp, top = 58.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Box(contentAlignment = Alignment.TopEnd) {
                Box(
                    Modifier.size(44.dp).background(Cozy.Blue, CircleShape).border(3.dp, OUT, CircleShape)
                        .clickable { chatOpen = !chatOpen; if (chatOpen) pm.unread = 0 },
                    contentAlignment = Alignment.Center
                ) { Text("💬", fontSize = 20.sp) }
                if (pm.unread > 0 && !chatOpen) {
                    Box(Modifier.size(14.dp).background(Color(0xFFFF4D6D), CircleShape).border(2.dp, OUT, CircleShape))
                }
            }
            Box(
                Modifier.size(44.dp)
                    .background(if (voice.talking) Cozy.Pink else Cozy.Mint, CircleShape)
                    .border(3.dp, OUT, CircleShape)
                    .pointerInput(Unit) {
                        detectTapGestures(onPress = {
                            if (ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                                voice.startTalking()
                                tryAwaitRelease()
                                voice.stopTalking()
                            } else micLauncher.launch(Manifest.permission.RECORD_AUDIO)
                        })
                    },
                contentAlignment = Alignment.Center
            ) { Text("🎤", fontSize = 20.sp) }
            Box(
                Modifier.size(44.dp).background(if (voice.muted) Cozy.Pink else Cozy.Yellow, CircleShape)
                    .border(3.dp, OUT, CircleShape).clickable { voice.toggleMute() },
                contentAlignment = Alignment.Center
            ) { Text(if (voice.muted) "🔇" else "🔊", fontSize = 20.sp) }
        }

        // ---- chat panel
        if (chatOpen) {
            Column(
                Modifier.align(Alignment.TopCenter).padding(top = 56.dp).width(340.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(18.dp))
                    .border(3.dp, OUT, RoundedCornerShape(18.dp)).padding(10.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                if (pm.chatLog.isEmpty()) Text("Say hi to your friends! 👋", fontSize = 13.sp, color = OUT)
                pm.chatLog.takeLast(4).forEach { Text(it, fontSize = 13.sp, color = OUT) }
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                    OutlinedTextField(
                        value = chatText,
                        onValueChange = { if (it.length <= 60) chatText = it },
                        singleLine = true,
                        placeholder = { Text("Say something…", fontSize = 13.sp) },
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier.weight(1f)
                    )
                    Pill("Send") { pm.sendChat(chatText); chatText = ""; chatOpen = false }
                }
            }
        }

        // ---- seed bag (shared farm inventory)
        Column(
            Modifier.align(Alignment.TopEnd).padding(top = 64.dp, end = 12.dp),
            horizontalAlignment = Alignment.End,
            verticalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            val sel = pm.farm.selectedSeed
            Pill("🌱 ${Crop.values()[sel].emoji} ×${pm.farm.seeds[sel]}") { bagOpen = !bagOpen }
            if (bagOpen) {
                Column(
                    Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(16.dp))
                        .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(8.dp),
                    verticalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    Text("Shared with all friends", fontSize = 11.sp, color = OUT)
                    Crop.values().forEachIndexed { i, c ->
                        Row(
                            Modifier.background(if (i == sel) Cozy.Pink else Color.Transparent, RoundedCornerShape(10.dp))
                                .clickable { pm.farm.selectedSeed = i }.padding(horizontal = 8.dp, vertical = 4.dp),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("${c.emoji} ${c.label}", fontSize = 13.sp, color = OUT)
                            Text("🌱${pm.farm.seeds[i]}  🧺${pm.farm.harvested[i]}", fontSize = 13.sp, color = OUT)
                        }
                    }
                }
            }
        }

        // ---- kitchen panels (fridge / recipe book)
        when (pm.panel) {
            "RECIPES" -> Box(Modifier.align(Alignment.Center)) { RecipePanel(pm) }
            "FRIDGE" -> Box(Modifier.align(Alignment.Center)) { FridgePanel(pm) }
            "TEETH" -> Box(Modifier.align(Alignment.Center)) { TeethPanel(pm) }
            "GAMES" -> Box(Modifier.align(Alignment.Center)) { GamesPanel(pm) }
            "QUESTS" -> Box(Modifier.align(Alignment.Center)) { QuestsPanel(pm) }
            "PETS" -> Box(Modifier.align(Alignment.Center)) { PetsPanel(pm) }
            "CREATOR" -> Box(Modifier.align(Alignment.Center)) { CreatorPanel(pm, paints) }
            "WARDROBE" -> Box(Modifier.align(Alignment.Center)) { WardrobePanel(pm, paints) }
            "PHOTO" -> Box(Modifier.align(Alignment.Center)) { PhotoPanel(pm, paints) }
            "PHOTOS" -> Box(Modifier.align(Alignment.Center)) { PhotoWallPanel(pm) }
            "INVENTORY" -> Box(Modifier.align(Alignment.Center)) { InventoryPanel(pm) }
            "SHOP" -> Box(Modifier.align(Alignment.Center)) { ShopPanel(pm, paints) }
        }

        // ---- friend bonus popup
        if (pm.bonusText.isNotEmpty()) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 88.dp)
                    .background(Cozy.Pink, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 5.dp)
            ) { Text(pm.bonusText, fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = OUT) }
        }

        // ---- mini-game HUD, countdown, result
        if (pm.mg.phase != 0) {
            Box(
                Modifier.align(Alignment.TopCenter).padding(top = 52.dp)
                    .background(Cozy.Yellow, RoundedCornerShape(16.dp)).border(3.dp, OUT, RoundedCornerShape(16.dp))
                    .padding(horizontal = 14.dp, vertical = 5.dp)
            ) { Text(hudLine(pm), fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT) }
            if (pm.mg.phase == 1) {
                Text(countdownText(pm), Modifier.align(Alignment.Center), fontSize = 44.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
            if (pm.mg.phase == 3) {
                Box(
                    Modifier.align(Alignment.Center)
                        .background(Color.White.copy(alpha = 0.96f), RoundedCornerShape(20.dp))
                        .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(18.dp)
                ) { Text(resultText(pm), fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = OUT) }
            }
        }

        // ---- NPC talk bubble
        if (pm.dialog == "NPC") {
            Column(
                Modifier.align(Alignment.Center).width(340.dp)
                    .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(pm.npcName, fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                Text(pm.npcText, fontSize = 14.sp, color = OUT)
                Pill("OK") { pm.dialog = null }
            }
        }

        // ---- shopkeeper talk + bus question
        if (pm.dialog == "SHOPKEEPER" || pm.dialog == "BUS") {
            Column(
                Modifier.align(Alignment.Center).width(340.dp)
                    .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(pm.npcName, fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                Text(pm.npcText, fontSize = 14.sp, color = OUT)
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    if (pm.dialog == "SHOPKEEPER") {
                        Pill("🛍️ Shop") { pm.openShop() }
                        Pill("OK") { pm.dialog = null }
                    } else {
                        Pill("🚌 Ride (5 🪙)") { pm.rideBus() }
                        Pill("No thanks") { pm.dialog = null }
                    }
                }
            }
        }
        if (pm.riding) {
            Box(Modifier.fillMaxSize().background(Color(0xCC101030)), contentAlignment = Alignment.Center) {
                Text("🚌 Riding the bus…", fontSize = 26.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
            }
        }

        // ---- sleep question
        if (pm.dialog == "SLEEP") {
            Column(
                Modifier.align(Alignment.Center)
                    .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text("😴 Sleep until Morning?", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    Pill("YES") { pm.startSleep() }
                    Pill("NO") { pm.dialog = null }
                }
            }
        }

        // ---- toast
        pm.toast?.let {
            Box(
                Modifier.align(Alignment.BottomCenter).padding(bottom = 28.dp)
                    .background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(16.dp))
                    .border(3.dp, OUT, RoundedCornerShape(16.dp)).padding(horizontal = 16.dp, vertical = 8.dp)
            ) { Text(it, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }

        // ---- friend actions (only when a friend is close, or while carrying / carried)
        Row(
            Modifier.align(Alignment.BottomCenter).padding(bottom = 80.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            when {
                pm.onToy -> Pill("⬇️ Get off") { pm.getOffToy() }
                pm.carriedById != null -> Pill("⬇️ Get down") { pm.getDown() }
                pm.carryingId != null -> Pill("⬇️ Put down") { pm.toggleCarry() }
                pm.nearPet && pm.nearbyFriend == null -> {
                    Pill("🍖 Feed") { pm.feedPet() }
                    Pill("❤️ Pet") { pm.petPet() }
                    Pill("🐾 Info") { pm.panel = "PETS" }
                }
                pm.nearbyFriend != null -> {
                    Pill("🤗 Hug") { pm.hug() }
                    Pill("🙌 High five") { pm.highFive() }
                    Pill("🎒 Carry") { pm.toggleCarry() }
                }
            }
        }

        // ---- camera controls (also: pinch with two fingers)
        Column(
            Modifier.align(Alignment.CenterEnd).padding(end = 6.dp, bottom = 70.dp),
            verticalArrangement = Arrangement.spacedBy(4.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            CamButton(if (pm.camTilt > 10f) "🎥" else "⬆️") { pm.cycleTilt() }
            CamButton("⟲") { pm.resetCamera() }
            CamButton("📷") { pm.panel = "PHOTO" }
            CamButton("🏠") { pm.panel = "INVENTORY" }
        }

        // ---- pet button
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 126.dp, bottom = 190.dp).size(40.dp)
                .background(Cozy.Pink, CircleShape).border(3.dp, OUT, CircleShape).clickable { pm.panel = "PETS" },
            contentAlignment = Alignment.Center
        ) { Text("🐾", fontSize = 18.sp) }

        // ---- emotes
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 52.dp, bottom = 140.dp).size(64.dp)
                .background(Cozy.Yellow, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { showEmotes = !showEmotes },
            contentAlignment = Alignment.Center
        ) { Text("😊", fontSize = 28.sp) }

        if (showEmotes) {
            Column(
                Modifier.align(Alignment.BottomEnd).padding(end = 124.dp, bottom = 120.dp)
                    .background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
                    .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(8.dp),
                verticalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                Emote.values().toList().chunked(6).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { e ->
                            Box(
                                Modifier.size(44.dp).background(Cozy.Cream, CircleShape).border(2.dp, OUT, CircleShape)
                                    .clickable { pm.emote(e); showEmotes = false },
                                contentAlignment = Alignment.Center
                            ) { Text(e.emoji, fontSize = 22.sp) }
                        }
                    }
                }
            }
        }

        // ---- joystick left, interact right
        Joystick(
            Modifier.align(Alignment.BottomStart).padding(start = 28.dp, bottom = 24.dp),
            onMove = { x, y -> pm.joyX = x; pm.joyY = y }
        )
        Box(
            Modifier.align(Alignment.BottomEnd).padding(end = 36.dp, bottom = 36.dp).size(92.dp)
                .background(Cozy.Mint, CircleShape).border(4.dp, OUT, CircleShape)
                .clickable { pm.interact() },
            contentAlignment = Alignment.Center
        ) { Text("✋", fontSize = 36.sp) }
    }
}

private fun hyp(a: Float, b: Float) = sqrt(a * a + b * b)

@Composable
private fun StatBar(icon: String, value: Int, color: Color) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        Text(icon, fontSize = 16.sp)
        Box(
            Modifier.width(52.dp).height(12.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(6.dp))
                .border(2.dp, OUT, RoundedCornerShape(6.dp))
        ) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(value.coerceIn(0, 100) / 100f).background(color, RoundedCornerShape(6.dp)))
        }
    }
}

@Composable
private fun Pill(text: String, onClick: () -> Unit) {
    Box(
        Modifier.background(Color.White.copy(alpha = 0.95f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).clickable { onClick() }
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) { Text(text, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT) }
}

// ------------------------------------------------------------------ joystick

@Composable
fun Joystick(modifier: Modifier, onMove: (Float, Float) -> Unit) {
    var knob by remember { mutableStateOf(Offset.Zero) }
    Box(
        modifier.size(150.dp).pointerInput(Unit) {
            awaitEachGesture {
                val down = awaitFirstDown()
                val center = Offset(size.width / 2f, size.height / 2f)
                val radius = size.width / 2f * 0.6f
                fun update(p: Offset) {
                    var d = p - center
                    val len = d.getDistance()
                    if (len > radius) d = d * (radius / len)
                    knob = d
                    onMove(d.x / radius, d.y / radius)
                }
                update(down.position)
                var pressed = true
                while (pressed) {
                    val event = awaitPointerEvent()
                    val change = event.changes.firstOrNull { it.id == down.id }
                    if (change != null && change.pressed) {
                        update(change.position)
                        change.consume()
                    } else pressed = false
                }
                knob = Offset.Zero
                onMove(0f, 0f)
            }
        }
    ) {
        Canvas(Modifier.fillMaxSize()) {
            val c = Offset(size.width / 2f, size.height / 2f)
            drawCircle(Color.White.copy(alpha = 0.55f), size.width / 2f - 4f, c)
            drawCircle(OUT, size.width / 2f - 4f, c, style = Stroke(5f))
            drawCircle(Cozy.Pink, 30.dp.toPx(), c + knob)
            drawCircle(OUT, 30.dp.toPx(), c + knob, style = Stroke(5f))
        }
    }
}

// ------------------------------------------------------------------ drawing (world units)

internal fun DrawScope.roundRectOutlined(tl: Offset, sz: Size, radius: Float, fill: Color, stroke: Float = 4f) {
    drawRoundRect(fill, tl, sz, CornerRadius(radius))
    drawRoundRect(OUT, tl, sz, CornerRadius(radius), style = Stroke(stroke))
}

internal fun DrawScope.circleOutlined(c: Offset, r: Float, fill: Color, stroke: Float = 3f) {
    drawCircle(fill, r, c)
    drawCircle(OUT, r, c, style = Stroke(stroke))
}

private fun floorColor(a: Area) = when (a) {
    Area.BEDROOM -> Color(0xFFFFE3F0)
    Area.LIVING_ROOM -> Color(0xFFFFF3D6)
    Area.KITCHEN -> Color(0xFFE0F7EA)
    Area.BATHROOM -> Color(0xFFE0F0FF)
    Area.GARDEN -> Color(0xFFC9F0B8)
    Area.PLAYGROUND -> Color(0xFFFBE9B7)
    Area.TOWN -> Color(0xFFE8E8E8)
}

private fun DrawScope.drawWorld(paints: Paints, farm: FarmManager, time: Float) {
    val nc = drawContext.canvas.nativeCanvas

    for ((area, r) in World.rooms) {
        drawRect(floorColor(area), r.topLeft, r.size)
        if (area == Area.KITCHEN || area == Area.BATHROOM) {
            val alt = if (area == Area.KITCHEN) Color(0xFFCFF0DD) else Color(0xFFCDE6FA)
            var iy = 0
            var y = r.top
            while (y < r.bottom) {
                var ix = 0
                var x = r.left
                while (x < r.right) {
                    if ((ix + iy) % 2 == 0) drawRect(alt, Offset(x, y), Size(80f, 80f))
                    x += 80f; ix++
                }
                y += 80f; iy++
            }
        }
        nc.drawText(World.areaLabel(area), r.center.x, r.top + 80f, paints.room)
    }
    drawTownGround()

    for (f in World.furniture.sortedBy { if (it.solid) 1 else 0 }) {
        if (f.name.startsWith("Plot ")) { drawPlot(f, farm, paints, time); continue }
        if (f.name == "Scarecrow") { drawScarecrow(f.rect.center.x, f.rect.top, time); continue }
        if (f.name.startsWith("Shop ")) { drawShop(f, paints); continue }
        if (f.name == "Cat" || f.name == "Bath Mirror" || f.name == "Swing" || f.name == "Seesaw" || f.name == "Trampoline" || f.name == "Window") continue
        val key = staticArtKey(f.name)
        if (key == null || !drawFurnitureArt(key, f.name, f.rect, f.color, time)) roundRectOutlined(f.rect.topLeft, f.rect.size, 14f, f.color)
    }

    for (w in World.walls) roundRectOutlined(w.topLeft, w.size, 8f, Color(0xFFE9B8CB), 4f)
}

private fun DrawScope.drawParticle(q: Particle, paints: Paints) {
    val life = (1f - q.age / q.life).coerceIn(0f, 1f)
    if (q.kind == 0) {
        val nc = drawContext.canvas.nativeCanvas
        paints.emoji.textSize = 20f
        paints.emoji.alpha = (255 * life).toInt()
        nc.drawText("💗", q.x, q.y, paints.emoji)
        paints.emoji.alpha = 255
    } else if (q.kind == 2) {
        drawCircle(Color(0xFF7CC4FF).copy(alpha = life), 2.8f, Offset(q.x, q.y))
    } else {
        val c = q.color.copy(alpha = life)
        withTransform({ rotate(q.spin * q.age, Offset(q.x, q.y)) }) {
            drawRect(c, Offset(q.x - 4f, q.y - 2.5f), Size(8f, 5f))
        }
    }
}

internal fun DrawScope.sparkle(c: Offset, r: Float, color: Color) {
    drawLine(color, Offset(c.x - r, c.y), Offset(c.x + r, c.y), 2.5f, StrokeCap.Round)
    drawLine(color, Offset(c.x, c.y - r), Offset(c.x, c.y + r), 2.5f, StrokeCap.Round)
}

private fun wrapChat(text: String, paint: Paint, maxW: Float): List<String> {
    val lines = ArrayList<String>()
    var cur = ""
    for (w in text.split(" ").flatMap { it.chunked(18) }) {
        val trial = if (cur.isEmpty()) w else "$cur $w"
        if (cur.isEmpty() || paint.measureText(trial) <= maxW) cur = trial else { lines.add(cur); cur = w }
        if (lines.size >= 3) break
    }
    if (cur.isNotEmpty() && lines.size < 3) lines.add(cur)
    return lines
}

internal fun DrawScope.drawPlayer(
    p: PlayerState, isMe: Boolean, near: Boolean, paints: Paints,
    px: Float, py: Float, carried: Boolean, speaking: Boolean
) {
    val nc = drawContext.canvas.nativeCanvas
    val t = p.animT
    val emote = p.emote
    val et = p.emoteT
    val happy = p.happiness
    val sad = happy < 30
    val joy = happy > 80

    val run = t * (if (joy) 17f else 14f)
    var bob = if (p.moving && !carried) abs(sin(run)) * 5f else sin(t * 2.5f) * 1.5f
    val step = if (p.moving && !carried) sin(run) * 5f else 0f

    // emote body animations
    var dx = 0f
    if (emote != null) {
        if (et < 0.4f) bob += abs(sin(et / 0.4f * PI.toFloat())) * 10f      // little hop for every emote
        when (emote) {
            Emote.DANCE -> { dx = sin(et * 10f) * 6f; bob += abs(sin(et * 10f)) * 6f }
            Emote.LAUGH, Emote.ANGRY -> dx = sin(et * 40f) * 1.5f
            else -> {}
        }
    }
    val x = px + dx
    val y = py - p.z + (if (p.sitT > 0f || p.seated || p.seesaw >= 0) 8f else 0f)

    val look = p.look
    val skin = Color(Look.SKINS[look.skin.coerceIn(0, 7)])
    val headY = y - 52f - bob

    // shadow + feet (not for carried: they sit on a back)
    if (!carried) {
        drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 17f, y - 6f + p.z), Size(34f, 12f))
        drawFoot(look, x - 8f, y - 4f - max(0f, step), 7f, skin)
        drawFoot(look, x + 8f, y - 4f - max(0f, -step), 7f, skin)
    } else {
        drawFoot(look, x - 8f, y - 4f, 6f, skin)
        drawFoot(look, x + 8f, y - 4f, 6f, skin)
    }

    // hair behind, outfit, head, hair on top (all from the player's Look)
    drawHairBack(look, x, headY, run, (p.moving && !carried) || p.swing >= 0)
    drawBackpackBack(look, x, y - 32f - bob)
    drawOutfit(look, x, y, bob)
    drawBackpackStraps(look, x, y - 32f - bob)
    drawHead(look, x, headY, skin)
    drawHairFront(look, x, headY)
    drawEarrings(look, paints, x, headY, faceHW(look.face))
    if (look.hat != 0) drawHatShape(look.hat, x, headY - faceHT(look.face), faceHW(look.face))

    // eyes
    val eyeY = headY + 4f
    if (emote == Emote.COOL) {
        roundRectOutlined(Offset(x - 17f, eyeY - 7f), Size(34f, 13f), 6f, Color(0xFF2F2A41), 2.5f)
    } else {
        for (sx in listOf(-9f, 9f)) {
            val cx = x + sx + 2f * p.facing
            val closed = p.blinkLeft > 0f || emote == Emote.LAUGH || emote == Emote.SLEEPY
            if (closed) {
                drawLine(OUT, Offset(cx - 5f, eyeY), Offset(cx + 5f, eyeY), 3f, StrokeCap.Round)
            } else {
                val big = if (emote == Emote.SURPRISE) 3f else 0f
                drawEye(look, paints, cx, eyeY, sx < 0f, big)
            }
            if (emote == Emote.ANGRY) {
                val s = if (sx < 0) 1f else -1f
                drawLine(OUT, Offset(cx - 6f * s, eyeY - 13f), Offset(cx + 5f * s, eyeY - 8f), 3f, StrokeCap.Round)
            }
            if (emote == Emote.CRY) {
                val ty = eyeY + 6f + (et * 40f) % 22f
                drawCircle(Color(0xFF7CC4FF), 3f, Offset(cx, ty))
            }
        }
    }

    if (emote != Emote.COOL && emote != Emote.ANGRY) drawBrowsNose(look, x, eyeY)

    // cheeks: blush near friends, red when angry, green when sick
    val cheek = when {
        emote == Emote.ANGRY -> Color(0xFFFF4D4D).copy(alpha = 0.6f)
        emote == Emote.SICK -> Color(0xFF8FD18F).copy(alpha = 0.8f)
        near -> Color(0xFFFF7FA5).copy(alpha = 0.65f)
        else -> null
    }
    if (cheek != null) {
        drawCircle(cheek, 6f, Offset(x - 15f, eyeY + 9f))
        drawCircle(cheek, 6f, Offset(x + 15f, eyeY + 9f))
    } else drawBlush(look, paints, x, eyeY)

    // mouth: sad frown, surprised O, happy smile
    when {
        emote == Emote.SURPRISE -> circleOutlined(Offset(x, eyeY + 10f), 3.5f, Color.White, 2f)
        sad || emote == Emote.CRY || emote == Emote.SICK ->
            drawArc(OUT, 200f, 140f, false, Offset(x - 5f, eyeY + 8f), Size(10f, 8f), style = Stroke(2.5f, cap = StrokeCap.Round))
        else -> drawLookMouth(look, x, eyeY, joy)
    }

    if (look.glasses != 0 && emote != Emote.COOL) drawGlasses(look, paints, x, eyeY)

    // wave hand
    if (emote == Emote.WAVE) {
        val hx = x + 24f
        val hy = headY + 6f + sin(et * 14f) * 7f
        drawLine(OUT, Offset(x + 14f, y - 26f - bob), Offset(hx, hy), 5f, StrokeCap.Round)
        circleOutlined(Offset(hx, hy), 6f, skin, 2.5f)
    }
    if (p.tool == null) drawHandheld(look, paints, x, y, bob, t)
    // tool in hand (watering can, seeds, basket)
    val tool = p.tool
    if (tool != null) {
        paints.emoji.textSize = 22f
        paints.emoji.alpha = 255
        nc.drawText(tool, x + 26f * p.facing, headY + 24f - bob, paints.emoji)
    }
    // sleepy Zz
    if (emote == Emote.SLEEPY) {
        nc.drawText("Z", x + 24f, headY - 8f - (et * 14f) % 18f, paints.nameFill)
        nc.drawText("z", x + 34f, headY - 18f - (et * 14f) % 18f, paints.nameFill)
    }

    // name
    val nameY = headY - 30f
    nc.drawText(p.name, x, nameY, paints.nameStroke)
    nc.drawText(p.name, x, nameY, paints.nameFill)
    if (isMe) drawCircle(Cozy.Pink, 4f, Offset(x, nameY - 20f))
    if (p.umbrella) {   // raining: umbrella
        val dome = Path().apply { moveTo(x - 26f, headY - 26f); quadraticBezierTo(x, headY - 64f, x + 26f, headY - 26f); close() }
        drawPath(dome, Color(0xFFFF8FB1)); drawPath(dome, OUT, style = Stroke(3f))
        drawLine(OUT, Offset(x, headY - 26f), Offset(x, headY - 8f), 3f, StrokeCap.Round)
    }
    if (p.isIt) {   // Tag: red hat
        val hat = Path().apply { moveTo(x - 14f, headY - 18f); lineTo(x + 14f, headY - 18f); lineTo(x, headY - 46f); close() }
        drawPath(hat, Color(0xFFFF4D4D)); drawPath(hat, OUT, style = Stroke(3f))
        circleOutlined(Offset(x, headY - 47f), 4f, Color.White, 2f)
    }
    if (p.crownT > 0f) { paints.emoji.textSize = 24f; paints.emoji.alpha = 255; nc.drawText("👑", x, headY - 34f, paints.emoji) }
    if (p.ghost) { paints.emoji.textSize = 24f; paints.emoji.alpha = 255; nc.drawText("👻", x + 22f, headY - 30f, paints.emoji) }
    if (p.combo >= 2) nc.drawText("x${p.combo}", x + 32f, headY, paints.nameFill)
    if (speaking) {
        paints.emoji.textSize = 15f
        paints.emoji.alpha = 255
        nc.drawText("🔊", x + paints.nameFill.measureText(p.name) / 2f + 14f, nameY, paints.emoji)
    }

    // happy sparkles
    if (joy) {
        for (i in 0..2) {
            val a = t * 2f + i * 2.1f
            val tw = 0.5f + 0.5f * sin(t * 6f + i)
            sparkle(Offset(x + cos(a) * 32f, headY + sin(a) * 20f), 3f + 3f * tw, Color(0xFFFFC93C).copy(alpha = 0.6f + 0.4f * tw))
        }
    }
    // sad rain cloud + rain
    if (sad) {
        val cy = headY - 58f
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(OUT, r + 2.5f, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for ((ox, r) in listOf(-12f to 9f, 0f to 12f, 12f to 9f)) drawCircle(Color(0xFFC5CFE0), r, Offset(x + ox, cy + (if (ox == 0f) -5f else 0f)))
        for (i in 0..2) {
            val ry = (t * 60f + i * 13f) % 24f
            drawLine(Color(0xFF7CC4FF), Offset(x - 10f + i * 10f, cy + 12f + ry), Offset(x - 10f + i * 10f, cy + 17f + ry), 2f, StrokeCap.Round)
        }
    }

    // chat bubble (5 seconds, fades out)
    val chat = p.chat
    if (chat != null) {
        val lines = wrapChat(chat, paints.chat, 150f)
        val w = (lines.maxOfOrNull { paints.chat.measureText(it) } ?: 0f) + 18f
        val h = lines.size * 17f + 10f
        val a = if (p.chatT > 4.5f) ((5f - p.chatT) / 0.5f).coerceIn(0f, 1f) else 1f
        val bottom = headY - 100f
        val top = bottom - h
        roundRectOutlined(Offset(x - w / 2f, top), Size(w, h), 12f, Color.White.copy(alpha = a), 3f)
        val tail = Path().apply { moveTo(x - 6f, bottom - 1f); lineTo(x + 6f, bottom - 1f); lineTo(x, bottom + 8f); close() }
        drawPath(tail, Color.White.copy(alpha = a))
        drawLine(OUT.copy(alpha = a), Offset(x - 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        drawLine(OUT.copy(alpha = a), Offset(x + 6f, bottom), Offset(x, bottom + 8f), 3f, StrokeCap.Round)
        paints.chat.alpha = (255 * a).toInt()
        lines.forEachIndexed { i, l -> nc.drawText(l, x, top + 18f + i * 17f, paints.chat) }
        paints.chat.alpha = 255
    }

    // emote bubble (pops in, floats, fades out)
    if (emote != null) {
        val pop = if (et < 0.2f) 0.4f + (et / 0.2f) * 0.8f else if (et < 0.3f) 1.2f - (et - 0.2f) * 2f else 1f
        val alpha = if (et > 2.1f) ((2.5f - et) / 0.4f).coerceIn(0f, 1f) else 1f
        val bx = x
        val by = headY - 78f - min(et, 1f) * 6f
        withTransform({ scale(pop, pop, Offset(bx, by)) }) {
            roundRectOutlined(Offset(bx - 20f, by - 18f), Size(40f, 34f), 14f, Color.White.copy(alpha = alpha), 3f)
            paints.emoji.textSize = 24f
            paints.emoji.alpha = (255 * alpha).toInt()
            nc.drawText(emote.emoji, bx, by + 8f, paints.emoji)
            paints.emoji.alpha = 255
        }
    }
}

// ------------------------------------------------------------------ farm + garden drawing

private fun DrawScope.drawPlot(f: Furniture, farm: FarmManager, paints: Paints, time: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val pl = farm.plots[f.name.removePrefix("Plot ").toInt() - 1]
    val wet = pl.wetMs > 0f
    roundRectOutlined(f.rect.topLeft, f.rect.size, 12f, if (wet) Color(0xFF7A5238) else Color(0xFFD2A679))   // dark = watered, light = dry
    if (pl.crop < 0) return

    val c = Crop.values()[pl.crop]
    val ready = pl.ready()
    val cx = f.rect.center.x
    val cy = f.rect.center.y
    val (emoji, size) = when {
        ready -> c.emoji to 46f                                  // Full
        pl.growMs / FarmManager.GROW_MS >= 0.5f -> "🌿" to 34f   // Small
        else -> "🌱" to 24f                                      // Sprout
    }
    if (ready && pl.crop == Crop.SUNFLOWER.ordinal) drawCircle(Color(0xFFFFE066).copy(alpha = 0.35f), 36f, Offset(cx, cy))
    paints.emoji.alpha = 255
    paints.emoji.textSize = size
    nc.drawText(emoji, cx, cy + size * 0.35f - (if (ready) 4f else 0f), paints.emoji)

    if (ready) {
        for (i in 0..2) {
            val a = time * 2.5f + i * 2.1f
            val tw = 0.5f + 0.5f * sin(time * 7f + i)
            sparkle(Offset(cx + cos(a) * 26f, cy - 6f + sin(a) * 18f), 3f + 3f * tw, Color(0xFFFFC93C).copy(alpha = 0.6f + 0.4f * tw))
        }
    } else if (!wet) {
        paints.emoji.textSize = 16f
        nc.drawText("💧", cx + 24f, f.rect.top - 4f + sin(time * 4f) * 3f, paints.emoji)   // "water me"
    }
}

internal fun DrawScope.drawScarecrow(cx: Float, top: Float, time: Float) {
    val wood = Color(0xFFB07A4F)
    val straw = Color(0xFFF2D16B)
    roundRectOutlined(Offset(cx - 3f, top + 14f), Size(6f, 50f), 3f, wood, 3f)                 // pole
    roundRectOutlined(Offset(cx - 28f, top + 26f), Size(56f, 7f), 3f, wood, 3f)                // cross bar
    val wave = sin(time * 4f) * 9f
    drawLine(OUT, Offset(cx + 24f, top + 29f), Offset(cx + 34f, top + 14f + wave), 5f, StrokeCap.Round) // waving arm
    circleOutlined(Offset(cx + 34f, top + 12f + wave), 5f, straw, 2.5f)
    circleOutlined(Offset(cx, top + 10f), 11f, straw)                                          // head
    drawCircle(OUT, 1.8f, Offset(cx - 4f, top + 9f)); drawCircle(OUT, 1.8f, Offset(cx + 4f, top + 9f))
    drawArc(OUT, 20f, 140f, false, Offset(cx - 4f, top + 10f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
    roundRectOutlined(Offset(cx - 15f, top - 1f), Size(30f, 5f), 2f, Color(0xFFE9B44C), 2.5f)  // hat brim
    roundRectOutlined(Offset(cx - 8f, top - 13f), Size(16f, 13f), 4f, Color(0xFFE9B44C), 2.5f) // hat top
}

private fun DrawScope.drawCritters(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    for (c in pm.critters) {
        val t = c.phase
        paints.emoji.alpha = 255
        when (c.kind) {
            0 -> {   // butterfly: wings flap
                paints.emoji.textSize = 22f
                val sx = 0.55f + 0.45f * abs(sin(t * 14f))
                withTransform({ scale(sx, 1f, Offset(c.x, c.y)) }) { nc.drawText("🦋", c.x, c.y + sin(t * 3f) * 4f, paints.emoji) }
            }
            1 -> {   // bee: fast buzz
                paints.emoji.textSize = 17f
                nc.drawText("🐝", c.x + sin(t * 30f) * 1.5f, c.y + cos(t * 22f) * 2f, paints.emoji)
            }
            else -> {   // bird
                drawOval(Color.Black.copy(alpha = 0.12f), Offset(c.x - 8f, c.y + 2f), Size(16f, 6f))
                paints.emoji.textSize = 20f
                nc.drawText("🐦", c.x, c.y - (if (c.wait > 0f) abs(sin(t * 8f)) * 3f else 0f), paints.emoji)
            }
        }
    }
}

private fun DrawScope.drawWeather(pm: PlayerManager, camX: Float, camY: Float, viewW: Float, viewH: Float) {
    val me = pm.me
    val outdoors = me == null || me.area == Area.GARDEN || me.area == Area.PLAYGROUND || me.area == Area.TOWN
    if (!outdoors) return
    when (pm.farm.weather) {
        Weather.SUNNY -> {}
        Weather.CLOUDY -> drawRect(Color(0x143A4B63), Offset(camX, camY), Size(viewW, viewH))
        Weather.RAINY -> {
            drawRect(Color(0x223A4B63), Offset(camX, camY), Size(viewW, viewH))
            val rain = Color(0xAA7CC4FF)
            for (i in 0 until 70) {
                val fx = (i * 0.6180339f) % 1f
                val x = camX + fx * viewW
                val y = camY + (pm.time * 420f + i * 57f) % viewH
                drawLine(rain, Offset(x, y), Offset(x - 4f, y + 14f), 2f, StrokeCap.Round)
            }
        }
    }
}

// ------------------------------------------------------------------ kitchen panels

@Composable
private fun RecipePanel(pm: PlayerManager) {
    val k = pm.kitchen
    Column(
        Modifier.width(400.dp).heightIn(max = 300.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📖 Recipe Book  (${k.cooks} dishes cooked)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            KitchenManager.RECIPES.forEachIndexed { i, r ->
                Row(
                    Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (!k.isUnlocked(i)) {
                        Text("🔒 ???  cook ${k.cooksToUnlock(i)} more dishes to unlock", fontSize = 12.sp, color = OUT)
                    } else {
                        Column(Modifier.weight(1f)) {
                            Text("${r.emoji} ${r.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                r.needs.forEach {
                                    Text("${it.emoji}×${k.have(it)}", fontSize = 12.sp,
                                        color = if (k.have(it) > 0) OUT else Color(0xFFB3261E))
                                }
                            }
                        }
                        if (k.canCook(i)) Pill("COOK") { pm.cook(i) }
                        else Text("need more", fontSize = 11.sp, color = Color(0xFFB3261E))
                    }
                }
            }
        }
    }
}

@Composable
private fun FridgePanel(pm: PlayerManager) {
    val k = pm.kitchen
    Column(
        Modifier.width(360.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🧊 Fridge (shared)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Ing.values().toList().chunked(5).forEach { row ->
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                row.forEach { ing ->
                    Column(
                        Modifier.width(60.dp).background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(vertical = 6.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Text(ing.emoji, fontSize = 22.sp)
                        Text("×${k.have(ing)}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                        Text(ing.label, fontSize = 9.sp, color = OUT)
                    }
                }
            }
        }
        Text("Crops come from the garden. Buy more ingredients at Fresh Mart in Town (coming soon).", fontSize = 11.sp, color = OUT)
    }
}

// ------------------------------------------------------------------ kitchen world effects

private fun DrawScope.drawKitchenFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val k = pm.kitchen
    val t = pm.time
    val stove = KitchenManager.STOVE
    val cx = stove.center.x
    val cy = stove.center.y

    // ---- pot on the stove
    if (k.phase != 0) {
        roundRectOutlined(Offset(cx - 22f, cy - 14f), Size(44f, 28f), 8f, if (k.phase == 3) Color(0xFF3B3B3B) else Color(0xFF9AA5B8), 3f)
        drawLine(OUT, Offset(cx - 28f, cy - 8f), Offset(cx - 22f, cy - 8f), 4f, StrokeCap.Round)
        drawLine(OUT, Offset(cx + 22f, cy - 8f), Offset(cx + 28f, cy - 8f), 4f, StrokeCap.Round)
    }
    when (k.phase) {
        1 -> {   // bubbling + steam + progress
            for (i in 0..2) {
                val b = (t * 1.6f + i * 0.37f) % 1f
                drawCircle(Color.White.copy(alpha = 0.85f * (1f - b)), 3f + 3f * b, Offset(cx - 10f + i * 10f, cy - 6f - b * 14f))
                val s = (t * 0.8f + i * 0.33f) % 1f
                drawCircle(Color.White.copy(alpha = 0.55f * (1f - s)), 6f + 8f * s, Offset(cx - 8f + i * 8f + sin(t * 3f + i) * 3f, cy - 22f - s * 40f))
            }
            val frac = (k.t / KitchenManager.COOK_S).coerceIn(0f, 1f)
            drawRoundRect(Color.White, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f))
            drawRoundRect(Color(0xFF7ED67E), Offset(cx - 25f, cy - 62f), Size(50f * frac, 8f), CornerRadius(4f))
            drawRoundRect(OUT, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f), style = Stroke(2f))
        }
        2 -> {   // ready! hurry before it burns
            val r = KitchenManager.RECIPES[k.recipe.coerceIn(0, KitchenManager.RECIPES.size - 1)]
            paints.emoji.alpha = 255
            paints.emoji.textSize = 28f
            nc.drawText(r.emoji, cx, cy - 30f - abs(sin(t * 4f)) * 6f, paints.emoji)
            sparkle(Offset(cx + 22f, cy - 44f), 4f + 3f * abs(sin(t * 6f)), Color(0xFFFFC93C))
            val left = (1f - k.t / KitchenManager.BURN_S).coerceIn(0f, 1f)
            val bar = if (left > 0.4f) Color(0xFFFFD86B) else Color(0xFFFF6B6B)
            drawRoundRect(Color.White, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f))
            drawRoundRect(bar, Offset(cx - 25f, cy - 62f), Size(50f * left, 8f), CornerRadius(4f))
            drawRoundRect(OUT, Offset(cx - 25f, cy - 62f), Size(50f, 8f), CornerRadius(4f), style = Stroke(2f))
        }
        3 -> {   // burnt: black smoke + funny face
            for (i in 0..4) {
                val s = (t * 0.7f + i * 0.2f) % 1f
                drawCircle(Color(0xFF2B2B2B).copy(alpha = 0.6f * (1f - s)), 8f + 14f * s, Offset(cx + sin(t * 2f + i) * 8f, cy - 18f - s * 60f))
            }
            paints.emoji.alpha = 255
            paints.emoji.textSize = 28f
            nc.drawText("🤪", cx, cy - 26f, paints.emoji)
        }
    }

    // ---- plates on the table
    val table = KitchenManager.TABLE
    val slots = listOf(
        Offset(table.left + 45f, table.top + 40f), Offset(table.right - 45f, table.top + 40f),
        Offset(table.left + 45f, table.bottom - 36f), Offset(table.right - 45f, table.bottom - 36f),
    )
    k.plates.forEachIndexed { i, rIdx ->
        if (i < slots.size) {
            circleOutlined(slots[i], 20f, Color.White, 3f)
            paints.emoji.alpha = 255
            paints.emoji.textSize = 26f
            nc.drawText(KitchenManager.RECIPES[rIdx.coerceIn(0, KitchenManager.RECIPES.size - 1)].emoji, slots[i].x, slots[i].y + 9f, paints.emoji)
        }
    }

    // ---- dirty dishes at the sink (flies when it piles up)
    val sink = KitchenManager.SINK
    val px = sink.center.x
    val py = sink.bottom + 22f
    for (i in 0 until minOf(k.dirty, 5)) {
        paints.emoji.alpha = 255
        paints.emoji.textSize = 22f
        nc.drawText("🍽️", px, py - i * 7f, paints.emoji)
    }
    if (k.dirty >= 4) {
        for (i in 0..2) {
            val a = t * 4f + i * 2.1f
            val fx = px + cos(a) * 28f
            val fy = py - 14f + sin(a * 1.3f) * 16f
            drawCircle(OUT, 2.4f, Offset(fx, fy))
            drawCircle(Color.White.copy(alpha = 0.7f), 2f, Offset(fx - 2f, fy - 2.5f))
        }
    }

    // ---- fridge opens: ingredients bounce out
    if (pm.fridgeOpenT > 0f) {
        val f = KitchenManager.FRIDGE
        drawRoundRect(Color(0xFFBFE9FF), Offset(f.left - 14f, f.top + 6f), Size(14f, f.height - 12f), CornerRadius(4f))
        drawRoundRect(OUT, Offset(f.left - 14f, f.top + 6f), Size(14f, f.height - 12f), CornerRadius(4f), style = Stroke(3f))
        val items = listOf("🥛", "🥚", "🧀")
        items.forEachIndexed { i, e ->
            paints.emoji.alpha = 255
            paints.emoji.textSize = 20f
            nc.drawText(e, f.center.x + (i - 1) * 24f, f.bottom + 26f - abs(sin(t * 9f + i)) * 16f, paints.emoji)
        }
    }
}

// ------------------------------------------------------------------ living room, bedroom, bathroom

private val DREAMS = listOf("🌈", "🍰", "🦄", "🐶", "☁️", "🎠")

@Composable
private fun TeethPanel(pm: PlayerManager) {
    var progress by remember { mutableStateOf(0f) }
    var brushX by remember { mutableStateOf(0.5f) }
    Column(
        Modifier.width(340.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🪥 Swipe left and right to brush!", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Box(
            Modifier.fillMaxWidth().height(120.dp).pointerInput(Unit) {
                detectDragGestures { change, drag ->
                    change.consume()
                    brushX = (change.position.x / size.width).coerceIn(0f, 1f)
                    progress = min(1f, progress + abs(drag.x) / 2600f)
                    if (progress >= 1f) pm.finishBrush()
                }
            }
        ) {
            Canvas(Modifier.fillMaxSize()) {
                val w = size.width
                val h = size.height
                drawRoundRect(Color(0xFFFFB3C6), Offset(0f, h * 0.15f), Size(w, h * 0.7f), CornerRadius(h * 0.35f))
                drawRoundRect(OUT, Offset(0f, h * 0.15f), Size(w, h * 0.7f), CornerRadius(h * 0.35f), style = Stroke(5f))
                val tw = w / 7.8f
                for (i in 0..5) {
                    val x = w * 0.07f + i * (tw + w * 0.02f)
                    drawRoundRect(Color.White, Offset(x, h * 0.25f), Size(tw, h * 0.5f), CornerRadius(16f))
                    drawRoundRect(OUT, Offset(x, h * 0.25f), Size(tw, h * 0.5f), CornerRadius(16f), style = Stroke(3f))
                    drawCircle(Color(0xFFD9B26F).copy(alpha = (1f - progress).coerceIn(0f, 1f)), 7f, Offset(x + tw / 2f, h * 0.42f + (i % 2) * 18f))
                    if (progress > 0.85f) sparkle(Offset(x + tw * 0.75f, h * 0.3f), 6f, Color(0xFFFFC93C))
                }
                for (i in 0..5) {   // foam
                    drawCircle(Color.White.copy(alpha = 0.85f), 5f + i % 3 * 2f, Offset(brushX * w + (i - 3) * 9f, h * 0.5f + (i % 2) * 14f - 7f))
                }
                drawRoundRect(Color(0xFF8EC9FF), Offset(brushX * w - 9f, h * 0.02f), Size(18f, h * 0.5f), CornerRadius(8f))
                drawRoundRect(OUT, Offset(brushX * w - 9f, h * 0.02f), Size(18f, h * 0.5f), CornerRadius(8f), style = Stroke(3f))
            }
        }
        Box(Modifier.fillMaxWidth().height(12.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(6.dp)).border(2.dp, OUT, RoundedCornerShape(6.dp))) {
            Box(Modifier.fillMaxHeight().fillMaxWidth(progress.coerceIn(0f, 1f)).background(Cozy.Mint, RoundedCornerShape(6.dp)))
        }
    }
}

private fun DrawScope.drawRoomFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time

    // ---- TV: 3 cartoon channels (+ static while changing, black when off)
    val tv = World.furniture.first { it.name == "TV" }.rect
    drawRoundRect(Color(0xFF2B2B3A), Offset(tv.left + 6f, tv.top + 4f), Size(tv.width - 12f, tv.height - 8f), CornerRadius(8f))
    val sx = tv.left + 12f; val sy = tv.top + 10f; val sw = tv.width - 24f; val sh = tv.height - 20f
    when {
        pm.tv == 3 -> drawRoundRect(Color(0xFF1A1A24), Offset(sx, sy), Size(sw, sh), CornerRadius(6f))
        pm.tvStatic > 0f -> for (i in 0 until 12) {
            val g = (sin(t * 50f + i * 7.3f) + 1f) / 2f
            drawRect(Color(g, g, g), Offset(sx, sy + i * sh / 12f), Size(sw, sh / 12f))
        }
        pm.tv == 0 -> {   // bouncing ball
            drawRect(Color(0xFFBDE0FE), Offset(sx, sy), Size(sw, sh))
            val u = (t * 0.5f) % 2f
            val fx = if (u < 1f) u else 2f - u
            circleOutlined(Offset(sx + 10f + fx * (sw - 20f), sy + sh - 12f - abs(sin(t * 4f)) * (sh - 24f)), 8f, Color(0xFFFF6B6B), 2f)
        }
        pm.tv == 1 -> {   // sunny sky with clouds
            drawRect(Color(0xFFFFF1A8), Offset(sx, sy), Size(sw, sh))
            circleOutlined(Offset(sx + sw * 0.25f, sy + sh * 0.45f), 10f, Color(0xFFFFA94D), 2f)
            for (i in 0..1) {
                val cx = sx + 8f + ((t * 22f + i * sw / 2f) % (sw - 16f))
                drawCircle(Color.White, 7f, Offset(cx, sy + sh * 0.3f + i * 14f))
                drawCircle(Color.White, 5f, Offset(cx + 7f, sy + sh * 0.3f + i * 14f + 2f))
            }
        }
        else -> {         // dancing bars
            drawRect(Color(0xFF3A2D6B), Offset(sx, sy), Size(sw, sh))
            val cols = listOf(Color(0xFFFF9EC4), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFF8EC9FF))
            val bw = (sw - 16f) / 8f
            for (i in 0..7) {
                val bh = (0.3f + 0.7f * abs(sin(t * 3f + i))) * (sh - 8f)
                drawRect(cols[i % 4], Offset(sx + 8f + i * bw, sy + sh - 4f - bh), Size(bw - 2f, bh))
            }
        }
    }

    // ---- fireplace flicker
    val fp = World.furniture.first { it.name == "Fireplace" }.rect
    for (i in 0..2) {
        val fx = fp.center.x - 20f + i * 20f
        val fh = 16f + 9f * abs(sin(t * 9f + i * 2f))
        drawCircle(Color(0xFFFF8A3D), 9f, Offset(fx, fp.bottom - 16f - fh / 2f))
        drawCircle(Color(0xFFFFD86B), 5f, Offset(fx, fp.bottom - 14f - fh / 3f))
        val sp = (t * 1.5f + i * 0.33f) % 1f
        drawCircle(Color(0xFFFFD86B).copy(alpha = 1f - sp), 2f, Offset(fx + sin(t * 4f + i) * 6f, fp.bottom - 24f - sp * 30f))
    }

    // ---- sleeping cat on the rug (wags its tail when petted)
    val cat = World.furniture.first { it.name == "Cat" }.rect
    val cx = cat.center.x
    val cy = cat.center.y
    val wag = pm.catWagT > 0f
    val a = if (wag) sin(t * 14f) * 0.6f else sin(t * 1.5f) * 0.08f
    drawLine(OUT, Offset(cx - 26f, cy + 2f), Offset(cx - 26f - 22f * cos(a), cy - 8f - 22f * sin(a)), 9f, StrokeCap.Round)
    drawLine(Color(0xFFF4B26B), Offset(cx - 26f, cy + 2f), Offset(cx - 26f - 22f * cos(a), cy - 8f - 22f * sin(a)), 5f, StrokeCap.Round)
    drawOval(OUT, Offset(cx - 30f, cy - 19f), Size(60f, 38f))
    drawOval(Color(0xFFF4B26B), Offset(cx - 28f, cy - 17f), Size(56f, 34f))
    drawLine(Color(0xFFD98B3A), Offset(cx - 8f, cy - 15f), Offset(cx - 8f, cy - 4f), 3f, StrokeCap.Round)
    drawLine(Color(0xFFD98B3A), Offset(cx + 2f, cy - 16f), Offset(cx + 2f, cy - 5f), 3f, StrokeCap.Round)
    circleOutlined(Offset(cx + 24f, cy - 2f), 14f, Color(0xFFF4B26B), 3f)
    val ear = Path().apply { moveTo(cx + 12f, cy - 12f); lineTo(cx + 15f, cy - 26f); lineTo(cx + 22f, cy - 14f); close() }
    val ear2 = Path().apply { moveTo(cx + 28f, cy - 14f); lineTo(cx + 34f, cy - 26f); lineTo(cx + 37f, cy - 10f); close() }
    drawPath(ear, Color(0xFFF4B26B)); drawPath(ear2, Color(0xFFF4B26B))
    if (wag) {
        drawArc(OUT, 200f, 140f, false, Offset(cx + 15f, cy - 8f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
        drawArc(OUT, 200f, 140f, false, Offset(cx + 27f, cy - 8f), Size(8f, 5f), style = Stroke(2f, cap = StrokeCap.Round))
    } else {
        drawLine(OUT, Offset(cx + 16f, cy - 5f), Offset(cx + 22f, cy - 5f), 2.5f, StrokeCap.Round)   // sleeping eyes
        drawLine(OUT, Offset(cx + 28f, cy - 5f), Offset(cx + 34f, cy - 5f), 2.5f, StrokeCap.Round)
        nc.drawText("z", cx + 38f, cy - 22f - (t * 10f) % 14f, paints.nameFill)
    }

    // ---- bathroom: mirror that fogs up after a shower, rubber duck in the tub
    val bm = World.furniture.first { it.name == "Bath Mirror" }.rect
    roundRectOutlined(bm.topLeft, bm.size, 10f, Color(0xFFE8F8FF), 4f)
    drawLine(Color.White, Offset(bm.left + 14f, bm.bottom - 6f), Offset(bm.left + 34f, bm.top + 6f), 4f, StrokeCap.Round)
    val fog = (pm.fogT / 5f).coerceIn(0f, 0.9f)
    if (fog > 0f) drawRoundRect(Color.White.copy(alpha = fog), bm.topLeft, bm.size, CornerRadius(10f))
    val tub = World.furniture.first { it.name == "Bathtub" }.rect
    paints.emoji.alpha = 255
    paints.emoji.textSize = 26f
    nc.drawText("🦆", tub.center.x + sin(t * 1.2f) * 30f, tub.center.y + 8f + sin(t * 2.4f) * 3f, paints.emoji)
}

private fun DrawScope.drawSleepFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time
    for (p in pm.players.values) {
        if (!p.sleeping) continue
        paints.emoji.alpha = 255
        paints.emoji.textSize = 20f
        nc.drawText("💤", p.x + 20f, p.y - 70f - (t * 14f) % 16f, paints.emoji)
        drawCircle(Color.White, 3f, Offset(p.x + 14f, p.y - 96f))
        drawCircle(Color.White, 5f, Offset(p.x + 22f, p.y - 108f))
        roundRectOutlined(Offset(p.x + 16f, p.y - 150f), Size(44f, 36f), 14f, Color.White, 3f)
        paints.emoji.textSize = 24f
        nc.drawText(DREAMS[(p.dream + (p.sleepT / 3f).toInt()) % DREAMS.size], p.x + 38f, p.y - 124f, paints.emoji)
    }
}

// ------------------------------------------------------------------ playground drawing

private fun DrawScope.drawPlayFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas

    // ---- trampoline
    val tr = World.furniture.first { it.name == "Trampoline" }.rect
    drawOval(OUT, Offset(tr.left - 3f, tr.top - 3f), Size(tr.width + 6f, tr.height + 6f))
    drawOval(Color(0xFFFF9EC4), Offset(tr.left, tr.top), Size(tr.width, tr.height))
    drawOval(Color(0xFF8EC9FF), Offset(tr.left + 14f, tr.top + 12f), Size(tr.width - 28f, tr.height - 24f))
    drawOval(OUT, Offset(tr.left + 14f, tr.top + 12f), Size(tr.width - 28f, tr.height - 24f), style = Stroke(3f))

    // ---- swing frame + chains (chains follow whoever is swinging)
    for (xs in listOf(1905f, 2095f)) {
        drawLine(OUT, Offset(xs, 740f), Offset(xs - 16f, 905f), 6f, StrokeCap.Round)
        drawLine(OUT, Offset(xs, 740f), Offset(xs + 16f, 905f), 6f, StrokeCap.Round)
    }
    roundRectOutlined(Offset(1895f, 734f), Size(210f, 14f), 6f, Color(0xFFB07A4F), 3f)
    for (s in 0..1) {
        val ax = PlayerManager.SWING_X[s]
        val occ = pm.players.values.firstOrNull { it.swing == s }
        val th = occ?.let {
            if (it.id == pm.myId) it.swingAng else asin(((it.x - ax) / PlayerManager.SWING_L).coerceIn(-1f, 1f))
        } ?: 0f
        val sx = ax + PlayerManager.SWING_L * sin(th)
        val sy = PlayerManager.SWING_Y + PlayerManager.SWING_L * cos(th)
        drawLine(OUT, Offset(ax - 8f, PlayerManager.SWING_Y), Offset(sx - 8f, sy), 2.5f)
        drawLine(OUT, Offset(ax + 8f, PlayerManager.SWING_Y), Offset(sx + 8f, sy), 2.5f)
        roundRectOutlined(Offset(sx - 14f, sy - 2f), Size(28f, 7f), 3f, Color(0xFFFFD86B), 2.5f)
    }

    // ---- seesaw: the plank follows the riders
    val l = pm.players.values.firstOrNull { it.seesaw == 0 }
    val r = pm.players.values.firstOrNull { it.seesaw == 1 }
    val base = PlayerManager.SEE_Y
    val yL = l?.y ?: if (r != null) base - PlayerManager.SEE_A else base
    val yR = r?.y ?: if (l != null) base - PlayerManager.SEE_A else base
    val a = Offset(PlayerManager.SEE_X[0] - 30f, yL + 12f)
    val b = Offset(PlayerManager.SEE_X[1] + 30f, yR + 12f)
    drawLine(OUT, a, b, 17f, StrokeCap.Round)
    drawLine(Color(0xFFFFB38A), a, b, 11f, StrokeCap.Round)
    val pivot = Path().apply { moveTo(2018f, 1102f); lineTo(2062f, 1102f); lineTo(2040f, 1062f); close() }
    drawPath(pivot, Color(0xFFFFD86B))
    drawPath(pivot, OUT, style = Stroke(3f))
    if ((l == null) != (r == null)) {
        val lone = l ?: r!!
        nc.drawText("needs a friend!", lone.x, lone.y - 86f, paints.nameFill)
    }
}

// ------------------------------------------------------------------ mini-games

private val GAME_INFO = listOf(
    "",
    "One player is IT (red hat). Run! Least time as IT wins 👑",
    "Hide for 15 seconds, then the seeker hunts with a flashlight. Found = ghost 👻",
    "3 laps around the garden. First across the line wins!",
    "Tap the balloons to pop them. Most pops wins!",
)

private fun hudLine(pm: PlayerManager): String {
    val mg = pm.mg
    @Suppress("UNUSED_VARIABLE") val v = mg.ver
    val me = pm.myId
    val g = mg.game.coerceIn(1, 4)
    val role = when (g) {
        MinigameManager.TAG -> if (mg.itId == me) "You are IT! 🔴" else "Run! ${pm.players[mg.itId]?.name ?: "?"} is IT"
        MinigameManager.HIDE -> if (mg.itId == me) "Find everyone! 🔦" else if (me in mg.ghosts) "You were found 👻" else "Hide! 🙈"
        MinigameManager.RACE -> "Lap ${min(MinigameManager.LAPS, (mg.lap[me] ?: 0) + 1)}/${MinigameManager.LAPS}"
        else -> "Pops: ${mg.scores[me] ?: 0}"
    }
    return "${MinigameManager.EMOJI[g]} ${MinigameManager.NAMES[g]} • ${mg.sec}s • $role"
}

private fun countdownText(pm: PlayerManager): String {
    val mg = pm.mg
    return if (mg.game == MinigameManager.HIDE) {
        if (mg.itId == pm.myId) "Counting… ${mg.sec}" else "Hide! ${mg.sec}"
    } else if (mg.sec > 0) "${mg.sec}" else "GO!"
}

private fun resultText(pm: PlayerManager): String {
    val mg = pm.mg
    @Suppress("UNUSED_VARIABLE") val v = mg.ver
    val names = mg.winners.mapNotNull { pm.players[it]?.name }
    return if (names.isEmpty()) "No winner this time 🙈" else "🏆 ${names.joinToString(" & ")} won!  +20 coins"
}

@Composable
private fun GamesPanel(pm: PlayerManager) {
    val n = pm.players.size
    Column(
        Modifier.width(400.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🎮 Mini-games  ($n players)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        for (g in 1..4) {
            val ok = n >= MinigameManager.MIN_PLAYERS[g]
            Row(
                Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text("${MinigameManager.EMOJI[g]} ${MinigameManager.NAMES[g]}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
                    Text(GAME_INFO[g] + if (ok) "" else "  (needs ${MinigameManager.MIN_PLAYERS[g]}+ players)", fontSize = 11.sp, color = OUT)
                }
                if (ok) Pill("PLAY") { pm.requestGame(g) }
            }
        }
    }
}

private val BALLOON_COLORS = listOf(Color(0xFFFF9EC4), Color(0xFF8EC9FF), Color(0xFF8EE6A0), Color(0xFFFFD86B), Color(0xFFD9B3FF))

private fun DrawScope.drawMinigameFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val mg = pm.mg
    val t = pm.time

    // ---- race track
    if (mg.game == MinigameManager.RACE && mg.phase in 1..2) {
        val dash = PathEffect.dashPathEffect(floatArrayOf(18f, 14f))
        for (i in 0..3) {
            val j = (i + 1) % 4
            drawLine(Color(0xFFFFB400).copy(alpha = 0.6f), Offset(MinigameManager.CPX[i], MinigameManager.CPY[i]),
                Offset(MinigameManager.CPX[j], MinigameManager.CPY[j]), 10f, StrokeCap.Round, pathEffect = dash)
        }
        for (i in 0..3) {
            val c = Offset(MinigameManager.CPX[i], MinigameManager.CPY[i])
            circleOutlined(c, 22f, if (i == 0) Color.White else Color(0xFFFFE9A8), 3f)
            paints.emoji.alpha = 255
            paints.emoji.textSize = 22f
            nc.drawText(if (i == 0) "🏁" else "$i", c.x, c.y + 8f, if (i == 0) paints.emoji else paints.nameFill)
        }
        val next = mg.cp[pm.myId] ?: 1
        drawCircle(Color(0xFFFF4D6D), 34f + 6f * sin(t * 6f), Offset(MinigameManager.CPX[next], MinigameManager.CPY[next]), style = Stroke(4f))
    }

    // ---- balloons
    if (mg.game == MinigameManager.BALLOON && mg.phase == 2) {
        val el = mg.elapsed()
        for (i in 0 until 32) {
            if (i in mg.popped) continue
            val b = mg.balloonAt(i, el) ?: continue
            val col = BALLOON_COLORS[i % 5]
            drawLine(OUT.copy(alpha = 0.6f), Offset(b.x, b.y + 25f), Offset(b.x + sin(t * 3f + i) * 6f, b.y + 54f), 2f)
            drawOval(OUT, Offset(b.x - 20f, b.y - 26f), Size(40f, 52f))
            drawOval(col, Offset(b.x - 17f, b.y - 23f), Size(34f, 46f))
            drawOval(Color.White.copy(alpha = 0.6f), Offset(b.x - 10f, b.y - 17f), Size(8f, 13f))
            drawCircle(col, 3.5f, Offset(b.x, b.y + 26f))
        }
    }
}

// ------------------------------------------------------------------ day / night, quests

@Composable
private fun QuestsPanel(pm: PlayerManager) {
    Column(
        Modifier.width(380.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("📜 Daily Quests", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        pm.quests.today.forEach { q ->
            Row(
                Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Column(Modifier.weight(1f)) {
                    Text("${q.emoji} ${q.text}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                    Box(Modifier.fillMaxWidth().height(8.dp).background(Color(0xFFF1E4EA), RoundedCornerShape(4.dp)).border(2.dp, OUT, RoundedCornerShape(4.dp))) {
                        Box(Modifier.fillMaxHeight().fillMaxWidth((q.progress.toFloat() / q.goal).coerceIn(0f, 1f)).background(Cozy.Mint, RoundedCornerShape(4.dp)))
                    }
                }
                Text("${min(q.progress, q.goal)}/${q.goal}", fontSize = 12.sp, color = OUT)
                if (q.claimed) Text("✅", fontSize = 16.sp)
                else if (q.progress >= q.goal) Pill("CLAIM") { pm.claimQuest(q) }
            }
        }
        Text("Each quest: 50 coins + 1 ⭐ + XP. New quests every day!", fontSize = 11.sp, color = OUT)
    }
}

/** The living-room window: sun by day, moon at night. */
private fun DrawScope.drawDayFx(pm: PlayerManager) {
    val w = World.furniture.first { it.name == "Window" }.rect
    val c = pm.clock
    val sky = when (c.phase()) {
        0 -> Color(0xFFFFE3A3); 1 -> Color(0xFF9AD8FF); 2 -> Color(0xFFFFA45C); else -> Color(0xFF0B1B4D)
    }
    roundRectOutlined(w.topLeft, w.size, 8f, sky, 4f)
    if (c.nightFactor() > 0.4f) {
        drawCircle(Color(0xFFFFF4C2), 9f, Offset(w.center.x + 6f, w.center.y - 6f))
        drawCircle(sky, 8f, Offset(w.center.x + 11f, w.center.y - 9f))      // crescent
        drawCircle(Color.White, 1.5f, Offset(w.left + 12f, w.top + 12f))
        drawCircle(Color.White, 1.5f, Offset(w.right - 14f, w.bottom - 16f))
    } else {
        val u = (c.frac() / 0.75f).coerceIn(0f, 1f)
        drawCircle(Color(0xFFFFD84D), 8f, Offset(w.left + 12f + u * (w.width - 24f), w.top + 34f - sin(u * 3.14159f) * 20f))
    }
    drawLine(OUT, Offset(w.center.x, w.top), Offset(w.center.x, w.bottom), 3f)
    drawLine(OUT, Offset(w.left, w.center.y), Offset(w.right, w.center.y), 3f)
}

private fun DrawScope.drawDayNight(pm: PlayerManager, camX: Float, camY: Float, viewW: Float, viewH: Float) {
    val c = pm.clock
    val t = pm.time
    val me = pm.me
    val outdoors = me == null || me.area == Area.GARDEN || me.area == Area.PLAYGROUND || me.area == Area.TOWN
    val k = if (outdoors) 1f else 0.45f

    // colour of the day (golden morning, orange sunset, blue night)
    val tint = c.tint()
    drawRect(tint.copy(alpha = tint.alpha * k), Offset(camX, camY), Size(viewW, viewH))

    val nf = c.nightFactor()
    if (outdoors && nf > 0.05f) {                      // twinkling stars
        for (i in 0 until 40) {
            val sx = camX + ((i * 0.618f) % 1f) * viewW
            val sy = camY + ((i * 0.382f + 0.13f * i) % 1f) * viewH
            drawCircle(Color.White.copy(alpha = nf * (0.35f + 0.65f * abs(sin(t * 2f + i)))), 1.6f, Offset(sx, sy))
        }
    }
    if (nf > 0.05f) {                                  // lamps you placed glow too
        for (pi in pm.house.placed) {
            val f = FurnitureCatalog.byId(pi.item) ?: continue
            if (f.kind != "lamp") continue
            val ctr = pm.house.rectOf(pi, f).center
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFE08A).copy(alpha = 0.6f * nf), Color.Transparent), center = ctr, radius = 120f),
                radius = 120f, center = ctr
            )
        }
    }
    if (nf > 0.05f) {                                  // lamps switch on by themselves
        for (name in listOf("Lamp", "Night Lamp")) {
            val r = World.furniture.first { it.name == name }.rect
            val ctr = r.center
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFFFFE08A).copy(alpha = 0.6f * nf), Color.Transparent), center = ctr, radius = 120f),
                radius = 120f, center = ctr
            )
        }
        if (pm.tv != 3) {                              // TV glow
            val tv = World.furniture.first { it.name == "TV" }.rect
            drawCircle(
                brush = Brush.radialGradient(listOf(Color(0xFF8EC9FF).copy(alpha = 0.35f * nf), Color.Transparent), center = tv.center, radius = 110f),
                radius = 110f, center = tv.center
            )
        }
    }
    val ff = c.fireflyFactor()
    if (outdoors && ff > 0.05f) {                      // fireflies in the garden
        for (i in 0 until 14) {
            val x = 1200f + sin(t * 0.4f + i * 1.7f) * 330f + sin(t * 1.3f + i) * 20f
            val y = 960f + cos(t * 0.35f + i * 2.3f) * 250f
            val pulse = 0.5f + 0.5f * sin(t * 3f + i * 1.9f)
            drawCircle(Color(0xFFFFF176).copy(alpha = 0.25f * ff * pulse), 12f, Offset(x, y))
            drawCircle(Color(0xFFFFF59D).copy(alpha = 0.9f * ff * pulse), 2.5f, Offset(x, y))
        }
    }
}

// ------------------------------------------------------------------ pets

@Composable
private fun PetsPanel(pm: PlayerManager) {
    Column(
        Modifier.width(360.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🐾 Your pet", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        if (!pm.hasPet) {
            Text("Adopt a friend! (free for now, more pets come to the Pet Shop in Town)", fontSize = 12.sp, color = OUT)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("🐱 Cat") { pm.adoptPet(0) }
                Pill("🐶 Dog") { pm.adoptPet(1) }
                Pill("🐰 Bunny") { pm.adoptPet(2) }
            }
        } else {
            Text("${PetCatalog.list[pm.petKind.coerceIn(0, 6)].emoji} ${pm.petName}", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            Row(horizontalArrangement = Arrangement.spacedBy(14.dp)) {
                StatBar("🍖", pm.petHunger, Color(0xFFFFA97A))
                StatBar("😊", pm.petHappy, Color(0xFFFF9EC4))
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("🍖 Feed") { pm.feedPet() }
                Pill("❤️ Pet") { pm.petPet() }
            }
            if (pm.ownedPets.size > 1) {
                Text("Your pets (tap to bring along):", fontSize = 11.sp, color = OUT)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { pm.ownedPets.forEach { t -> Pill(PetCatalog.list[t].emoji) { pm.switchPet(t) } } }
            }
            Text("Stand next to your pet to feed or pet it. It follows you, sleeps when you rest, and digs up coins in the garden!", fontSize = 11.sp, color = OUT)
        }
    }
}

private fun DrawScope.drawPet(p: PlayerState, paints: Paints, t: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val x = p.petX
    val y = p.petY
    val bob = if (p.petMoving) abs(sin(t * 12f)) * 5f else sin(t * 2.2f)
    drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 12f, y - 4f), Size(24f, 8f))
    val e = PetCatalog.list.getOrNull(p.petType)?.emoji ?: "🐾"
    paints.emoji.alpha = 255
    paints.emoji.textSize = 28f
    withTransform({ scale(if (p.petFace < 0) -1f else 1f, 1f, Offset(x, y)) }) {
        nc.drawText(e, x, y - 4f - bob, paints.emoji)
    }
    if (p.look.hat != 0) {   // the pet wears a little matching hat
        withTransform({ translate(x, y - 22f); scale(0.45f, 0.45f, Offset.Zero) }) { drawHatShape(p.look.hat, 0f, 0f, 22f) }
    }
    if (p.petSleep) nc.drawText("z", x + 14f, y - 30f - (t * 10f) % 12f, paints.nameFill)
    if (p.petBubbleT > 0f && p.petBubble.isNotEmpty()) {
        paints.emoji.textSize = 20f
        nc.drawText(p.petBubble, x, y - 42f - (2f - p.petBubbleT).coerceAtLeast(0f) * 4f, paints.emoji)
    }
    if (p.petName.isNotBlank()) nc.drawText(p.petName, x, y + 18f, paints.nameFill)
}

// ------------------------------------------------------------------ NPCs, rainbow, seasons

private fun DrawScope.drawNpcFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time
    paints.emoji.alpha = 255
    paints.emoji.textSize = 22f
    if (pm.grandmaOn) nc.drawText("💬", pm.grandma.x + 24f, pm.grandma.y - 96f - abs(sin(t * 3f)) * 4f, paints.emoji)
    val box = World.furniture.first { it.name == "Mailbox" }.rect
    if (pm.mailReady()) nc.drawText("📬", box.center.x, box.top - 8f - abs(sin(t * 3f)) * 4f, paints.emoji)   // flag is up: you have mail
}

private fun DrawScope.drawRainbow(pm: PlayerManager) {
    if (pm.rainbowT <= 0f) return
    val fade = (pm.rainbowT / 5f).coerceIn(0f, 1f)
    val cols = listOf(0xFFFF6B6B, 0xFFFFA94D, 0xFFFFE066, 0xFF8EE6A0, 0xFF74C0FC, 0xFF9775FA, 0xFFD0A2F7)
    val cx = 1200f
    val cy = 1250f
    for ((i, c) in cols.withIndex()) {
        val r = 400f - i * 14f
        drawArc(Color(c).copy(alpha = 0.5f * fade), 180f, 180f, false, Offset(cx - r, cy - r), Size(r * 2f, r * 2f), style = Stroke(14f))
    }
}

private fun DrawScope.drawSeasonFx(pm: PlayerManager, paints: Paints, camX: Float, camY: Float, viewW: Float, viewH: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time
    val season = pm.season()
    if (season == 0) return
    paints.emoji.alpha = 255
    if (season == 1) {   // Halloween: pumpkins + floating ghosts
        paints.emoji.textSize = 34f
        for ((x, y) in listOf(840f to 600f, 1560f to 600f, 830f to 1240f, 1570f to 1240f, 2360f to 600f)) nc.drawText("🎃", x, y, paints.emoji)
        paints.emoji.textSize = 30f
        for (i in 0..3) {
            val gx = 900f + i * 220f + sin(t * 0.7f + i) * 40f
            val gy = (if (i % 2 == 0) 300f else 1000f) + sin(t * 1.3f + i * 2f) * 20f
            nc.drawText("👻", gx, gy, paints.emoji)
        }
    } else {              // Christmas: tree + snow
        paints.emoji.textSize = 70f
        nc.drawText("🎄", 1520f, 590f, paints.emoji)
        val me = pm.me
        if (me == null || me.area == Area.GARDEN || me.area == Area.PLAYGROUND || me.area == Area.TOWN) {
            for (i in 0 until 60) {
                val x = camX + ((i * 0.618f) % 1f) * viewW + sin(t + i) * 10f
                val y = camY + (t * 40f + i * 37f) % viewH
                drawCircle(Color.White.copy(alpha = 0.85f), 2.2f, Offset(x, y))
            }
        }
    }
}

// ------------------------------------------------------------------ Town

@Composable
private fun BuyRow(emoji: String, name: String, note: String, price: String, can: Boolean, need: String, onBuy: () -> Unit) {
    Row(
        Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp)
    ) {
        Column(Modifier.weight(1f)) {
            Text("$emoji $name", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
            if (note.isNotEmpty()) Text(note, fontSize = 11.sp, color = OUT)
        }
        Text(price, fontSize = 18.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
        Pill(if (can) "Buy" else need) { onBuy() }
    }
}

@Composable
private fun ShopPanel(pm: PlayerManager, paints: Paints) {
    val shop = TownData.shops.firstOrNull { it.id == pm.shopId }
    Column(
        Modifier.width(430.dp).heightIn(max = 310.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("${shop?.emoji ?: "🛍️"} ${shop?.name ?: "Shop"}", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Text("🪙 ${pm.coins}  ⭐ ${pm.stars}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
            Pill("✕") { pm.panel = null }
        }
        if (pm.marketDay()) Text("🎉 Market Day! Everything is 20% off", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD6336C))
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            when (pm.shopId) {
                "mart" -> {
                    val deal = pm.dealKey()
                    val dealName = if (deal.startsWith("seed")) "${Crop.values()[deal.removePrefix("seed").toInt()].label} seeds"
                        else Ing.values().first { it.pantryIdx == deal.removePrefix("ing").toInt() }.label
                    Text("🏷️ Daily deal: $dealName is 50% off!", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD6336C))
                    Crop.values().forEach { c ->
                        val key = "seed${c.ordinal}"
                        val p = pm.price(5, key)
                        BuyRow(c.emoji, "${c.label} seeds", if (key == deal) "🏷️ DEAL" else "", "$p 🪙", pm.coins >= p, "Need ${p - pm.coins} more!") { pm.buyItem(key, 5) }
                    }
                    Ing.values().filter { it.pantryIdx >= 0 }.forEach { ing ->
                        val key = "ing${ing.pantryIdx}"
                        val p = pm.price(8, key)
                        BuyRow(ing.emoji, ing.label, if (key == deal) "🏷️ DEAL" else "", "$p 🪙", pm.coins >= p, "Need ${p - pm.coins} more!") { pm.buyItem(key, 8) }
                    }
                }
                "pet" -> PetCatalog.list.forEach { d ->
                    val owned = d.type in pm.ownedPets
                    val stock = pm.petStock[d.type]
                    val p = if (d.stars > 0) d.stars else pm.price(d.coins, "pet${d.type}")
                    val have = if (d.stars > 0) pm.stars else pm.coins
                    val note = when {
                        owned -> "owned ✓"
                        d.rare && stock <= 0 -> "Sold out! Back tomorrow"
                        d.rare -> "Only 1 left!"
                        else -> ""
                    }
                    BuyRow(d.emoji, d.name, note, if (d.stars > 0) "$p ⭐" else "$p 🪙", owned || (have >= p && !(d.rare && stock <= 0)),
                        if (d.rare && stock <= 0) "Sold out" else "Need ${p - have} more!") { pm.buyPet(d) }
                }
                "cafe" -> {
                    Text("Friends sitting near you share your treat (+Energy +Happiness for all)!", fontSize = 11.sp, color = OUT)
                    listOf("🍰" to "Cake", "🍕" to "Pizza", "🧋" to "Bubble Tea", "🍨" to "Ice Cream").forEachIndexed { i, (e, n) ->
                        val p = pm.price(10, "cafe$i")
                        BuyRow(e, n, "", "$p 🪙", pm.coins >= p, "Need ${p - pm.coins} more!") { pm.buyCafe(i) }
                    }
                }
                "style" -> StyleItems(pm, paints)
                "home" -> HomeShop(pm)
                "toy" -> {
                    val p = pm.price(10, "arcade")
                    BuyRow("🕹️", "Arcade game", "Win a 30 coin prize (1 in 3)!", "$p 🪙", pm.coins >= p, "Need ${p - pm.coins} more!") { pm.playArcade() }
                    Accessories.ALL.filter { it.shop == "toy" && !pm.ownsAcc(it) }.forEach { a ->
                        val tp = pm.accPrice(a)
                        BuyRow(a.emoji, a.name, "toy to hold", "$tp 🪙", pm.coins >= tp, "Need ${tp - pm.coins} more!") { pm.buyAcc(a) }
                    }
                    Text("Hold your toys: Wardrobe > 🎈 Held tab.", fontSize = 11.sp, color = OUT)
                }
                else -> Text(
                    if (pm.shopId == "style") "Outfits arrive with the Wardrobe update! 👗" else "Furniture arrives with the House decorating update! 🛋️",
                    fontSize = 13.sp, color = OUT
                )
            }
        }
    }
}

private fun DrawScope.drawTownGround() {
    val top = 1280f
    drawRect(Color(0xFFEFE6DA), Offset(0f, top), Size(2400f, 220f))            // stone plaza behind the shops
    drawRect(Color(0xFFF5F0E6), Offset(0f, 1450f), Size(2400f, 50f))           // sidewalk (north)
    drawRect(Color(0xFF8A8FA3), Offset(0f, 1500f), Size(2400f, 120f))          // road
    drawRect(Color(0xFFF5F0E6), Offset(0f, 1620f), Size(2400f, 60f))          // sidewalk (south)
    drawRect(Color(0xFFC9F0B8), Offset(0f, 1680f), Size(2400f, 236f))          // park
    var x = 20f
    while (x < 2400f) { drawRect(Color.White.copy(alpha = 0.85f), Offset(x, 1557f), Size(46f, 6f)); x += 90f }   // road line
    var cx = 1150f
    while (cx < 1260f) { drawRect(Color.White, Offset(cx, 1505f), Size(8f, 110f)); cx += 14f }                  // crosswalk
    drawLine(OUT.copy(alpha = 0.25f), Offset(0f, 1500f), Offset(2400f, 1500f), 3f)
    drawLine(OUT.copy(alpha = 0.25f), Offset(0f, 1620f), Offset(2400f, 1620f), 3f)
}

private fun DrawScope.drawShop(f: Furniture, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val def = TownData.shops.first { "Shop ${it.id}" == f.name }
    val r = f.rect
    roundRectOutlined(r.topLeft, r.size, 16f, def.color, 5f)
    // windows
    roundRectOutlined(Offset(r.left + 24f, r.top + 70f), Size(64f, 46f), 8f, Color(0xFFDDF3FF), 3f)
    roundRectOutlined(Offset(r.right - 88f, r.top + 70f), Size(64f, 46f), 8f, Color(0xFFDDF3FF), 3f)
    // door
    roundRectOutlined(Offset(r.center.x - 24f, r.bottom - 62f), Size(48f, 62f), 8f, Color(0xFFB07A4F), 3f)
    drawCircle(OUT, 3f, Offset(r.center.x + 14f, r.bottom - 30f))
    // striped awning
    var ax = r.left + 6f
    var k = 0
    while (ax < r.right - 6f) {
        drawRect(if (k % 2 == 0) Color.White else Color(0xFFFF9EC4), Offset(ax, r.top + 46f), Size(28f, 16f))
        ax += 28f; k++
    }
    drawRoundRect(OUT, Offset(r.left + 6f, r.top + 46f), Size(r.width - 12f, 16f), CornerRadius(4f), style = Stroke(3f))
    // sign
    roundRectOutlined(Offset(r.left + 40f, r.top + 8f), Size(r.width - 80f, 32f), 10f, Color.White, 3f)
    paints.emoji.alpha = 255
    paints.emoji.textSize = 18f
    nc.drawText(def.emoji, r.left + 58f, r.top + 31f, paints.emoji)
    paints.nameFill.textSize = 13f
    nc.drawText(def.name, r.center.x + 10f, r.top + 29f, paints.nameFill)
    paints.nameFill.textSize = 15f
}

private fun DrawScope.drawTownFx(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    val t = pm.time
    // cars
    for (i in 0..3) {
        val x = TownData.carX(i, t)
        val y = TownData.carY(i)
        val col = TownData.carColors[i % 4]
        val dir = if (i % 2 == 0) 1f else -1f
        drawOval(Color.Black.copy(alpha = 0.15f), Offset(x - 36f, y + 12f), Size(72f, 12f))
        roundRectOutlined(Offset(x - 36f, y - 14f), Size(72f, 28f), 10f, col, 3f)
        roundRectOutlined(Offset(x - 18f, y - 26f), Size(36f, 16f), 8f, Color(0xFFDDF3FF), 3f)
        circleOutlined(Offset(x - 20f, y + 14f), 7f, Color(0xFF5B3A4A), 2f)
        circleOutlined(Offset(x + 20f, y + 14f), 7f, Color(0xFF5B3A4A), 2f)
        drawCircle(Color(0xFFFFF59D), 4f, Offset(x + dir * 34f, y - 2f))
    }
    // pigeons
    paints.emoji.alpha = 255
    paints.emoji.textSize = 18f
    for (i in 0..5) {
        val px = 200f + i * 380f + sin(t * 0.5f + i) * 60f
        val py = 1710f + sin(t * 0.4f + i * 2f) * 40f
        nc.drawText("🕊️", px, py - abs(sin(t * 6f + i)) * 3f, paints.emoji)
    }
    // fountain water
    val f = World.furniture.first { it.name == "Fountain" }.rect
    for (i in 0..4) {
        val u = (t * 1.2f + i * 0.2f) % 1f
        drawCircle(Color(0xFF8EC9FF).copy(alpha = 1f - u), 3f, Offset(f.center.x + (i - 2) * 9f, f.center.y - 10f - sin(u * 3.14159f) * 26f + u * 12f))
    }
}

// ------------------------------------------------------------------ floating "+5 Coins!"

private fun DrawScope.drawFloaters(pm: PlayerManager, paints: Paints, camX: Float, camY: Float, s: Float, screenW: Float) {
    val nc = drawContext.canvas.nativeCanvas
    val tx = camX + (screenW - 110f) / s          // the coin counter in the top bar
    val ty = camY + 28f / s
    for (f in pm.floaters) {
        val age = pm.time - f.t0
        val a = (1f - age / 1.4f).coerceIn(0f, 1f)
        paints.nameFill.textSize = 18f; paints.nameStroke.textSize = 18f
        paints.nameFill.alpha = (255 * a).toInt(); paints.nameStroke.alpha = (255 * a).toInt()
        nc.drawText(f.text, f.x, f.y - age * 40f, paints.nameStroke)
        nc.drawText(f.text, f.x, f.y - age * 40f, paints.nameFill)
        paints.nameFill.textSize = 15f; paints.nameStroke.textSize = 15f
        paints.nameFill.alpha = 255; paints.nameStroke.alpha = 255
        val u = ((age - 0.35f) / 0.8f)
        if (u in 0f..1f) {                         // the coin flies up to the top bar
            val cx = f.x + (tx - f.x) * u
            val cy = (f.y - 14f) + (ty - (f.y - 14f)) * u - sin(u * 3.14159f) * 30f
            paints.emoji.alpha = 255
            paints.emoji.textSize = 20f
            nc.drawText(f.emoji, cx, cy, paints.emoji)
        }
    }
}

// ------------------------------------------------------------------ character creator

@Composable
private fun ColorDots(colors: List<Int>, selected: Int, onPick: (Int) -> Unit) {
    colors.chunked(8).forEachIndexed { r, row ->
        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            row.forEachIndexed { c, col ->
                val i = r * 8 + c
                Box(
                    Modifier.size(30.dp).background(Color(col), CircleShape)
                        .border(if (i == selected) 4.dp else 2.dp, OUT, CircleShape).clickable { onPick(i) }
                )
            }
        }
    }
}

@Composable
private fun OptionPills(names: List<String>, selected: Int, perRow: Int, onPick: (Int) -> Unit) {
    names.chunked(perRow).forEachIndexed { r, row ->
        Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            row.forEachIndexed { c, n ->
                val i = r * perRow + c
                Box(
                    Modifier.background(if (i == selected) Cozy.Pink else Color.White, RoundedCornerShape(12.dp))
                        .border(2.dp, OUT, RoundedCornerShape(12.dp)).clickable { onPick(i) }
                        .padding(horizontal = 8.dp, vertical = 4.dp)
                ) { Text(n, fontSize = 11.sp, color = OUT) }
            }
        }
    }
}

@Composable
private fun RgbSliders(color: Int, onChange: (Int) -> Unit) {
    val r = (color shr 16) and 0xFF
    val g = (color shr 8) and 0xFF
    val b = color and 0xFF
    fun rgb(rr: Int, gg: Int, bb: Int) = (0xFF shl 24) or (rr shl 16) or (gg shl 8) or bb
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("R", fontSize = 11.sp, color = OUT)
        Slider(value = r / 255f, onValueChange = { onChange(rgb((it * 255).toInt(), g, b)) }, modifier = Modifier.weight(1f))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("G", fontSize = 11.sp, color = OUT)
        Slider(value = g / 255f, onValueChange = { onChange(rgb(r, (it * 255).toInt(), b)) }, modifier = Modifier.weight(1f))
    }
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text("B", fontSize = 11.sp, color = OUT)
        Slider(value = b / 255f, onValueChange = { onChange(rgb(r, g, (it * 255).toInt())) }, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun CreatorPanel(pm: PlayerManager, paints: Paints) {
    var tab by remember { mutableStateOf(0) }
    val look = pm.myLook
    val tabs = listOf("Skin", "Face", "Eyes", "Brows", "Nose", "Mouth", "Blush", "Hair", "Hair color", "Outfit", "Outfit color", "Personality", "Voice")
    val preview = remember { PlayerState("preview", "", 0) }
    preview.name = pm.me?.name ?: ""
    preview.updateLook(look)
    var t by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { n -> t = n / 1_000_000_000f } } }

    Row(
        Modifier.fillMaxWidth(0.94f).height(300.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.width(150.dp).fillMaxHeight().background(Cozy.Cream, RoundedCornerShape(16.dp)).border(2.dp, OUT, RoundedCornerShape(16.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val frame = t
                val sc = size.height / 150f
                preview.animT = t
                withTransform({ translate(size.width / 2f, size.height * 0.9f); scale(sc, sc, Offset.Zero) }) {
                    drawPlayer(preview, false, false, paints, 0f, 0f, false, false)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                tabs.forEachIndexed { i, n ->
                    Box(
                        Modifier.background(if (i == tab) Cozy.Pink else Color.White, RoundedCornerShape(12.dp))
                            .border(2.dp, OUT, RoundedCornerShape(12.dp)).clickable { tab = i }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) { Text(n, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OUT) }
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                when (tab) {
                    0 -> ColorDots(Look.SKINS, look.skin) { pm.applyLook(look.copy(skin = it)) }
                    1 -> OptionPills(Look.FACES, look.face, 4) { pm.applyLook(look.copy(face = it)) }
                    2 -> OptionPills(Look.EYES, look.eyes, 4) { pm.applyLook(look.copy(eyes = it)) }
                    3 -> OptionPills(Look.BROWS, look.brows, 3) { pm.applyLook(look.copy(brows = it)) }
                    4 -> OptionPills(Look.NOSES, look.nose, 4) { pm.applyLook(look.copy(nose = it)) }
                    5 -> OptionPills(Look.MOUTHS, look.mouth, 4) { pm.applyLook(look.copy(mouth = it)) }
                    6 -> OptionPills(Look.BLUSHES, look.blush, 5) { pm.applyLook(look.copy(blush = it)) }
                    7 -> {
                        Text("Style: ${Look.HAIRS[look.hair.coerceIn(0, 29)].name}", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
                        OptionPills((1..30).map { "$it" }, look.hair, 10) { pm.applyLook(look.copy(hair = it)) }
                    }
                    8 -> {
                        ColorDots(Look.HAIR_COLORS, Look.HAIR_COLORS.indexOf(look.hairColor)) { pm.applyLook(look.copy(hairColor = Look.HAIR_COLORS[it])) }
                        Text("Custom colour:", fontSize = 11.sp, color = OUT)
                        RgbSliders(look.hairColor) { pm.applyLook(look.copy(hairColor = it)) }
                        Pill(if (look.highlight) "✨ Highlight ON" else "Highlight OFF") { pm.applyLook(look.copy(highlight = !look.highlight)) }
                        if (look.highlight) {
                            ColorDots(Look.HIGHLIGHT_COLORS, Look.HIGHLIGHT_COLORS.indexOf(look.highlightColor)) { pm.applyLook(look.copy(highlightColor = Look.HIGHLIGHT_COLORS[it])) }
                        }
                    }
                    9 -> OptionPills(Look.OUTFITS, look.outfit, 3) { pm.applyLook(look.copy(outfit = it)) }
                    10 -> {
                        ColorDots(Look.OUTFIT_COLORS, Look.OUTFIT_COLORS.indexOf(look.outfitColor)) { pm.applyLook(look.copy(outfitColor = Look.OUTFIT_COLORS[it])) }
                        Text("Custom colour:", fontSize = 11.sp, color = OUT)
                        RgbSliders(look.outfitColor) { pm.applyLook(look.copy(outfitColor = it)) }
                    }
                    11 -> OptionPills(Look.PERSONALITIES, look.personality, 4) { pm.applyLook(look.copy(personality = it)) }
                    else -> OptionPills(Look.VOICES, look.voice, 4) { pm.applyLook(look.copy(voice = it)) }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("🎲 Random") { pm.applyLook(Look.random()) }
                Pill("✔ Done") { pm.panel = null; pm.saveNow() }
            }
        }
    }
}

// ------------------------------------------------------------------ wardrobe + Style Star

@Composable
private fun MiniAvatar(look: Look, paints: Paints, box: Dp) {
    val pv = remember { PlayerState("mini", "", 0) }
    pv.updateLook(look)
    Canvas(Modifier.size(box)) {
        val sc = size.height / 120f
        withTransform({ translate(size.width / 2f, size.height * 0.94f); scale(sc, sc, Offset.Zero) }) {
            drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
        }
    }
}

@Composable
private fun StyleItems(pm: PlayerManager, paints: Paints) {
    val todo = Wardrobe.ALL.filter { it.id !in pm.ownedGarments }
    if (pm.outfitVouchers > 0) Text("🎟️ You have ${pm.outfitVouchers} free outfit voucher(s)! Tap FREE on any piece.", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = Color(0xFFD6336C))
    Text("Your avatar wears it in the picture, so you can see how it looks!", fontSize = 11.sp, color = OUT)
    if (todo.isEmpty()) Text("You own everything! ✨", fontSize = 13.sp, color = OUT)
    todo.forEach { g ->
        val p = pm.garmentPrice(g)
        Row(
            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MiniAvatar(pm.myLook.copy(garment = g.id, outfitColor = g.color), paints, 62.dp)
            Column(Modifier.weight(1f)) {
                Text(g.name, fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
                Text(g.cat.label, fontSize = 11.sp, color = OUT)
            }
            Text("$p 🪙", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            if (pm.outfitVouchers > 0) Pill("FREE 🎟️") { pm.buyGarment(g.id, true) }
            Pill(if (pm.coins >= p) "Buy" else "Need ${p - pm.coins} more!") { pm.buyGarment(g.id, false) }
        }
    }
    AccessoryShop(pm, paints)
}

@Composable
private fun WardrobePanel(pm: PlayerManager, paints: Paints) {
    var tab by remember { mutableStateOf(0) }
    val look = pm.myLook
    val preview = remember { PlayerState("wardrobe", "", 0) }
    preview.name = pm.me?.name ?: ""
    preview.updateLook(look)
    var t by remember { mutableStateOf(0f) }
    LaunchedEffect(Unit) { while (true) { withFrameNanos { n -> t = n / 1_000_000_000f } } }
    val tabs = listOf("All", "Tops", "Bottoms", "Dresses", "Onesies", "Sets", "🎨 Colors", "🎩 Hats", "👓 Glasses", "💎 Earrings", "🎒 Packs", "👟 Shoes", "🎈 Held", "⭐ Looks")
    val accCats = listOf("hat", "glasses", "earrings", "backpack", "shoes", "handheld")
    val cats = listOf(null, GCat.TOP, GCat.BOTTOM, GCat.DRESS, GCat.ONESIE, GCat.SET)

    Row(
        Modifier.fillMaxWidth(0.94f).height(300.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // dressing-room mirror: the avatar turns around
        Box(Modifier.width(150.dp).fillMaxHeight().background(Cozy.Cream, RoundedCornerShape(16.dp)).border(2.dp, OUT, RoundedCornerShape(16.dp))) {
            Canvas(Modifier.fillMaxSize()) {
                @Suppress("UNUSED_VARIABLE") val frame = t
                val sc = size.height / 150f
                val spin = 0.3f + 0.7f * abs(cos(t * 1.2f))
                preview.animT = t
                withTransform({ translate(size.width / 2f, size.height * 0.9f); scale(sc * spin, sc, Offset.Zero) }) {
                    drawPlayer(preview, false, false, paints, 0f, 0f, false, false)
                }
            }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                tabs.forEachIndexed { i, n ->
                    Box(
                        Modifier.background(if (i == tab) Cozy.Pink else Color.White, RoundedCornerShape(12.dp))
                            .border(2.dp, OUT, RoundedCornerShape(12.dp)).clickable { tab = i }
                            .padding(horizontal = 8.dp, vertical = 4.dp)
                    ) { Text(n, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OUT) }
                }
            }
            Column(Modifier.weight(1f).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                if (tab == 6) {
                    Text("Colour of what you wear (20 colours + your own mix):", fontSize = 11.sp, color = OUT)
                    ColorDots(Look.OUTFIT_COLORS, Look.OUTFIT_COLORS.indexOf(look.outfitColor)) { pm.applyLook(look.copy(outfitColor = Look.OUTFIT_COLORS[it])) }
                    RgbSliders(look.outfitColor) { pm.applyLook(look.copy(outfitColor = it)) }
                } else if (tab == 13) {
                    LooksTab(pm)
                } else if (tab >= 7) {
                    AccessoryList(pm, accCats[(tab - 7).coerceIn(0, 5)])
                } else {
                    if (tab == 0) {
                        Row(
                            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("🎀 Starter outfit (from the creator)", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.weight(1f))
                            if (look.garment == 0) Text("✓ Wearing", fontSize = 12.sp, color = Color(0xFF2E7D32)) else Pill("Wear") { pm.equipGarment(0) }
                        }
                    }
                    val owned = Wardrobe.ALL.filter { it.id in pm.ownedGarments && (cats[tab] == null || it.cat == cats[tab]) }
                    if (owned.isEmpty()) Text("Nothing here yet. Buy clothes at Style Star in Town! 👗", fontSize = 12.sp, color = OUT)
                    owned.forEach { g ->
                        Row(
                            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Column(Modifier.weight(1f)) {
                                Text(g.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                                Text(g.cat.label, fontSize = 10.sp, color = OUT)
                            }
                            if (look.garment == g.id) Text("✓ Wearing", fontSize = 12.sp, color = Color(0xFF2E7D32)) else Pill("Wear") { pm.equipGarment(g.id) }
                        }
                    }
                }
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("🎲 Surprise me") { pm.surprise() }
                Pill("📷 Photo") { pm.panel = "PHOTO" }
                Pill("✔ Done") { pm.panel = null; pm.saveNow() }
            }
        }
    }
}

// ------------------------------------------------------------------ accessories UI

@Composable
private fun AccessoryList(pm: PlayerManager, cat: String) {
    val cur = pm.myLook.accOf(cat)
    val label = Accessories.CAT_LABEL[cat] ?: cat
    Row(
        Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(if (cat == "shoes") "👟 Starter shoes" else "None", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.weight(1f))
        if (cur == 0) Text("✓ Wearing", fontSize = 12.sp, color = Color(0xFF2E7D32)) else Pill("Wear") { pm.equipAcc(cat, 0) }
    }
    val owned = Accessories.of(cat).filter { pm.ownsAcc(it) }
    if (owned.isEmpty()) Text("No $label yet. Buy some at Style Star in Town! 🛍️", fontSize = 12.sp, color = OUT)
    owned.forEach { a ->
        Row(
            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Text("${a.emoji} ${a.name}", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.weight(1f))
            if (cur == a.id) Text("✓ Wearing", fontSize = 12.sp, color = Color(0xFF2E7D32)) else Pill("Wear") { pm.equipAcc(cat, a.id) }
        }
    }
}

@Composable
private fun AccessoryShop(pm: PlayerManager, paints: Paints) {
    val items = Accessories.ALL.filter { it.shop == "style" && it.price >= 0 && !pm.ownsAcc(it) }
    if (items.isEmpty()) return
    Text("✨ Accessories", fontSize = 14.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
    items.forEach { a ->
        val price = if (a.stars > 0) a.stars else pm.accPrice(a)
        val have = if (a.stars > 0) pm.stars else pm.coins
        Row(
            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            MiniAvatar(pm.myLook.withAcc(a.cat, a.id), paints, 62.dp)
            Column(Modifier.weight(1f)) {
                Text("${a.emoji} ${a.name}", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = OUT)
                Text(Accessories.CAT_LABEL[a.cat] ?: a.cat, fontSize = 11.sp, color = OUT)
            }
            Text(if (a.stars > 0) "$price ⭐" else "$price 🪙", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            Pill(if (have >= price) "Buy" else "Need ${price - have} more!") { pm.buyAcc(a) }
        }
    }
}

@Composable
private fun CamButton(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(34.dp).background(Color.White.copy(alpha = 0.9f), CircleShape).border(3.dp, OUT, CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT) }
}

// ------------------------------------------------------------------ saved looks, photo mode, photo wall

@Composable
private fun LooksTab(pm: PlayerManager) {
    val names = listOf("🎒 School", "🎉 Party", "😴 Sleep", "🌱 Farming", "🏙️ Town")
    Text("Save what you wear right now into a slot, wear it again with one tap.", fontSize = 11.sp, color = OUT)
    names.forEachIndexed { i, n ->
        Row(
            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Column(Modifier.weight(1f)) {
                Text(n, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                Text(if (pm.savedLooks[i].isEmpty()) "empty" else "saved ✓", fontSize = 10.sp, color = OUT)
            }
            Pill("Save now") { pm.saveLookSlot(i) }
            if (pm.savedLooks[i].isNotEmpty()) Pill("Wear") { pm.wearLookSlot(i) }
        }
    }
}

@Composable
private fun PhotoPanel(pm: PlayerManager, paints: Paints) {
    val ctx = LocalContext.current
    var pose by remember { mutableStateOf(0) }
    var bg by remember { mutableStateOf(0) }
    val name = pm.me?.name ?: ""
    Row(
        Modifier.fillMaxWidth(0.94f).height(300.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(10.dp),
        horizontalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        Box(Modifier.size(270.dp).background(Cozy.Cream, RoundedCornerShape(16.dp)).border(2.dp, OUT, RoundedCornerShape(16.dp))) {
            Canvas(Modifier.fillMaxSize()) { drawPhotoScene(pm.myLook, name, pose, bg, paints, size.width, size.height) }
        }
        Column(Modifier.weight(1f).fillMaxHeight(), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("📷 Photo Mode", fontSize = 16.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            Text("Pose", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
            OptionPills(PhotoStore.POSES, pose, 4) { pose = it }
            Text("Background", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
            OptionPills(PhotoStore.BACKGROUNDS, bg, 3) { bg = it }
            Spacer(Modifier.weight(1f))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Pill("📸 Take photo") { pm.photoSaved(PhotoStore.save(ctx, PhotoStore.render(pm.myLook, name, pose, bg, paints))) }
                Pill("🖼️ Wall") { pm.panel = "PHOTOS" }
                Pill("✕") { pm.panel = null }
            }
        }
    }
}

@Composable
private fun PhotoWallPanel(pm: PlayerManager) {
    val ctx = LocalContext.current
    var files by remember { mutableStateOf(PhotoStore.list(ctx)) }
    var open by remember { mutableStateOf<java.io.File?>(null) }
    Column(
        Modifier.width(430.dp).heightIn(max = 310.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Text("🖼️ Photo Wall (${files.size}/50)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("📷 New") { pm.panel = "PHOTO" }
            Pill("✕") { pm.panel = null }
        }
        val big = open
        if (big != null) {
            val bmp = remember(big) { android.graphics.BitmapFactory.decodeFile(big.path)?.asImageBitmap() }
            if (bmp != null) Image(bmp, contentDescription = null, modifier = Modifier.size(190.dp).align(Alignment.CenterHorizontally))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), modifier = Modifier.align(Alignment.CenterHorizontally)) {
                Pill("⬅ Back") { open = null }
                Pill("🗑️ Delete") { PhotoStore.list(ctx).firstOrNull { it.path == big.path }?.delete(); files = PhotoStore.list(ctx); open = null }
            }
        } else {
            if (files.isEmpty()) Text("No photos yet. Take one in Photo Mode! 📸", fontSize = 12.sp, color = OUT)
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                files.chunked(4).forEach { row ->
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        row.forEach { f ->
                            val opts = android.graphics.BitmapFactory.Options().apply { inSampleSize = 4 }
                            val thumb = remember(f) { android.graphics.BitmapFactory.decodeFile(f.path, opts)?.asImageBitmap() }
                            if (thumb != null) Image(thumb, contentDescription = null,
                                modifier = Modifier.size(90.dp).border(2.dp, OUT, RoundedCornerShape(8.dp)).clickable { open = f })
                        }
                    }
                }
            }
        }
    }
}

// ------------------------------------------------------------------ furniture: shop, inventory, drawing

internal fun DrawScope.drawHouseItems(pm: PlayerManager, paints: Paints) {
    val nc = drawContext.canvas.nativeCanvas
    // flat things (rugs, paths) first, then the solid pieces from back to front
    val items = pm.house.placed.sortedWith(compareBy({ FurnitureCatalog.byId(it.item)?.solid == true }, { it.y }))
    for (pi in items) {
        val f = FurnitureCatalog.byId(pi.item) ?: continue
        val r = pm.house.rectOf(pi, f)
        if (!drawFurnitureArt(catalogArtKey(f), f.name, r, Color(f.color), pm.time)) roundRectOutlined(r.topLeft, r.size, 12f, Color(f.color), if (f.solid) 4f else 2.5f)
    }
}

@Composable
private fun FurnPreview(f: Furn) {
    Box(Modifier.size(52.dp), contentAlignment = Alignment.Center) {
        Canvas(Modifier.fillMaxSize()) {
            val k = minOf(size.width / f.w, size.height / f.h) * 0.92f
            val w = f.w * k
            val h = f.h * k
            val ox = (size.width - w) / 2f
            val oy = (size.height - h) / 2f
            val rect = androidx.compose.ui.geometry.Rect(ox, oy, ox + w, oy + h)
            if (!drawFurnitureArt(catalogArtKey(f), f.name, rect, Color(f.color), 0f)) roundRectOutlined(Offset(ox, oy), Size(w, h), 8f, Color(f.color), 3f)
        }
    }
}

@Composable
private fun HomeShop(pm: PlayerManager) {
    var tab by remember { mutableStateOf(0) }
    Text("Buy furniture for the whole house! It goes to the shared House Inventory (🏠 button), then you place it.", fontSize = 11.sp, color = OUT)
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
        FurnitureCatalog.ROOMS.forEachIndexed { i, r ->
            Box(
                Modifier.background(if (i == tab) Cozy.Pink else Color.White, RoundedCornerShape(12.dp))
                    .border(2.dp, OUT, RoundedCornerShape(12.dp)).clickable { tab = i }
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) { Text(FurnitureCatalog.ROOM_LABEL[r] ?: r, fontSize = 11.sp, fontWeight = FontWeight.Bold, color = OUT) }
        }
    }
    FurnitureCatalog.ALL.filter { it.room == FurnitureCatalog.ROOMS[tab] }.forEach { f ->
        val p = if (f.stars > 0) f.stars else pm.price(f.price, "home${f.id}")
        val have = if (f.stars > 0) pm.stars else pm.coins
        Row(
            Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(6.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FurnPreview(f)
            Column(Modifier.weight(1f)) {
                Text(f.name, fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT)
                Text(f.cat + when (f.kind) { "sofa" -> " · sit" ; "bed" -> " · sleep"; "lamp" -> " · glows at night"; else -> "" }, fontSize = 10.sp, color = OUT)
            }
            Text(if (f.stars > 0) "$p ⭐" else "$p 🪙", fontSize = 17.sp, fontWeight = FontWeight.ExtraBold, color = OUT)
            Pill(if (have >= p) "Buy" else "Need ${p - have} more!") { pm.buyFurniture(f) }
        }
    }
}

@Composable
private fun InventoryPanel(pm: PlayerManager) {
    Column(
        Modifier.width(430.dp).heightIn(max = 310.dp)
            .background(Color.White.copy(alpha = 0.97f), RoundedCornerShape(20.dp))
            .border(3.dp, OUT, RoundedCornerShape(20.dp)).padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(6.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("🏠 House Inventory (shared)", fontSize = 15.sp, fontWeight = FontWeight.ExtraBold, color = OUT, modifier = Modifier.weight(1f))
            Pill("✕") { pm.panel = null }
        }
        Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text("In storage", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
            val counts = pm.house.inventory.groupingBy { it }.eachCount()
            if (counts.isEmpty()) Text("Empty. Buy furniture at Cozy Home in Town! 🛋️", fontSize = 12.sp, color = OUT)
            counts.forEach { (id, n) ->
                val f = FurnitureCatalog.byId(id) ?: return@forEach
                Row(
                    Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    FurnPreview(f)
                    Text("${f.name} ×$n", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = OUT, modifier = Modifier.weight(1f))
                    Pill("Place near me") { pm.placeFurniture(id) }
                }
            }
            Text("Placed in the house (${pm.house.placed.size})", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = OUT)
            pm.house.placed.reversed().forEach { pi ->
                val f = FurnitureCatalog.byId(pi.item) ?: return@forEach
                Row(
                    Modifier.fillMaxWidth().background(Cozy.Cream, RoundedCornerShape(12.dp)).padding(6.dp),
                    verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("${f.emoji} ${f.name}", fontSize = 12.sp, color = OUT, modifier = Modifier.weight(1f))
                    Pill("Store") { pm.storeFurniture(pi.uid) }
                    if (pm.isHostNow()) Pill("🗑️") { pm.deleteFurniture(pi.uid) }
                }
            }
            Text("Tip: stand where you want it and tap Place. Decorate Mode (drag, rotate, snap) comes next.", fontSize = 10.sp, color = OUT)
        }
    }
}
