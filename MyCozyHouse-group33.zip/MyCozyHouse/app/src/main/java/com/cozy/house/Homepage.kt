package com.cozy.house

import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.withTransform
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.cozy.house.game.Emote
import com.cozy.house.game.HouseSaves
import com.cozy.house.game.Look
import com.cozy.house.game.LocalSave
import com.cozy.house.game.Paints
import com.cozy.house.game.PlayerState
import com.cozy.house.game.drawPlayer
import kotlinx.coroutines.launch

private val BROWN = Color(0xFF6B3F2A)
private val NAVY = Color(0xCC3A4A86)

/** House colours the player picks when building a house. */
class HouseTheme(val label: String, val roof: Color, val wall: Color, val door: Color, val garden: Boolean = false)

val HOUSE_THEMES = listOf(
    HouseTheme("Pink", Color(0xFFE9809F), Color(0xFFFFB9CB), Color(0xFFFFD6E0)),
    HouseTheme("Garden", Color(0xFF79B955), Color(0xFFFFF0D2), Color(0xFF8CCB6A), garden = true),
    HouseTheme("Blue", Color(0xFF4F80D8), Color(0xFFC3DBF6), Color(0xFF5B8FE0)),
    HouseTheme("Sunny", Color(0xFFF2A93B), Color(0xFFFFEDB5), Color(0xFFFFC857)),
    HouseTheme("Lavender", Color(0xFF9B7FD9), Color(0xFFE6DAFB), Color(0xFFB89BEA)),
)

/** The girl from the picture: long black hair, pink beanie, pink hoodie. */
private fun mascotLook() = Look(
    eyes = 2, brows = 5, blush = 1, hair = 0, hairColor = 0xFF1E1B26.toInt(),
    outfit = 1, outfitColor = 0xFFFF9EC4.toInt(), hat = 2, eyeColor = 0xFF4A3428.toInt()
)

private fun myLook(ctx: android.content.Context): Look =
    LocalSave.load(ctx).optString("look").takeIf { it.isNotEmpty() }?.let { Look.decode(it) } ?: mascotLook()

// ------------------------------------------------------------------ the house, seen from outside

private fun DrawScope.drawHouseScene(th: HouseTheme, t: Float, pv: PlayerState, paints: Paints) {
    val w = size.width
    val h = size.height
    val u = minOf(0.74f * h, w / 1.5f)
    val x0 = (w - 1.5f * u) / 2f
    val y0 = 0.07f * h
    fun X(v: Float) = x0 + v * u
    fun Y(v: Float) = y0 + v * u
    val lw = (u * 0.007f).coerceAtLeast(3f)

    fun box(x: Float, y: Float, bw: Float, bh: Float, r: Float, c: Color) {
        drawRoundRect(c, Offset(X(x), Y(y)), Size(bw * u, bh * u), CornerRadius(r * u))
        drawRoundRect(BROWN, Offset(X(x), Y(y)), Size(bw * u, bh * u), CornerRadius(r * u), style = Stroke(lw))
    }
    fun ball(cx: Float, cy: Float, r: Float, c: Color) {
        drawCircle(c, r * u, Offset(X(cx), Y(cy)))
        drawCircle(BROWN, r * u, Offset(X(cx), Y(cy)), style = Stroke(lw * 0.8f))
    }

    // sky, clouds, hills, grass
    drawRect(Brush.verticalGradient(listOf(Color(0xFF8ED0F7), Color(0xFFE2F4FF)), 0f, h * 0.65f), size = Size(w, h * 0.65f))
    for ((cx, cy, s) in listOf(Triple(0.2f, 0.16f, 1f), Triple(1.25f, 0.12f, 1.2f))) {
        val a = (t * 0.01f) % 0.05f
        for (k in listOf(-0.07f to 0f, 0f to -0.03f, 0.07f to 0f)) {
            drawCircle(Color.White, 0.05f * s * u, Offset(X(cx + k.first + a), Y(cy + k.second)))
        }
    }
    drawCircle(Color(0xFFB8E48F), 0.55f * u, Offset(X(0.15f), Y(0.95f)))
    drawCircle(Color(0xFFA8DC7E), 0.6f * u, Offset(X(1.35f), Y(1.0f)))
    drawRect(Brush.verticalGradient(listOf(Color(0xFF9AD66A), Color(0xFF74BC4C)), Y(0.64f), h),
        Offset(0f, Y(0.64f)), Size(w, h - Y(0.64f)))

    // trees
    for (tx in listOf(0.04f, 1.46f)) {
        drawRoundRect(Color(0xFF9C6B3E), Offset(X(tx) - 0.02f * u, Y(0.45f)), Size(0.04f * u, 0.25f * u), CornerRadius(8f))
        for ((dx, dy, r) in listOf(Triple(0f, 0.35f, 0.14f), Triple(-0.09f, 0.42f, 0.1f), Triple(0.09f, 0.42f, 0.1f))) {
            drawCircle(Color(0xFF7DC15A), r * u, Offset(X(tx + dx), Y(dy)))
            drawCircle(Color(0xFF4C8F3A), r * u, Offset(X(tx + dx), Y(dy)), style = Stroke(lw * 0.8f))
        }
    }

    // chimney + smoke (behind the roof)
    box(1.0f, 0.15f, 0.07f, 0.17f, 0.01f, Color(0xFFB07A5A))
    for (i in 0..2) {
        val ph = (t * 0.35f + i / 3f) % 1f
        drawCircle(Color.White.copy(alpha = (1f - ph) * 0.8f), (0.016f + 0.02f * ph) * u, Offset(X(1.035f + ph * 0.04f), Y(0.14f - ph * 0.12f)))
    }

    // walls
    box(0.4f, 0.44f, 0.7f, 0.26f, 0.015f, th.wall)

    // roof
    val roofFull = Path().apply {
        moveTo(X(0.3f), Y(0.48f)); lineTo(X(0.75f), Y(0.11f)); lineTo(X(1.2f), Y(0.48f)); close()
    }
    drawPath(roofFull, th.roof)
    drawPath(roofFull, Color.Black.copy(alpha = 0.06f))
    for (k in 1..5) {   // shingle rows
        val yy = 0.11f + 0.07f * k
        val half = (yy - 0.11f) / 0.37f * 0.45f
        drawLine(Color.Black.copy(alpha = 0.18f), Offset(X(0.75f - half + 0.02f), Y(yy)), Offset(X(0.75f + half - 0.02f), Y(yy)), lw * 0.7f)
    }
    drawPath(roofFull, BROWN, style = Stroke(lw * 1.2f, join = StrokeJoin.Round))

    // attic window
    ball(0.75f, 0.31f, 0.045f, Color(0xFFCFEFFF))
    drawLine(BROWN, Offset(X(0.705f), Y(0.31f)), Offset(X(0.795f), Y(0.31f)), lw * 0.7f)
    drawLine(BROWN, Offset(X(0.75f), Y(0.265f)), Offset(X(0.75f), Y(0.355f)), lw * 0.7f)

    // windows with flower boxes
    for (wx in listOf(0.47f, 0.87f)) {
        box(wx, 0.5f, 0.16f, 0.13f, 0.01f, Color(0xFFCFEFFF))
        drawLine(BROWN, Offset(X(wx + 0.08f), Y(0.5f)), Offset(X(wx + 0.08f), Y(0.63f)), lw * 0.8f)
        drawLine(BROWN, Offset(X(wx), Y(0.565f)), Offset(X(wx + 0.16f), Y(0.565f)), lw * 0.8f)
        box(wx - 0.01f, 0.63f, 0.18f, 0.04f, 0.008f, Color(0xFFC98B5B))
        val fc = listOf(Color(0xFFFF8FB5), Color(0xFFFFE066), Color(0xFFFFFFFF), Color(0xFFB69CFF))
        for (k in 0..5) drawCircle(fc[k % 4], 0.014f * u, Offset(X(wx + 0.01f + k * 0.03f), Y(0.622f)))
    }

    // door with arch, wreath and knob
    val door = Path().apply {
        moveTo(X(0.69f), Y(0.7f)); lineTo(X(0.69f), Y(0.56f))
        arcTo(androidx.compose.ui.geometry.Rect(X(0.69f), Y(0.5f), X(0.81f), Y(0.62f)), 180f, 180f, false)
        lineTo(X(0.81f), Y(0.7f)); close()
    }
    drawPath(door, th.door)
    drawPath(door, BROWN, style = Stroke(lw, join = StrokeJoin.Round))
    drawCircle(Color(0xFFFFD25A), 0.01f * u, Offset(X(0.79f), Y(0.62f)))
    drawCircle(Color(0xFF6FBF4F), 0.028f * u, Offset(X(0.75f), Y(0.57f)), style = Stroke(0.012f * u))
    drawCircle(Color(0xFFFF8FB5), 0.008f * u, Offset(X(0.735f), Y(0.56f)))
    drawCircle(Color(0xFFFFE066), 0.008f * u, Offset(X(0.765f), Y(0.58f)))
    box(0.66f, 0.7f, 0.18f, 0.015f, 0.005f, Color(0xFFD9D2C3))

    // garden-house pots
    if (th.garden) {
        for (px in listOf(0.56f, 0.94f)) {
            for (k in 0..2) {
                val cx = px + k * 0.05f
                drawCircle(Color(0xFF5FB04A), 0.025f * u, Offset(X(cx), Y(0.67f)))
                box(cx - 0.02f, 0.69f, 0.04f, 0.035f, 0.006f, Color(0xFFD98A5A))
            }
        }
    }

    // stone path
    for (k in 0..3) {
        val cy = 0.75f + k * 0.05f
        drawOval(Color(0xFFDCD5C6), Offset(X(0.75f - 0.05f - k * 0.008f), Y(cy)), Size((0.1f + k * 0.016f) * u, 0.035f * u))
        drawOval(BROWN.copy(alpha = 0.5f), Offset(X(0.75f - 0.05f - k * 0.008f), Y(cy)), Size((0.1f + k * 0.016f) * u, 0.035f * u), style = Stroke(lw * 0.5f))
    }

    // white fence on both sides
    for (side in 0..1) {
        val start = if (side == 0) 0.04f else 1.14f
        val n = 9
        for (k in 0 until n) {
            val fx = start + k * 0.04f
            box(fx, 0.62f, 0.03f, 0.11f, 0.008f, Color(0xFFFFF6E4))
        }
        drawLine(BROWN, Offset(X(start), Y(0.66f)), Offset(X(start + n * 0.04f), Y(0.66f)), lw * 0.7f)
    }

    // flowers all over the grass
    val rnd = kotlin.random.Random(5)
    val cols = listOf(Color(0xFFFF8FB5), Color(0xFFFFE066), Color(0xFFB69CFF), Color(0xFFFFFFFF), Color(0xFFFFA45C), Color(0xFFFF6F91))
    repeat(70) {
        val fx = rnd.nextFloat() * w
        val fy = Y(0.7f) + rnd.nextFloat() * (h - Y(0.7f))
        val r = (0.01f + 0.014f * ((fy - Y(0.7f)) / (h - Y(0.7f)))) * u
        drawCircle(Color(0xFF4C9F3A), r * 0.7f, Offset(fx, fy + r))
        drawCircle(cols[it % cols.size], r, Offset(fx, fy))
        drawCircle(Color(0xFFFFE9A8), r * 0.4f, Offset(fx, fy))
    }

    // the character, in front of the house, waving
    pv.animT = t
    pv.emote = Emote.WAVE
    pv.emoteT = 0.5f + t
    val sc = u * 0.0042f
    withTransform({ translate(X(0.75f), Y(0.8f)); scale(sc, sc, Offset.Zero) }) {
        drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
    }
}

@Composable
fun HouseScene(theme: Int, look: Look, time: State<Float>, modifier: Modifier = Modifier) {
    val paints = remember { Paints() }
    val pv = remember { PlayerState("home", "", 0) }
    pv.updateLook(look)
    val th = HOUSE_THEMES[theme.coerceIn(0, HOUSE_THEMES.lastIndex)]
    Canvas(modifier) { drawHouseScene(th, time.value, pv, paints) }
}

// ------------------------------------------------------------------ homepage

@Composable
private fun OutlinedText(text: String, size: TextUnit, fill: Color, stroke: Color, width: Float = 12f) {
    Box {
        Text(text, fontSize = size, fontWeight = FontWeight.Black, textAlign = TextAlign.Center,
            style = TextStyle(color = stroke, drawStyle = Stroke(width = width, join = StrokeJoin.Round)))
        Text(text, fontSize = size, fontWeight = FontWeight.Black, textAlign = TextAlign.Center, color = fill)
    }
}

@Composable
private fun RoundArrow(label: String, onClick: () -> Unit) {
    Box(
        Modifier.size(46.dp).clip(CircleShape).background(Color.White.copy(alpha = 0.18f))
            .border(3.dp, Color.White.copy(alpha = 0.8f), CircleShape).clickable { onClick() },
        contentAlignment = Alignment.Center
    ) { Text(label, fontSize = 22.sp, fontWeight = FontWeight.Black, color = Color.White) }
}

@Composable
private fun BottomButton(icon: String, label: String, modifier: Modifier, onClick: () -> Unit) {
    Column(
        modifier.height(54.dp).background(Color(0x993A4A86), RoundedCornerShape(16.dp))
            .border(2.dp, Color.White.copy(alpha = 0.45f), RoundedCornerShape(16.dp)).clickable { onClick() },
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center
    ) {
        Text(icon, fontSize = 20.sp)
        Text(label, fontSize = 11.sp, fontWeight = FontWeight.ExtraBold, color = Color.White)
    }
}

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun HomeScreen(notice: String?, onPlay: (HouseSaves.Info) -> Unit, onPick: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var houses by remember { mutableStateOf(HouseSaves.list(ctx)) }
    val look = remember { myLook(ctx) }
    var askDelete by remember { mutableStateOf(false) }

    val first = remember { HouseSaves.lastPlayed(ctx)?.let { l -> houses.indexOfFirst { it.id == l.id } }?.coerceAtLeast(0) ?: 0 }
    val pager = rememberPagerState(initialPage = first, pageCount = { maxOf(1, houses.size) })
    val time = rememberInfiniteTransition(label = "t").animateFloat(
        0f, 600f, infiniteRepeatable(tween(600_000, easing = LinearEasing), RepeatMode.Restart), label = "t"
    )
    val cur = houses.getOrNull(pager.currentPage)

    Box(Modifier.fillMaxSize()) {
        HorizontalPager(pager, Modifier.fillMaxSize()) { page ->
            HouseScene(houses.getOrNull(page)?.theme ?: 0, look, time, Modifier.fillMaxSize())
        }

        // top bar: logo + my character
        Row(
            Modifier.align(Alignment.TopCenter).fillMaxWidth().padding(10.dp)
                .background(NAVY, RoundedCornerShape(22.dp)).border(2.dp, Color.White.copy(alpha = 0.4f), RoundedCornerShape(22.dp))
                .padding(horizontal = 14.dp, vertical = 6.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text("🏠 My Cozy House 🏡", fontSize = 20.sp, fontWeight = FontWeight.ExtraBold, color = Color.White, modifier = Modifier.weight(1f))
            AvatarBadge(look)
        }
        if (notice != null) {
            Text(notice, Modifier.align(Alignment.TopCenter).padding(top = 70.dp).background(Color.White.copy(alpha = 0.9f), RoundedCornerShape(12.dp)).padding(8.dp),
                fontSize = 13.sp, color = Cozy.Error, textAlign = TextAlign.Center)
        }

        // bottom panel
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().padding(horizontal = 10.dp, vertical = 8.dp)
                .background(NAVY, RoundedCornerShape(26.dp)).border(2.dp, Color.White.copy(alpha = 0.35f), RoundedCornerShape(26.dp))
                .padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                if (houses.size > 1) RoundArrow("‹") { scope.launch { pager.animateScrollToPage((pager.currentPage - 1 + houses.size) % houses.size) } }
                else Spacer(Modifier.size(46.dp))
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    if (cur != null) {
                        OutlinedText(cur.name, 26.sp, Color.White, Color(0xFFE9709A))
                        Box(
                            Modifier.padding(top = 2.dp)
                                .background(Brush.verticalGradient(listOf(Color(0xFFFF9DB4), Color(0xFFF2587A))), RoundedCornerShape(26.dp))
                                .border(3.dp, Color(0xFFFFC0D0), RoundedCornerShape(26.dp)).clickable { onPlay(cur) }
                                .padding(horizontal = 44.dp, vertical = 6.dp)
                        ) {
                            Text("▶ PLAY", fontSize = 24.sp, fontWeight = FontWeight.Black, color = Color.White,
                                style = TextStyle(shadow = Shadow(BROWN, Offset(2f, 3f), 4f)))
                        }
                    } else {
                        OutlinedText("Build your first house!", 22.sp, Color.White, Color(0xFFE9709A))
                        Box(
                            Modifier.padding(top = 2.dp)
                                .background(Brush.verticalGradient(listOf(Color(0xFFFF9DB4), Color(0xFFF2587A))), RoundedCornerShape(26.dp))
                                .border(3.dp, Color(0xFFFFC0D0), RoundedCornerShape(26.dp)).clickable { onPick(Screen.CREATE) }
                                .padding(horizontal = 30.dp, vertical = 6.dp)
                        ) { Text("🔨 CREATE HOUSE", fontSize = 20.sp, fontWeight = FontWeight.Black, color = Color.White) }
                    }
                }
                if (houses.size > 1) RoundArrow("›") { scope.launch { pager.animateScrollToPage((pager.currentPage + 1) % houses.size) } }
                else Spacer(Modifier.size(46.dp))
            }
            if (houses.size > 1) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp), verticalAlignment = Alignment.CenterVertically) {
                    houses.forEachIndexed { i, _ ->
                        Box(Modifier.size(10.dp).clip(CircleShape)
                            .background(if (i == pager.currentPage) Color(0xFFFF6FA0) else Color.Transparent)
                            .border(2.dp, if (i == pager.currentPage) Color(0xFFFF6FA0) else Color.White.copy(alpha = 0.8f), CircleShape))
                    }
                }
                Text("Swipe to see next house", fontSize = 11.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            if (cur != null) {
                Text("Day ${cur.day} · ${cur.furniture} furniture · tap here to delete this house 🗑️", fontSize = 10.sp, color = Color.White.copy(alpha = 0.8f),
                    modifier = Modifier.clickable { askDelete = true })
            }
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                BottomButton("🔨", "CREATE HOUSE", Modifier.weight(1f)) { onPick(Screen.CREATE) }
                BottomButton("👥", "JOIN HOUSE", Modifier.weight(1f)) { onPick(Screen.JOIN) }
                BottomButton("📖", "HOW TO PLAY", Modifier.weight(1f)) { onPick(Screen.HOW) }
                BottomButton("⚙️", "SETTINGS", Modifier.weight(1f)) { onPick(Screen.SETTINGS) }
            }
        }
    }

    if (askDelete && cur != null) {
        AlertDialog(
            onDismissRequest = { askDelete = false },
            title = { Text("Delete ${cur.name}?") },
            text = { Text("The whole house is removed from this phone. This can't be undone.") },
            confirmButton = {
                TextButton(onClick = { HouseSaves.delete(ctx, cur.id); houses = HouseSaves.list(ctx); askDelete = false }) { Text("Delete", color = Cozy.Error) }
            },
            dismissButton = { TextButton(onClick = { askDelete = false }) { Text("Keep it") } }
        )
    }
}

/** Round avatar picture for the top bar. */
@Composable
private fun AvatarBadge(look: Look) {
    val paints = remember { Paints() }
    val pv = remember { PlayerState("badge", "", 0) }
    pv.updateLook(look)
    Canvas(Modifier.size(44.dp).clip(CircleShape).background(Color(0xFFFFC2D6)).border(3.dp, Color.White, CircleShape)) {
        val sc = size.height / 62f
        withTransform({ translate(size.width / 2f, size.height * 1.12f); scale(sc, sc, Offset.Zero) }) {
            drawPlayer(pv, false, false, paints, 0f, 0f, false, false)
        }
    }
}
