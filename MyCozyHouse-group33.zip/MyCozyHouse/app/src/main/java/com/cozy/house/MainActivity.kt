package com.cozy.house

import android.Manifest
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.Image
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.unit.TextUnit
import com.cozy.house.game.GameScreen
import com.cozy.house.game.HouseSaves

enum class Screen { MENU, CREATE, JOIN, HOW, SETTINGS, HOST_LOBBY, CLIENT_LOBBY, GAME }

class MainActivity : ComponentActivity() {

    private val permLauncher =
        registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        askNetworkPermissions()
        setContent {
            MaterialTheme(colorScheme = lightColorScheme(primary = Cozy.Pink, background = Cozy.Cream)) {
                CozyApp()
            }
        }
    }

    /** Only what LAN needs now. Mic / camera / photos are asked later, when the feature is used. */
    private fun askNetworkPermissions() {
        val p = mutableListOf(Manifest.permission.ACCESS_FINE_LOCATION)
        if (Build.VERSION.SDK_INT >= 33) p += Manifest.permission.NEARBY_WIFI_DEVICES
        permLauncher.launch(p.toTypedArray())
    }
}

@Composable
fun CozyApp() {
    var screen by rememberSaveable { mutableStateOf(Screen.MENU) }
    var notice by remember { mutableStateOf<String?>(null) }
    val ctx = LocalContext.current

    val exit: (String?) -> Unit = { msg -> notice = msg; screen = Screen.MENU }
    val inSession = screen == Screen.HOST_LOBBY || screen == Screen.CLIENT_LOBBY || screen == Screen.GAME

    // If the app was restarted by Android, there is no live session: go back to the menu.
    LaunchedEffect(screen) { if (inSession && !Session.active) screen = Screen.MENU }

    BackHandler(enabled = screen in listOf(Screen.CREATE, Screen.JOIN, Screen.HOW, Screen.SETTINGS)) {
        screen = Screen.MENU
    }

    Box(Modifier.fillMaxSize().background(Cozy.Cream).systemBarsPadding()) {
        when (screen) {
            Screen.MENU -> HomeScreen(
                notice,
                onPlay = { h ->
                    val err = startHost(ctx, h.id, h.name, savedPlayerName(ctx))
                    if (err == null) { notice = null; screen = Screen.HOST_LOBBY } else notice = err
                }
            ) { notice = null; screen = it }
            Screen.CREATE -> CreateHouseScreen(onCreated = { screen = Screen.HOST_LOBBY }, onBack = { screen = Screen.MENU })
            Screen.JOIN -> JoinHouseScreen(onJoined = { screen = Screen.CLIENT_LOBBY }, onBack = { screen = Screen.MENU })
            Screen.HOST_LOBBY -> HostLobbyScreen(onStart = { screen = Screen.GAME }, onExit = exit)
            Screen.CLIENT_LOBBY -> ClientLobbyScreen(onExit = exit)
            Screen.GAME -> GameScreen(onExit = exit)
            Screen.HOW -> InfoScreen(
                "How to Play",
                "1. One friend taps CREATE HOUSE.\n" +
                "2. Everyone else joins the same WiFi or phone hotspot and taps JOIN HOUSE.\n" +
                "3. No internet needed!\n" +
                "4. Farm, cook, play and decorate together."
            ) { screen = Screen.MENU }
            Screen.SETTINGS -> InfoScreen("Settings", "Sound, music and language come later.") { screen = Screen.MENU }
        }

        val client = Session.client
        if (client != null && (screen == Screen.CLIENT_LOBBY || screen == Screen.GAME)) {
            ClientEffects(client, screen, setScreen = { screen = it }, onExit = exit)
        }
    }
}

@Composable
fun CozyButton(label: String, color: Color, onClick: () -> Unit) {
    Button(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth().height(56.dp),
        shape = RoundedCornerShape(28.dp),
        border = BorderStroke(3.dp, Cozy.Outline),
        colors = ButtonDefaults.buttonColors(containerColor = color, contentColor = Cozy.Outline)
    ) { Text(label, fontSize = 18.sp, fontWeight = FontWeight.Bold) }
}

@Composable
private fun InfoScreen(title: String, body: String, onBack: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Text(title, fontSize = 28.sp, fontWeight = FontWeight.ExtraBold, color = Cozy.Outline)
        Text(body, fontSize = 18.sp, color = Cozy.Outline)
        CozyButton("BACK", Cozy.Pink, onBack)
    }
}
